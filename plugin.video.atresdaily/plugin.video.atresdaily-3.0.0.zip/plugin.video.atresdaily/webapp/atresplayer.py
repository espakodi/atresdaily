"""Cliente HTTP directo al API de Atresplayer. Replica las llamadas que hace el connector
sin pasar por xbmcplugin ni mostrar diálogos en Kodi. Thread-safe."""

import difflib
import re
import threading
import time
import urllib.parse
import requests

_BBCODE_RE = re.compile(r'\[/?[A-Za-z][A-Za-z0-9=/ #]*\]')


def strip_bbcode(s):
    """Elimina etiquetas BBCode de Kodi: [COLOR blue], [B], [/COLOR], etc."""
    if not s:
        return s
    return _BBCODE_RE.sub('', s).strip()

API_BASE = "https://api.atresplayer.com"
MAIN_CH_ID = "5a6b32667ed1a834493ec03b"

CATS = [
    ("Series",       "5a6a1b22986b281d18a512b8"),
    ("Programas",    "5a6a1ba0986b281d18a512b9"),
    ("Documentales", "5b067bf3986b28b0a27c2f42"),
    ("Infantil",     "5a6a24b1986b281d18a512c0"),
    ("Actualidad",   "5a6a215e986b281d18a512bc"),
    ("Cine",         "5b5f2f777ed1a86860102144"),
    ("Extra",        "605b306f7ed1a86f42397281"),
]

CHANNELS = [
    {"id": "5a6a165a7ed1a834493ebf6a", "name": "Antena 3"},
    {"id": "5a6a172c7ed1a834493ebf6b", "name": "laSexta"},
    {"id": "5a6a17da7ed1a834493ebf6d", "name": "Neox"},
    {"id": "5a6a180b7ed1a834493ebf6e", "name": "Nova"},
    {"id": "5a6a18357ed1a834493ebf6f", "name": "Mega"},
    {"id": "5a6a189a7ed1a834493ebf70", "name": "Atreseries"},
]

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Origin": "https://www.atresplayer.com",
    "Referer": "https://www.atresplayer.com/",
}

_DM_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36",
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

_session = requests.Session()
_session.headers.update(_HEADERS)

# --- Caché simple en memoria ---
_cache = {}
_CACHE_TTL = 600  # 10 min


def _cached(key, fn, ttl=_CACHE_TTL):
    now = time.time()
    entry = _cache.get(key)
    if entry and (now - entry[1]) < ttl:
        return entry[0]
    val = fn()
    _cache[key] = (val, now)
    return val


def _fix_img(url):
    """Convierte un path relativo/protocolo-relativo a URL absoluta.
    Replica ui_utils.fix_img — misma lógica que usa el connector en Kodi."""
    if not url:
        return ""
    if url.startswith("//"):
        url = "https:" + url
    elif url.startswith("/"):
        url = "https://www.atresplayer.com" + url
    if url.endswith("/"):
        url += "1280x720.jpg"
    return url


# --- Catálogo: secciones ---

def get_category_items(cat_id, page=0, size=50):
    """Items de una categoría (Series/Programas/etc). Devuelve lista de dicts normalizados."""
    def fetch():
        params = {
            "entityType": "ATPFormat",
            "sectionCategory": "true",
            "mainChannelId": MAIN_CH_ID,
            "categoryId": cat_id,
            "sortType": "THE_MOST",
            "size": size,
            "page": page,
        }
        try:
            r = _session.get(f"{API_BASE}/client/v1/row/search", params=params, timeout=15)
            if r.status_code != 200:
                return []
            return r.json().get("itemRows", [])
        except Exception:
            return []
    return _cached(f"cat_{cat_id}_{page}_{size}", fetch, ttl=1800)


def get_catalog_overview():
    """Devuelve un resumen del catálogo: por sección, los primeros N items.
    NO usa connector._fetch_all_catalog (que muestra DialogProgress)."""
    overview = []
    for name, cid in CATS:
        items = get_category_items(cid, page=0, size=20)
        overview.append({"name": name, "id": cid, "items": items})
    return overview


# --- Detalles de un programa/serie ---

def get_details(url):
    """Recupera info de un programa: temporadas, episodios o subitems."""
    def fetch():
        try:
            r = _session.get(url, timeout=15)
            if r.status_code != 200:
                return {}
            return r.json()
        except Exception:
            return {}
    return _cached(f"details_{url}", fetch, ttl=600)


def get_episodes(url):
    """Lista de episodios de una temporada/programa."""
    def fetch():
        try:
            r = _session.get(url, timeout=15)
            if r.status_code != 200:
                return []
            return r.json().get("itemRows", [])
        except Exception:
            return []
    return _cached(f"eps_{url}", fetch, ttl=600)


# --- Directos ---

def get_live_channels():
    """Lista de canales en directo con logos del API de Atresplayer.
    Intenta obtener los logos directamente del endpoint /directos/ (mismo
    método que usa el connector) y cae a Wikipedia solo si falla."""
    def fetch():
        # Mapa logo del API: id → url
        api_logos = _fetch_live_logos()

        result = list(CHANNELS)
        # Enriquecer con logos del API
        for ch in result:
            if ch["id"] in api_logos:
                ch["logo"] = api_logos[ch["id"]]

        # Añadir canales nuevos descubiertos por API
        try:
            r = _session.get(f"{API_BASE}/client/v1/info/channels", timeout=8)
            if r.status_code == 200:
                existing = {x["id"] for x in result}
                for c in r.json():
                    cid = c.get("id")
                    name = (c.get("name") or "").strip()
                    if cid in existing:
                        continue
                    if not name:
                        name = (c.get("link", {}).get("url", "") or "").split('/')[-1].replace('-', ' ').title()
                    if any(b in name.lower() for b in ["flooxer", "kidz", "vix", "onda", "canal 5", "5a6"]):
                        continue
                    if name:
                        entry = {"id": cid, "name": name}
                        if cid in api_logos:
                            entry["logo"] = api_logos[cid]
                        result.append(entry)
        except Exception:
            pass
        return result
    return _cached("live_channels", fetch, ttl=3600)


def _fetch_live_logos():
    """Obtiene logos de canales del endpoint /directos/ del API de Atresplayer.
    Devuelve dict {ch_id: logo_url}. Nunca lanza excepción."""
    logos = {}
    try:
        r = _session.get(f"{API_BASE}/client/v1/url", params={"href": "/directos/"}, timeout=10)
        if r.status_code != 200:
            return logos
        data = r.json()
        # Navegar al rowLive si existe
        row_url = data.get("rowLive")
        if not row_url and data.get("redirect"):
            href = data.get("href") or data.get("url")
            if href:
                r2 = _session.get(f"{API_BASE}/client/v1/url", params={"href": href}, timeout=10)
                if r2.status_code == 200:
                    data = r2.json()
                    row_url = data.get("rowLive")
        if not row_url:
            nodes = data.get("nodes") or data.get("itemRows") or []
            for n in nodes:
                if n.get("type") == "LIVE" and n.get("href"):
                    row_url = n["href"]
                    break
        if row_url:
            rr = _session.get(row_url, timeout=10)
            items = rr.json().get("itemRows") or rr.json().get("items") or []
        else:
            items = data.get("nodes") or data.get("itemRows") or []

        for item in items:
            ch_id = item.get("mainChannel") or item.get("contentId")
            link = item.get("link") or {}
            href = link.get("href", "")
            if not ch_id and "/" in href:
                ch_id = href.rstrip("/").split("/")[-1]
            if not ch_id:
                continue
            img_data = item.get("image") or item.get("images") or {}
            img = img_data.get("pathHorizontal") or img_data.get("pathVertical")
            if img:
                logos[ch_id] = _fix_img(img)
    except Exception:
        pass
    return logos


CH_LOGOS = {
    "5a6a165a7ed1a834493ebf6a": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Antena_3_2025_%28sin_wordmark%29.svg/330px-Antena_3_2025_%28sin_wordmark%29.svg.png",
    "5a6a172c7ed1a834493ebf6b": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/LaSexta_2024_Logo.svg/330px-LaSexta_2024_Logo.svg.png",
    "5a6a17da7ed1a834493ebf6d": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Neox_2023_logo.svg/330px-Neox_2023_logo.svg.png",
    "5a6a180b7ed1a834493ebf6e": "https://upload.wikimedia.org/wikipedia/commons/d/d5/Nova_TV.png",
    "5a6a18357ed1a834493ebf6f": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/MEGA.svg/330px-MEGA.svg.png",
    "5a6a189a7ed1a834493ebf70": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Atreseries_2020_logo.svg/330px-Atreseries_2020_logo.svg.png",
}


def get_channel_logo(ch_id):
    """Devuelve el logo del canal. Prioriza los obtenidos del API de Atresplayer
    (ya incluidos en el dict al llamar a get_live_channels) sobre Wikipedia."""
    # Buscar en los canales ya cargados (pueden llevar el campo logo del API)
    channels = _cache.get("live_channels")
    if channels:
        for ch in channels[0]:  # channels[0] es el valor; channels[1] es el timestamp
            if ch.get("id") == ch_id and ch.get("logo"):
                return ch["logo"]
    # Fallback a Wikipedia
    return CH_LOGOS.get(ch_id, "")


# --- Resolución de streams ---

def resolve_live(ch_id):
    """Devuelve (stream_url, headers) o (None, None) si falla."""
    url = f"{API_BASE}/player/v1/live/{ch_id}?NODRM=true"
    try:
        r = _session.get(url, timeout=10)
        if r.status_code != 200:
            return None, None
        for src in r.json().get("sourcesLive", []):
            if "mpegurl" in (src.get("type") or "").lower():
                return src["src"], dict(_HEADERS)
    except Exception:
        pass
    return None, None


def resolve_episode(vid):
    """Resuelve un episodio de Atresplayer. Devuelve (stream_url, headers) o (None, None)."""
    url = f"{API_BASE}/player/v1/episode/{vid}?NODRM=true"
    try:
        h = dict(_HEADERS)
        h["Referer"] = "https://www.atresplayer.com/"
        r = _session.get(url, headers=h, timeout=10)
        if r.status_code != 200:
            return None, None
        for src in r.json().get("sources", []):
            if "mpegurl" in (src.get("type") or "").lower():
                return src["src"], dict(_HEADERS)
    except Exception:
        pass
    return None, None


# --- Búsqueda en catálogo Atresplayer ---

def search_catalog(q, max_results=15):
    """Busca en el catálogo Atresplayer fetcheando 1 página por categoría en paralelo
    y haciendo fuzzy match con difflib. Devuelve lista de (score, dict_normalizado)."""
    if not q:
        return []
    ql = q.lower().strip()
    cache_key = f"atp_search_{ql}_{max_results}"
    cached = _cache.get(cache_key)
    if cached and (time.time() - cached[1]) < 300:
        return cached[0]

    all_rows = []
    lock = threading.Lock()

    def fetch_cat(cat_name, cid):
        params = {
            "entityType": "ATPFormat",
            "sectionCategory": "true",
            "mainChannelId": MAIN_CH_ID,
            "categoryId": cid,
            "sortType": "THE_MOST",
            "size": 50,
            "page": 0,
        }
        try:
            r = _session.get(f"{API_BASE}/client/v1/row/search", params=params, timeout=7)
            if r.status_code == 200:
                rows = r.json().get("itemRows", [])
                with lock:
                    all_rows.extend((cat_name, row) for row in rows)
        except Exception:
            pass

    threads = [threading.Thread(target=fetch_cat, args=(name, cid), daemon=True)
               for name, cid in CATS]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=8)

    matched = []
    seen_urls = set()
    for cat_name, item in all_rows:
        title = item.get("title", "")
        if not title:
            continue
        tl = title.lower()
        score = (0.95 + (len(ql) / max(len(tl), 1)) * 0.05) if ql in tl else difflib.SequenceMatcher(None, ql, tl).ratio()
        if score <= 0.3:
            continue
        link = (item.get("link") or {}).get("href", "")
        if not link or link in seen_urls:
            continue
        seen_urls.add(link)
        norm = normalize_catalog_row(item)
        norm["category"] = cat_name
        matched.append((score, norm))

    matched.sort(key=lambda x: x[0], reverse=True)
    result = matched[:max_results]
    _cache[cache_key] = (result, time.time())
    return result


# --- Búsqueda en Dailymotion (catálogo asociado) ---

def search_dailymotion(q, limit=50):
    """Búsqueda directa contra api.dailymotion.com. Devuelve lista de videos."""
    if not q:
        return []
    def fetch():
        params = {
            "search": q,
            "fields": "id,title,thumbnail_720_url,thumbnail_480_url,duration,owner.screenname,owner.username,created_time,views_total",
            "limit": limit,
        }
        try:
            r = requests.get("https://api.dailymotion.com/videos", params=params,
                             headers={"User-Agent": _HEADERS["User-Agent"]}, timeout=10)
            if r.status_code != 200:
                return []
            return r.json().get("list", [])
        except Exception:
            return []
    return _cached(f"dm_search_{q}_{limit}", fetch, ttl=300)


def score_dm_results(q, videos):
    """Puntúa y ordena resultados DM por similitud con q. Replica _gsr de connector.py."""
    if not videos:
        return []
    scored = []
    ql = q.lower().strip()
    qn = re.findall(r'(\d+)', ql)
    q_words = [w for w in ql.replace('-', ' ').replace('.', ' ').split() if len(w) > 2]

    for v in videos:
        t = v.get("title", "").strip()
        tl = t.lower()
        if not t:
            continue
        s = difflib.SequenceMatcher(None, ql, tl).ratio()
        if q_words:
            if q_words[0] not in tl:
                s -= 0.6
            found_words = sum(1 for w in q_words if w in tl)
            if found_words < len(q_words):
                s -= 0.1 * (len(q_words) - found_words)
        if ql in tl:
            s += 0.5
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            try:
                qn_ints = [int(x) for x in qn]
                tn_ints = [int(x) for x in tn]
                if set(qn_ints).issubset(set(tn_ints)):
                    s += 2.0
                elif qn:
                    s -= 0.5
            except Exception:
                pass
        du = int(v.get("duration", 0) or 0)
        if s > 0.4:
            if du > 600:
                s += 0.3
            elif du > 300:
                s += 0.1
            if du < 60:
                s -= 0.2
        scored.append((s, v))

    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:25]


# --- Lookup de thumb de Dailymotion por vid ---

def get_dm_thumb(vid):
    """Devuelve la URL del thumbnail de un vídeo de Dailymotion. Cacheado."""
    if not vid:
        return ''
    def fetch():
        try:
            r = requests.get(
                f"https://api.dailymotion.com/video/{vid}",
                params={"fields": "thumbnail_720_url,thumbnail_480_url,thumbnail_240_url"},
                headers={"User-Agent": _HEADERS["User-Agent"]},
                timeout=8,
            )
            if r.status_code != 200:
                return ''
            j = r.json()
            return j.get("thumbnail_720_url") or j.get("thumbnail_480_url") or j.get("thumbnail_240_url") or ''
        except Exception:
            return ''
    return _cached(f"dm_thumb_{vid}", fetch, ttl=86400)


# --- Helpers para normalización ---

def normalize_catalog_row(row):
    """Convierte un row de Atresplayer (programa/serie) a un item normalizado."""
    title = row.get("title", "Sin título")
    link = (row.get("link") or {}).get("href", "")
    desc = row.get("description", "")
    img = (row.get("image") or {}).get("pathHorizontal") or (row.get("image") or {}).get("pathVertical")
    thumb = _fix_img(img)
    return {
        "title": title,
        "url": link,
        "thumb": thumb,
        "plot": desc,
    }


def normalize_episode(row, ctx_title=""):
    """Convierte un episodio Atresplayer a item normalizado."""
    t = row.get("title", "Episodio")
    n = row.get("name", "")
    full_t = f"{n} - {t}" if n else t
    is_premium = (row.get("claim") == "PREMIUM")
    vid = row.get("id")
    if not vid:
        href = (row.get("link") or {}).get("href", "")
        if "/episode/" in href:
            vid = href.split("/episode/")[1].split("/")[0]
    if not vid:
        return None
    img = (row.get("image") or {}).get("pathHorizontal") or (row.get("image") or {}).get("pathVertical")
    thumb = _fix_img(img)
    du = row.get("duration", 0) or 0
    if du > 10000:
        du = du / 1000
    plot = row.get("description") or ""
    return {
        "title": full_t,
        "vid": vid,
        "thumb": thumb,
        "plot": plot,
        "duration": int(du),
        "is_premium": is_premium,
    }


def normalize_dm_video(v, score=None):
    """Convierte un vídeo de Dailymotion a item normalizado."""
    du = int(v.get("duration", 0) or 0)
    mins, secs = divmod(du, 60)
    own = v.get("owner.screenname", "Dailymotion")
    cts = v.get("created_time", 0) or 0
    vws = v.get("views_total", 0) or 0
    try:
        f_date = time.strftime("%d/%m/%Y", time.localtime(cts))
    except Exception:
        f_date = "??"
    plot = f"Canal: {own}\nPublicado: {f_date}\nDuración: {mins}m {secs}s\nVistas: {vws}"
    title = v.get("title", "Vídeo")
    if score is not None:
        title = f"{title} ({int(score * 100)}% match)"
    return {
        "title": title,
        "vid": v.get("id", ""),
        "thumb": v.get("thumbnail_720_url") or v.get("thumbnail_480_url") or "",
        "plot": plot,
        "duration": du,
    }
