const CACHE = 'atresdaily-v5';
const SHELL = [
  '/',
  '/css/base.css',
  '/css/layout.css',
  '/css/cards.css',
  '/css/player.css',
  '/css/animations.css',
  '/css/mobile.css',
  '/js/app.js',
  '/js/api.js',
  '/js/icons.js',
  '/js/ui/home.js',
  '/js/ui/row.js',
  '/js/ui/grid.js',
  '/js/ui/player.js',
  '/js/ui/search.js',
  '/js/ui/live.js',
  '/js/ui/toast.js',
  '/js/vendor/hls.min.js',
  '/manifest.webmanifest',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(SHELL.map(u => new Request(u, { cache: 'reload' })))).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);

  // Excluir de la caché las peticiones de API, proxy y miniaturas dinámicas
  if (url.pathname.startsWith('/api/') ||
      url.pathname.startsWith('/proxy/') ||
      url.pathname.startsWith('/thumb/')) {
    return;
  }

  // Estrategia Stale-While-Revalidate para recursos estáticos
  if (url.pathname.startsWith('/css/') ||
      url.pathname.startsWith('/js/') ||
      url.pathname.startsWith('/img/')) {
    e.respondWith(
      caches.open(CACHE).then(cache =>
        cache.match(e.request).then(cached => {
          const fetchPromise = fetch(e.request).then(r => {
            if (r && r.status === 200) cache.put(e.request, r.clone());
            return r;
          }).catch(() => cached);
          return cached || fetchPromise;
        })
      )
    );
    return;
  }

  // Shell de SPA: estrategia Network-First con fallback a caché local
  e.respondWith(
    fetch(e.request).catch(() => caches.match('/'))
  );
});
