import hashlib
import os
import time
import base64
import threading
import uuid

_store = {}  # token -> {url, headers, kind, base_url, expires_at, meta}
_thumb_store = {}  # thumb_id -> {url, expires_at}
_lock = threading.Lock()

# Clave de sesión: XOR+b64 para ocultar URLs en los path params del proxy.
# 256 bits aleatorios, generados al cargar el módulo. Nunca salen del proceso.
_SESSION_KEY = os.urandom(32)

# TTL deslizante: 4h es generoso pero el coste de mantener un token vivo es
# trivial (~200 bytes). Evita cortes cuando el usuario pausa el VOD un rato.
_TTL = 4 * 3600
_THUMB_TTL = 6 * 3600

# Tamaño máximo del store: si un cliente local hace muchos POST /api/resolve
# sin usar los tokens, el dict podría crecer indefinidamente. Cap defensivo.
_MAX_STORE = 500
_TRIM_TO = 400  # cuántos quedan tras el trim


def _xor(data, key):
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))


def encode_url(url):
    """Cifra una URL para que no sea legible en los path params del proxy."""
    return base64.urlsafe_b64encode(_xor(url.encode(), _SESSION_KEY)).decode()


def decode_url(token):
    return _xor(base64.urlsafe_b64decode(token.encode()), _SESSION_KEY).decode()


def _cleanup():
    now = time.time()
    for k in [k for k, v in _store.items() if v['expires_at'] < now]:
        del _store[k]
    for k in [k for k, v in _thumb_store.items() if v['expires_at'] < now]:
        del _thumb_store[k]


def _trim(store, target=_TRIM_TO):
    if len(store) > _MAX_STORE:
        # ascendente por expires_at: los primeros en expirar se descartan primero
        items = sorted(store.items(), key=lambda kv: kv[1]['expires_at'])
        for k, _ in items[:len(store) - target]:
            del store[k]


def create(url, headers, kind, base_url, meta=None):
    with _lock:
        _cleanup()
        _trim(_store)
        token = str(uuid.uuid4()).replace('-', '')
        _store[token] = {
            'url': url,
            'headers': headers,
            'kind': kind,
            'base_url': base_url,
            'expires_at': time.time() + _TTL,
            'meta': meta or {},
        }
        return token


def get(token):
    """Devuelve la entrada y refresca el TTL (sliding). None si expiró o no existe."""
    with _lock:
        entry = _store.get(token)
        if entry is None:
            return None
        if entry['expires_at'] < time.time():
            del _store[token]
            return None
        entry['expires_at'] = time.time() + _TTL
        return entry


def peek(token):
    """Como get() pero NO refresca el TTL ni elimina si expiró. Lectura cruda."""
    with _lock:
        return _store.get(token)


def update_url(token, url, headers, base_url):
    with _lock:
        if token in _store:
            _store[token]['url'] = url
            _store[token]['headers'] = headers
            _store[token]['base_url'] = base_url
            _store[token]['expires_at'] = time.time() + _TTL


def create_thumb(url):
    tid = hashlib.sha256(url.encode()).hexdigest()[:32]
    with _lock:
        _thumb_store[tid] = {'url': url, 'expires_at': time.time() + _THUMB_TTL}
        return tid


def get_thumb(tid):
    with _lock:
        entry = _thumb_store.get(tid)
        if entry and entry['expires_at'] > time.time():
            return entry['url']
        return None
