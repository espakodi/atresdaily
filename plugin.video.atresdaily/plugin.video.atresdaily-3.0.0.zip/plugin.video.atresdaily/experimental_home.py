# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Interfaz experimental 'Modo cine' ventana WindowXML que pinta
# hero rotatorio + filas horizontales de pósters por categoría, al estilo de
# la web de atresplayer. El fetch va directo a la API usando las constantes
# públicas del connector (API_BASE, CH_ID, CATS); el connector real se carga
# cifrado y no expone helpers internos, así que no podemos importar nada
# privado. Al pulsar, delega al flujo `list_details` / `search_movie`.
import os
import sys
import json
import time
import hashlib
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import requests

import xbmc
import xbmcgui
import xbmcaddon

import connector
import ui_utils

_LOG_TAG = "[AtresDaily/ExpHome]"

_ROW_CATS = ["Series", "Programas", "Cine", "Documentales", "Actualidad", "Infantil", "Extra"]

_ID_HERO_LIST = 200
_ID_LOADING = 500
_ID_ROW_PANEL_BASE = 310  # 310..316, uno por categoría

_FOCUS_POLL_MS = 250

# Cache local de imágenes: persiste 2 días. Mejor que confiar solo en el
# cache de texturas de Kodi (textures.db), que es global y puede expirar
# por presión de espacio o reinstalación.
_IMG_CACHE_DIR_NAME = "imgcache"
_IMG_CACHE_TTL_SECS = 2 * 24 * 3600


def _img_cache_dir():
    p = ui_utils.get_path(_IMG_CACHE_DIR_NAME)
    if not os.path.exists(p):
        try: os.makedirs(p)
        except Exception: pass
    return p


def _url_to_local(url):
    h = hashlib.md5(url.encode('utf-8')).hexdigest()
    return os.path.join(_img_cache_dir(), h + ".jpg")


def _local_if_fresh(url):
    local = _url_to_local(url)
    try:
        if os.path.exists(local):
            age = time.time() - os.path.getmtime(local)
            if age < _IMG_CACHE_TTL_SECS and os.path.getsize(local) > 200:
                return local
    except Exception:
        pass
    return None


def _download_to_local(url):
    local = _url_to_local(url)
    if _local_if_fresh(url):
        return local
    try:
        r = requests.get(url, headers=ui_utils.HEADERS, timeout=12, stream=True)
        if r.status_code == 200:
            tmp = local + ".tmp"
            with open(tmp, 'wb') as f:
                for chunk in r.iter_content(8192):
                    if chunk: f.write(chunk)
            os.replace(tmp, local)
            return local
    except Exception:
        pass
    return None


def _cleanup_old_cache():
    # Elimina imágenes con más de TTL de antigüedad. Se ejecuta en background
    # al abrir la home, no bloquea nada.
    cache_dir = _img_cache_dir()
    if not os.path.exists(cache_dir): return
    now = time.time()
    removed = 0
    try:
        for fname in os.listdir(cache_dir):
            path = os.path.join(cache_dir, fname)
            try:
                if now - os.path.getmtime(path) > _IMG_CACHE_TTL_SECS:
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
    except Exception:
        pass
    if removed:
        xbmc.log(f"{_LOG_TAG} cache cleanup: {removed} imágenes expiradas eliminadas", xbmc.LOGINFO)

_MOVE_ACTIONS = {
    xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
    xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN,
    xbmcgui.ACTION_PAGE_UP, xbmcgui.ACTION_PAGE_DOWN,
    xbmcgui.ACTION_MOUSE_MOVE,
}
_CLOSE_ACTIONS = {
    xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
}


def _fetch_cat_rows(cid, page=0):
    # Réplica del fetch+caché de connector.list_cat usando solo constantes
    # públicas (API_BASE, CH_ID). El connector se carga cifrado, no podemos
    # llamar a helpers internos. Caché compartida con el catálogo normal.
    cfg = ui_utils.load_json('settings.json')
    if isinstance(cfg, list): cfg = {}
    expiry = cfg.get('cache_expiry')
    if expiry is None: expiry = 2592000 if cfg.get('cache_active', False) else 0
    use_cache = (expiry != 0)
    cache_file = f'cat_cache_{cid}_{page}.json'

    if use_cache:
        try:
            full_path = ui_utils.get_path(cache_file)
            if os.path.exists(full_path):
                age = time.time() - os.path.getmtime(full_path)
                if expiry == -1 or age < expiry:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        return json.load(f)
        except Exception:
            pass

    u = f"{connector.API_BASE}/client/v1/row/search"
    p = {"entityType": "ATPFormat", "sectionCategory": "true", "mainChannelId": connector.CH_ID,
         "categoryId": cid, "sortType": "THE_MOST", "size": 50, "page": page}
    rows = []
    try:
        try:
            r = requests.get(u, params=p, headers=ui_utils.HEADERS, timeout=15)
        except (requests.exceptions.SSLError, requests.exceptions.ConnectionError):
            r = requests.get(u, params=p, headers=ui_utils.HEADERS, timeout=15, verify=False)
        if r.status_code == 200:
            rows = r.json().get("itemRows", [])
            if use_cache and rows:
                try:
                    with open(ui_utils.get_path(cache_file), 'w', encoding='utf-8') as f:
                        json.dump(rows, f)
                except Exception:
                    pass
        else:
            xbmc.log(f"{_LOG_TAG} cat {cid} HTTP {r.status_code}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"{_LOG_TAG} cat {cid} fetch error: {e}", xbmc.LOGWARNING)
    return rows


def _build_listitem(item, cat_name=""):
    title = item.get("title", "Sin título")
    href = item.get("link", {}).get("href", "")
    if not href: return None
    img_url = ui_utils.fix_img(item.get("image", {}).get("pathHorizontal"))
    # ui_utils.fix_img pide 1280x720 por defecto. Los pósters de fila son 340x200 y los del hero 600x370; con 480x270 sobra para ambos y el JPG pesa ~6x menos que 1280x720. El cuello de botella del "tarda en cargar" era el ancho de banda total con 100+ imágenes a la vez.
    if img_url and img_url.endswith("1280x720.jpg"):
        img_url = img_url[:-len("1280x720.jpg")] + "480x270.jpg"
    # Si está en cache local (home visitada en los últimos 2 días): Kodi lee del disco, instantáneo.
    # Si no: sirve URL remota; el prefetch en background la guarda para el próximo open.
    img = _local_if_fresh(img_url) or img_url
    plot = (item.get("description") or "")[:600]
    tag = item.get("tagType", "")
    is_open = item.get("open", False)
    is_prem = tag in ("EXCLUSIVE", "ORIGINAL", "PREVIEW") and not is_open
    badge = ""
    if is_prem:
        badge = {"ORIGINAL": "ATP Original", "PREVIEW": "ATP Avance"}.get(tag, "ATP+")

    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_title", title)
    li.setProperty("ad_plot", plot)
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_href", href)
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_badge", badge)
    li.setProperty("ad_is_movie", "1" if cat_name == "Cine" else "0")
    return li


class ExperimentalHome(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.selected_href = None
        self.selected_title = ""
        self.selected_is_movie = False
        self._cat_rows = {}
        self._loaded = False
        self._closing = False
        self._poll_thread = None

    def onInit(self):
        self._set_focus_props(title="Cargando…", plot="", fanart="")
        threading.Thread(target=_cleanup_old_cache, daemon=True).start()
        threading.Thread(target=self._load_all, daemon=True).start()
        self._poll_thread = threading.Thread(target=self._focus_poll_loop, daemon=True)
        self._poll_thread.start()

    def _load_all(self):
        try:
            results = {}
            lock = threading.Lock()

            def worker(name):
                cid = connector.CATS.get(name)
                if not cid: return
                try:
                    rows = _fetch_cat_rows(cid, page=0)
                except Exception as e:
                    xbmc.log(f"{_LOG_TAG} fetch {name} fallo: {e}", xbmc.LOGWARNING)
                    rows = []
                with lock:
                    results[name] = rows or []
                xbmc.log(f"{_LOG_TAG} cat {name}: {len(results[name])} items", xbmc.LOGINFO)

            threads = [threading.Thread(target=worker, args=(n,), daemon=True) for n in _ROW_CATS]
            for t in threads: t.start()
            for t in threads: t.join(timeout=20)

            self._cat_rows = results
            if self._closing: return
            self._populate_ui()
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} _load_all error: {e}", xbmc.LOGERROR)
            self._set_loading_text("[COLOR red]Error al cargar el catálogo. Pulsa Atrás para cerrar.[/COLOR]")

    def _populate_ui(self):
        hero_items = []
        for name in ("Series", "Cine", "Programas", "Documentales", "Actualidad"):
            rows = self._cat_rows.get(name, [])
            if not rows: continue
            li = _build_listitem(rows[0], cat_name=name)
            if li: hero_items.append(li)
            if len(hero_items) >= 5: break

        if hero_items:
            try:
                self.getControl(_ID_HERO_LIST).addItems(hero_items)
            except Exception as e:
                xbmc.log(f"{_LOG_TAG} hero populate: {e}", xbmc.LOGWARNING)

        any_row_filled = False
        for idx, name in enumerate(_ROW_CATS):
            panel_id = _ID_ROW_PANEL_BASE + idx
            rows = self._cat_rows.get(name, [])
            items = [li for li in (_build_listitem(r, cat_name=name) for r in rows[:12]) if li]
            if not items: continue
            try:
                self.getControl(panel_id).addItems(items)
                any_row_filled = True
            except Exception as e:
                xbmc.log(f"{_LOG_TAG} panel {panel_id} ({name}) populate: {e}", xbmc.LOGWARNING)

        try:
            self.getControl(_ID_LOADING).setVisible(False)
        except Exception:
            pass

        if hero_items:
            try: self.setFocusId(_ID_HERO_LIST)
            except Exception: pass
        elif any_row_filled:
            try: self.setFocusId(_ID_ROW_PANEL_BASE)
            except Exception: pass

        if not hero_items and not any_row_filled:
            self._set_loading_text("[COLOR orange]No hay contenido disponible. Revisa tu conexión.[/COLOR]")

        self._loaded = True
        self._refresh_focus_props()

        if hero_items or any_row_filled:
            threading.Thread(target=self._spinner_loop, daemon=True).start()
            threading.Thread(target=self._prefetch_images_to_local, daemon=True).start()

    def _prefetch_images_to_local(self):
        # Caché preventiva asíncrona de miniaturas para agilizar futuras cargas de la interfaz.
        xbmc.log(f"{_LOG_TAG} prefetch start (cats={len(self._cat_rows)})", xbmc.LOGINFO)
        urls = set()
        for _name, rows in self._cat_rows.items():
            for r in rows[:12]:
                img = ui_utils.fix_img(r.get("image", {}).get("pathHorizontal", ""))
                if not img: continue
                if img.endswith("1280x720.jpg"):
                    img = img[:-len("1280x720.jpg")] + "480x270.jpg"
                if not _local_if_fresh(img):
                    urls.add(img)
        xbmc.log(f"{_LOG_TAG} prefetch: {len(urls)} URLs nuevas a descargar", xbmc.LOGINFO)
        if not urls:
            return
        downloaded = 0
        failed = 0
        try:
            with ThreadPoolExecutor(max_workers=10) as ex:
                for result in ex.map(_download_to_local, urls):
                    if self._closing:
                        xbmc.log(f"{_LOG_TAG} prefetch aborted ({downloaded} ok)", xbmc.LOGINFO)
                        return
                    if result: downloaded += 1
                    else: failed += 1
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} prefetch error: {e}", xbmc.LOGWARNING)
        xbmc.log(f"{_LOG_TAG} prefetch done: {downloaded} ok, {failed} fail", xbmc.LOGINFO)

    def _spinner_loop(self, max_duration=12.0):
        # Control visual no bloqueante de carga en segundo plano.
        frames = (
            "Cargando imágenes",
            "Cargando imágenes [COLOR FFffaa66]·[/COLOR]",
            "Cargando imágenes [COLOR FFffaa66]· ·[/COLOR]",
            "Cargando imágenes [COLOR FFffaa66]· · ·[/COLOR]",
        )
        monitor = xbmc.Monitor()
        start = time.time()
        i = 0
        while not self._closing and time.time() - start < max_duration:
            self.setProperty("img_loading", frames[i % 4])
            i += 1
            if monitor.waitForAbort(0.35):
                break
        self.setProperty("img_loading", "")

    def _focus_poll_loop(self):
        # Actualización de propiedades Window.Property(focused_*) tras cambios en el foco activo.
        monitor = xbmc.Monitor()
        last_key = None
        while not self._closing and not monitor.abortRequested():
            try:
                key = self._current_focus_key()
                if key != last_key:
                    self._refresh_focus_props()
                    last_key = key
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000.0):
                break

    def _current_focus_key(self):
        try:
            ctrl = self.getFocus()
            cid = ctrl.getId()
            if cid == _ID_HERO_LIST or _ID_ROW_PANEL_BASE <= cid < _ID_ROW_PANEL_BASE + len(_ROW_CATS):
                return (cid, ctrl.getSelectedPosition())
        except Exception:
            return None
        return None

    def _refresh_focus_props(self):
        try:
            ctrl = self.getFocus()
            cid = ctrl.getId()
            if cid != _ID_HERO_LIST and not (_ID_ROW_PANEL_BASE <= cid < _ID_ROW_PANEL_BASE + len(_ROW_CATS)):
                return
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
            if li is None: return
            self._set_focus_props(
                title=li.getProperty("ad_title") or li.getLabel() or "",
                plot=li.getProperty("ad_plot") or "",
                fanart=li.getProperty("ad_fanart") or li.getProperty("ad_image") or "",
            )
        except Exception:
            pass

    def _set_focus_props(self, title="", plot="", fanart=""):
        self.setProperty("focused_title", title)
        self.setProperty("focused_plot", plot)
        self.setProperty("focused_fanart", fanart)

    def _set_loading_text(self, msg):
        try:
            ctrl = self.getControl(_ID_LOADING)
            ctrl.setLabel(msg)
            ctrl.setVisible(True)
        except Exception:
            pass

    def onAction(self, action):
        aid = action.getId()
        if aid in _CLOSE_ACTIONS:
            self._closing = True
            self.close()
            return

    def onClick(self, controlId):
        if not self._loaded: return
        is_known = controlId == _ID_HERO_LIST or _ID_ROW_PANEL_BASE <= controlId < _ID_ROW_PANEL_BASE + len(_ROW_CATS)
        if not is_known: return
        try:
            ctrl = self.getControl(controlId)
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
            href = li.getProperty("ad_href")
            if not href: return
            self.selected_href = href
            self.selected_title = li.getProperty("ad_title") or li.getLabel() or ""
            self.selected_is_movie = li.getProperty("ad_is_movie") == "1"
            self._closing = True
            self.close()
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} onClick error: {e}", xbmc.LOGERROR)


def show():
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    win = ExperimentalHome("experimental_home.xml", addon_path, "Default", "1080i")
    try:
        win.doModal()
        href = win.selected_href
        title = win.selected_title
        is_movie = win.selected_is_movie
    finally:
        del win

    if not href:
        return

    qs = {
        "action": "search_movie" if is_movie else "list_details",
        "title": title,
        "url": href,
        "extra": title,
    }
    next_url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
    xbmc.executebuiltin(f"Container.Update({next_url})")
