# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import sys
import os
import json
import time
import re
import subprocess
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import dm_resolver

_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

_STREAM_EXTENSIONS = {
    '.m3u8', '.mp4', '.mkv', '.avi', '.ts', '.flv',
    '.mov', '.wmv', '.webm', '.mpd', '.m3u'
}

# Script inline para subprocess (Windows). Similar a dm_resolver pero sin módulo
# externo: usa la API de metadatos de DM + parseo del master HLS con regex.
_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), 'url_history.json')


def _bookmarks_path():
    return os.path.join(_get_profile(), 'url_bookmarks.json')


def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except IOError:
        pass


def parse_url_with_headers(raw_url):
    """
    Separa una URL con headers en formato pipe de Kodi.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", "Referer": "yyy"})

    Si no hay pipe, devuelve la URL limpia y un diccionario vacío.
    """
    if not raw_url:
        return '', {}

    raw_url = raw_url.strip()

    if '|' not in raw_url:
        return raw_url, {}

    parts = raw_url.split('|', 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()

    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            key = key.strip()
            value = value.strip()
            # Quitar comillas simples o dobles envolventes
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = value

    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta directamente a un stream reproducible."""
    try:
        parsed = urllib.parse.urlparse(url)
        path_lower = parsed.path.lower()
        _, ext = os.path.splitext(path_lower)
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye la URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    header_parts = []
    for key, value in headers.items():
        header_parts.append(f"{key}={value}")
    return f"{url}|{'&'.join(header_parts)}"


def detect_dailymotion_id(url):
    """Extrae el ID de DM de dailymotion.com/video/{ID}, dai.ly/{ID},
    /embed/video/{ID} y geo-subdomains. Devuelve None si no es DM."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        if host.startswith('www.'):
            host = host[4:]

        if host.endswith('dailymotion.com'):
            # /video/x8abc123 o /video/x8abc123_titulo
            match = re.match(r'/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
            # /embed/video/x8abc123
            match = re.match(r'/embed/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
        elif host == 'dai.ly':
            # dai.ly/x8abc123
            vid = parsed.path.strip('/')
            if vid:
                return vid.split('_')[0].split('?')[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extrae el ID de YT de /watch?v=, youtu.be/ y /shorts/. Devuelve None si no es YT."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        if host.startswith('www.'):
            host = host[4:]

        if host in ('youtube.com', 'm.youtube.com'):
            if '/watch' in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get('v', [])
                if vid_list:
                    return vid_list[0]
            elif '/shorts/' in parsed.path:
                match = re.match(r'/shorts/([a-zA-Z0-9_-]+)', parsed.path)
                if match:
                    return match.group(1)
        elif host == 'youtu.be':
            vid = parsed.path.strip('/')
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """Clasifica raw_url. Tipos: 'acestream', 'dailymotion', 'youtube', 'direct_stream', 'web_page'."""
    url, _ = parse_url_with_headers(raw_url)

    if url.startswith("acestream://"):
        content_id = url.replace("acestream://", "").strip()
        if content_id:
            return 'acestream', content_id

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return 'dailymotion', dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return 'youtube', yt_id

    if is_direct_stream(url):
        return 'direct_stream', raw_url

    return 'web_page', url


def _add_to_history(raw_url, label=None):
    """Registra en historial, moviendo al frente si ya existía (dedup)."""
    history = _load_json(_history_path())
    history = [h for h in history if h.get('url') != raw_url]

    entry = {
        'url': raw_url,
        'label': label or raw_url,
        'date': time.strftime('%d/%m/%Y %H:%M'),
        'timestamp': int(time.time())
    }
    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    _save_json(_history_path(), [])


def _remove_from_history(url):
    history = _get_history()
    history = [h for h in history if h.get('url') != url]
    _save_json(_history_path(), history)


def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    bookmarks = _get_bookmarks()
    if any(b.get('url') == url for b in bookmarks):
        return False
    bookmarks.append({
        'name': name,
        'url': url,
        'date': time.strftime('%d/%m/%Y %H:%M')
    })
    bookmarks = bookmarks[:MAX_BOOKMARKS]
    _save_json(_bookmarks_path(), bookmarks)
    return True


def _remove_bookmark(url):
    bookmarks = _get_bookmarks()
    new_bookmarks = [b for b in bookmarks if b.get('url') != url]
    _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    bookmarks = _get_bookmarks()
    changed = False
    for b in bookmarks:
        if b.get('url') == url:
            b['name'] = new_name
            changed = True
            break
    if changed:
        _save_json(_bookmarks_path(), bookmarks)
    return changed



def _u(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    h = int(sys.argv[1])

    # 0. Abrir / Instalar StreamNinja
    sn_id = "plugin.video.streamninja"
    is_sn_installed = xbmc.getCondVisibility(f"System.HasAddon({sn_id})")
    
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')

    if is_sn_installed:
        lbl_sn = "[COLOR royalblue]Abrir StreamNinja[/COLOR]"
        plt_sn = "¡Activa el Modo Ninja! Desenvaina la potencia de StreamNinja para dominar cualquier enlace de vídeo con precisión y rapidez."
    else:
        lbl_sn = "[COLOR orange]Instalar StreamNinja[/COLOR]"
        plt_sn = "Instala el Modo Ninja: Desenvaina la potencia necesaria para dominar cualquier enlace de vídeo."
        
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({'icon': sn_icon})
    li_sn.setInfo('video', {'plot': plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_player_ensure_sn'), listitem=li_sn, isFolder=False)

    # 1. Pegar nueva URL
    li = xbmcgui.ListItem(label="[COLOR limegreen]Pegar URL de vídeo[/COLOR]")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot':
        "Pega una URL de vídeo para reproducirla.\n\n"
        "URLs soportadas:\n"
        "  • Dailymotion: dailymotion.com/video/xxx o dai.ly/xxx\n"
        "  • YouTube: youtube.com/watch?v=xxx o youtu.be/xxx\n"
        "  • Stream directo: compatible con la mayoría de vídeos\n"
        "  • Otras webs: se intenta resolver automáticamente"
    })
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_input'), listitem=li, isFolder=False)

    # 2. Historial
    history = _get_history()
    if history:
        li = xbmcgui.ListItem(label=f"[COLOR cyan]Historial de URLs ({len(history)})[/COLOR]")
        li.setArt({'icon': 'DefaultRecentlyAddedMovies.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history'), listitem=li, isFolder=True)

    # 3. Marcadores
    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(label=f"[COLOR khaki]Marcadores ({len(bookmarks)})[/COLOR]")
        li.setArt({'icon': 'DefaultSets.png'})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_bookmarks'), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def _resolve_and_play(raw_url):
    url_type, value = detect_url_type(raw_url)

    if url_type == 'acestream':
        has_plexus = xbmc.getCondVisibility("System.HasAddon(program.plexus)")
        has_horus = xbmc.getCondVisibility("System.HasAddon(script.module.horus)")
        if has_plexus:
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en Plexus...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://program.plexus/?url=acestream://{value}&mode=1&name=Acestream"
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
        elif has_horus:
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en Horus...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://script.module.horus/?action=play&id={value}"
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "No se puede reproducir este enlace AceStream.\n\n"
                "Necesitas un addon de Kodi que maneje el protocolo acestream://:\n"
                "  • program.plexus (recomendado)\n"
                "  • script.module.horus\n\n"
                "Ambos requieren además el AceStream Engine instalado en el sistema.")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return

    if url_type == 'dailymotion':
        xbmcgui.Dialog().notification("AtresDaily",
            f"Dailymotion detectado: {value}", xbmcgui.NOTIFICATION_INFO, 2000)
        _played = False
        _python_missing = False
        _ytdlp_missing = False

        # Windows paso 1: script inline, sin yt-dlp, ~1-2s.
        if xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                _proc = subprocess.run(
                    ['python', '-c', _DM_SYSPY_SCRIPT, value],
                    capture_output=True, text=True, timeout=20,
                    creationflags=0x08000000,
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    stream_url = json.loads(_proc.stdout).get('url', '')
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setMimeType('application/x-mpegURL')
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        _played = True
                        xbmc.log(f"[url_player] DM inline OK: {stream_url[:80]}", xbmc.LOGINFO)
                if not _played:
                    xbmc.log(
                        f"[url_player] DM inline rc={_proc.returncode} "
                        f"err={(_proc.stderr or '')[:200]}",
                        xbmc.LOGWARNING,
                    )
            except FileNotFoundError:
                _python_missing = True
                xbmc.log("[url_player] DM: python no encontrado en PATH", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"[url_player] DM inline error: {e}", xbmc.LOGWARNING)

        # Windows paso 2: yt-dlp. Sin Python disponible, yt-dlp tampoco funciona.
        if not _played and not _python_missing and xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                _proc = subprocess.run(
                    ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                     '--format', 'best[ext=mp4]/best', '--no-playlist',
                     f'https://www.dailymotion.com/video/{value}'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=0x08000000,
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    stream_url = json.loads(_proc.stdout).get('url', '')
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        _played = True
                        xbmc.log(f"[url_player] DM yt-dlp OK: {stream_url[:80]}", xbmc.LOGINFO)
                if not _played:
                    _err = (_proc.stderr or '') + (_proc.stdout or '')
                    if 'No module named' in _err and 'yt_dlp' in _err:
                        _ytdlp_missing = True
                    xbmc.log(f"[url_player] DM yt-dlp sin URL rc={_proc.returncode}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"[url_player] DM yt-dlp error: {e}", xbmc.LOGWARNING)

        if xbmc.getCondVisibility("System.Platform.Windows") and (_python_missing or _ytdlp_missing):
            _hint = (
                "Instala Python y yt-dlp para reproducción más fiable en Windows"
                if _python_missing
                else "Instala yt-dlp (pip install yt-dlp) para mayor fiabilidad"
            )
            xbmcgui.Dialog().notification("AtresDaily", _hint, xbmcgui.NOTIFICATION_INFO, 6000)

        # Paso 3 (todas las plataformas): inputstream.adaptive con headers para
        # que los segmentos de vod*.cf.dmcdn.net no devuelvan 403.
        if not _played:
            _result = dm_resolver.resolve(value)
            if _result:
                url_val = _result['url']
                mime_val = _result.get('mime', 'application/x-mpegURL')
                subs_val = _result.get('subs', [])
                headers_dict = _result.get('headers', {})
                is_hls = 'mpegURL' in mime_val
                header_str = '&'.join(
                    f'{k}={urllib.parse.quote(str(v))}' for k, v in headers_dict.items()
                ) if headers_dict else ''
                if not is_hls and header_str:
                    url_val = f"{url_val}|{header_str}"
                li = xbmcgui.ListItem(path=url_val)
                li.setMimeType(mime_val)
                li.setProperty('IsPlayable', 'true')
                li.setContentLookup(False)
                if is_hls and header_str:
                    li.setProperty('inputstream', 'inputstream.adaptive')
                    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    li.setProperty('inputstream.adaptive.manifest_headers', header_str)
                    li.setProperty('inputstream.adaptive.stream_headers', header_str)
                if subs_val:
                    li.setSubtitles(subs_val)
                xbmc.Player().play(url_val, li)
                _played = True
                xbmc.log("[url_player] DM API directa OK", xbmc.LOGINFO)

        # Paso 4: dm_gujal, legacy, funciona principalmente en Android/Linux.
        if not _played:
            try:
                import dm_gujal
                _result = dm_gujal.play_dm_extreme(value)
                if _result and _result[0]:
                    final_url, subs, mime = _result
                    li = xbmcgui.ListItem(path=final_url)
                    if mime:
                        li.setMimeType(mime)
                    if subs:
                        li.setSubtitles(subs)
                    li.setProperty('IsPlayable', 'true')
                    xbmc.Player().play(final_url, li)
                    _played = True
            except Exception as e:
                xbmc.log(f"[url_player] DM gujal error: {e}", xbmc.LOGWARNING)

        if not _played:
            xbmcgui.Dialog().ok("AtresDaily", "No se pudo resolver el vídeo de Dailymotion.")

    elif url_type == 'youtube':
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().notification("AtresDaily",
                "Abriendo en YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
            yt_url = (
                f"plugin://plugin.video.youtube/play/"
                f"?video_id={value}"
            )
            xbmc.executebuiltin(f'PlayMedia("{yt_url}")')
            xbmc.sleep(1500)  # mantener el script vivo para que PlayMedia no se cancele al salir
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "El addon de YouTube no está instalado.\n\n"
                "Instálalo para reproducir vídeos de YouTube.")

    elif url_type == 'direct_stream':
        url, headers = parse_url_with_headers(raw_url)
        kodi_url = build_kodi_url(url, headers)
        li = xbmcgui.ListItem(path=kodi_url)
        if '.mpd' in url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        elif '.m3u8' in url.lower():
            li.setMimeType('application/x-mpegURL')
        if headers:
            header_str = '&'.join(f'{k}={v}' for k, v in headers.items())
            li.setProperty('inputstream.adaptive.stream_headers', header_str)
        xbmc.Player().play(kodi_url, li)

    elif url_type == 'web_page':
        # Intentar resolver URL de página web con addons externos
        has_sendtokodi = xbmc.getCondVisibility("System.HasAddon(plugin.video.sendtokodi)")
        has_youtube = xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)")

        if has_sendtokodi:
            # SendToKodi: diseñado exactamente para resolver URLs de webs arbitrarias
            xbmcgui.Dialog().notification("AtresDaily",
                "Resolviendo con SendToKodi...", xbmcgui.NOTIFICATION_INFO, 2000)
            stk_url = (
                f"plugin://plugin.video.sendtokodi/"
                f"?{urllib.parse.urlencode({'url': value})}"
            )
            xbmc.executebuiltin(f'PlayMedia("{stk_url}")')
        elif has_youtube:
            # Alternativa: YouTube addon (también usa yt-dlp)
            xbmcgui.Dialog().notification("AtresDaily",
                "Resolviendo con YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
            yt_url = (
                f"plugin://plugin.video.youtube/uri2addon/"
                f"?uri={urllib.parse.quote(value)}"
            )
            xbmc.executebuiltin(f'PlayMedia("{yt_url}")')
        else:
            xbmcgui.Dialog().ok("AtresDaily",
                "No se puede resolver esta URL.\n\n"
                "Instala uno de estos addons:\n"
                "  • plugin.video.sendtokodi (recomendado)\n"
                "  • plugin.video.youtube\n\n"
                "O pega directamente la URL del stream (.m3u8, .mp4, etc.)")


def url_input():
    kb = xbmc.Keyboard('', 'Pegar URL (Dailymotion, YouTube, stream...)')
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    if not raw.startswith(('http://', 'https://', 'rtmp://', 'rtsp://')):
        xbmcgui.Dialog().ok("AtresDaily",
            "La URL introducida no parece válida.\n\n"
            "Debe empezar por http://, https://, rtmp:// o rtsp://")
        return

    _add_to_history(raw)
    url_type, _ = detect_url_type(raw)
    type_labels = {
        'dailymotion': 'Dailymotion',
        'youtube': 'YouTube',
        'direct_stream': 'Stream directo',
        'web_page': 'Página web'
    }
    detected = type_labels.get(url_type, 'Desconocido')
    url_display = raw[:50] + '...' if len(raw) > 50 else raw

    opts = [
        f"Reproducir ahora ({detected})",
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador"
    ]
    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)


def url_history_menu():
    h = int(sys.argv[1])
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay URLs en el historial[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial de URLs[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history_clear'), listitem=li, isFolder=False)

    for entry in history:
        raw_url = entry.get('url', '')
        label = entry.get('label', raw_url)
        date = entry.get('date', '')

        display = label[:80] + '...' if len(label) > 80 else label
        li = xbmcgui.ListItem(label=f"{display}")
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': f"URL: {raw_url}\n\nFecha: {date}"})

        cm = [
            ("Guardar como marcador", f"RunPlugin({_u(action='url_bookmark_save_from_history', url=raw_url)})"),
            ("Eliminar del historial", f"RunPlugin({_u(action='url_history_remove', url=raw_url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=raw_url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()

    if not bookmarks:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay marcadores guardados[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get('url', '')
        name = bm.get('name', url)
        date = bm.get('date', '')

        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': f"URL: {url}\n\nGuardado: {date}"})

        cm = [
            ("Renombrar", f"RunPlugin({_u(action='url_bookmark_rename', url=url)})"),
            ("Eliminar marcador", f"RunPlugin({_u(action='url_bookmark_delete', url=url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard('', 'Nombre para el marcador')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ''
    for b in bookmarks:
        if b.get('url') == url:
            current_name = b.get('name', '')
            break

    kb = xbmc.Keyboard(current_name, 'Nuevo nombre')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification("AtresDaily", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial."""
    if not raw_url:
        return
    _add_to_history(raw_url)
    _resolve_and_play(raw_url)


def url_player_ensure_streamninja():
    import ui_utils
    ui_utils.streamninja_open_or_install()
