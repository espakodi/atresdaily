# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""EPG en Texto — parrilla de programación en texto, basada en XML XMLTV público.

Portado de EspaTV (mismo autor, GPL-2.0). Cache propia en profile/epg_texto_cache.json.
"""
import gzip
import io
import json
import os
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

# _parse_epg_dt() reemplaza strptime — bug #7980 de CPython lo rompe en threads de Kodi.

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[AtresDaily-EPG]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "epg_texto_cache.json")
_CACHE_TTL       = 7200  # 2 horas
_TIMEOUT         = 30
_EPG_URL         = "https://epgshare01.online/epgshare01/epg_ripper_ES1.xml.gz"
_EPG_URL_FALLBACK = "https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv.xml.gz"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_GRUPOS_CH = {
    "Nacionales TDT": {
        "La1.es", "La2.es", "Antena.3.es", "Telecinco.es", "Cuatro.es",
        "laSexta.es", "Neox.es", "Nova.es", "FDF.es", "Energy.es",
        "Boing.es", "Divinity.es", "Mega.es", "Atreseries.es",
        "24H.es", "Clan.es", "Teledeporte.es",
        "BeMad.es", "Be Mad.es", "DMAX.es", "Ten.es", "Paramount.es",
        "RealMadrid.es", "GOL.es", "GolPlay.es",
    },
    "Autonómicos": {
        "TV3.es", "324.es", "33.es", "Esport3.es", "SuperC.es",
        "ETB1.es", "ETB2.es", "ETB3.es", "ETB4.es",
        "TVG.gal", "TVG2.gal", "TVG.es", "TVG2.es",
        "CanalSur.es", "CanalSur2.es", "Canal Sur.es", "Canal Sur 2.es",
        "Telemadrid.es", "LaOtra.es", "La Otra.es", "AragonTV.es",
        "Aragon TV.es", "A3-9.es", "Apunt.es", "IB3.es", "TPA.es", "CMM.es",
        "7NN.es", "LaRioja.es",
        "Andalucia TV.es", "7TV Andalucia.es", "8 Madrid.es",
        "13 TV.es", "7 Region de Murcia.es", "Beteve.es", "Castilla La Mancha Media.es",
    },
    "Temáticos": {
        "Disney.es", "Disney Channel.es", "Disney Junior.es",
        "Nickelodeon.es", "Discovery.es", "Discovery Channel.es",
        "NatGeo.es", "Nat Geo.es", "AMC.es", "AMC Break.es", "AMC Crime.es",
        "History.es", "AXN.es", "AXN Movies.es", "Fox.es", "Calle 13.es", "Calle13.es",
        "TCM.es", "Syfy.es", "MGM.es", "Cosmo.es",
        "SundanceTV.es", "Sundance TV.es",
        "BBC Earth.es", "BBC Food.es", "BBC News.es",
        "Baby TV.es", "BeIN Sports.es", "Bloomberg.es",
    },
}

_ATRES_ORDER = ["Antena.3.es", "laSexta.es", "Neox.es", "Nova.es", "Mega.es", "Atreseries.es"]

_ACCENT_MAP = str.maketrans("áéíóúñÁÉÍÓÚÑàèìòùÀÈÌÒÙäëïöüÄËÏÖÜâêîôûÂÊÎÔÛ",
                             "aeiounAEIOUNaeiouAEIOUaeiouAEIOUaeiouAEIOU")


def _normalize_ch_id(ch_id):
    core = ch_id.rsplit(".", 1)[0]
    return core.lower().replace(".", "").replace(" ", "").translate(_ACCENT_MAP)


_ID_A_GRUPO = {}
for _g, _ids in _GRUPOS_CH.items():
    for _cid in _ids:
        _ID_A_GRUPO[_normalize_ch_id(_cid)] = _g


def _grupo_de(ch_id):
    return _ID_A_GRUPO.get(_normalize_ch_id(ch_id), "Otros")


_ORDEN_GRUPOS = ["Nacionales TDT", "Autonómicos", "Temáticos", "Otros"]
_COLOR_GRUPOS = {
    "Nacionales TDT": "gold",
    "Autonómicos":    "deepskyblue",
    "Temáticos":      "plum",
    "Otros":          "grey",
}


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _utc_to_local(utc_dt):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)


def _parse_epg_dt(s):
    # Sin strptime: bug #7980 lo rompe en threads de Kodi.
    if not s:
        return None
    s = s[:14] if len(s) >= 14 else (s[:12] + "00" if len(s) >= 12 else None)
    if not s or len(s) != 14 or not s.isdigit():
        return None
    try:
        return datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]),
                        int(s[8:10]), int(s[10:12]), int(s[12:14]))
    except (ValueError, TypeError):
        return None


def _fmt_time(ts_str):
    if ts_str is None:
        return ""
    utc_dt = _parse_epg_dt(ts_str)
    if utc_dt is None:
        return ts_str[:4] if ts_str else ""
    local_dt = _utc_to_local(utc_dt)
    return "{0:02d}:{1:02d}".format(local_dt.hour, local_dt.minute)


def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("channels", {}), obj.get("programmes", {})
    except (OSError, ValueError):
        pass
    return None, None


def _save_cache(channels, programmes):
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "channels": channels, "programmes": programmes}, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


def _download_epg_xml(url):
    headers = {"User-Agent": "AtresDaily/1.0 (Kodi addon; EPG texto)", "Accept-Encoding": "gzip"}
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return gzip.GzipFile(fileobj=io.BytesIO(resp.content)).read(50 * 1024 * 1024)


def _fetch_epg():
    channels, programmes = _load_cache()
    if channels is not None:
        return channels, programmes

    xml_data = None
    for url in (_EPG_URL, _EPG_URL_FALLBACK):
        try:
            xbmc.log("{0} Descargando EPG desde {1}…".format(_LOG, url), xbmc.LOGINFO)
            xml_data = _download_epg_xml(url)
            break
        except Exception as e:
            xbmc.log("{0} Fuente EPG {1} falló: {2}".format(_LOG, url, e), xbmc.LOGWARNING)

    if not xml_data:
        xbmc.log("{0} Todas las fuentes EPG fallaron — devolviendo vacío".format(_LOG), xbmc.LOGERROR)
        return {}, {}

    try:
        root = ET.fromstring(xml_data)
    except ET.ParseError as e:
        xbmc.log("{0} Error parseando XML EPG: {1}".format(_LOG, e), xbmc.LOGERROR)
        return {}, {}

    channels  = {}
    programmes = {}

    for ch in root.findall("channel"):
        ch_id   = ch.get("id", "")
        name_el = ch.find("display-name")
        ch_name = (name_el.text or ch_id) if name_el is not None else ch_id
        icon_el = ch.find("icon")
        ch_icon = icon_el.get("src", "") if icon_el is not None else ""
        if ch_id:
            channels[ch_id] = {"name": ch_name, "icon": ch_icon}

    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    cutoff_start = now_utc - timedelta(hours=2)
    cutoff_end   = now_utc + timedelta(hours=26)

    for prog in root.findall("programme"):
        ch_id   = prog.get("channel", "")
        start_s = prog.get("start", "")
        stop_s  = prog.get("stop", "")
        if not ch_id or not start_s:
            continue
        start_dt = _parse_epg_dt(start_s)
        if start_dt is None:
            continue
        if not (cutoff_start <= start_dt <= cutoff_end):
            continue

        title_el = prog.find("title")
        title_t  = title_el.text if title_el is not None and title_el.text else "Sin título"
        desc_el  = prog.find("desc")
        desc_t   = desc_el.text if desc_el is not None and desc_el.text else ""
        cat_el   = prog.find("category")
        cat_t    = cat_el.text if cat_el is not None and cat_el.text else ""

        if ch_id not in programmes:
            programmes[ch_id] = []
        programmes[ch_id].append({
            "start": start_s[:14],
            "stop":  stop_s[:14] if stop_s else "",
            "title": title_t,
            "desc":  desc_t,
            "cat":   cat_t,
        })

    for ch_id in programmes:
        programmes[ch_id].sort(key=lambda x: x["start"])

    _save_cache(channels, programmes)
    return channels, programmes


def epg_texto_menu():
    h = int(sys.argv[1])
    try:
        xbmcgui.Dialog().notification("EPG", "Cargando parrilla…", xbmcgui.NOTIFICATION_INFO, 1500)
        channels, _ = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error: {1}".format(_LOG, e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error cargando EPG — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_epg_texto.png")

    conteo = {g: 0 for g in _ORDEN_GRUPOS}
    for ch_id in channels:
        conteo[_grupo_de(ch_id)] += 1

    for grupo in _ORDEN_GRUPOS:
        color = _COLOR_GRUPOS[grupo]
        n = conteo[grupo]
        label = "[B][COLOR {0}]{1}[/COLOR][/B]  [COLOR grey]({2} canales)[/COLOR]".format(color, grupo, n)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver canales de la categoria {0}.".format(grupo)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_grupo", grupo=grupo),
            listitem=li,
            isFolder=True,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar parrilla ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga la parrilla EPG."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def epg_texto_atres():
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, "Atresplayer — Parrilla")
    try:
        xbmcgui.Dialog().notification("EPG", "Cargando parrilla…", xbmcgui.NOTIFICATION_INFO, 1500)
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error atres: {1}".format(_LOG, e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error cargando EPG — comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    seen = set()
    ordered = []
    for cid in _ATRES_ORDER:
        if cid in channels and cid not in seen:
            ordered.append(cid)
            seen.add(cid)

    if not ordered:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin datos EPG para canales Atresplayer[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for ch_id in ordered:
        ch_info = channels[ch_id]
        ch_name = ch_info["name"]
        ch_icon = ch_info.get("icon") or icon
        progs = programmes.get(ch_id, [])
        n_progs = len(progs)

        current = None
        for p in progs:
            s = _parse_epg_dt(p["start"])
            if s is None:
                continue
            e = _parse_epg_dt(p["stop"]) if p["stop"] else s + timedelta(hours=1)
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                current = p
                break

        now_label = ("  [COLOR deepskyblue]{0}[/COLOR]".format(current["title"]) if current else "")
        label = "[B]{0}[/B]{1}  [COLOR grey]({2} prog.)[/COLOR]".format(ch_name, now_label, n_progs)
        plot = "{0}\n{1} programas en parrilla".format(ch_name, n_progs)
        if current:
            plot += "\nAhora: {0}".format(current["title"])
            if current.get("desc"):
                plot += "\n{0}".format(current["desc"])

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ch_icon, "thumb": ch_icon})
        li.setInfo("video", {"title": ch_name, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_canal", ch_id=ch_id, ch_name=ch_name),
            listitem=li,
            isFolder=True,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar parrilla ][/COLOR]")
    li_r.setArt({"icon": "DefaultIconInfo.png"})
    li_r.setInfo("video", {"plot": "Recarga la parrilla EPG."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def epg_texto_grupo(grupo_nombre):
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, grupo_nombre)
    try:
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error grupo: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    icon = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    ch_with_now = []
    ch_others   = []
    for ch_id, ch_info in sorted(channels.items(), key=lambda x: x[1]["name"]):
        if _grupo_de(ch_id) != grupo_nombre:
            continue
        progs = programmes.get(ch_id, [])
        current = None
        for p in progs:
            s = _parse_epg_dt(p["start"])
            if s is None:
                continue
            e = _parse_epg_dt(p["stop"]) if p["stop"] else s + timedelta(hours=1)
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                current = p
                break
        if current:
            ch_with_now.append((ch_id, ch_info, current))
        else:
            ch_others.append((ch_id, ch_info, None))

    if not ch_with_now and not ch_others:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin canales en esta categoria[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for ch_id, ch_info, current in (ch_with_now + ch_others):
        ch_name = ch_info["name"]
        ch_icon = ch_info.get("icon") or icon
        n_progs = len(programmes.get(ch_id, []))

        now_label = ("  [COLOR deepskyblue]{0}[/COLOR]".format(current["title"])
                     if current else "")
        label = "[B]{0}[/B]{1}  [COLOR grey]({2} prog.)[/COLOR]".format(ch_name, now_label, n_progs)
        plot  = "{0}\n{1} programas en parrilla".format(ch_name, n_progs)
        if current:
            plot += "\nAhora: {0}".format(current["title"])
            if current.get("desc"):
                plot += "\n{0}".format(current["desc"])

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ch_icon, "thumb": ch_icon})
        li.setInfo("video", {"title": ch_name, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_canal", ch_id=ch_id, ch_name=ch_name),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def epg_texto_canal(ch_id, ch_name):
    h = int(sys.argv[1])
    if ch_name:
        xbmcplugin.setPluginCategory(h, ch_name)
    try:
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error canal: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    progs = programmes.get(ch_id, [])
    icon  = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    if not progs:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin programación disponible[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    prev_date = None
    for p in progs:
        start_utc = _parse_epg_dt(p["start"])
        if start_utc is None:
            continue
        is_now = False
        if p["stop"]:
            stop_utc = _parse_epg_dt(p["stop"])
            if stop_utc is not None:
                is_now = start_utc <= now_utc < stop_utc

        local_start = _utc_to_local(start_utc)
        date_str = "{0:02d}/{1:02d}".format(local_start.day, local_start.month)

        if date_str != prev_date:
            prev_date = date_str
            sep = xbmcgui.ListItem(label="[COLOR gold]──  {0}  ──[/COLOR]".format(date_str))
            sep.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        hora   = _fmt_time(p["start"])
        titulo = p["title"]
        desc   = p.get("desc", "")
        cat    = p.get("cat", "")

        if is_now:
            color = "gold"
            marca = "  [COLOR gold]▶ EN CURSO[/COLOR]"
        else:
            color = "white"
            marca = ""

        label = "[B][COLOR {0}]{1}[/COLOR][/B]  {2}{3}".format(color, hora, titulo, marca)
        plot  = "{0}  {1}\n{2}".format(hora, titulo, desc)
        if cat:
            plot += "\n[{0}]".format(cat)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": titulo, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_programa", title=titulo, plot=plot),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def epg_texto_programa(title, plot):
    xbmcgui.Dialog().textviewer(title, plot)


def epg_texto_refresh():
    try:
        os.remove(_CACHE_FILE)
    except OSError:
        pass
    try:
        channels, _ = _fetch_epg()
        if not channels:
            xbmcgui.Dialog().notification(
                "EPG", "Sin datos disponibles. Reintenta en unos minutos.",
                xbmcgui.NOTIFICATION_WARNING, 3000
            )
    except Exception as e:
        xbmc.log("{0} Refresh falló: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "EPG", "Error al actualizar — fuente caída",
            xbmcgui.NOTIFICATION_ERROR, 3000
        )
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="epg_texto_menu")))
