# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
AtresDaily - Explorador del catálogo de A3Player para Kodi.

Busca y reproduce contenido público de Dailymotion, YouTube y otras fuentes
legales asociado al catálogo de A3Player. Gestiona historial, favoritos,
categorías, listas IPTV y descargas.

Addon desarrollado por fullstackcurso y espakodi - RSDFA1labernt
Licencia: GPL-2.0-or-later (Si vas a usar este código, por favor, da crédito al desarrollador original e incluye esta licencia,
ademas intenta contribuir al proyecto original si los cambios no son significativos para no fragmentar el desarrollo y la comunidad).

Este addon se ha hecho intentando que todo sea lo mas legal posible. Si crees que algo no lo es, ponte en contacto.
"""
import sys
import base64
import shutil
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import urllib.parse
import json
import time
import difflib
import re
import tempfile
import core_settings
import category_manager
import ui_utils
import exploration_history
import epg_texto
import types

_ACC_COLOR_MODE = 'none'
_ACC_BOLD_ENABLED = True
_ACC_STRIP_SYMBOLS = False
try:
    _acc_addon = xbmcaddon.Addon()
    _ACC_COLOR_MODE = _acc_addon.getSetting('acc_color_mode') or 'none'
    _ACC_BOLD_ENABLED = _acc_addon.getSetting('acc_bold_enabled') != 'false'
    _ACC_STRIP_SYMBOLS = _acc_addon.getSetting('acc_strip_symbols') == 'true'
    del _acc_addon
except Exception:
    pass

_ACC_DRG_MAP = {
    'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
    'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
    'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
    'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
    'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
    'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
    'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
    'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
    'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
    'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
    'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
    'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})
_ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z]+)\]')
_ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})


def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    elif _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
    elif _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
    return match.group(0)


def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _ACC_BOLD_ENABLED and '[B]' not in s:
        s = '[B]' + s + '[/B]'
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s


_ACC_NEEDS_TRANSFORM = _ACC_BOLD_ENABLED or _ACC_STRIP_SYMBOLS or (_ACC_COLOR_MODE not in ('', 'none'))

if _ACC_NEEDS_TRANSFORM:
    try:
        _OrigListItem = getattr(xbmcgui, '_OrigListItemAtresdaily', None) or xbmcgui.ListItem
        xbmcgui._OrigListItemAtresdaily = _OrigListItem

        def _ListItemFactory(*args, **kwargs):
            if 'label' in kwargs:
                kwargs['label'] = _acc_transform(kwargs['label'])
            elif args:
                args = (_acc_transform(args[0]),) + args[1:]
            if 'label2' in kwargs:
                kwargs['label2'] = _acc_transform(kwargs['label2'])
            elif len(args) >= 2:
                args = (args[0], _acc_transform(args[1])) + args[2:]
            return _OrigListItem(*args, **kwargs)

        xbmcgui.ListItem = _ListItemFactory
        xbmc.log("[AtresDaily] Accessibility patch installed (color={0} bold={1} symbols={2})".format(
            _ACC_COLOR_MODE, _ACC_BOLD_ENABLED, _ACC_STRIP_SYMBOLS), xbmc.LOGINFO)
    except Exception as _e:
        xbmc.log("[AtresDaily] Accessibility patch failed: {0}".format(_e), xbmc.LOGWARNING)
else:
    try:
        _orig = getattr(xbmcgui, '_OrigListItemAtresdaily', None)
        if _orig is not None and xbmcgui.ListItem is not _orig:
            xbmcgui.ListItem = _orig
    except Exception:
        pass

ui_utils._title_transform = _acc_transform

# Identidad del addon — no eliminar (GPL requiere mantener los avisos de autoria)
xbmc.log(
    "[AtresDaily] Addon original por RubénSDFA1laberot — "
    "https://github.com/fullstackcurso — GPL-2.0-or-later",
    xbmc.LOGINFO,
)

# Firma de build original — no eliminar
_ORIGIN = "fullstackcurso-RSDFA1-v1"

_CK0 = "32a59ad216d7a1e83c7eab2846236cc938fcf84ce142e4650075589b1a071e96"
_CK1 = "b9c331496668e1072d21880a9f5a246fd173bb1b21e54c93d6899d515348fa67"
_DATA_NODES = [
    "aHR0cHM6Ly9hMy5yYXdnaXN0LndvcmtlcnMuZGV2Lw==",
]

def _get_secure_cache_dir():
    """Obtiene un directorio con permisos de escritura verificados."""
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    p_addon = os.path.join(addon_path, 'cache')
    
    if not os.path.exists(p_addon):
        try: os.makedirs(p_addon)
        except Exception: pass
        
    if os.path.exists(p_addon) and os.access(p_addon, os.W_OK):
        try:
            probe = os.path.join(p_addon, '.probe')
            with open(probe, 'wb') as f: f.write(b'\x00')
            os.remove(probe)
            return p_addon
        except Exception:
            pass
        
    p_profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    p_prof_cache = os.path.join(p_profile, 'cache')
    if not os.path.exists(p_prof_cache):
        try: os.makedirs(p_prof_cache)
        except Exception: pass
    return p_prof_cache

def _get_connector_bin_path():
    return os.path.join(_get_secure_cache_dir(), 'cache_data.bin')

def _load_stealth_module(module_name, file_path):
    if module_name in sys.modules:
        return sys.modules[module_name]
    
    if not os.path.exists(file_path):
        return None
        
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            
        source = raw_data.decode('utf-8')
            
        new_module = types.ModuleType(module_name)
        new_module.__file__ = f"<system_metadata_{module_name}>"
        new_module.__package__ = ""
        
        sys.modules[module_name] = new_module
        
        compiled_code = compile(source, new_module.__file__, 'exec')
        exec(compiled_code, new_module.__dict__)
        
        return new_module
    except SyntaxError as se:
        xbmc.log(f"[AtresDaily Stealth] Corrupción de sintaxis detectada en el binario: {se}", xbmc.LOGERROR)
        if module_name in sys.modules:
            del sys.modules[module_name]
        return None
    except Exception as e:
        xbmc.log(f"[AtresDaily Stealth] Error de carga en componente crítico: {e}", xbmc.LOGERROR)
        if module_name in sys.modules:
            del sys.modules[module_name]
        return None

def _get_loader_config_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'loader_config.json')

def _get_connector_path():
    return _get_connector_bin_path()

def _load_custom_urls():
    """Carga URLs personalizadas del archivo de configuración."""
    cfg_path = _get_loader_config_path()
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('custom_urls', [])
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error leyendo loader config: {e}", xbmc.LOGWARNING)
    return []

def _save_custom_url(url):
    """Guarda una URL personalizada en el archivo de configuración."""
    cfg_path = _get_loader_config_path()
    custom_urls = _load_custom_urls()
    if url not in custom_urls:
        custom_urls.append(url)
    try:
        with open(cfg_path, 'w', encoding='utf-8') as f:
            json.dump({'custom_urls': custom_urls}, f)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error guardando loader config: {e}", xbmc.LOGWARNING)

def _download_connector(url):
    ua_list = [
        {"User-Agent": "AtresDaily-SecureGateway-V1-X7"},
        {"User-Agent": "AtresDaily-Updater/SecureClient-v2 (Kr; Lnx)"}
    ]

    for headers in ua_list:
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.text) > 500:
                if 'X7-Daily-Secure-992' in r.text:
                    return r.text
        except Exception:
            pass
            
    return None

def _get_sha256(content_bytes):
    """Calcula un hash SHA-256 determinista para la integridad de binarios."""
    import hashlib
    return hashlib.sha256(content_bytes).hexdigest()

def _get_local_hash():
    connector_path = _get_connector_path()
    if not os.path.exists(connector_path):
        return None
    try:
        with open(connector_path, 'rb') as f:
            content = f.read()
        return _get_sha256(content)
    except Exception:
        return None

def _ensure_connector():
    bin_path = _get_connector_bin_path()
    
    # TTL Check (Cache Atómica sin JSON auxiliar)
    try:
        import time as _hf_time
        _cache_hours = 24
        if os.path.exists(bin_path):
            _mtime = os.path.getmtime(bin_path)
            _hours_passed = (_hf_time.time() - _mtime) / 3600
            
            if _hours_passed < _cache_hours:
                # Caché Válida (TTL OK) -> Cargar directamente
                xbmc.log(f"[AtresDaily Stealth] Caché vigente ({_hours_passed:.1f}h < {_cache_hours}h). Bypass de red.", xbmc.LOGINFO)
                if _load_stealth_module('connector', bin_path):
                    return True
    except Exception as e:
        xbmc.log(f"[AtresDaily Stealth] Error evaluando TTL de caché: {e}", xbmc.LOGWARNING)

    # Si expira o no existe, intentar actualizar
    local_hash = _get_local_hash()
    
    # Janitor
    try:
        old_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'connector.py')
        if os.path.exists(old_path):
            os.remove(old_path)
            xbmc.log("[AtresDaily Janitor] Purga de archivos obsoletos completada.", xbmc.LOGINFO)
    except Exception: pass
    
    builtin_urls = []
    for b in _DATA_NODES:
        try: builtin_urls.append(base64.b64decode(b).decode('utf-8'))
        except Exception: pass

    all_urls = builtin_urls + _load_custom_urls()
    all_urls = [u for u in all_urls if 'PLACEHOLDER' not in u and u.strip()]
    
    if not all_urls:
        if local_hash:
            return _load_stealth_module('connector', bin_path) is not None
        else:
            xbmcgui.Dialog().ok("AtresDaily - Configuración", "El módulo de conexión no está configurado.")
            return False
            
    code_bytes = None
    for url in all_urls:
        code_str = _download_connector(url)
        if code_str:
            code_bytes = code_str.encode('utf-8')
            break
            
    if code_bytes:
        remote_hash = _get_sha256(code_bytes)
        
        if local_hash == remote_hash:
            # El archivo local ya es idéntico a la red, actualizar el timestamp (touch)
            try:
                import time
                os.utime(bin_path, (time.time(), time.time()))
            except: pass
            return _load_stealth_module('connector', bin_path) is not None
        else:
            try:
                with open(bin_path, 'wb') as f:
                    f.write(code_bytes)
                return _load_stealth_module('connector', bin_path) is not None
            except Exception as e:
                xbmc.log(f"[AtresDaily Stealth] Fallo al escribir binario: {e}", xbmc.LOGERROR)
                if local_hash:
                    return _load_stealth_module('connector', bin_path) is not None
                return False
                
    # Degradación Elegante (Red Caída pero Caché Local Existente)
    if local_hash:
        xbmc.log("[AtresDaily Stealth] Fallo de red. Degradación a caché caducada.", xbmc.LOGWARNING)
        return _load_stealth_module('connector', bin_path) is not None
        
    xbmcgui.Dialog().ok(
        "AtresDaily - Módulo No Disponible",
        "No se ha podido conectar con los servidores y no hay caché local.\n\n"
        "Comprueba tu conexión o introduce una URL alternativa."
    )
    
    kb = xbmc.Keyboard('', 'URL del módulo connector.py')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        custom_url = kb.getText().strip()
        code_str = _download_connector(custom_url)
        if code_str:
            _save_custom_url(custom_url)
            try:
                with open(bin_path, 'wb') as f:
                    f.write(code_str.encode('utf-8'))
                xbmcgui.Dialog().notification("AtresDaily", "Módulo descargado", xbmcgui.NOTIFICATION_INFO)
                return _load_stealth_module('connector', bin_path) is not None
            except Exception:
                pass
        xbmcgui.Dialog().ok("Error", "No se pudo descargar el módulo desde esa URL.")
    
    return False


# --- INICIALIZAR CONECTOR ---
connector = None

# Comprobar aceptación legal ANTES de hacer nada con el conector
_cfg_init = ui_utils.load_json('settings.json')

if _cfg_init.get('legal_accepted_v2', False):
    # El usuario ha aceptado los términos -> Cargar/Descargar Conector
    if _ensure_connector():
        try:
            import sys as _sys
            connector = _sys.modules.get('connector')
            
            if not connector:
                xbmc.log("[AtresDaily Loader] Error CRÍTICO: Módulo cargado pero no encontrado en sys.modules", xbmc.LOGERROR)
                # Intento de recuperación forzada
                connector = _load_stealth_module('connector', _get_connector_bin_path())
            
            import __main__
            if not hasattr(__main__, 'exploration_history'):
                __main__.exploration_history = exploration_history
            
            if getattr(connector, '_DEBUG_MODE_BACKDOOR', False):
                 xbmc.log("[AtresDaily] HONEYPOT ACTIVADO. Integridad comprometida.", xbmc.LOGERROR)
                 xbmcgui.Dialog().ok("SISTEMA COMPROMETIDO", "ALERTA CRÍTICA DE SEGURIDAD\n\nModificación no autorizada detectada.\nEl sistema se ha bloqueado por seguridad.")
                 time.sleep(300) # Congelar ejecución
                 sys.exit()

            xbmc.log("[AtresDaily Loader] módulo conector cargado correctamente.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[AtresDaily Loader] Error al importar el conector: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("AtresDaily Error", f"Error al cargar el módulo:\n{str(e)}")
            connector = None
else:
    # Términos no aceptados -> No tocar red, no descargar, no cargar código.
    xbmc.log("[AtresDaily Loader] Términos legales no aceptados aún. Saltando carga del conector.", xbmc.LOGINFO)

# Mostrar error solo si esperábamos que funcionara (ej: términos aceptados pero carga fallida)
if connector is None and _cfg_init.get('legal_accepted_v2', False):
    xbmcgui.Dialog().ok("AtresDaily", "El addon no puede funcionar sin el módulo de conexión.\nPor favor, reinstala o contacta con el desarrollador.")


# FIN DEL CONNECTOR LOADER


# --- CONFIGURACIÓN DEL NÚCLEO ---
ADDON = xbmcaddon.Addon()
ICON_MAIN = ui_utils.ICON_MAIN
HEADERS = ui_utils.HEADERS

# --- CONFIGURACIÓN REMOTA ---
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/status.json" 
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/messages.json"
_E3 = "https://api.dailymotion.com/videos"

# --- MINI-PLUGINTOOLS INTEGRADO ---
def get_params():
    return ui_utils.get_params()



# --- COMPROBACIONES REMOTAS ---
def check_validity():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'status_check.json')
    
    # Ruta al archivo de estado local
    local_status = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'status.json')
    
    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    if os.path.exists(sf):
        st = ui_utils.load_json('status_check.json', default={'last_check': 0, 'disabled': False})
    
    if st.get('disabled', False): return False
    
    # Comprobar cada 7 días
    if now - st.get('last_check', 0) > 604800:
        data = None
        # 1. Intentar remoto
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            if r.status_code == 200: data = r.json()
        except Exception: pass
        
        # 2. Alternativa local si el remoto falla
        if not data and os.path.exists(local_status):
            try:
                with open(local_status, 'r', encoding='utf-8') as f: data = json.load(f)
            except Exception: pass
            
        if data:
            if not data.get('allowed', True):
                st['disabled'] = True
                ui_utils.save_json('status_check.json', st)
                return False
            
            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]
            
            if pv(cur_v) < pv(min_v):
                msg = data.get('message', "Tu versión está obsoleta. Actualiza el addon.")
                xbmcgui.Dialog().ok("AtresDaily", msg)
                st['disabled'] = True
                ui_utils.save_json('status_check.json', st)
                return False
            
            st['last_check'] = now
            st['disabled'] = False
            ui_utils.save_json('status_check.json', st)
            
    return True

def check_messages():
    msg = None
    # 1. Intentar remoto
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        if r.status_code == 200: msg = r.json()
    except Exception: pass
    
    # 2. Alternativa a local
    if not msg:
        local_msg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'messages.json')
        if os.path.exists(local_msg):
            try:
                with open(local_msg, 'r', encoding='utf-8') as f: msg = json.load(f)
            except Exception: pass
            
    if not msg: return
    
    mid = msg.get("id")
    mrep = msg.get("repeat", 0)
    
    if not mid or mrep == 0: return
    
    # Cargar estado local de mensajes
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    mf = 'messages_state.json'
    st = ui_utils.load_json(mf, default={})
    
    views = st.get(mid, 0)
    show_it = False
    if mrep == -1: show_it = True
    elif views < mrep: show_it = True
    
    if show_it:
        xbmcgui.Dialog().ok(msg.get("title", "Aviso"), msg.get("message", ""))
        st[mid] = views + 1
        ui_utils.save_json(mf, st)

# --- MENUS ---
class LegalScrollDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            tb = self.getControl(1)
            tb.setText(getattr(self, '_legal_text', ''))
            tb.autoScroll(2000, 4500, 0)
        except Exception as e:
            xbmc.log("[AtresDaily] LegalScrollDialog.onInit: {0}".format(e), xbmc.LOGWARNING)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP):
            self.close()

    def onClick(self, controlId):
        if controlId == 10:
            self.close()


def check_legal_compliance():
    cfg = ui_utils.load_json('settings.json')

    if cfg.get('legal_accepted_v2', False):
        return True

    addon = xbmcaddon.Addon()
    f_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    legal_text = "No se encontró el archivo AVISO_LEGAL.txt"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f:
                legal_text = f.read()
        except Exception:
            pass

    dlg = LegalScrollDialog('dialog_legal.xml', addon.getAddonInfo('path'), 'Default', '1080i')
    dlg._legal_text = legal_text
    dlg.doModal()
    del dlg

    prompt_msg = (
        "[COLOR red][B]CONSENTIMIENTO REQUERIDO[/B][/COLOR]\n\n"
        "¿Confirmas haber leído el Acuerdo y aceptas voluntariamente la política integral de uso de AtresDaily?"
    )
    
    user_accepts = xbmcgui.Dialog().yesno(
        "Términos y Condiciones", 
        prompt_msg, 
        yeslabel="SÍ, ACEPTO", 
        nolabel="RECHAZAR"
    )
    
    if user_accepts:
        cfg['legal_accepted_v2'] = True
        ui_utils.save_json('settings.json', cfg)
        verify_cfg = ui_utils.load_json('settings.json')
        if not verify_cfg.get('legal_accepted_v2', False):
            xbmcgui.Dialog().ok("Error del Sistema", "No se pudo guardar el consentimiento en el disco.\nRevisa el espacio y los permisos de la carpeta profile.")
            return False
        xbmcgui.Dialog().ok("AtresDaily", "¡Términos Aceptados!\n\nEl sistema se reiniciará para aplicar los cambios.")
        xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")
        return False
    else:
        xbmcgui.Dialog().notification("AtresDaily", "Acceso denegado. Términos rechazados.", xbmcgui.NOTIFICATION_WARNING)
        return False

def menu_root():
    # Bloqueo legal al inicio
    if not check_legal_compliance(): return

    check_messages()
    # Punto de entrada al catálogo principal del addon
    ui_utils.add_item(action="catalog_menu", title="Catálogo", thumbnail=ui_utils.media_icon("catalogo.png"), folder=True)

    ui_utils.add_item(action="input_search", title="[COLOR dodgerblue]Buscar en internet[/COLOR]", thumbnail=ui_utils.media_icon("busqueda.png"), folder=True)
    ui_utils.add_item(action="view_history", title="[COLOR aqua]Historial de Búsqueda[/COLOR]", thumbnail=ui_utils.media_icon("historial.png"), folder=True)
    ui_utils.add_item(action="live_tv_menu", title="[COLOR limegreen]Programación en Directo[/COLOR]", thumbnail=ui_utils.media_icon("directo.png"), folder=True)

    ui_utils.add_item(action="view_favorites", title="[COLOR khaki]Mis Favoritos[/COLOR]", thumbnail=ui_utils.media_icon("favoritos.png"), folder=True)
    ui_utils.add_item(action="view_downloads", title="[COLOR lightblue]Mis Descargas[/COLOR]", thumbnail=ui_utils.media_icon("descargas.png"), folder=True)
    ui_utils.add_item(action="open_url", title="[COLOR mediumpurple]Abrir URL[/COLOR]", thumbnail=ui_utils.media_icon("url.png"), folder=True, plot="Pega una URL de vídeo para reproducirla.")

    ui_utils.add_item(action="info_menu", title="EspaKodi e Información", thumbnail=ui_utils.media_icon("info.png"), folder=True)


    ui_utils.add_item(action="settings_menu", title="[COLOR ivory]Configuración[/COLOR]", thumbnail=ui_utils.media_icon("opciones.png"), folder=True)
    ui_utils.close_item_list()

def info_menu():
    """Submenú consolidado de información y activos del addon."""
    
    try:
        # Contextos de menú para mantener la funcionalidad legal
        cm_info = [
            ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
            ("REVOCAR Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
        ]
        cm_web = [("Código base de RubénSDFA1laberot", "Notification(AtresDaily, Código base de RubénSDFA1laberot, 3000)")]

        # 1. Universo EspaKodi
        ui_utils.add_item(action="show_web_info", title="Universo EspaKodi", thumbnail="DefaultIconInfo.png", folder=False, context=cm_web)

        # 2. Información Legal y Versión
        try:
            ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
        except Exception:
            ver = "?.?.?"
        
        # Botón de versión independiente
        ui_utils.add_item(action="noop", title=f"Versión {ver}", thumbnail="DefaultIconInfo.png", folder=False)

        # Estado del Repositorio (Detección de actualizador activo)
        try:
            from repository import detector
            is_val = detector.is_installed("atresdaily", "repository.atresdaily")
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallo al cargar módulo repository: {e}", xbmc.LOGWARNING)
            from ui_utils import is_repo_installed
            is_val = is_repo_installed("atresdaily", "repository.atresdaily")
            
        status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_val else "[COLOR orange]○ NO DETECTADO[/COLOR]"
        repo_title = f"Actualizaciones: {status_tag}"
        ui_utils.add_item(
            action="check_atres_repo",
            title=repo_title,
            thumbnail="DefaultAddonRepository.png",
            folder=False,
            plot="Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."
        )

        ui_utils.add_item(
            action="espakodi_addons_menu",
            title="EspaKodi addons",
            thumbnail=ui_utils.media_icon("espakodi_logo.jpg") or ui_utils.media_icon("descargas.png"),
            folder=True,
            plot="Instala los addons del proyecto EspaKodi: EspaTV, EspaDaily, LoioLog, Flow FavManager y StreamNinja."
        )

        ui_utils.add_item(action="show_info", title="Términos y Condiciones", thumbnail="DefaultIconInfo.png", folder=False, context=cm_info)

    except Exception as e:
        xbmc.log(f"[AtresDaily] Error crítico en info_menu: {e}", xbmc.LOGERROR)
    finally:
        # El cierre del handle debe ser garantizado por el bloque finally para evitar bloqueos en la UI
        ui_utils.close_item_list()


def _addon_status_label(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        pass
    if _addon_is_known(addon_id):
        return "[COLOR orange]Deshabilitado[/COLOR]"
    return "[COLOR gray]No instalado[/COLOR]"

def _addon_icon(addon_id, fallback=None):
    """Devuelve el icono del addon instalado, o el fallback si no está disponible."""
    try:
        ad = xbmcaddon.Addon(addon_id)
        path = ad.getAddonInfo('path')
        for name in ('icon.png', 'icon.jpg'):
            p = os.path.join(path, name)
            if os.path.exists(p):
                return p
    except Exception:
        pass
    return fallback or ui_utils.media_icon("play_generic.png") or "DefaultAddonVideo.png"

def espakodi_addons_menu():
    """Lista todos los instaladores de addons EspaKodi con estado y acceso a launchers."""
    try:
        ui_utils.add_item(
            action="espatv_launch",
            title=f"EspaTV — {_addon_status_label(_ESPATV_ADDON_ID)}",
            thumbnail=_addon_icon(_ESPATV_ADDON_ID, fallback=ui_utils.media_icon("directo.png")),
            folder=False,
            plot="EspaTV: TV, radio, podcast, agenda deportiva, top películas y series..."
        )
        ui_utils.add_item(
            action="espadaily_launch",
            title=f"EspaDaily — {_addon_status_label(_ESPADAILY_ADDON_ID)}",
            thumbnail=_addon_icon(_ESPADAILY_ADDON_ID),
            folder=False,
            plot="EspaDaily: contenido de RTVE y otras plataformas españolas."
        )
        ui_utils.add_item(
            action="atresdaily_launch",
            title=f"AtresDaily — {_addon_status_label(_ATRESDAILY_ADDON_ID)}",
            thumbnail=_addon_icon(_ATRESDAILY_ADDON_ID, fallback=ui_utils.ICON_MAIN),
            folder=False,
            plot="AtresDaily: catálogo de Atresplayer y búsquedas externas (este addon)."
        )
        ui_utils.add_item(
            action="loiolog_launch",
            title=f"LoioLog — {_addon_status_label(_LOIOLOG_ADDON_ID)}",
            thumbnail=_addon_icon(_LOIOLOG_ADDON_ID, fallback=ui_utils.media_icon("adv_log.png")),
            folder=False,
            plot="LoioLog: visor avanzado de logs de Kodi con filtros y exportación."
        )
        ui_utils.add_item(
            action="flowfav_launch",
            title=f"Flow FavManager — {_addon_status_label(_FLOWFAV_ADDON_ID)}",
            thumbnail=_addon_icon(_FLOWFAV_ADDON_ID, fallback=ui_utils.media_icon("favoritos.png")),
            folder=False,
            plot="Flow FavManager: gestor avanzado de favoritos para Kodi."
        )
        ui_utils.add_item(
            action="streamninja_launch",
            title=f"StreamNinja — {_addon_status_label(_STREAMNINJA_ADDON_ID)}",
            thumbnail=_addon_icon(_STREAMNINJA_ADDON_ID, fallback=ui_utils.media_icon("srch_externa.png")),
            folder=False,
            plot="StreamNinja: extracción neutral de flujos de vídeo públicamente accesibles."
        )
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error en espakodi_addons_menu: {e}", xbmc.LOGERROR)
    finally:
        ui_utils.close_item_list()

def history_menu():
    """Submenú que agrupa Historial de Exploración e Historial de Reproducciones."""
    ui_utils.add_item(action="exp_menu", title="[COLOR cyan]Historial de Exploración[/COLOR]", thumbnail="DefaultAddonService.png", folder=True)
    ui_utils.add_item(action="watch_history", title="[COLOR mediumpurple]Historial de Reproducciones[/COLOR]", thumbnail="DefaultRecentlyAddedMovies.png", folder=True)
    ui_utils.close_item_list()

# --- INSTALADOR DEL ADDON ESPADAILY ---
_ESPADAILY_ADDON_ID = "plugin.video.espadaily"
_ESPADAILY_REPO_ID  = "repository.espadaily"
_ESPADAILY_REPO_ZIP = "https://espatv.github.io/espadaily/repository.espadaily-1.0.0.zip"
_ESPADAILY_SOURCE   = "https://espatv.github.io/espadaily/"

def _espadaily_show_instructions():
    t = (
        "[B]Cómo instalar EspaDaily manualmente[/B]\n\n"
        "[B]1.[/B] Kodi → Ajustes → Sistema → Addons\n"
        "     Activa [B]Orígenes desconocidos[/B]\n\n"
        "[B]2.[/B] Kodi → Ajustes → Gestor de archivos → Añadir fuente\n"
        f"     URL: {_ESPADAILY_SOURCE}\n"
        "     Nombre: EspaDaily\n\n"
        "[B]3.[/B] Inicio → Addons → Instalar desde archivo zip\n"
        "     Selecciona [B]EspaDaily[/B] → repository.espadaily-x.x.x.zip\n"
        "     Espera la notificación de repositorio instalado\n\n"
        "[B]4.[/B] Addons → Instalar desde repositorio → EspaDaily\n"
        "     Addons de vídeo → EspaDaily → Instalar\n\n"
        "GitHub: https://github.com/espatv/espadaily"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — EspaDaily", t)

def _espadaily_install():
    try:
        xbmcaddon.Addon(_ESPADAILY_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo EspaDaily...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_ESPADAILY_ADDON_ID})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_ESPADAILY_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "EspaDaily no está instalado pero el repositorio sí.\n\n¿Instalar EspaDaily ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_ESPADAILY_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de EspaDaily.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "EspaDaily no está instalado.\n\n¿Descargar e instalar automáticamente?\n[I](puede fallar si el origen no está permitido)[/I]"):
        return

    _install_repo_and_addon(_ESPADAILY_ADDON_ID, _ESPADAILY_REPO_ID, _ESPADAILY_REPO_ZIP, "EspaDaily")

def _espadaily_launch():
    try:
        xbmcaddon.Addon(_ESPADAILY_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo EspaDaily...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_ESPADAILY_ADDON_ID})")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("EspaDaily — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _espadaily_install()
    elif idx == 1:
        _espadaily_show_instructions()

def show_vpn_info():
    quitar = xbmcgui.Dialog().yesno(
        "Consejo",
        "Si tienes problemas para acceder al catálogo, desactiva la VPN.",
        nolabel="Quitar mensaje",
        yeslabel="OK",
        defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
    )
    if not quitar:
        xbmcaddon.Addon().setSetting('hide_vpn_info', 'true')
        xbmc.executebuiltin("Container.Refresh")


# --- HELPER COMÚN: DESCARGA REPO + INSTALA ADDON CON ESPERA ACTIVA ---
_REPO_POLL_TIMEOUT_S   = 20
_ADDON_POLL_TIMEOUT_S  = 60
_POLL_INTERVAL_MS      = 500
_MAX_REPO_ZIP_BYTES    = 50 * 1024 * 1024
_MAX_ADDON_ZIP_BYTES   = 200 * 1024 * 1024


def _addon_is_installed(addon_id):
    """Estricto: True solo si Kodi reconoce el addon (registrado y habilitado).
    Coincide con el criterio de _addon_status_label."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def _addon_dir_present(addon_id):
    """Solo disco: los archivos del addon existen aunque Kodi no lo reconozca todavía."""
    addon_dir = xbmcvfs.translatePath(f"special://home/addons/{addon_id}/")
    return os.path.isdir(addon_dir) and os.path.isfile(os.path.join(addon_dir, 'addon.xml'))


def _jsonrpc(method, params=None):
    """Llama a JSON-RPC interno de Kodi y devuelve la respuesta parseada."""
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return {}


def _addon_is_known(addon_id):
    """True si Kodi conoce el addon (instalado), aunque esté deshabilitado.
    Usa JSON-RPC porque xbmcaddon.Addon() falla con addons deshabilitados."""
    resp = _jsonrpc("Addons.GetAddonDetails", {
        "addonid": addon_id,
        "properties": ["enabled"]
    })
    return "result" in resp and "addon" in resp.get("result", {})


def _enable_addon_jsonrpc(addon_id):
    """Habilita un addon vía JSON-RPC (síncrono, devuelve error si falla)."""
    resp = _jsonrpc("Addons.SetAddonEnabled", {
        "addonid": addon_id,
        "enabled": True
    })
    return resp.get("result") == "OK"


def _try_recover_addon(addon_id):
    """Recovery en cascada para tres escenarios:
    1) Addon registrado pero deshabilitado → JSON-RPC SetAddonEnabled.
    2) Archivos en disco pero no registrado → UpdateLocalAddons + Enable.
    3) Builtin EnableAddon como último recurso (algunas plataformas lo prefieren)."""
    # Caso 1: registrado pero deshabilitado — el más rápido y común
    if _addon_is_known(addon_id):
        if _enable_addon_jsonrpc(addon_id):
            xbmc.sleep(800)
            if _addon_is_installed(addon_id):
                return True

    # Caso 2: archivos en disco pero no registrado
    if not _addon_dir_present(addon_id):
        return False

    xbmc.executebuiltin("UpdateLocalAddons()")
    xbmc.sleep(1500)

    # Tras UpdateLocalAddons, reintentamos JSON-RPC
    if _addon_is_known(addon_id) and _enable_addon_jsonrpc(addon_id):
        xbmc.sleep(800)
        if _addon_is_installed(addon_id):
            return True

    # Caso 3: builtin como último recurso
    xbmc.executebuiltin(f"EnableAddon({addon_id})")
    xbmc.sleep(1500)
    return _addon_is_installed(addon_id)


def _get_repo_datadir(repo_id):
    """Lee el addon.xml del repo recién extraído y devuelve la URL <datadir>."""
    repo_xml = xbmcvfs.translatePath(f"special://home/addons/{repo_id}/addon.xml")
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        m = re.search(r'<datadir[^>]*>\s*([^<\s]+)\s*</datadir>', content)
        if m:
            url = m.group(1).strip()
            if not url.endswith('/'):
                url += '/'
            return url
    except Exception as e:
        xbmc.log(f"[AtresDaily] No se pudo leer datadir del repo {repo_id}: {e}", xbmc.LOGWARNING)
    return None


def _find_addon_version_in_index(addons_xml_text, addon_id):
    """Parsea addons.xml del repo y devuelve la version del addon_id, o None."""
    try:
        m = re.search(
            r'<addon[^>]*\bid="' + re.escape(addon_id) + r'"[^>]*\bversion="([^"]+)"',
            addons_xml_text
        )
        if m: return m.group(1)
        m = re.search(
            r'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="' + re.escape(addon_id) + r'"',
            addons_xml_text
        )
        if m: return m.group(1)
    except Exception:
        pass
    return None


def _install_addon_zip_directly(addon_id, repo_id, friendly_name):
    """Fallback: descarga e instala el ZIP del addon manualmente desde el datadir del repo."""
    try:
        datadir = _get_repo_datadir(repo_id)
        if not datadir:
            xbmc.log(f"[AtresDaily] Fallback ({friendly_name}): no se pudo obtener datadir de {repo_id}", xbmc.LOGWARNING)
            return False

        try:
            r = requests.get(datadir + 'addons.xml', timeout=20)
            if r.status_code != 200:
                xbmc.log(f"[AtresDaily] Fallback: addons.xml HTTP {r.status_code}", xbmc.LOGWARNING)
                return False
            addons_xml = r.text
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallback: error al descargar addons.xml: {e}", xbmc.LOGWARNING)
            return False

        version = _find_addon_version_in_index(addons_xml, addon_id)
        if not version:
            xbmc.log(f"[AtresDaily] Fallback: no se encontró {addon_id} en addons.xml", xbmc.LOGWARNING)
            return False

        addon_zip_url = f"{datadir}{addon_id}/{addon_id}-{version}.zip"
        xbmc.log(f"[AtresDaily] Fallback: descargando {addon_zip_url}", xbmc.LOGINFO)

        try:
            r = requests.get(addon_zip_url, timeout=60)
            if r.status_code != 200:
                xbmc.log(f"[AtresDaily] Fallback: ZIP HTTP {r.status_code}", xbmc.LOGWARNING)
                return False
            if len(r.content) < 4 or r.content[:2] != b'PK':
                xbmc.log(f"[AtresDaily] Fallback: ZIP inválido", xbmc.LOGWARNING)
                return False
            if len(r.content) > _MAX_ADDON_ZIP_BYTES:
                xbmc.log(f"[AtresDaily] Fallback: ZIP demasiado grande", xbmc.LOGWARNING)
                return False
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallback: error descargando ZIP del addon: {e}", xbmc.LOGWARNING)
            return False

        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        addons_dir_real = os.path.realpath(addons_dir)
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{addon_id}-{version}.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)

        import zipfile
        with zipfile.ZipFile(zip_path, "r") as zf:
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if not resolved.startswith(addons_dir_real):
                    raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
            zf.extractall(addons_dir)

        try: os.remove(zip_path)
        except Exception: pass

        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin(f"EnableAddon({addon_id})")
        xbmc.sleep(1500)

        for _ in range(20):
            if _addon_is_installed(addon_id):
                return True
            xbmc.executebuiltin(f"EnableAddon({addon_id})")
            xbmc.sleep(_POLL_INTERVAL_MS)

        # Último intento: forzar UpdateLocalAddons + EnableAddon una vez más
        return _try_recover_addon(addon_id) or _addon_is_installed(addon_id)

    except Exception as e:
        xbmc.log(f"[AtresDaily] Fallback excepción: {e}", xbmc.LOGERROR)
        return False


def _install_repo_and_addon(addon_id, repo_id, repo_zip_url, friendly_name):
    """Descarga el ZIP del repo, lo extrae y solicita la instalación del addon.

    Estrategia:
      1) Descargar y extraer repo.
      2) UpdateLocalAddons + esperar a que el repo se registre.
      3) EnableAddon(repo) + UpdateAddonRepos para forzar fetch del índice.
      4) InstallAddon(addon) — abre el confirm modal de Kodi.
      5) Polling con detección por API + disco.
      6) Si falla, fallback automático: descarga el ZIP del addon desde el datadir del repo y lo extrae.

    Devuelve True si el addon queda instalado.
    """
    if _addon_is_installed(addon_id):
        xbmcgui.Dialog().notification("AtresDaily", f"{friendly_name} ya está instalado", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True

    # Si está deshabilitado o hay restos en disco, intentamos recuperarlo antes de reinstalar.
    if _try_recover_addon(addon_id):
        xbmcgui.Dialog().notification("AtresDaily", f"{friendly_name} reactivado correctamente", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", f"Descargando repositorio de {friendly_name}...")
    zip_path = None
    bg = None

    try:
        dp.update(5, "Descargando repositorio...")
        r = requests.get(repo_zip_url, timeout=30)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")
        if len(r.content) < 4 or r.content[:2] != b'PK':
            raise Exception("El archivo descargado no es un ZIP válido")
        if len(r.content) > _MAX_REPO_ZIP_BYTES:
            raise Exception(f"Tamaño sospechoso: {len(r.content) // 1024}KB")

        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{repo_id}.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)

        dp.update(20, "Extrayendo repositorio...")
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        addons_dir_real = os.path.realpath(addons_dir)
        import zipfile
        with zipfile.ZipFile(zip_path, "r") as zf:
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if not resolved.startswith(addons_dir_real):
                    raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
            zf.extractall(addons_dir)

        dp.update(35, "Registrando repositorio en Kodi...")
        xbmc.executebuiltin("UpdateLocalAddons()")

        # Esperamos a que Kodi registre el repo. Reintentamos EnableAddon en
        # iteraciones intermedias porque algunos repos extraídos quedan deshabilitados.
        repo_iters = (_REPO_POLL_TIMEOUT_S * 1000) // _POLL_INTERVAL_MS
        repo_ready = False
        for i in range(repo_iters):
            if dp.iscanceled():
                raise Exception("Cancelado por el usuario")
            try:
                xbmcaddon.Addon(repo_id)
                repo_ready = True
                break
            except Exception:
                if i in (4, 12, 24):
                    xbmc.executebuiltin(f"EnableAddon({repo_id})")
                xbmc.sleep(_POLL_INTERVAL_MS)

        if not repo_ready:
            raise Exception(f"Kodi no registró el repositorio tras {_REPO_POLL_TIMEOUT_S}s")

        dp.update(55, "Activando repositorio...")
        xbmc.executebuiltin(f"EnableAddon({repo_id})")
        xbmc.sleep(1500)

        # Forzamos fetch del índice del repo: sin esto, InstallAddon a veces no
        # encuentra el addon porque Kodi no ha bajado todavía addons.xml del repo.
        dp.update(65, "Actualizando índice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)

        # Cerrar el progress antes de InstallAddon: Kodi abre su propio modal
        # de confirmación y dos diálogos modales superpuestos confunden al usuario.
        dp.close()

        xbmcgui.Dialog().notification("AtresDaily", f"Confirma la instalación de {friendly_name}", xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin(f"InstallAddon({addon_id})")

        bg = xbmcgui.DialogProgressBG()
        bg.create("AtresDaily", f"Esperando instalación de {friendly_name}...")

        addon_iters = (_ADDON_POLL_TIMEOUT_S * 1000) // _POLL_INTERVAL_MS
        addon_ready = False
        for i in range(addon_iters):
            if _addon_is_installed(addon_id):
                addon_ready = True
                break
            xbmc.sleep(_POLL_INTERVAL_MS)
            pct = min(int((i + 1) * 100 / addon_iters), 99)
            bg.update(pct, "AtresDaily", f"Esperando instalación de {friendly_name}...")

        bg.close()
        bg = None

        # Si el polling acabó sin éxito pero los archivos están en disco, intentamos recuperar.
        if not addon_ready and _try_recover_addon(addon_id):
            addon_ready = True

        if addon_ready:
            xbmcgui.Dialog().notification("AtresDaily", f"{friendly_name} instalado correctamente", xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True

        # FALLBACK: InstallAddon no completó. Intentamos descargar e instalar el ZIP directamente.
        bg = xbmcgui.DialogProgressBG()
        bg.create("AtresDaily", f"Instalación automática de {friendly_name} (fallback)...")
        bg.update(50)
        ok = _install_addon_zip_directly(addon_id, repo_id, friendly_name)
        bg.close()
        bg = None

        if ok:
            xbmcgui.Dialog().notification("AtresDaily", f"{friendly_name} instalado correctamente", xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True

        xbmcgui.Dialog().ok(
            "AtresDaily",
            f"El repositorio de {friendly_name} se instaló, pero la instalación del addon no se completó.\n\n"
            f"Para terminarla manualmente:\n"
            f"Addons → Instalar desde repositorio → {friendly_name} → Instalar"
        )
        return False

    except Exception as e:
        try: dp.close()
        except Exception: pass
        if bg:
            try: bg.close()
            except Exception: pass
        xbmc.log(f"[AtresDaily] Error instalando {friendly_name}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Error de instalación",
            f"No se pudo instalar {friendly_name} automáticamente.\n\nError: {e}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes."
        )
        return False

    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


# --- INSTALADOR DEL ADDON ESPATV ---
_ESPATV_ADDON_ID = "plugin.video.espatv"
_ESPATV_REPO_ID = "repository.espatv"
_ESPATV_REPO_ZIP = "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip"
_ESPATV_SOURCE   = "https://espakodi.github.io/espatv/"

def _espatv_show_instructions():
    t = (
        "[B]Cómo instalar EspaTV manualmente[/B]\n\n"
        "[B]1.[/B] Kodi → Ajustes → Sistema → Addons\n"
        "     Activa [B]Orígenes desconocidos[/B]\n\n"
        "[B]2.[/B] Kodi → Ajustes → Gestor de archivos → Añadir fuente\n"
        f"     URL: {_ESPATV_SOURCE}\n"
        "     Nombre: EspaTV\n\n"
        "[B]3.[/B] Inicio → Addons → Instalar desde archivo zip\n"
        "     Selecciona [B]EspaTV[/B] → repository.espatv-x.x.x.zip\n"
        "     Espera la notificación de repositorio instalado\n\n"
        "[B]4.[/B] Addons → Instalar desde repositorio → EspaTV\n"
        "     Addons de vídeo → EspaTV → Instalar"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — EspaTV", t)

def _espatv_install():
    try:
        xbmcaddon.Addon(_ESPATV_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo EspaTV...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_ESPATV_ADDON_ID})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_ESPATV_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "EspaTV no está instalado pero el repositorio sí.\n\n¿Instalar EspaTV ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_ESPATV_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de EspaTV.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "EspaTV no está instalado.\n\n¿Descargar e instalar automáticamente?"):
        return

    _install_repo_and_addon(_ESPATV_ADDON_ID, _ESPATV_REPO_ID, _ESPATV_REPO_ZIP, "EspaTV")

def _espatv_launch():
    try:
        xbmcaddon.Addon(_ESPATV_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo EspaTV...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_ESPATV_ADDON_ID})")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("EspaTV — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _espatv_install()
    elif idx == 1:
        _espatv_show_instructions()


# --- INSTALADOR DEL ADDON LOIOLOG ---
_LOIOLOG_ADDON_ID = "plugin.program.loiolog"
_LOIOLOG_REPO_ID = "repository.loiolog"
_LOIOLOG_REPO_ZIP = "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip"
_LOIOLOG_SOURCE   = "https://loioloio.github.io/loiolog/"

def _loiolog_show_instructions():
    t = (
        "[B]Cómo instalar LoioLog manualmente[/B]\n\n"
        "[B]1.[/B] Kodi → Ajustes → Sistema → Addons\n"
        "     Activa [B]Orígenes desconocidos[/B]\n\n"
        "[B]2.[/B] Kodi → Ajustes → Gestor de archivos → Añadir fuente\n"
        f"     URL: {_LOIOLOG_SOURCE}\n"
        "     Nombre: LoioLog\n\n"
        "[B]3.[/B] Inicio → Addons → Instalar desde archivo zip\n"
        "     Selecciona [B]LoioLog[/B] → repository.loiolog-x.x.x.zip\n"
        "     Espera la notificación de repositorio instalado\n\n"
        "[B]4.[/B] Addons → Instalar desde repositorio → LoioLog\n"
        "     Addons de programa → LoioLog → Instalar"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — LoioLog", t)

def _loiolog_install():
    try:
        xbmcaddon.Addon(_LOIOLOG_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo LoioLog...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_LOIOLOG_ADDON_ID})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_LOIOLOG_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "LoioLog no está instalado pero el repositorio sí.\n\n¿Instalar LoioLog ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_LOIOLOG_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de LoioLog.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "LoioLog no está instalado.\n\n¿Descargar e instalar automáticamente?"):
        return

    _install_repo_and_addon(_LOIOLOG_ADDON_ID, _LOIOLOG_REPO_ID, _LOIOLOG_REPO_ZIP, "LoioLog")

def _loiolog_launch():
    try:
        xbmcaddon.Addon(_LOIOLOG_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo LoioLog...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_LOIOLOG_ADDON_ID})")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("LoioLog — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _loiolog_install()
    elif idx == 1:
        _loiolog_show_instructions()


# --- INSTALADOR DEL ADDON FLOW FAVMANAGER ---
_FLOWFAV_ADDON_ID = "plugin.program.flowfavmanager"
_FLOWFAV_REPO_ID  = "repository.flowfavmanager"
_FLOWFAV_REPO_ZIP = "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip"
_FLOWFAV_SOURCE   = "https://loioloio.github.io/flowfav/"

def _flowfav_show_instructions():
    t = (
        "[B]Flow FavManager[/B] — gestor avanzado de favoritos para Kodi.\n"
        "Permite organizar, personalizar colores, iconos, formatos, acciones,\n"
        "crear secciones, perfiles y copias de seguridad.\n\n"
        "[B]Opción 1: Desde el Administrador de Archivos de Kodi (Recomendado)[/B]\n"
        "1. Ajustes → Sistema → Addons → activa [B]Orígenes desconocidos[/B]\n"
        "2. Ajustes → Explorador de archivos → Añadir fuente\n"
        f"3. URL: {_FLOWFAV_SOURCE}\n"
        "   IMPORTANTE: NO uses la URL de github.com (no funciona en Kodi)\n"
        "4. Nombre: flowfav\n"
        "5. Inicio → Add-ons → icono de cajita → Instalar desde archivo zip\n"
        "6. Selecciona la fuente flowfav → repository.flowfavmanager-1.0.0.zip\n"
        "7. Espera la notificación de Add-on instalado\n"
        "8. Instalar desde repositorio → Flow FavManager Repository →\n"
        "   Program add-ons → Flow FavManager → Instalar\n\n"
        "[B]Opción 2: ZIP manual[/B]\n"
        "1. Descarga repository.flowfavmanager-1.0.0.zip desde:\n"
        "   https://github.com/loioloio/flowfav/releases\n"
        "2. Add-ons → cajita → Instalar desde archivo zip → seleccionarlo"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — Flow FavManager", t)

def _flowfav_install():
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo Flow FavManager...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_FLOWFAV_ADDON_ID})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_FLOWFAV_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "Flow FavManager no está instalado pero el repositorio sí.\n\n¿Instalar Flow FavManager ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_FLOWFAV_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de Flow FavManager.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "Flow FavManager no está instalado.\n\n¿Descargar e instalar automáticamente?\n[I](puede fallar si el origen no está permitido)[/I]"):
        return

    _install_repo_and_addon(_FLOWFAV_ADDON_ID, _FLOWFAV_REPO_ID, _FLOWFAV_REPO_ZIP, "Flow FavManager")

def _flowfav_launch():
    try:
        xbmcaddon.Addon(_FLOWFAV_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo Flow FavManager...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_FLOWFAV_ADDON_ID})")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("Flow FavManager — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _flowfav_install()
    elif idx == 1:
        _flowfav_show_instructions()


# --- INSTALADOR DEL ADDON STREAMNINJA ---
_STREAMNINJA_ADDON_ID = "plugin.video.streamninja"
_STREAMNINJA_REPO_ID  = "repository.streamninja"
_STREAMNINJA_REPO_ZIP = "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip"
_STREAMNINJA_SOURCE   = "https://fullstackcurso.github.io/estreamninja/"

def _streamninja_show_instructions():
    t = (
        "[B]Cómo instalar StreamNinja manualmente[/B]\n\n"
        "[B]1.[/B] Kodi → Ajustes → Sistema → Addons\n"
        "     Activa [B]Orígenes desconocidos[/B]\n\n"
        "[B]2.[/B] Kodi → Ajustes → Gestor de archivos → Añadir fuente\n"
        f"     URL: {_STREAMNINJA_SOURCE}\n"
        "     Nombre: StreamNinja\n\n"
        "[B]3.[/B] Inicio → Addons → Instalar desde archivo zip\n"
        "     Selecciona [B]StreamNinja[/B] → repository.streamninja-x.x.x.zip\n"
        "     Espera la notificación de repositorio instalado\n\n"
        "[B]4.[/B] Addons → Instalar desde repositorio → StreamNinja\n"
        "     Addons de vídeo → StreamNinja → Instalar\n\n"
        "GitHub: https://github.com/fullstackcurso/estreamninja"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — StreamNinja", t)

def _streamninja_install():
    try:
        xbmcaddon.Addon(_STREAMNINJA_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_STREAMNINJA_ADDON_ID})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_STREAMNINJA_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "StreamNinja no está instalado pero el repositorio sí.\n\n¿Instalar StreamNinja ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_STREAMNINJA_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de StreamNinja.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "StreamNinja no está instalado.\n\n¿Descargar e instalar automáticamente?\n[I](puede fallar si el origen no está permitido)[/I]"):
        return

    _install_repo_and_addon(_STREAMNINJA_ADDON_ID, _STREAMNINJA_REPO_ID, _STREAMNINJA_REPO_ZIP, "StreamNinja")

def _streamninja_launch():
    try:
        xbmcaddon.Addon(_STREAMNINJA_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({_STREAMNINJA_ADDON_ID})")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("StreamNinja — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _streamninja_install()
    elif idx == 1:
        _streamninja_show_instructions()


# --- INSTALADOR DEL ADDON ATRESDAILY ---
_ATRESDAILY_ADDON_ID = "plugin.video.atresdaily"
_ATRESDAILY_REPO_ID  = "repository.atresdaily"
_ATRESDAILY_REPO_ZIP = "https://fullstackcurso.github.io/atresdaily/repository.atresdaily-1.0.1.zip"
_ATRESDAILY_SOURCE   = "https://fullstackcurso.github.io/atresdaily/"

def _atresdaily_show_instructions():
    t = (
        "[B]Cómo instalar AtresDaily manualmente[/B]\n\n"
        "[B]1.[/B] Kodi → Ajustes → Sistema → Addons\n"
        "     Activa [B]Orígenes desconocidos[/B]\n\n"
        "[B]2.[/B] Kodi → Ajustes → Gestor de archivos → Añadir fuente\n"
        f"     URL: {_ATRESDAILY_SOURCE}\n"
        "     Nombre: AtresDaily\n\n"
        "[B]3.[/B] Inicio → Addons → Instalar desde archivo zip\n"
        "     Selecciona [B]AtresDaily[/B] → repository.atresdaily-x.x.x.zip\n"
        "     Espera la notificación de repositorio instalado\n\n"
        "[B]4.[/B] Addons → Instalar desde repositorio → AtresDaily\n"
        "     Addons de vídeo → AtresDaily → Instalar\n\n"
        "GitHub: https://github.com/fullstackcurso/atresdaily"
    )
    xbmcgui.Dialog().textviewer("Instrucciones — AtresDaily", t)

def _atresdaily_install():
    try:
        xbmcaddon.Addon(_ATRESDAILY_ADDON_ID)
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo AtresDaily...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"Container.Update(plugin://{_ATRESDAILY_ADDON_ID}/,replace)")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_ATRESDAILY_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", "AtresDaily no está instalado pero el repositorio sí.\n\n¿Instalar AtresDaily ahora?"):
            xbmc.executebuiltin(f"InstallAddon({_ATRESDAILY_ADDON_ID})")
            xbmcgui.Dialog().ok("AtresDaily", "Se ha solicitado la instalación de AtresDaily.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    if not xbmcgui.Dialog().yesno("AtresDaily", "AtresDaily no está instalado.\n\n¿Descargar e instalar automáticamente?\n[I](puede fallar si el origen no está permitido)[/I]"):
        return

    _install_repo_and_addon(_ATRESDAILY_ADDON_ID, _ATRESDAILY_REPO_ID, _ATRESDAILY_REPO_ZIP, "AtresDaily")

def _atresdaily_launch():
    try:
        xbmcaddon.Addon(_ATRESDAILY_ADDON_ID)
        xbmc.executebuiltin(f"Container.Update(plugin://{_ATRESDAILY_ADDON_ID}/,replace)")
        return
    except Exception:
        pass

    opciones = ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"]
    idx = xbmcgui.Dialog().select("AtresDaily — ¿Cómo quieres instalarlo?", opciones)
    if idx == 0:
        _atresdaily_install()
    elif idx == 1:
        _atresdaily_show_instructions()


# --- INSTALADOR DEL ADDON SLYGUY ---
_SLYGUY_REPO_ID = "repository.slyguy"
_SLYGUY_REPO_ZIP = "https://k.slyguy.xyz/repository.slyguy.zip"

def _slyguy_install(addon_id, addon_name):
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("AtresDaily", f"Abriendo {addon_name}...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({addon_id})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_SLYGUY_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", f"{addon_name} no está instalado pero el repositorio SlyGuy sí.\n\n¿Instalar {addon_name} ahora?"):
            xbmc.executebuiltin(f"InstallAddon({addon_id})")
            xbmcgui.Dialog().ok("AtresDaily", f"Se ha solicitado la instalación de {addon_name}.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve al Catálogo y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    opts = [
        "Instalar repositorio automáticamente",
        "Ver instrucciones manuales",
    ]
    sel = xbmcgui.Dialog().select(
        f"Se necesita el repo SlyGuy para {addon_name}", opts
    )

    if sel == 0:
        _auto_install_slyguy_repo(addon_id, addon_name)
    elif sel == 1:
        _show_slyguy_instructions(addon_name)

def _auto_install_slyguy_repo(addon_id, addon_name):
    """Descarga e instala el repo SlyGuy automáticamente."""
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Descargando repositorio SlyGuy...")
    zip_path = None

    try:
        # Descargar ZIP del repo
        dp.update(10, "Descargando repositorio...")
        r = requests.get(_SLYGUY_REPO_ZIP, timeout=30)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        # Validar que el contenido es un ZIP real (magic bytes: PK\x03\x04)
        if len(r.content) < 4 or r.content[:2] != b'PK':
            raise Exception("El archivo descargado no es un ZIP válido")

        # Validar tamaño razonable (no debería ser >50MB para un repo)
        if len(r.content) > 50 * 1024 * 1024:
            raise Exception(f"Tamaño sospechoso: {len(r.content) // 1024}KB")

        # Guardar en temp
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "repository.slyguy.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)

        dp.update(50, "Extrayendo repositorio...")

        # Extraer al directorio de addons con validación de seguridad
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        import zipfile
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Protección contra path traversal
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if not resolved.startswith(os.path.realpath(addons_dir)):
                    raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
            zf.extractall(addons_dir)

        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(2000)

        # Activar el repo
        xbmc.executebuiltin(f"EnableAddon({_SLYGUY_REPO_ID})")
        xbmc.sleep(1000)

        dp.update(90, f"Instalando {addon_name}...")
        xbmc.executebuiltin(f"InstallAddon({addon_id})")

        dp.close()
        xbmcgui.Dialog().notification("AtresDaily", f"Repo SlyGuy instalado. Instalando {addon_name}...", xbmcgui.NOTIFICATION_INFO, 5000)

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error instalando repo SlyGuy: {e}", xbmc.LOGERROR)

        # Si falla (ej: orígenes desconocidos desactivados)
        choice = xbmcgui.Dialog().yesno(
            "Error de instalación",
            f"No se pudo instalar automáticamente.\n\n"
            f"Error: {e}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?",
        )
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        # Limpiar ZIP temporal siempre
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass

def _show_slyguy_instructions(addon_name):
    """Muestra instrucciones para instalar el repo SlyGuy manualmente."""
    t = (
        f"[B]Cómo instalar {addon_name}[/B]\n\n"
        "1. Ve a [B]Ajustes → Sistema → Addons[/B]\n"
        "   Activa [B]Orígenes desconocidos[/B]\n\n"
        "2. Ve a [B]Ajustes → Administrador de archivos[/B]\n"
        "   Añade fuente: [B]https://k.slyguy.xyz[/B]\n"
        "   Nombre: [B]slyguy[/B]\n\n"
        "3. Ve a [B]Addons → Instalar desde ZIP[/B]\n"
        "   Selecciona [B]slyguy → repository.slyguy.zip[/B]\n\n"
        f"4. Ve a [B]Addons → Instalar desde repositorio[/B]\n"
        f"   SlyGuy → Video addons → [B]{addon_name}[/B]\n\n"
        "Tras instalarlo, vuelve al Catálogo de AtresDaily y pulsa de nuevo."
    )
    xbmcgui.Dialog().textviewer(f"Instalar {addon_name}", t)

def catalog_menu():
    # 1. Botones de Gestión de Contenidos
    # [Categorías / Carpetas]
    items_count = len(category_manager.load_cats())
    li = xbmcgui.ListItem(label=f"[COLOR white][Categorías / Carpetas] ({items_count})[/COLOR]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=cat_menu", listitem=li, isFolder=True)

    # [Historial]
    li = xbmcgui.ListItem(label="[COLOR white]Historial[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('historial.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=history_menu", listitem=li, isFolder=True)

    # 2. Categorías Originales con Iconos Profesionales (Cargados por Usuario)
    icon_map = {
        "Series": "tv.png",
        "Programas": "pelis.png",
        "Documentales": "documentales.png",
        "Infantil": "dibus.png",
        "Actualidad": "noticias.png",
        "Cine": "cine.png",
        "Extra": "extra.png"
    }
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    
    cats_dict = getattr(connector, "CATS", {})
    for k, v in cats_dict.items():
        thumb = "DefaultFolder.png"
        if k in icon_map:
            # Construir ruta absoluta al nuevo icono
            icon_file = os.path.join(addon_path, "resources", "media", icon_map[k])
            if os.path.exists(icon_file):
                thumb = icon_file
                
        ui_utils.add_item(action="list_cat", title=k, url=v, thumbnail=thumb, folder=True)

    # [Listas de Trakt.tv]
    li = xbmcgui.ListItem(label="Trakt.tv")
    li.setArt({'icon': ui_utils.media_icon("adv_trakt.png") or 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=trakt_root", listitem=li, isFolder=True)

    # EspaTV
    try:
        xbmcaddon.Addon(_ESPATV_ADDON_ID)
        espatv_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        espatv_status = "[COLOR gray]No instalado[/COLOR]"
    li = xbmcgui.ListItem(label=f"[COLOR red]Es[/COLOR][COLOR gold]pa[/COLOR][COLOR red]TV[/COLOR] — TV, radio, podcast, agenda deportiva, top películas y series y más — {espatv_status}")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot':
        "[B]EspaTV[/B] - Addon todo-en-uno para contenido en castellano\n\n"
        "TV, Dailymotion, YouTube, radio, podcast, agenda deportiva, top películas y series y más.\n\n"
        "Pulsa para abrir o instalar automáticamente.\n\n"
        "https://github.com/espakodi/espatv"
    })
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=espatv_install", listitem=li, isFolder=False)

    # Publi EspaDaily
    li = xbmcgui.ListItem(label="[COLOR gold]Espa[/COLOR][COLOR blue]Daily[/COLOR] — Más contenido: RTVE, Mitele y otras")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot':
        "[B]EspaDaily[/B] - Addon complementario de AtresDaily\n\n"
        "Accede al contenido de RTVE, Mitele y otras plataformas españolas.\n\n"
        "Búscalo como plugin.video.espadaily o visita:\n"
        "https://github.com/fullstackcurso"
    })
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=espadaily_launch", listitem=li, isFolder=False)

    # Boton de alerta de conexion (VPN)
    if xbmcaddon.Addon().getSetting('hide_vpn_info') != 'true':
        li = xbmcgui.ListItem(label="[COLOR gold]Si tienes problemas para acceder al catalogo, desactiva la VPN[/COLOR]")
        li.setArt({'icon': 'DefaultIconWarning.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=show_vpn_info", listitem=li, isFolder=False)

    ui_utils.close_item_list()

def settings_menu():
    cfg = ui_utils.load_json('settings.json')
    
    # 1. Menú de Búsqueda
    if cfg.get('advanced_search_active', True):
        m_label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        m_plot = "MENÚ AVANZADO: Muestra opciones de búsqueda (Modo Cine, HD, Recientes) antes de buscar.\n\n[I]Pulsa para volver a búsqueda directa.[/I]"
    else:
        m_label = "Menú de Búsqueda: [COLOR gray]SIMPLE (Directa)[/COLOR]"
        m_plot = "BÚSQUEDA DIRECTA: Abre el teclado y busca inmediatamente sin preguntar.\n\n[I]Pulsa para activar menú avanzado.[/I]"
    ui_utils.add_item(action="toggle_advanced_search", title=m_label, thumbnail=ui_utils.media_icon("adv_busqueda.png"), folder=False, plot=m_plot)

    # 2. Priorización
    if cfg.get('prioritize_match_active', False):
        p_label = "Priorizar: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        p_plot = "PRIORIZAR AJUSTE: Se busca la coincidencia exacta de palabras en el título del vídeo sobre la duración.\n\n[I]Pulsa para activar modo duración.[/I]"
    else:
        p_label = "Priorizar: [COLOR gray]DURACIÓN (ESTÁNDAR)[/COLOR]"
        p_plot = "PRIORIZAR DURACIÓN: Se priorizan vídeos largos (capítulos completos) sobre trailers o clips cortos.\n\n[I]Pulsa para activar modo precisión.[/I]"
    ui_utils.add_item(action="toggle_prioritize_match", title=p_label, thumbnail=ui_utils.media_icon("adv_priorizar.png"), folder=False, plot=p_plot)

    # 3. Filtro Temporal
    if cfg.get('recent_active', False):
        t_label = "Filtro Temporal: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        t_plot = "MODO RECIENTE: Se priorizan los vídeos subidos en las últimas 24h-48h.\n\n[I]Pulsa para pasar a modo mixto.[/I]"
    else:
        t_label = "Filtro Temporal: [COLOR gray]RELEVANCIA (POR DEFECTO)[/COLOR]"
        t_plot = "MODO MIXTO: El orden depende de cuánto se parezca el título al buscado, sin importar la fecha.\n\n[I]Pulsa para activar orden RECIENTE.[/I]"
    ui_utils.add_item(action="toggle_recent", title=t_label, thumbnail=ui_utils.media_icon("adv_filtro_tiempo.png"), folder=False, plot=t_plot)

    # 4. Anti-Trailers
    min_m = cfg.get('min_duration', 0)
    a_label = f"Anti-Trailers: [COLOR green]SOLO +{min_m} MIN[/COLOR]" if min_m > 0 else "Anti-Trailers: [COLOR gray]DESACTIVADO[/COLOR]"
    a_plot = "ANTI-TRAILERS: Filtra automáticamente los vídeos que duran menos del tiempo seleccionado para evitar clips cortos.\n\n[I]Pulsa para configurar.[/I]"
    ui_utils.add_item(action="set_min_duration", title=a_label, thumbnail=ui_utils.media_icon("adv_antitrailers.png"), folder=False, plot=a_plot)

    # --- OPCIONES ORIGINALES ---
    ui_utils.add_item(action="set_precision", title="Precisión de Búsqueda (Nivel de Contexto)", thumbnail=ui_utils.media_icon("adv_precision.png"), folder=False, plot="Configura el nivel de detalle que el addon usa para buscar contenido alternativo.")

    # Caché configurable
    expiry = cfg.get('cache_expiry')
    if expiry is None: expiry = 2592000 if cfg.get('cache_active', False) else 0

    if expiry == 0: c_txt = "[COLOR gray]APAGADO[/COLOR]"
    elif expiry == 86400: c_txt = "[COLOR green]1 DÍA[/COLOR]"
    elif expiry == 604800: c_txt = "[COLOR green]1 SEMANA[/COLOR]"
    elif expiry == 2592000: c_txt = "[COLOR green]1 MES[/COLOR]"
    elif expiry == 31536000: c_txt = "[COLOR green]1 AÑO[/COLOR]"
    elif expiry == -1: c_txt = "[COLOR gold]INDEFINIDO[/COLOR]"
    else: c_txt = f"[COLOR green]{expiry // 3600}h[/COLOR]"

    c_label = f"Caché: {c_txt}"
    c_plot = "CACHÉ: Configura cuánto tiempo se guardan los menús para cargar más rápido.\n\n[I]Pulsa para seleccionar duración.[/I]"
    ui_utils.add_item(action="set_cache_config", title=c_label, thumbnail=ui_utils.media_icon("adv_cache.png"), folder=False, plot=c_plot)

    ui_utils.add_item(action="clear_ui_cache", title="Limpiar Interfaz (Reload)", thumbnail=ui_utils.media_icon("adv_refrescar.png"), folder=False, plot="Refresca la vista actual para aplicar cambios o ver nuevos contenidos.")
    ui_utils.add_item(action="restore_warnings", title="Restaurar mensajes de advertencia", thumbnail=ui_utils.media_icon("info.png") or "DefaultIconInfo.png", folder=False, plot="Vuelve a mostrar los mensajes de aviso que hayas ocultado (nota VPN en directos, aviso VPN en catálogo).")
    # ui_utils.add_item(action="clear_full_cache", title="[COLOR red]¡BORRAR TODA LA CACHÉ![/COLOR]", thumbnail="DefaultIconError.png", folder=False, plot="Elimina todos los archivos temporales, imágenes y datos guardados del addon.")

    # 4. Backups de Archivos (ZIP)
    ui_utils.add_item(action="backups_menu", title="Copias de Seguridad", thumbnail=ui_utils.media_icon("adv_backup.png"), folder=True)

    # 5. Descargas
    d_path = cfg.get('download_path', '')
    d_label = f"Ruta de Descargas: [COLOR green]{d_path}[/COLOR]" if d_path else "Ruta de Descargas: [COLOR gray]NO CONFIGURADA[/COLOR]"
    ui_utils.add_item(action="set_download_path", title=d_label, thumbnail=ui_utils.media_icon("adv_ruta_dl.png"), folder=False, plot="Selecciona la carpeta donde se guardarán los vídeos descargados.")

    # 6. Modo Anti-Errores Dailymotion (4 niveles)
    dm_level = cfg.get('dm_safe_level', 0)  # 0=off, 1=basic, 2=extreme, 3=yt-dlp
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR gray]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de AtresDaily.\n\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android con cookies de sesión.\n\n"
        "[B]EXTREMO:[/B] Todas las técnicas del addon Dailymotion de Gujal00:\n"
        "- Subtítulos automáticos\n"
        "- Verificación de enlaces (HEAD)\n"
        "- Limitador de calidad\n"
        "- Gestión avanzada de tokens y cookies\n"
        "- API moderna de Kodi (VideoInfoTag)\n\n"
        "[B]YT-DLP:[/B] Usa yt-dlp con TLS spoofing (curl-cffi).\n"
        "Requiere: pip install yt-dlp curl-cffi\n"
        "Recomendado en Windows donde el CDN bloquea Kodi.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    ui_utils.add_item(action="set_dm_safe_level", title=dm_label, thumbnail=ui_utils.media_icon("adv_anti_errores.png"), folder=False, plot=dm_plot)

    # 6.5. Modo de Descarga
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR gray]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO ESPADAILY (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"

    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Descarga simple HTTP.\n"
        "[B]SAFE MODE:[/B] Header estandar (Gujal).\n"
        "[B]ESPADAILY:[/B] Procesa HLS secuencialmente.\n"
        "[B]YT-DLP:[/B] Usa binario externo.\n"
        "[B]ULTRA:[/B] Descarga HLS multi-hilo (4x velocidad). Recomendado."
    )
    ui_utils.add_item(action="set_dl_mode", title=dl_s_label, thumbnail=ui_utils.media_icon("adv_modo_dl.png"), folder=False, plot=dl_s_plot)

    # 7. Instantáneas (con menú contextual oculto para ver log)
    snap_context = [("Ver Log de Kodi (últimas 50 líneas)", f"RunPlugin({sys.argv[0]}?action=view_kodi_log)")]
    ui_utils.add_item(action="snapshots_menu", title="Instantáneas del Catálogo (Offline)", thumbnail=ui_utils.media_icon("adv_snapshot.png"), folder=True, plot="Guarda una copia estática del catálogo de Series y Programas para acceder sin conexión a la lista oficial.", context=snap_context)

    # 8. Motor TDT
    use_ia = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    ia_label = "Motor TDT (En Directo): [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]" if use_ia else "Motor TDT (En Directo): [COLOR grey]NATIVO (Por defecto)[/COLOR]"
    ia_plot = (
        "REPRODUCTOR AVANZADO: Forzando Kodi a usar el motor InputStream para M3U8. "
        "Mejora la reconexión de red y permite pausar el directo (TimeShift)."
        if use_ia else
        "REPRODUCTOR ESTÁNDAR: Usando el motor de vídeo nativo interno de Kodi. "
        "El directo no se puede pausar, pero es compatible con todos los sistemas operativos."
    )
    ui_utils.add_item(action="toggle_inputstream", title=ia_label, thumbnail=ui_utils.media_icon("adv_motor_tdt.png"), folder=False, plot=ia_plot)

    # 9. Modo Anti-Errores IPTV
    anti_err = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    ae_label = "Modo Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]" if anti_err else "Modo Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
    ae_plot = "Si un canal IPTV te da 'Playback failed', activa este modo para intentar solucionar el error de reproducción."
    ui_utils.add_item(action="toggle_iptv_anti_errors", title=ae_label, thumbnail=ui_utils.media_icon("adv_anti_errores_iptv.png"), folder=False, plot=ae_plot)

    # 10. Accesibilidad
    ui_utils.add_item(action="acc_menu", title="Accesibilidad", thumbnail=ui_utils.media_icon("adv_acc.png"), folder=True, plot="Opciones de accesibilidad: modo de color, negrita y reemplazo de símbolos.")

    # LoioLog
    try:
        xbmcaddon.Addon(_LOIOLOG_ADDON_ID)
        loiolog_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        loiolog_status = "[COLOR gray]No instalado[/COLOR]"
    ui_utils.add_item(action="loiolog_install", title=f"LoioLog — Gestor avanzado de logs — {loiolog_status}", thumbnail=ui_utils.media_icon("adv_log.png"), folder=False, plot="[B]LoioLog[/B] - Visor de logs de Kodi con colores por severidad.\n\nFiltra por addon, texto o regex. Exporta, comparte o abre en el móvil.\n\nPulsa para abrir o instalar automáticamente.\n\nhttps://github.com/loioloio/loiolog")

    ui_utils.add_item(action="open_addon_settings", title="Ajustes del Addon", thumbnail="DefaultAddonService.png", folder=False, plot="Abre el panel de ajustes oficial del addon en Kodi.")

    if xbmc.getSkinDir() == 'skin.estuary.palantir':
        applied = _ep_sync_state()
        fix_label = "Fix Estuary Palantir: [COLOR green]APLICADO[/COLOR]" if applied else "Fix Estuary Palantir: [COLOR grey]NO APLICADO[/COLOR]"
        ui_utils.add_item(action="toggle_estuary_palantir_fix", title=fix_label, thumbnail="DefaultAddonSkin.png", folder=False, plot="Instala o desinstala el parche que corrige la pantalla negra al ver resultados de Palantir con la skin Estuary Palantir.\n\nSi la skin se actualiza y el parche desaparece, este botón te permite reaplicarlo.")

    ui_utils.close_item_list()

def backups_menu():
    ui_utils.add_item(action="", title="[I][COLOR aqua]BACKUPS: Guarda tus ajustes, historial y favoritos en un ZIP.[/COLOR][/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="create_backup", title="[COLOR green]+ CREAR COPIA (Ligera)[/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="create_backup_full", title="[COLOR lime]+ CREAR COPIA COMPLETA (Con Caché)[/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="list_backups", title="RESTAURAR COPIA...", thumbnail="DefaultFolder.png", folder=True)
    ui_utils.add_item(action="export_backups_menu", title="[COLOR gold]EXPORTAR COPIA (Guardar fuera)...[/COLOR]", thumbnail="DefaultIconExport.png", folder=True)
    ui_utils.add_item(action="del_backups_menu", title="[COLOR red]BORRAR COPIAS...[/COLOR]", thumbnail="DefaultIconError.png", folder=True)
    ui_utils.close_item_list()

def _toggle_inputstream():
    cur = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    xbmcaddon.Addon().setSetting('use_inputstream', 'false' if cur else 'true')
    if not cur:
        try:
            xbmcaddon.Addon('inputstream.adaptive')
            xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive ACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
        except RuntimeError:
            xbmcgui.Dialog().ok(
                "Aviso Importante",
                "Has activado InputStream Adaptive, pero el componente no está instalado en Kodi.\n\n"
                "Instala 'InputStream Adaptive' desde el repositorio oficial de Kodi antes de usar este modo."
            )
    else:
        xbmcgui.Dialog().notification("Reproductor", "Volviendo al motor NATIVO", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_iptv_anti_errors():
    cur = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    xbmcaddon.Addon().setSetting('iptv_anti_errors', 'false' if cur else 'true')
    if not cur:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores IPTV ACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores IPTV DESACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def acc_menu():
    _addon = xbmcaddon.Addon()
    color_mode = _addon.getSetting('acc_color_mode') or 'none'
    bold_on    = _addon.getSetting('acc_bold_enabled') != 'false'
    strip_sym  = _addon.getSetting('acc_strip_symbols') == 'true'

    _COLOR_LABELS = {
        'none':         "Sin modificar (colores originales)",
        'white':        "Texto blanco (todos los colores -> blanco)",
        'daltonic_rg':  "Daltonico rojo-verde (deuteranopia/protanopia)",
        'daltonic_by':  "Daltonico azul-amarillo (tritanopia)",
        'hc_dark':      "Alto contraste — fondo oscuro (amarillo)",
        'hc_light':     "Alto contraste — fondo claro (negro)",
    }
    color_txt = _COLOR_LABELS.get(color_mode, color_mode)
    bold_txt  = "[COLOR green]ACTIVADA[/COLOR]"  if bold_on   else "[COLOR grey]DESACTIVADA[/COLOR]"
    sym_txt   = "[COLOR green]ACTIVADO[/COLOR]"   if strip_sym else "[COLOR grey]DESACTIVADO[/COLOR]"

    ui_utils.add_item(action="acc_set_color_mode",  title=f"Modo de color: [COLOR gold]{color_txt}[/COLOR]",  thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Cambia el esquema de colores del addon para mejorar la visibilidad.")
    ui_utils.add_item(action="acc_toggle_bold",     title=f"Negrita en menús: {bold_txt}",                    thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Activa o desactiva el texto en negrita en todos los menús del addon.")
    ui_utils.add_item(action="acc_toggle_symbols",  title=f"Reemplazar simbolos: {sym_txt}",                  thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Sustituye simbolos especiales (estrellas, flechas) por caracteres ASCII compatibles.")
    ui_utils.close_item_list()

def _acc_set_color_mode():
    options = [
        "Sin modificar (colores originales)",
        "Texto blanco (todos los colores -> blanco)",
        "Daltonico rojo-verde (deuteranopia/protanopia)",
        "Daltonico azul-amarillo (tritanopia)",
        "Alto contraste — fondo oscuro (amarillo)",
        "Alto contraste — fondo claro (negro)",
    ]
    keys = ['none', 'white', 'daltonic_rg', 'daltonic_by', 'hc_dark', 'hc_light']
    cur_key = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    preselect = keys.index(cur_key) if cur_key in keys else 0
    sel = xbmcgui.Dialog().select("Modo de color", options, preselect=preselect)
    if sel >= 0:
        xbmcaddon.Addon().setSetting('acc_color_mode', keys[sel])
        xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_bold():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('acc_bold_enabled') != 'false'
    addon.setSetting('acc_bold_enabled', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _random_fake_url():
    """Genera una URL falsa de aspecto realista."""
    import random, string
    domains = ['cdn-stream', 'api-media', 'cache-node', 'edge-srv', 'static-res']
    tlds = ['net', 'io', 'cloud', 'media', 'stream']
    path = ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(8, 16)))
    return f"https://{random.choice(domains)}-{random.randint(1,99)}.{random.choice(tlds)}/{path}"

def _random_token():
    """Genera un token falso de aspecto realista."""
    import random, string
    return ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(20, 40)))

def view_kodi_log():
    """Muestra las últimas 50 líneas del log de Kodi en un diálogo de texto."""
    try:
        log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo de log.")
            return
        from collections import deque
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            last_50 = deque(f, maxlen=50)
        
        censored_lines = []
        for line in last_50:
            line = re.sub(r'https?://[^\s]*connector\.py[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://gist\.githubusercontent\.com[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*\.netlify\.app[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com[^\s]*/connector[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com/fullstackcurso[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*/status\.json[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*/messages\.json[^\s]*', _random_fake_url, line)
            line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(bearer=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(hdnts=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            censored_lines.append(line)
        
        log_text = ''.join(censored_lines)
        xbmcgui.Dialog().textviewer("Log de Kodi (últimas 50 líneas)", log_text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo leer el log: {e}")

# --- INTERRUPTORES Y BÚSQUEDA AVANZADA ---
def _clear_cat_cache():
    """Elimina todos los archivos de caché del catálogo (cat_cache_*.json)."""
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    for f in os.listdir(profile):
        if f.startswith("cat_cache_") and f.endswith(".json"):
            try: os.remove(os.path.join(profile, f))
            except Exception: pass

def set_cache_config():
    # Opciones de configuracion + Acciones extra
    opts = ["Apagado", "1 Día", "1 Semana", "1 Mes (Recomendado)", "1 Año", "Indefinido", "[COLOR red]Borrar solo caché del Addon[/COLOR]", "[COLOR red]Borrar caché de Kodi (Reload Skin)[/COLOR]", "[COLOR gold]Exportar caché...[/COLOR]"]
    vals = [0, 86400, 604800, 2592000, 31536000, -1, -97, -99, -88]
    
    idx = xbmcgui.Dialog().select("Duración de la Caché", opts)
    if idx >= 0:
        # Acciones especiales
        if vals[idx] == -99:
            clear_full_cache() # Reload Skin
            return
        elif vals[idx] == -97:
            # Borrar SOLO ficheros del addon
            if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todos los datos descargados del catálogo?\n(No afecta a tus ajustes ni favoritos)"):
                _clear_cat_cache()
                xbmcgui.Dialog().notification("AtresDaily", "Caché del Addon borrada")
            return
        elif vals[idx] == -88:
            export_cache()
            return

        cfg = ui_utils.load_json('settings.json')
        cfg['cache_expiry'] = vals[idx]
        cfg['cache_active'] = (vals[idx] != 0)
        ui_utils.save_json('settings.json', cfg)
        
        if vals[idx] == 0:
            _clear_cat_cache()
            xbmcgui.Dialog().notification("AtresDaily", f"Caché desactivada y limpiada")
        else:
            xbmcgui.Dialog().notification("AtresDaily", f"Caché: {opts[idx]}")
        
        xbmc.executebuiltin("Container.Refresh")

def _toggle_advanced_search():
    cfg = ui_utils.load_json('settings.json')
    new_state = not cfg.get('advanced_search_active', True)
    cfg['advanced_search_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Menú Avanzado ACTIVADO" if new_state else "Búsqueda Directa")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_prioritize_match():
    cfg = ui_utils.load_json('settings.json')
    new_state = not cfg.get('prioritize_match_active', False)
    cfg['prioritize_match_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Modo Precisión" if new_state else "Modo Duración")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    cfg = ui_utils.load_json('settings.json')
    new_state = not cfg.get('recent_active', False)
    cfg['recent_active'] = new_state
    ui_utils.save_json('settings.json', cfg)
    xbmcgui.Dialog().notification("AtresDaily", "Orden Reciente" if new_state else "Orden Relevancia")
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min"]
    vals = [0, 2, 5, 10, 20]
    idx = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        cfg['min_duration'] = vals[idx]
        ui_utils.save_json('settings.json', cfg)
        xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    # --- CATÁLOGO A3PLAYER ---
    ui_utils.add_item(action="", title="[I]— CATÁLOGO A3PLAYER —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="atresplayer_catalog_search", title="Buscar en Catálogo de A3Player", thumbnail="DefaultMovies.png", folder=True, plot="Busca directamente en el catálogo oficial de A3Player por nombre aproximado.\n\nEscribe el nombre de una serie o programa y se buscará la coincidencia más cercana.")

    # --- SECCIÓN BÁSICA ---
    ui_utils.add_item(action="", title="[I]— BUSCAR EN INTERNET —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Estándar (Por Título)", url="standard", thumbnail=ui_utils.media_icon("srch_estandar.png"), folder=True, plot="Búsqueda tradicional por palabras clave en todo el catálogo.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Películas (Modo Cine)", url="movie", thumbnail=ui_utils.media_icon("srch_peliculas.png"), folder=True, plot="Optimiza la búsqueda añadiendo filtros para localizar vídeos de películas en castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Series (Temporada + Capítulo)", url="series", thumbnail=ui_utils.media_icon("srch_series.png"), folder=True, plot="Asistente guiado para construir la búsqueda exacta de un episodio (Ej: Serie T1x01).")
    ui_utils.add_item(action="execute_adv_search", title="Buscar con Elementum (P2P - Torrent)", url="torrent_p2p", thumbnail=ui_utils.media_icon("srch_torrent.png"), folder=False, plot="Busca vídeos usando Elementum, el addon de streaming P2P para Kodi.")

    # --- FILTROS DE DURACIÓN ---
    ui_utils.add_item(action="", title="[I]— FILTROS DE DURACIÓN —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Largos (+20 min)", url="long", thumbnail=ui_utils.media_icon("srch_largos.png"), folder=True, plot="Filtra resultados cortos. Ideal para programas completos, documentales o episodios.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Cortos (-10 min)", url="short", thumbnail=ui_utils.media_icon("srch_cortos.png"), folder=True, plot="Ideal para buscar clips, noticias rápidas, trailers o momentos destacados.")

    # --- FILTROS TEMPORALES ---
    ui_utils.add_item(action="", title="[I]— FILTROS TEMPORALES —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Hoy (Últimas 24h)", url="recent_24h", thumbnail=ui_utils.media_icon("srch_hoy.png"), folder=True, plot="Muestra solo contenido subido en el último día.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Esta Semana", url="week", thumbnail=ui_utils.media_icon("srch_semana.png"), folder=True, plot="Amplía el rango a los últimos 7 días.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Este Mes", url="month", thumbnail=ui_utils.media_icon("srch_mes.png"), folder=True, plot="Busca contenido subido en los últimos 30 días.")

    # --- FILTROS AVANZADOS ---
    ui_utils.add_item(action="", title="[I]— FILTROS AVANZADOS —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Solo Contenido en Español", url="spanish", thumbnail=ui_utils.media_icon("srch_espanol.png"), folder=True, plot="Añade términos de idioma a la búsqueda para priorizar castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Usuario / Canal", url="by_user", thumbnail=ui_utils.media_icon("srch_canal.png"), folder=True, plot="Restringe la búsqueda a un canal o usuario de Dailymotion específico.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Inversa (Excluir palabras)", url="inverse", thumbnail=ui_utils.media_icon("srch_inversa.png"), folder=True, plot="Define qué palabras NO quieres que aparezcan en los resultados.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Exacta (Sin limpieza)", url="exact", thumbnail=ui_utils.media_icon("srch_exacta.png"), folder=True, plot="Envía el término tal cual a la API, sin procesado inteligente de texto.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Palabras Clave", url="tags", thumbnail=ui_utils.media_icon("srch_tags.png"), folder=True, plot="Busca utilizando el sistema de etiquetas (tags) de la plataforma.")
    ui_utils.add_item(action="search_user_playlists", title="Buscar Playlists de un Canal", thumbnail=ui_utils.media_icon("srch_playlists.png"), folder=True, plot="Introduce el nombre de un canal de Dailymotion para ver sus listas de reproducción organizadas.")

    # --- UTILIDADES ---
    ui_utils.add_item(action="", title="[I]— UTILIDADES —[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    ui_utils.add_item(action="search_external", title="Búsqueda externa", thumbnail=ui_utils.media_icon("srch_externa.png"), folder=True, plot="Introduce un texto y abre directamente el menú '¿No es lo que buscas?' con todas las opciones de búsqueda disponibles.")
    ui_utils.add_item(action="multi_search", title="Búsqueda Múltiple (varios términos)", thumbnail=ui_utils.media_icon("srch_multiple.png"), folder=True, plot="Busca varios términos a la vez separados por comas.\nEjemplo: La Promesa, Sueños de libertad, El Hormiguero")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Personalizada (Combinar Filtros)", url="custom", thumbnail=ui_utils.media_icon("srch_custom.png"), folder=True, plot="Crea una búsqueda a medida combinando múltiples filtros (HD + Fecha + Duración + Idioma).")
    ui_utils.add_item(action="execute_adv_search", title="Repetir Última Búsqueda", url="repeat", thumbnail=ui_utils.media_icon("srch_repetir.png"), folder=True, plot="Vuelve a lanzar la última búsqueda realizada, manteniendo sus filtros si los tenía.")
    ui_utils.close_item_list()

def _search_atresplayer_catalog():
    """Busca en el catálogo de A3Player por nombre aproximado."""

    kb = xbmc.Keyboard('', 'Nombre del programa o serie')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return

    query = kb.getText().strip().lower()

    # Obtener catálogo completo
    xbmcgui.Dialog().notification("AtresDaily",
        "Cargando catálogo...", xbmcgui.NOTIFICATION_INFO, 2000)

    try:
        catalog = connector._fetch_all_catalog()
    except Exception as e:
        xbmcgui.Dialog().ok("AtresDaily",
            f"Error al obtener el catálogo: {str(e)}")
        return

    if not catalog:
        xbmcgui.Dialog().ok("AtresDaily",
            "No se pudo obtener el catálogo de A3Player.\n\n"
            "Puede que el conector no esté instalado o haya un error de red.")
        return

    # Recopilar todos los programas
    # Formato del catálogo: {categoria: [{t: titulo, u: url, th: thumb, p: plot}, ...]}
    all_programs = []
    for cat_name, cat_items in catalog.items():
        if isinstance(cat_items, list):
            for item in cat_items:
                if isinstance(item, dict):
                    # Intentar claves cortas (t, u) y largas (title, url) para máxima compatibilidad
                    title = item.get('t') or item.get('title') or item.get('name') or ''
                    url = item.get('u') or item.get('url') or item.get('link') or ''
                    thumb = item.get('th') or item.get('thumbnail') or ''
                    plot = item.get('p') or item.get('plot') or ''
                    if title:
                        all_programs.append({
                            'title': title,
                            'url': url,
                            'thumb': thumb,
                            'plot': plot,
                            'category': cat_name
                        })
                elif isinstance(item, str) and item:
                    all_programs.append({
                        'title': item,
                        'url': '',
                        'thumb': '',
                        'plot': '',
                        'category': cat_name
                    })

    if not all_programs:
        xbmcgui.Dialog().ok("AtresDaily",
            "No se encontraron programas en el catálogo.\n\n"
            f"Categorías encontradas: {', '.join(list(catalog.keys())[:5])}")
        return

    xbmc.log(f"[AtresDaily] Catalog search: {len(all_programs)} programs found, searching '{query}'", xbmc.LOGINFO)

    # Coincidencia difusa: calcular similitud con cada programa
    scored = []
    for prog in all_programs:
        title_lower = prog['title'].lower()
        # Coincidencia directa parcial (substring) — prioridad máxima
        if query in title_lower:
            score = 0.95 + (len(query) / max(len(title_lower), 1)) * 0.05
        else:
            score = difflib.SequenceMatcher(None, query, title_lower).ratio()
        if score > 0.3:
            scored.append((score, prog))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = scored[:20]

    if not results:
        # Sin resultados de coincidencia difusa, ofrecer búsqueda en Dailymotion
        if xbmcgui.Dialog().yesno("AtresDaily",
            f"No se encontró '{query}' en el catálogo.\n\n"
            "¿Buscar en Dailymotion en su lugar?"):
            connector.search_internet(query)
        return

    # Mostrar resultados
    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        title = prog['title']
        cat = prog['category']
        url = prog.get('url', '')
        thumb = prog.get('thumb', '')

        label = f"{title} [COLOR gray]({cat})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb or 'DefaultVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': prog.get('plot') or f"Programa: {title}\nCategoría: {cat}\nCoincidencia: {pct}%"})

        if url:
            # Navegar al programa en A3Player (temporadas/capítulos)
            nav_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'list_details', 'url': url, 'extra': title})
        else:
            # Sin URL directa → buscar por título en Dailymotion como alternativa
            nav_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'search', 'url': title})

        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def _execute_adv_search(mode):
    if mode == "torrent_p2p":
        q = xbmcgui.Dialog().input("Buscar en Torrents (P2P)")
        if q: _search_elementum(q)
        return

    if mode == "repeat":
        last = ui_utils.load_json('last_adv.json')
        if not last:
            xbmcgui.Dialog().notification("AtresDaily", "No hay búsquedas previas", xbmcgui.NOTIFICATION_ERROR)
            return
        connector.search_internet(last["q"], extra_params=last["ep"])
        return

    # Prompts especiales
    if mode == "series":
        title = xbmcgui.Dialog().input("Nombre de la Serie")
        if not title: return
        so = xbmcgui.Dialog().input("Temporada (Ej: 1)", type=xbmcgui.INPUT_NUMERIC)
        if so:
             q = f"{title} Temporada {int(so)}"
        else:
            q = title
    elif mode == "inverse":
        q = xbmcgui.Dialog().input("¿Qué buscas?")
        if not q: return
        exc = xbmcgui.Dialog().input("Palabras a EXCLUIR (separadas por espacio)")
        ep = {} 
        if exc: ep["_exclude"] = exc.lower().split()
    elif mode == "by_user":
        user = xbmcgui.Dialog().input("Nombre de Usuario / Canal (ID)")
        if not user: return
        q_filter = xbmcgui.Dialog().input(f"¿Qué buscar dentro de {user}? (Dejar vacío para ver todo)")
        q = q_filter # Permitimos vacio
    else:
        # Traducción de títulos de cuadro de dialogo
        mod_titles = {
            "movie": "Búsqueda de Película (Cine)",
            "long": "Búsqueda de Vídeos Largos (+20min)",
            "short": "Búsqueda de Vídeos Cortos (-10min)",
            "standard": "Búsqueda Estándar",
            "recent_24h": "Contenido de Hoy (24h)",
            "week": "Contenido de la Semana",
            "month": "Contenido del Mes",
            "hd": "Búsqueda en Alta Definición (HD)",
            "spanish": "Contenido en Español",
            "exact": "Búsqueda Exacta",
            "tags": "Búsqueda por Etiquetas",
            "custom": "Búsqueda Personalizada (Introducir término)"
        }
        dlg_title = mod_titles.get(mode, f"Búsqueda Avanzada: {mode.upper()}")
        
        kb = xbmc.Keyboard('', dlg_title)
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText(): return
        q = kb.getText()
    
    if 'ep' not in locals():
        ep = {}
    
    if mode == "movie":
        # Menos restrictivo: quitamos "castellano" obligatorio
        q = f"{q} pelicula completa"
    elif mode == "series":
        pass
    elif mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "week":
        ep = {"created_after": int(time.time()) - (86400 * 7), "sort": "recent"}
    elif mode == "month":
        ep = {"created_after": int(time.time()) - (86400 * 30), "sort": "recent"}
    elif mode == "hd":
        # En lugar de buscar texto "hd" (que falla mucho), activamos un filtro interno
        # para verificar la calidad real del vídeo devuelto.
        ep = {"_hd": True}
    elif mode == "spanish":
        # "castellano" a veces es muy restrictivo, "español" es mas generico
        # Pero lo ideal es no ensuciar la query si busca algo en ingles.
        # Probamos añadiendo " español" solo si no parece que ya busca idioma.
        q = f"{q} español"
    elif mode == "by_user":
        # Intento de búsqueda "difusa" de usuario si no es un ID exacto
        # Hacemos una llamada rapida a la API de users para sacar el ID real
        try:
           # _E3 es https://api.dailymotion.com/videos. Necesitamos https://api.dailymotion.com/users
           base_api = "https://api.dailymotion.com"
           u_search = requests.get(f"{base_api}/users", params={"search": user, "fields": "id,screenname", "limit": 1}, timeout=5)
           if u_search.status_code == 200:
               u_list = u_search.json().get("list", [])
               if u_list:
                   real_user_id = u_list[0].get("id")
                   # Notificar si el ID es diferente
                   if real_user_id != user:
                        xbmcgui.Dialog().notification("AtresDaily", f"Canal encontrado: {u_list[0].get('screenname')}")
                   user = real_user_id
        except Exception: pass

        ep = {"owner": user}
        if not q: q = "" # Si está vacío, buscará todo del propietario
    elif mode == "tags":
        ep = {"tags": q} # Búsqueda real por etiquetas
        # Limpiamos q para que busque solo por etiquetas si la API lo permite, o usamos q como filtro adicional
        q = "" 
    elif mode == "custom":
        # Dialogo multiseleccion para combinar filtros
        opts = [
            "Alta Definición (HD)",           # 0
            "Larga Duración (+20 min)",       # 1
            "Corta Duración (-10 min)",       # 2
            "Subido Hoy (24h)",               # 3
            "Subido esta Semana",             # 4
            "Subido este Mes",                # 5
            "Ordenar por Recientes",          # 6
            "Solo Español (Añadir texto)"     # 7
        ]
        sel = xbmcgui.Dialog().multiselect("Combinar Filtros", opts)
        if not sel: 
            # Si cancela, buscamos normal sin filtros extra
            pass 
        else:
            if 0 in sel: ep["_hd"] = True
            
            # Conflictos de duración
            if 1 in sel: ep["longer_than"] = 20
            elif 2 in sel: ep["shorter_than"] = 10
            
            # Conflictos de fecha
            now = int(time.time())
            if 3 in sel: ep["created_after"] = now - 86400
            elif 4 in sel: ep["created_after"] = now - (86400 * 7)
            elif 5 in sel: ep["created_after"] = now - (86400 * 30)
            
            if 6 in sel: ep["sort"] = "recent"
            if 7 in sel: q = f"{q} español"

    # Guardar en historial
    if q: connector.add_hist(q)

    # Guardar para repetir
    ui_utils.save_json('last_adv.json', {"q": f"adv:{q}", "ep": ep})
    
    # Ejecutar
    if mode == "exact":
        connector.search_internet(f"adv:{q}", extra_params=ep, direct=True) # El modo directo pasa el término exacto
    else:
        connector.search_internet(f"adv:{q}", extra_params=ep)


def set_precision():
    opts = ["Nivel 1: BÁSICO (Solo Título)", "Nivel 2: ESTÁNDAR (Serie + Título - Recomendado)", "Nivel 3: AVANZADO (Serie + Temporada)"]
    idx = xbmcgui.Dialog().select("Contexto de Búsqueda", opts)
    if idx >= 0:
        d = ui_utils.load_json('settings.json')
        d['context_level'] = idx + 1
        ui_utils.save_json('settings.json', d)
        xbmcgui.Dialog().notification("AtresDaily", f"Nivel {idx+1} guardado")

def clear_ui_cache():
    xbmc.executebuiltin("Container.Refresh")
    xbmcgui.Dialog().notification("AtresDaily", "Interfaz actualizada", xbmcgui.NOTIFICATION_INFO)

def set_download_path():
    d = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if d:
        cfg = ui_utils.load_json('settings.json')
        cfg['download_path'] = d
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", "Ruta de descargas guardada")
        xbmc.executebuiltin("Container.Refresh")

def set_dm_safe_level():
    # Selector de 4 niveles para el modo anti-errores de Dailymotion
    options = [
        "Desactivado (Conexión Normal)",
        "Básico (Móvil + Cookies)",
        "Extremo (Todas las técnicas de Gujal00)",
        "YT-DLP (TLS Spoofing - Recomendado en PC)"
    ]
    cfg = ui_utils.load_json('settings.json')
    current = cfg.get('dm_safe_level', 0)
    
    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        # Si selecciona yt-dlp, verificar que está disponible
        if sel == 3:
            try:
                import yt_dlp
                xbmc.log(f"[AtresDaily] yt-dlp v{yt_dlp.version.__version__} disponible", xbmc.LOGINFO)
            except ImportError:
                xbmcgui.Dialog().ok("AtresDaily", "yt-dlp no está instalado.\n\n"
                    "Instálalo con:\npip install yt-dlp curl-cffi")
                return
        cfg['dm_safe_level'] = sel
        # Mantener compatibilidad con la antigua variable booleana
        cfg['dm_safe_mode'] = sel > 0
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

def set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Normal)", 
        "Nivel 2: SAFE MODE (Gujal Style)", 
        "Nivel 3: MODO ESPADAILY (Procesado HLS)",
        "Nivel 4: YT-DLP (Requiere yt-dlp instalado)",
        "Nivel 5: ULTRA (Multi-hilo HLS+)"
    ]
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        cfg['dl_mode'] = idx # 0=Direct, 1=Safe, 2=EspaDaily, 3=yt-dlp, 4=Ultra
        
        # Mantener compatibilidad hacia atrás
        cfg['dl_safe_mode'] = (idx == 1)
        
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _do_download_ultra(url, dest, title):
    """
    Modo ULTRA: Descarga HLS Multi-hilo.
    Usa concurrent.futures para maximizar el ancho de banda.
    """
    import concurrent.futures
    
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)
             
        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Analizando stream de alta velocidad...")
        
        # 1. Resolver lista de reproducción maestra
        session = requests.Session()
        session.headers.update(HEADERS)
        
        r = session.get(url, timeout=15)
        m3u8_content = r.text
        base_url = r.url.rsplit('/', 1)[0] + '/'
        
        # Seleccionar mejor calidad
        if "#EXT-X-STREAM-INF" in m3u8_content:
             dp.update(0, "Optimizando calidad...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1] if i+1 < len(lines) else ''
             if best_url:
                 if not best_url.startswith('http'): best_url = base_url + best_url
                 r = session.get(best_url, timeout=15)
                 m3u8_content = r.text
                 base_url = r.url.rsplit('/', 1)[0] + '/'

        # 2. Parsear Segmentos
        segments = []
        for l in m3u8_content.splitlines():
            l = l.strip()
            if not l or l.startswith("#"): continue
            seg_url = l
            if not seg_url.startswith('http'): seg_url = base_url + seg_url
            segments.append(seg_url)
        
        total_segs = len(segments)
        if total_segs == 0: raise Exception("Stream vacío")
        
        # 3. Descarga paralela (4 hilos de trabajo)
        # Para archivos grandes, RAM es peligroso. Mejor tempfiles individuales.
        temp_dir = os.path.join(xbmcvfs.translatePath("special://temp/"), "atresdaily_ultra_dl")
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)
        os.makedirs(temp_dir)
            
        completed = 0
        failed = False
        
        def download_segment(idx, seg_url):
            t_path = os.path.join(temp_dir, f"{idx:05d}.ts")
            try:
                # Reintentos internos
                for _ in range(3):
                    sr = session.get(seg_url, timeout=10)
                    if sr.status_code == 200:
                        with open(t_path, 'wb') as f: f.write(sr.content)
                        return True
                    time.sleep(0.5)
                return False
            except Exception as e:
                return False

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            # Encolar tareas
            futures = {executor.submit(download_segment, i, s): i for i, s in enumerate(segments)}
            
            for future in concurrent.futures.as_completed(futures):
                if dp.iscanceled(): 
                    executor.shutdown(wait=False)
                    break
                    
                if future.result():
                    completed += 1
                else:
                    failed = True # Un segmento falló irrecuperablemente
                
                pct = int(completed * 100 / total_segs)
                dp.update(pct, f"Bajando paquetes: {completed}/{total_segs}")
                
        if dp.iscanceled():
            dp.close()
            return

        # 4. Unir archivos
        dp.update(100, "Ensamblando archivo final...")
        with open(dest, 'wb') as final_file:
            for i in range(total_segs):
                t_path = os.path.join(temp_dir, f"{i:05d}.ts")
                if os.path.exists(t_path):
                    with open(t_path, 'rb') as tf:
                        final_file.write(tf.read())
                    os.remove(t_path) # Limpiar
                
        dp.close()
        
        connector._log_download_complete(title, dest, "MP4 (ULTRA)")
        xbmcgui.Dialog().ok("AtresDaily", "¡Descarga ULTRA completada!")
        
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] Ultra Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error Ultra", f"Fallo en descarga Ultra:\n{str(e)}")
    finally:
        # Limpiar directorio temporal siempre
        if 'temp_dir' in locals() and os.path.exists(temp_dir):
            try: shutil.rmtree(temp_dir)
            except Exception: pass

def _do_download_ytdlp(vid, dest, title):
    """
    Descarga usando yt-dlp (el método más robusto).
    Requiere que yt-dlp esté instalado en el sistema.
    """
    import subprocess
    import shutil
    
    # Buscar yt-dlp en el sistema
    ytdlp_path = shutil.which('yt-dlp')
    if not ytdlp_path:
        # Intentar rutas comunes en Windows/Linux
        common_paths = [
            'yt-dlp',
            'yt-dlp.exe',
            '/usr/local/bin/yt-dlp',
            '/usr/bin/yt-dlp',
            os.path.expanduser('~/.local/bin/yt-dlp'),
        ]
        for p in common_paths:
            if os.path.exists(p):
                ytdlp_path = p
                break
    
    if not ytdlp_path:
        xbmcgui.Dialog().ok("AtresDaily - yt-dlp", 
            "yt-dlp no está instalado en el sistema.\n\n"
            "Para usar este modo, instala yt-dlp:\n"
            "- Windows: winget install yt-dlp\n"
            "- Linux: pip install yt-dlp\n"
            "- Más info: github.com/yt-dlp/yt-dlp")
        return
    
    # URL de Dailymotion
    dm_url = f"https://www.dailymotion.com/video/{vid}"
    
    # Preparar nombre de archivo seguro
    safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
    if not safe_title: safe_title = vid
    
    # Plantilla de salida de yt-dlp
    output_template = os.path.join(os.path.dirname(dest), f"{safe_title}.%(ext)s")
    
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando con yt-dlp", f"Iniciando descarga de:\n{title}")
    
    try:
        # Ejecutar yt-dlp
        cmd = [
            ytdlp_path,
            '-f', 'best[ext=mp4]/best',  # Preferir MP4
            '-o', output_template,
            '--no-playlist',
            '--no-warnings',
            dm_url
        ]
        
        xbmc.log(f"[AtresDaily] Ejecutando: {' '.join(cmd)}", xbmc.LOGINFO)
        
        # Ejecutar en un subproceso
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )
        
        # Monitorear el progreso
        while True:
            if dp.iscanceled():
                process.terminate()
                dp.close()
                xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada")
                return
                
            line = process.stdout.readline()
            if not line and process.poll() is not None:
                break
                
            if line:
                # Analizar el progreso de yt-dlp (formato: [download] XX.X% of ...)
                if '[download]' in line and '%' in line:
                    try:
                        pct = float(re.search(r'(\d+\.?\d*)%', line).group(1))
                        dp.update(int(pct), f"Descargando: {int(pct)}%")
                    except Exception:
                        pass
            
            xbmc.sleep(100)
        
        dp.close()
        
        retcode = process.returncode
        if retcode == 0:
            # Buscar el archivo descargado
            base_dir = os.path.dirname(dest)
            for f in os.listdir(base_dir):
                if f.startswith(safe_title) and (f.endswith('.mp4') or f.endswith('.mkv') or f.endswith('.webm')):
                    final_path = os.path.join(base_dir, f)
                    connector._log_download_complete(title, final_path, "yt-dlp")
                    xbmcgui.Dialog().ok("AtresDaily", f"Descarga completada con yt-dlp:\n{f}")
                    return
            
            xbmcgui.Dialog().ok("AtresDaily", "yt-dlp terminó pero no se encontró el archivo descargado.")
        else:
            xbmcgui.Dialog().ok("AtresDaily Error", f"yt-dlp falló con código: {retcode}\n\nPrueba otro modo de descarga.")
            
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] yt-dlp Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error yt-dlp", f"Error ejecutando yt-dlp:\n{str(e)}")

def _do_download_espadaily(url, dest, title):
    # Descarga segmentos secuenciales y los une en un solo archivo MP4/TS
    import tempfile as _tf
    tmp_dest = None
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)
             
        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo EspaDaily)", "Analizando lista de reproducción...")
        
        # 1. Obtener lista M3U8 y resolver redirecciones
        r = requests.get(url, headers=HEADERS, timeout=15)
        m3u8_content = r.text
        base_url = r.url.rsplit('/', 1)[0] + '/'
        
        # Si es una lista de reproducción maestra, necesitamos elegir la mejor calidad primero
        if "#EXT-X-STREAM-INF" in m3u8_content:
             dp.update(0, "Resolviendo flujo final...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1] if i+1 < len(lines) else ''
             
             if best_url:
                 if not best_url.startswith('http'): best_url = base_url + best_url
                 r = requests.get(best_url, headers=HEADERS, timeout=15)
                 m3u8_content = r.text
                 base_url = r.url.rsplit('/', 1)[0] + '/'

        # 2. Extraer segmentos
        segments = []
        lines = m3u8_content.splitlines()
        
        for l in lines:
            l = l.strip()
            if not l: continue
            if l.startswith("#EXT-X-KEY"):
                xbmc.log("[AtresDaily] Encriptación detectada en HLS. La descarga 'raw' podría no ser reproducible.", xbmc.LOGWARNING)
            if not l.startswith("#"):
                seg_url = l
                if not seg_url.startswith('http'): seg_url = base_url + seg_url
                segments.append(seg_url)
        
        total_segs = len(segments)
        if total_segs == 0:
            raise Exception("No se encontraron segmentos de video")
            
        dp.update(0, f"Descargando 0/{total_segs} segmentos")
        
        # 3. Descargar a archivo TEMPORAL (evita corrupción si se cancela)
        tmp_dest = dest + '.tmp'
        failed_segs = 0
        with open(tmp_dest, 'wb') as outfile:
            for i, seg in enumerate(segments):
                if dp.iscanceled(): break
                
                success = False
                for attempt in range(3):
                    try:
                        sr = requests.get(seg, headers=HEADERS, timeout=10)
                        if sr.status_code == 200:
                            outfile.write(sr.content)
                            success = True
                            break
                    except Exception: time.sleep(1 << attempt)  # 1s, 2s, 4s
                
                if not success:
                    xbmc.log(f"[AtresDaily] Fallo al descargar segmento {i}", xbmc.LOGWARNING)
                    failed_segs += 1
                
                percent = int((i + 1) * 100 / total_segs)
                dp.update(percent, f"Procesando segmento {i+1}/{total_segs}")
        
        dp.close()
        
        if not dp.iscanceled():
            # Renombrar temporal al destino final solo si se completó
            os.replace(tmp_dest, dest)
            tmp_dest = None  # Ya no hay que limpiar
            connector._log_download_complete(title, dest, "MP4 (EspaDaily)")
            if failed_segs > 0:
                xbmcgui.Dialog().ok("AtresDaily", f"Descarga finalizada con {failed_segs} segmento(s) fallido(s).\nEl vídeo puede tener cortes.")
            else:
                xbmcgui.Dialog().ok("AtresDaily", "Descarga finalizada correctamente (Modo EspaDaily)")
            
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] EspaDaily Download Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Error en descarga EspaDaily:\n{str(e)}")
    finally:
        # Limpiar temporal si existe (cancelación o error)
        if tmp_dest and os.path.exists(tmp_dest):
            try: os.remove(tmp_dest)
            except Exception: pass

def clear_full_cache():
    # Limpiar caché JSON de catálogo y otros temporales
    if xbmcgui.Dialog().yesno("Limpiar Caché", "¿Borrar todos los datos de caché del catálogo?\nEsto forzará a recargar la información de A3Player."):
        try:
             _clear_cat_cache()
             xbmcgui.Dialog().notification("AtresDaily", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
             xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
             xbmcgui.Dialog().notification("AtresDaily", f"Error borrando caché: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

def export_cache():
    # Exportar archivos de caché del catálogo
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return
    
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
    
    if not files:
        xbmcgui.Dialog().notification("AtresDaily", "No hay caché para exportar")
        return
        
    import shutil
    count = 0
    try:
        for f in files:
            shutil.copy2(os.path.join(profile, f), os.path.join(d, f))
            count += 1
        xbmcgui.Dialog().notification("AtresDaily", f"{count} archivos exportados")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo al exportar caché: {e}")

def show_info():
    t = (
        "[B]Términos y Condiciones:[/B]\n• Este addon es completamente GRATUITO y siempre lo será, además es sin ánimo de lucro. Si alguien te lo ha vendido, te han estafado. Las etiquetas ATP+ o Premium hacen referencia a la suscripción de la plataforma de origen, no a este addon.\n"
        "• NO aloja ningún contenido\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "Los desarrolladores de este addon NO se hacen responsables del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de búsquedas externas.\n\n"
        "[B]¿Cómo funciona?[/B]\nAccede a contenido de internet replicando el comportamiento de un navegador web estándar. No elude restricciones técnicas ni sistemas de autenticación. El usuario es responsable de verificar que el uso cumple con los términos de cada plataforma que accede.\n\n"
        "Además del catálogo directo, permite buscar vídeos relacionados en plataformas de terceros. No está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres un trailer, un resumen, o contenido similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible de forma libre en internet.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    ver = xbmcaddon.Addon().getAddonInfo("version")
    xbmcgui.Dialog().textviewer("AtresDaily - Términos y Condiciones", t)

def show_legal_txt():
    f_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'AVISO_LEGAL.txt')
    content = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f: content = f.read()
        except Exception: pass
    xbmcgui.Dialog().textviewer("AVISO LEGAL - AtresDaily", content)

def revoke_legal():
    if xbmcgui.Dialog().yesno(
        "Revocar Términos",
        "¿Estás seguro de que deseas REVOCAR tu aceptación de los términos legales?\n\nEl addon dejará de funcionar hasta que vuelvas a aceptarlos explícitamente."
    ):
        cfg = ui_utils.load_json('settings.json')
        cfg['legal_accepted_v2'] = False
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().ok("AtresDaily", "Términos revocados.\n\nEl addon se reiniciará para aplicar los cambios.")
        xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")

def show_web_info():
    import universo; universo.show()

# --- MOTOR DE INSTANTÁNEAS DEL CATÁLOGO ACTUAL ---
def snapshots_menu():
    # msg = "Las instantáneas guardan una copia estática del catálogo actual para que puedas acceder a los contenidos incluso si las listas online fallan."
    # ui_utils.add_item(action="snapshot_help", title=f"[COLOR cyan][B]RECOMENDACIÓN:[/B][/COLOR] Crear periódicamente", thumbnail="DefaultIconInfo.png", folder=False, plot=msg)
    
    ui_utils.add_item(action="create_catalog_snapshot", title="[COLOR green]+ CREAR NUEVA FOTO DEL CATÁLOGO[/COLOR]", thumbnail="DefaultAddonService.png", folder=False)
    ui_utils.add_item(action="delete_snapshot_menu", title="[COLOR red]BORRAR INSTANTÁNEA...[/COLOR]", thumbnail="DefaultIconError.png", folder=True)
    
    # Contexto de búsqueda independiente para instantáneas
    cfg = ui_utils.load_json('settings.json')
    lvl = cfg.get('snapshot_context_level', 2)
    labels = ["", "BÁSICO (Título)", "ESTÁNDAR (Recomendado)", "AVANZADO"]
    cur_label = labels[lvl] if lvl < len(labels) else labels[2]
    
    c_plot = (
        "CONTEXTO DE BÚSQUEDA: Define cómo se busca el vídeo al pulsar en la foto.\n\n"
        "• BÁSICO: Solo el título (Ej: 'Capítulo 1')\n"
        "• ESTÁNDAR: Añade la categoría (Ej: 'Series Capítulo 1')\n"
        "• AVANZADO: Añade plataforma (Ej: 'Atresplayer Series Capítulo 1')\n\n"
        "[I]Pulsa para cambiar de nivel.[/I]"
    )
    ui_utils.add_item(action="toggle_snapshot_precision", title=f"Contexto en Instantánea: [COLOR yellow]{cur_label}[/COLOR]", thumbnail="DefaultAddonService.png", folder=False, plot=c_plot)
    
    # Listar instantáneas JSON existentes
    sdir = _get_snapshot_dir()
    if os.path.exists(sdir):
        files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
        for f in files:
            ts = f.replace("snap_", "").replace(".json", "")
            # Formateo visual de fecha
            try: d_str = f"{ts[6:8]}/{ts[4:6]}/{ts[0:4]} {ts[9:11]}:{ts[11:13]}"
            except Exception: d_str = ts
            ui_utils.add_item(action="view_snapshot", title=f"Instantánea: {d_str}", url=f, extra="root", thumbnail="DefaultFolder.png", folder=True)
            
    ui_utils.close_item_list()

def snapshot_help():
    t = (
        "[B]¿Qué es el Contexto de Búsqueda?[/B]\n\n"
        "Como una instantánea es solo una 'foto' (título y foto), cuando pulsas en una serie, "
        "el addon tiene que buscarla en Dailymotion.\n\n"
        "El [B]Contexto[/B] le dice a esa búsqueda cuánta información extra debe usar:\n\n"
        "- [B]BÁSICO:[/B] Solo busca el nombre. Si la serie se llama 'Eva', puede que encuentre mil cosas.\n"
        "- [B]ESTÁNDAR:[/B] Busca 'Series Eva'. Mucho más preciso.\n"
        "- [B]AVANZADO:[/B] Busca 'Atresplayer Series Eva'. Máxima precisión, pero si el título en Dailymotion "
        "no incluye 'Atresplayer', podría no encontrar nada.\n\n"
        "Se recomienda el nivel [B]ESTÁNDAR[/B]."
    )
    xbmcgui.Dialog().textviewer("Ayuda de Instantáneas", t)

def toggle_snapshot_precision():
    d = ui_utils.load_json('settings.json')
    cur = d.get('snapshot_context_level', 2)
    cur += 1
    if cur > 3: cur = 1
    d['snapshot_context_level'] = cur
    ui_utils.save_json('settings.json', d)
    xbmc.executebuiltin("Container.Refresh")

def _get_snapshot_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'snapshots_json')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_catalog_snapshot():
    if not xbmcgui.Dialog().yesno("AtresDaily", "¿Crear una foto completa del catálogo actual?\nEsto guardará todas las series y programas para acceso offline."):
        return
        
    catalog = connector._fetch_all_catalog()
    if not catalog: return
    
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"snap_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)
    
    try:
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(catalog, f)
        xbmcgui.Dialog().notification("AtresDaily", "Foto del catálogo guardada")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo guardar la instantánea: {e}")

def view_snapshot(fname, path="root"):
    fpath = os.path.join(_get_snapshot_dir(), fname)
    if not os.path.exists(fpath): return
    
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (json.JSONDecodeError, ValueError):
        xbmcgui.Dialog().ok("AtresDaily", "La instantánea está corrupta o vacía.")
        return
        
    if path == "root":
        for cat_name in data.keys():
            ui_utils.add_item(action="view_snapshot", title=cat_name, url=fname, extra=cat_name, folder=True)
    else:
        items = data.get(path, [])
        cfg = ui_utils.load_json('settings.json')
        lvl = cfg.get('snapshot_context_level', 2)
        
        for i in items:
            t = i.get("t"); h = i.get("u"); th = i.get("th"); pl = i.get("p")
            # En modo instantanea, la busqueda debe ser inteligente
            q = t
            if lvl == 2: q = f"{path} {t}"
            elif lvl == 3: q = f"Atresplayer {path} {t}"
            
            # Los elementos de las instantáneas siempre van a búsqueda externa (catalog_search)
            ui_utils.add_item(action="catalog_search", title=t, url=q, thumbnail=th, plot=pl, folder=True)
            
    ui_utils.close_item_list()

def delete_snapshot_menu():
    sdir = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_snap", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f, thumbnail="DefaultIconError.png", folder=False)
    ui_utils.close_item_list()

def delete_single_snap(fname):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar instantánea {fname}?"):
        try:
            os.remove(os.path.join(_get_snapshot_dir(), fname))
        except Exception as e:
            xbmcgui.Dialog().ok("Error", f"No se pudo borrar: {e}")
            return
        xbmc.executebuiltin("Container.Refresh")

# --- SISTEMA DE COPIA DE SEGURIDAD DE ARCHIVOS (ZIP) ---
def _get_backup_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'backups_zip')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_backup(include_cache=False):
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Creando backup ZIP...")
    try:
        ts = time.strftime("%Y%m%d_%H%M%S")
        suffix = "_FULL" if include_cache else ""
        target = os.path.join(_get_backup_dir(), f"Backup_{ts}{suffix}.zip")
        files = ['settings.json', 'history.json', 'search_history.json', 'last_adv.json', 'favorites.json', 'exploration_history.json', 'custom_categories.json', 'loader_config.json']
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        import zipfile
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in files:
                fp = os.path.join(profile, f)
                if os.path.exists(fp): zf.write(fp, f)
            # Incluir caché si se solicita
            if include_cache:
                cache_files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
                for cf in cache_files:
                    cfp = os.path.join(profile, cf)
                    if os.path.exists(cfp): zf.write(cfp, cf)
        # Verificar integridad del ZIP
        with zipfile.ZipFile(target, 'r') as zf:
            bad = zf.testzip()
            if bad:
                xbmc.log(f"[AtresDaily] ZIP corrupto: {bad}", xbmc.LOGWARNING)
                xbmcgui.Dialog().notification("AtresDaily", "Backup creado con advertencias", xbmcgui.NOTIFICATION_WARNING)
            else:
                xbmcgui.Dialog().notification("AtresDaily", "Copia ZIP creada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e: xbmcgui.Dialog().ok("Error", str(e))
    finally: dp.close()

def _list_backups():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="restore_backup", title=f"Restaurar: {f}", url=f, folder=False)
    ui_utils.close_item_list()

def restore_backup(fname):
    """Restaurar backup con opciones granulares."""
    source = os.path.join(_get_backup_dir(), fname)
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    import zipfile
    
    # Mapeo de archivos a nombres amigables (sin revelar información sensible)
    file_labels = {
        'settings.json': 'Configuración General',
        'history.json': 'Historial de Búsquedas',
        'search_history.json': 'Historial de Búsquedas (v2)',
        'last_adv.json': 'Última Búsqueda Avanzada',
        'favorites.json': 'Favoritos',
        'exploration_history.json': 'Historial de Navegación',
        'custom_categories.json': 'Categorías Personalizadas',
        'loader_config.json': 'Otros (Avanzado)',
    }
    
    # Archivos que permiten fusión (listas JSON)
    mergeable_files = ['favorites.json', 'history.json', 'search_history.json', 'exploration_history.json']
    
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available_files = zf.namelist()
        
        # Filtrar solo archivos conocidos
        known_files = [f for f in available_files if f in file_labels]
        
        if not known_files:
            xbmcgui.Dialog().ok("AtresDaily", "Este backup no contiene datos reconocidos.")
            return
        
        # Crear lista de opciones
        options = [file_labels.get(f, f) for f in known_files]
        
        # Selección múltiple
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        
        if selected is None or len(selected) == 0:
            return
        
        files_to_restore = [known_files[i] for i in selected]
        
        with zipfile.ZipFile(source, 'r') as zf:
            for fname_zip in files_to_restore:
                dest_path = os.path.join(profile, fname_zip)
                
                # Si el archivo es fusionable y ya existe, preguntar
                if fname_zip in mergeable_files and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(
                        f"{file_labels[fname_zip]}", 
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"]
                    )
                    
                    if choice == 2 or choice == -1:  # Omitir
                        continue
                    elif choice == 1:  # Fusionar
                        try:
                            # Leer actual
                            with open(dest_path, 'r', encoding='utf-8') as f:
                                current_data = json.load(f)
                            # Leer del backup
                            with zf.open(fname_zip) as zfile:
                                backup_data = json.load(zfile)
                            # Fusionar (si son listas)
                            if isinstance(current_data, list) and isinstance(backup_data, list):
                                merged = current_data + [x for x in backup_data if x not in current_data]
                                with open(dest_path, 'w', encoding='utf-8') as f:
                                    json.dump(merged, f, ensure_ascii=False)
                                continue
                            elif isinstance(current_data, dict) and isinstance(backup_data, dict):
                                current_data.update(backup_data)
                                with open(dest_path, 'w', encoding='utf-8') as f:
                                    json.dump(current_data, f, ensure_ascii=False)
                                continue
                        except Exception as e:
                            xbmc.log(f"[AtresDaily] Error fusionando {fname_zip}: {e}", xbmc.LOGWARNING)
                            # Si falla la fusión, caer en extracción normal (sustituir)
                
                # Extracción normal (sustituir)
                zf.extract(fname_zip, profile)
        
        xbmcgui.Dialog().notification("AtresDaily", "Restauración completada")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo en restauración: {e}")

def _del_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_backup", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f, folder=False)
    ui_utils.close_item_list()

def delete_single_backup(fname):
    try:
        os.remove(os.path.join(_get_backup_dir(), fname))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo borrar: {e}")
        return
    xbmc.executebuiltin("Container.Refresh")

def _export_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    ui_utils.add_item(action="", title="[I]Selecciona copia para exportar:[/I]", thumbnail="DefaultIconInfo.png", folder=False)
    for f in files:
        ui_utils.add_item(action="export_single_backup", title=f"Exportar: {f}", url=f, folder=False)
    ui_utils.close_item_list()

def export_single_backup(fname):
    source = os.path.join(_get_backup_dir(), fname)
    # Type 3: ShowAndGetWriteableDirectory
    dest_folder = xbmcgui.Dialog().browse(3, f'Guardar {fname} en...', 'files')
    if dest_folder:
        try:
            dest_file = os.path.join(dest_folder, fname)
            shutil.copy2(source, dest_file)
            xbmcgui.Dialog().notification("AtresDaily", f"Exportado a: {dest_folder}")
        except Exception as e:
            xbmcgui.Dialog().ok("Error al Exportar", str(e))

# --- ENVOLTORIO DE TV EN VIVO ---
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"
_CUSTOM_IPTV_FILE = "custom_iptv_lists.json"

def _load_custom_iptv():
    """Carga las listas IPTV personalizadas."""
    return ui_utils.load_json(_CUSTOM_IPTV_FILE, default=[])

def _save_custom_iptv(lists):
    """Guarda las listas IPTV personalizadas."""
    ui_utils.save_json(_CUSTOM_IPTV_FILE, lists)

def _parse_m3u_content(text):
    """Parsea contenido M3U/M3U8 y devuelve lista de canales."""
    lines = text.splitlines()
    channels = []
    current_name = ""
    current_logo = ""
    current_group = ""

    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            current_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            logo_match = re.search(r'tvg-logo="([^"]*)"', line)
            current_logo = logo_match.group(1) if logo_match else ""
            group_match = re.search(r'group-title="([^"]*)"', line)
            current_group = group_match.group(1) if group_match else ""
        elif line and not line.startswith("#"):
            channels.append({
                "name": current_name or "Canal",
                "url": line,
                "logo": current_logo,
                "group": current_group,
            })
    return channels

def live_tv_menu():
    """TV en directo: canales A3Player + TDT + listas personalizadas."""
    if xbmcaddon.Addon().getSetting('hide_vpn_nota') != 'true':
        li_vpn = xbmcgui.ListItem(label="[B][COLOR yellow]NOTA: Los directos suelen fallar con VPN activa[/COLOR][/B] (pulsa aquí para quitar este mensaje)")
        li_vpn.setInfo('video', {'plot': "Las emisiones en directo de A3Player tienen sistemas de detección que suelen bloquear las conexiones a través de VPN. Si tienes problemas, prueba a desactivarla."})
        li_vpn.setArt({'icon': ui_utils.media_icon("info.png")})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0] + "?action=vpn_nota", listitem=li_vpn, isFolder=False)

    # Interceptar endOfDirectory para añadir más elementos al final
    _original_end = xbmcplugin.endOfDirectory
    xbmcplugin.endOfDirectory = lambda *a, **kw: None
    try:
        connector.list_live()
    except Exception:
        pass
    finally:
        xbmcplugin.endOfDirectory = _original_end
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    directo_icon = os.path.join(addon_path, "resources", "media", "directo.png")
    directo_thumb = directo_icon if os.path.exists(directo_icon) else "DefaultAddonPVRClient.png"
    ui_utils.add_item(action="list_live_cats", title="En Directo A3", thumbnail=directo_thumb, folder=True)

    ui_utils.add_item(
        action="epg_texto_atres",
        title="[B][COLOR lightcyan]EPG (guía de televisión)[/COLOR][/B]",
        thumbnail=ui_utils.media_icon("cat_epg_texto.png") or "DefaultIconInfo.png",
        folder=True,
        plot="EPG de los canales aquí listados.\nParrilla completa disponible en EspaTV."
    )

    # EspaTV — instalar/abrir
    try:
        xbmcaddon.Addon(_ESPATV_ADDON_ID)
        _espatv_live_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        _espatv_live_status = "[COLOR gray]No instalado[/COLOR]"
    li = xbmcgui.ListItem(label=f"[COLOR red]Es[/COLOR][COLOR gold]pa[/COLOR][COLOR red]TV[/COLOR] — Canales, TV, radio, agenda deportiva, top películas y series y más — {_espatv_live_status}")
    li.setArt({'icon': 'DefaultAddonVideo.png'})
    li.setInfo('video', {'plot': (
        "[B]EspaTV[/B] - Addon todo-en-uno para contenido en castellano\n\n"
        "• TV España (nacionales, autonómicos, temáticos)\n"
        "• Samsung TV Plus y Pluto TV\n"
        "• Radio y podcast\n"
        "• Agenda deportiva\n"
        "• Top películas y series\n"
        "• Dailymotion y YouTube\n\n"
        "Pulsa para abrir o instalar automáticamente.\n\n"
        "https://github.com/espakodi/espatv"
    )})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=sys.argv[0] + "?action=espatv_install",
        listitem=li,
        isFolder=False
    )

    li_ace = xbmcgui.ListItem(label="Buscar directos en AceStream (VPN)")
    li_ace.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li_ace.setInfo('video', {'plot': (
        "[COLOR yellow]Si no aparecen resultados o falla la búsqueda, prueba activando una VPN. El servidor público de AceStream suele estar restringido en algunas redes españolas.[/COLOR]\n\n"
        "Busca canales y streams en la red AceStream. Consulta primero el motor local (127.0.0.1:6878) y, si no responde, el servidor público search.acestream.net.\n\n"
        "El protocolo acestream:// no es nativo de Kodi, así que necesitas tener instalado program.plexus (recomendado) o script.module.horus. Dependiendo del addon y la plataforma, puede que también necesites el AceStream Engine instalado en el sistema."
    )})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0] + "?action=search_acestream", listitem=li_ace, isFolder=True)

    ui_utils.add_item(action="tdt_channels_json", title="TDT Channels España", thumbnail="DefaultAddonPVRClient.png", folder=True, plot="Lista completa de canales de la TDT española organizada por categorías.\nFuente: tdtchannels.com\n\nIncluye nacionales, autonómicos, temáticos y más.")

    # --- ADDONS RECOMENDADOS (SlyGuy) ---
    _slyguy_addons = [
        ("slyguy.samsung.tv.plus", "Samsung TV Plus", "TV gratis: canales en directo y películas bajo demanda sin necesidad de cuenta."),
        ("slyguy.pluto.tv.provider", "Pluto TV", "Cientos de canales de TV en directo y contenido bajo demanda totalmente gratis."),
    ]
    for addon_id, addon_name, addon_desc in _slyguy_addons:
        status = "[COLOR lime]Instalado[/COLOR]" if _addon_is_known(addon_id) else "[COLOR gray]No instalado[/COLOR]"

        li = xbmcgui.ListItem(label=f"{addon_name} — {status}")
        li.setArt({'icon': 'DefaultAddonVideo.png'})
        li.setInfo('video', {'plot': f"{addon_desc}\n\nRequiere el repositorio SlyGuy.\nPulsa para abrir o instalar."})
        url = f"{sys.argv[0]}?action=slyguy_install&url={addon_id}&title={urllib.parse.quote(addon_name)}"
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

    # TDT M3U
    ui_utils.add_item(action="tdt_channels", title="TDT Channels España (M3U)", thumbnail="DefaultAddonPVRClient.png", folder=True, plot="Lista M3U alternativa de canales TDT.\nMismo contenido en formato plano.")

    # Listas m3u del usuario
    custom_lists = _load_custom_iptv()
    for i, lst in enumerate(custom_lists):
        name = lst.get("name", f"Lista {i+1}")
        url = lst.get("url", "")
        cm = [("Eliminar esta lista", f"RunPlugin({sys.argv[0]}?action=delete_custom_iptv&url={urllib.parse.quote(url, safe='')})")]
        ui_utils.add_item(action="view_custom_iptv", title=name, url=url, thumbnail="DefaultAddonPVRClient.png", folder=True, plot=f"Lista personalizada\nURL: {url}", context=cm)

    # Botón para añadir nueva lista
    ui_utils.add_item(action="add_custom_iptv", title="Añadir IPTV M3U", thumbnail="DefaultAddSource.png", folder=False, plot="Introduce la URL de canales IPTV en formato M3U/M3U8.\nEjemplo: https://ejemplo.com/canales.m3u8")

    ui_utils.close_item_list()

def _render_m3u_channels(channels, source_label=""):
    """Renderiza una lista de canales parseados de M3U en el directorio de Kodi."""
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')

    for ch in channels:
        label = ch["name"]
        if ch["group"]:
            label = f"[COLOR gray][{ch['group']}][/COLOR] {ch['name']}"

        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or "DefaultAddonPVRClient.png"
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {
            'title': ch["name"],
            'plot': f"Canal: {ch['name']}\nGrupo: {ch['group']}\n\nFuente: {source_label}" if source_label else f"Canal: {ch['name']}\nGrupo: {ch['group']}"
        })

        cm = []
        cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(ch['name'], safe='')}&url={urllib.parse.quote(ch['url'], safe='')}&thumbnail={urllib.parse.quote(thumb, safe='')}&extra=&fav_action=play_tdt)"))
        li.addContextMenuItems(cm)

        play_url = f"{sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(ch['url'], safe='')}&title={urllib.parse.quote(ch['name'], safe='')}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

# Cache temporal del JSON de TDT (se descarga cada vez que entras a la sección)
_tdt_json_cache = {"data": None}

def search_acestream():
    kb = xbmc.Keyboard('', 'Buscar en AceStream')
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    query = kb.getText().strip()
    _search_acestream_results(query)

def _search_acestream_results(query):
    h = int(sys.argv[1])
    encoded_q = urllib.parse.quote_plus(query)
    api_urls = [
        ("motor local",    f"http://127.0.0.1:6878/server/api?method=search&query={encoded_q}&page=0"),
        ("servidor público", f"https://search.acestream.net/?method=search&api_key=test_api_key&api_version=1&query={encoded_q}&page=0"),
    ]
    progress = xbmcgui.DialogProgressBG()
    try: progress.create("AceStream", f"Buscando: {query}")
    except Exception: progress = None

    data = None; last_error = None
    from urllib.request import urlopen as _urlopen, Request as _Request
    for label, api_url in api_urls:
        try:
            xbmc.log(f"[AtresDaily AceStream] Buscando '{query}' via {label}", xbmc.LOGINFO)
            req = _Request(api_url, headers={"User-Agent": "Mozilla/5.0 (Kodi)"})
            raw = _urlopen(req, timeout=10).read().decode("utf-8", errors="replace")
            parsed = json.loads(raw)
            if isinstance(parsed, dict) and parsed.get("error"):
                last_error = f"{label}: {parsed.get('error')}"
                xbmc.log(f"[AtresDaily AceStream] {label} devolvió error: {parsed.get('error')}", xbmc.LOGWARNING)
                continue
            xbmc.log(f"[AtresDaily AceStream] {label} OK ({len(raw)} chars)", xbmc.LOGINFO)
            data = parsed; break
        except Exception as e:
            last_error = f"{label}: {e}"
            xbmc.log(f"[AtresDaily AceStream] {label} falló: {e}", xbmc.LOGWARNING)
            continue

    if progress:
        try: progress.close()
        except Exception: pass

    if data is None:
        xbmcgui.Dialog().ok("Buscar en AceStream", f"No se pudo realizar la búsqueda.\n\n{last_error or 'error desconocido'}")
        xbmcplugin.endOfDirectory(h, succeeded=False); return

    results = []
    if isinstance(data, list): results = data
    elif isinstance(data, dict):
        results = (data.get("result") or {}).get("results") or data.get("results") or []

    if not results:
        xbmcgui.Dialog().ok("AceStream", f"Sin resultados para: {query}")
        xbmcplugin.endOfDirectory(h, succeeded=True); return

    xbmcplugin.setPluginCategory(h, f"AceStream: {query}")
    xbmcplugin.setContent(h, "videos")
    for item in results:
        if not isinstance(item, dict): continue
        name = str(item.get("name") or item.get("title") or "Sin nombre")
        infohash = str(item.get("infohash") or item.get("id") or "").strip()
        if not infohash: continue
        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1: availability /= 100.0
        except (TypeError, ValueError): availability = 0
        plot_parts = []
        cats = item.get("categories") or []
        if isinstance(cats, list) and cats: plot_parts.append("Categoría: " + ", ".join(str(c) for c in cats if c))
        if availability > 0: plot_parts.append(f"Disponibilidad: {availability*100:.0f}%")
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": "\n".join(plot_parts) or name})
        li.setArt({"icon": "DefaultAddonTvInfo.png"})
        li.setProperty("IsPlayable", "true")
        play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote('acestream://'+infohash)}&title={urllib.parse.quote(name)}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def tdt_channels_json():
    """Descarga y muestra las categorías de TDT Channels España (JSON)."""
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")

    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_JSON_URL, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        dp.update(70, "Procesando canales...")
        data = r.json()
        dp.close()

        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h)
            return

        # Guardar en caché para acceso rápido desde tdt_json_ambit
        _tdt_json_cache["data"] = countries[0].get("ambits", [])

        # Mostrar ambits como carpetas
        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            ui_utils.add_item(
                action="tdt_json_ambit", title=f"{name} [COLOR gray]({num})[/COLOR]",
                url=name, thumbnail="DefaultAddonPVRClient.png", folder=True,
                plot=f"Categoría: {name}\nCanales: {num}"
            )

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error TDT JSON: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TDT Channels", f"No se pudo cargar:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def tdt_json_ambit(ambit_name):
    """Muestra los canales de un ambit concreto del JSON de TDT Channels."""
    h = int(sys.argv[1])

    # Si no hay caché, volver a descargar
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            r = requests.get(_TDT_JSON_URL, timeout=15)
            data = r.json()
            countries = data.get("countries", [])
            ambits = countries[0].get("ambits", []) if countries else []
            _tdt_json_cache["data"] = ambits
        except Exception as e:
            xbmcgui.Dialog().ok("Error", f"No se pudo descargar: {e}")
            xbmcplugin.endOfDirectory(h)
            return

    # Buscar el ámbito por nombre
    ambit = next((a for a in ambits if a.get("name") == ambit_name), None)
    if not ambit:
        xbmcgui.Dialog().ok("TDT Channels", f"Categoría '{ambit_name}' no encontrada.")
        xbmcplugin.endOfDirectory(h)
        return

    xbmcplugin.setContent(h, 'videos')

    for ch in ambit.get("channels", []):
        name = ch.get("name", "Canal")
        logo = ch.get("logo", "")
        options = ch.get("options", [])
        extra_info = ch.get("extra_info", [])
        web_url = ch.get("web", "")

        # Buscar el primer flujo válido
        stream_url = ""
        stream_format = ""
        for opt in options:
            u = opt.get("url", "")
            if u:
                stream_url = u
                stream_format = opt.get("format", "")
                break

        # Etiqueta
        label = name
        if "GEO" in extra_info:
            label += " [COLOR orange][GEO][/COLOR]"

        thumb = logo or "DefaultAddonPVRClient.png"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})

        if stream_url:
            # Canal con flujo directo
            opts_text = "\n".join([f"  • {o.get('url','')[:60]}..." for o in options[:4]])
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\nFormato: {stream_format}\n\nStreams disponibles ({len(options)}):\n{opts_text}"
            })

            cm = []
            cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(name, safe='')}&url={urllib.parse.quote(stream_url, safe='')}&thumbnail={urllib.parse.quote(thumb, safe='')}&extra=&fav_action=play_tdt)"))
            if len(options) > 1 and options[1].get("url"):
                cm.append(("Probar otro stream", f"RunPlugin({sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(options[1].get('url',''), safe='')}&title={urllib.parse.quote(name, safe='')})"))
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(stream_url, safe='')}&title={urllib.parse.quote(name, safe='')}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        elif web_url:
            # Canal sin flujo pero con web oficial (Mediaset, etc.)
            label = f"{name} [COLOR skyblue][WEB][/COLOR]"
            if "GEO" in extra_info:
                label += " [COLOR orange][GEO][/COLOR]"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\n\nEste canal no tiene stream directo.\nSe abrirá en el navegador:\n{web_url}"
            })
            open_url = f"{sys.argv[0]}?action=open_browser_url&url={urllib.parse.quote(web_url, safe='')}"
            xbmcplugin.addDirectoryItem(handle=h, url=open_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def tdt_channels():
    """Descarga y muestra la lista M3U de TDT Channels España."""
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")

    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_M3U_URL, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()

        if not channels:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron canales en la lista.")
            xbmcplugin.endOfDirectory(h)
            return

        _render_m3u_channels(channels, "TDT Channels España")

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error TDT Channels: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TDT Channels", f"No se pudo cargar la lista:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def open_browser_url(url):
    """Abre una URL en el navegador. Soporta Android (TV/Fire Stick) y PC."""
    h = int(sys.argv[1])
    try:
        # 1. Android (Fire Stick, TV Box, tablets...)
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin(f"StartAndroidActivity(,android.intent.action.VIEW,,{url})")
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            # 2. PC (Windows/Mac/Linux)
            import webbrowser
            webbrowser.open(url)
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)

    except Exception:
        # 3. Alternativa: mostrar la URL para que el usuario la copie
        xbmcgui.Dialog().ok("Abrir en navegador",
            f"No se pudo abrir el navegador automáticamente.\n\n"
            f"Abre esta URL manualmente:\n{url}")
    finally:
        # Cerrar directorio Kodi para que no se quede colgado
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except Exception:
            pass

def play_tdt(url, title="", ua="", ref=""):
    """Reproduce un canal TDT/IPTV (stream M3U8/MP4)."""
    try:
        play_url = url
        is_m3u8 = '.m3u8' in url.lower()

        use_ia = False
        if is_m3u8 and xbmcaddon.Addon().getSetting('use_inputstream') == 'true':
            try:
                xbmcaddon.Addon('inputstream.adaptive')
                use_ia = True
            except RuntimeError:
                xbmc.log("[AtresDaily] InputStream Adaptive activado pero no instalado.", xbmc.LOGWARNING)

        if xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true' and not ua:
            ua = ui_utils.HEADERS["User-Agent"]

        if (ua or ref) and not use_ia:
            parts = []
            if ua:  parts.append("User-Agent=" + urllib.parse.quote(ua))
            if ref: parts.append("Referer="    + urllib.parse.quote(ref))
            play_url = url + "|" + "&".join(parts)

        li = xbmcgui.ListItem(path=play_url)
        if title:   li.setInfo('video', {'title': title})
        if is_m3u8: li.setMimeType('application/x-mpegURL')

        if use_ia:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if ua:
                li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + ua)

        xbmc.Player().play(play_url, li)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error TDT play: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"No se pudo reproducir:\n{e}")

def add_custom_iptv():
    """Añadir una lista IPTV personalizada por URL."""
    kb = xbmc.Keyboard('', 'URL de la lista M3U/M3U8')
    kb.doModal()
    if not kb.isConfirmed(): return
    url = kb.getText().strip()
    if not url:
        return
    if not url.startswith(('http://', 'https://')):
        xbmcgui.Dialog().ok("AtresDaily", "La URL debe empezar por http:// o https://")
        return

    # Verificar que la URL es accesible
    try:
        r = requests.get(url, timeout=10)
        if r.status_code != 200:
            xbmcgui.Dialog().ok("AtresDaily", f"No se pudo acceder a la URL.\nError HTTP {r.status_code}")
            return
        channels = _parse_m3u_content(r.text)
        if not channels:
            xbmcgui.Dialog().ok("AtresDaily", "La URL no contiene canales válidos en formato M3U.")
            return
    except Exception as e:
        xbmcgui.Dialog().ok("AtresDaily", f"Error al verificar la URL:\n{e}")
        return

    # Pedir nombre
    kb2 = xbmc.Keyboard('', f'Nombre para la lista ({len(channels)} canales encontrados)')
    kb2.doModal()
    if not kb2.isConfirmed() or not kb2.getText().strip():
        return
    name = kb2.getText().strip()

    # Guardar
    lists = _load_custom_iptv()
    # Evitar duplicados
    if any(l.get("url") == url for l in lists):
        xbmcgui.Dialog().notification("AtresDaily", "Esta lista ya está añadida", xbmcgui.NOTIFICATION_WARNING)
        return
    lists.append({"name": name, "url": url})
    _save_custom_iptv(lists)
    xbmcgui.Dialog().notification("AtresDaily", f"Lista '{name}' añadida", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def view_custom_iptv(url):
    """Descarga y muestra los canales de una lista IPTV personalizada."""
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Lista IPTV", "Descargando lista...")

    try:
        dp.update(30, "Descargando...")
        r = requests.get(url, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()

        if not channels:
            xbmcgui.Dialog().ok("Lista IPTV", "No se encontraron canales.")
            xbmcplugin.endOfDirectory(h)
            return

        _render_m3u_channels(channels, "Lista personalizada")

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error lista IPTV: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Lista IPTV", f"No se pudo cargar:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def delete_custom_iptv(url):
    """Elimina una lista IPTV personalizada."""
    lists = _load_custom_iptv()
    name = next((l.get("name", "Lista") for l in lists if l.get("url") == url), "Lista")
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Eliminar la lista '{name}'?"):
        new_lists = [l for l in lists if l.get("url") != url]
        _save_custom_iptv(new_lists)
        xbmcgui.Dialog().notification("AtresDaily", "Lista eliminada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def input_search():
    cfg = ui_utils.load_json('settings.json')

    adv_active = cfg.get('advanced_search_active', True)
    if str(adv_active).lower() == 'true': adv_active = True
    if adv_active:
        _advanced_search_menu()
        return
    kb = xbmc.Keyboard('', 'AtresDaily Search')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        t = kb.getText()
        connector.add_hist(t)
        connector.search_internet(t)
    else:
        ui_utils.close_item_list()


def view_history():
    ui_utils.add_item(action="del_history", title="[COLOR red]Borrar Historial[/COLOR]", thumbnail="DefaultIconError.png", folder=False)
    h = ui_utils.load_json('history.json')
    for q in h:
        # Añadir opción de guardar búsqueda en favoritos
        cm = [("Añadir a Favoritos de AtresDaily", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=search&url={urllib.parse.quote(q)}&title={urllib.parse.quote(q)}&f_thumb={urllib.parse.quote(ICON_MAIN)})")]
        cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(q)})"))
        ui_utils.add_item(action="search", title=q, url=q, thumbnail=ICON_MAIN, folder=True, direct="true", context=cm)
    ui_utils.close_item_list()

def del_history():
    ui_utils.save_json('history.json', [])
    xbmc.executebuiltin("Container.Refresh")

# --- LÓGICA DE FAVORITOS ---
def view_favorites():
    favs = core_settings.get_favorites()

    # --- INTEGRACIÓN CON FLOW FAVMANAGER ---
    try:
        xbmcaddon.Addon('plugin.program.flowfavmanager')
        flow_installed = True
    except Exception:
        flow_installed = False

    if flow_installed:
        li_flow = xbmcgui.ListItem(label="[COLOR violet]Flow FavManager[/COLOR]")
        li_flow.setArt({'icon': 'DefaultAddonProgram.png'})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=flowfav_launch", listitem=li_flow, isFolder=False)
    else:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': 'DefaultAddonProgram.png'})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi. Pulsa para instalarlo automáticamente o ver las instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=flowfav_launch", listitem=li_flow, isFolder=False)

    # --- ENLACE PARA AÑADIR CATEGORÍAS PERSONALIZADAS ---
    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow]Mis Categorías ({len(cats)})[/COLOR]")
         li_c.setArt({'icon': 'DefaultAddonService.png'})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=cat_menu", listitem=li_c, isFolder=True)

    # --- BOTÓN DE NOVEDADES ---
    if favs:
        li_news = xbmcgui.ListItem(label="[COLOR orange]Novedades de mis Favoritos[/COLOR]")
        li_news.setArt({'icon': 'DefaultRecentlyAddedMovies.png'})
        li_news.setInfo('video', {'plot': 'Busca contenido reciente subido a Dailymotion relacionado con tus favoritos.\nElige un margen de tiempo (24h, 48h, 7 días, 30 días).'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=fav_news", listitem=li_news, isFolder=True)

    # --- COPIA DE SEGURIDAD ---
    ui_utils.add_item(action="backup_favs_dialog", title="Copia de Seguridad", thumbnail=ui_utils.media_icon("backup_favs.png"), folder=False, plot="Exportar o importar favoritos (JSON o TXT).")

    if not favs:
        if not cats:
             ui_utils.add_item(action="", title="No tienes favoritos guardados", thumbnail="DefaultIconInfo.png", folder=False)
    else:
        for f in favs:
            t = f.get('title')
            u = f.get('url')
            if not u: continue
            
            icon = f.get('icon', ICON_MAIN)
            action = f.get('action', 'search')
            params = f.get('params', {})
            
            # Menú contextual
            cm = []
            
            # Gestión
            cm.append(("Renombrar...", f"RunPlugin({sys.argv[0]}?action=fav_rename&fav_url={urllib.parse.quote(u)}&old_title={urllib.parse.quote(t)})"))
            cm.append(("Mover arriba", f"RunPlugin({sys.argv[0]}?action=fav_move_up&fav_url={urllib.parse.quote(u)})"))
            cm.append(("Mover abajo", f"RunPlugin({sys.argv[0]}?action=fav_move_down&fav_url={urllib.parse.quote(u)})"))
            
            # Soporte de categorías
            cm.append(("Mover a Categoría...", f"RunPlugin({sys.argv[0]}?action=cat_move_from_favs&fav_url={urllib.parse.quote(u)}&q={urllib.parse.quote(t)})"))
            
            # Buscar en webs de torrent
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(t)})"))
            
            # Eliminar
            cm.append(("Eliminar de Favoritos", f"RunPlugin({sys.argv[0]}?action=del_fav&url={urllib.parse.quote(u)})"))
            
            extra = params.get('extra') or ''
            
            # Forzar direct=true para saltar el menú avanzado
            kwargs = {}
            if action == "search":
                kwargs["direct"] = "true"
            
            ui_utils.add_item(action=action, title=t, url=u, thumbnail=icon, extra=extra, folder=True, context=cm, **kwargs)
        
    ui_utils.close_item_list()

def show_fav_news():
    """Agregador: Busca contenido reciente de los favoritos con margen dinámico."""
    h = int(sys.argv[1])
    try:
        favs = core_settings.get_favorites()
        if not favs:
            xbmcgui.Dialog().notification("AtresDaily", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h)
            return

        if connector is None:
            xbmcgui.Dialog().notification("AtresDaily", "Conector no disponible", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(h)
            return

        # 1. Preguntar margen temporal
        opts = [
            "Últimas 24 horas",
            "Últimas 48 horas (Recomendado)",
            "Última semana (7 días)",
            "Último mes (30 días - Lento)"
        ]
        sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
        if sel < 0:
            xbmcplugin.endOfDirectory(h)
            return

        margins = [86400, 172800, 604800, 2592000]
        time_limit = int(time.time()) - margins[sel]
        sel_label = opts[sel]

        # 2. Extraer consultas únicas de los favoritos
        queries = []
        seen = set()
        for f in favs:
            q = None
            act = f.get('action', '')
            # search / trakt_search_dialog: el título del favorito ES la query
            if act in ('search', 'trakt_search_dialog'):
                q = f.get('title', '').strip()
            # Otros tipos: usar el título limpio
            elif act in ('list_details', 'play_media', 'list_cat'):
                q = f.get('title', '').strip()
                # Limpiar prefijos de color Kodi
                if q.startswith('['):
                    q = re.sub(r'\[/?[A-Za-z ]+\]', '', q).strip()

            if q and q.lower() not in seen:
                queries.append(q)
                seen.add(q.lower())

        if not queries:
            xbmcgui.Dialog().ok("Novedades", "No hay búsquedas válidas en tus favoritos para analizar.")
            xbmcplugin.endOfDirectory(h)
            return

        # 3. Buscar novedades con cuadro de diálogo de progreso cancelable
        pdp = xbmcgui.DialogProgress()
        pdp.create("Novedades de mis Favoritos", f"Buscando: {sel_label}...")

        all_results = []
        seen_ids = set()
        total = len(queries)
        cancelled = False

        for i, q in enumerate(queries):
            if pdp.iscanceled():
                cancelled = True
                break
            pdp.update(int((i / total) * 100), f"Analizando: [B]{q}[/B]")

            try:
                rs = connector._sr(q, {"created_after": time_limit})
                if rs:
                    sr = connector._gsr(q, rs)
                    for score, v in sr:
                        if score > 0.35:  # Filtro de calidad
                            vid = v.get("id")
                            if vid and vid not in seen_ids:
                                seen_ids.add(vid)
                                all_results.append((score, v, q))
            except Exception:
                pass  # Silenciar errores individuales, seguir con el resto

        pdp.close()

        if not all_results:
            if cancelled:
                xbmcgui.Dialog().notification("AtresDaily", "Búsqueda cancelada", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().ok("Novedades de mis Favoritos",
                    f"No se han encontrado novedades en '{sel_label}' para tus favoritos.")
            xbmcplugin.endOfDirectory(h)
            return

        # 4. Mostrar resultados consolidados
        all_results.sort(key=lambda x: x[0], reverse=True)
        xbmcplugin.setContent(h, 'videos')

        for score, v, origin in all_results:
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.username", "Unknown")
            du = v.get("duration", 0)
            try:
                du = int(du)
            except (ValueError, TypeError):
                du = 0
            dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ICON_MAIN

            label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {
                'title': vt,
                'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du // 60}m {du % 60}s",
                'duration': du
            })
            li.setProperty("IsPlayable", "true")

            # Menú contextual
            cm = []
            cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vi or '')})"))
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
            if vi:
                cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vi)}&title={urllib.parse.quote(vt)})"))
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vi or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al buscar novedades:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def show_trending():
    """Muestra los vídeos trending de Dailymotion filtrados por idioma español."""
    h = int(sys.argv[1])
    try:
        # Llamada directa a la API pública de Dailymotion
        time_limit = int(time.time()) - 604800  # 7 días
        api_url = "https://api.dailymotion.com/videos"
        params = {
            "sort": "trending",
            "language": "es",
            "created_after": time_limit,
            "limit": 50,
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        resp = requests.get(api_url, params=params, timeout=15)
        data = resp.json()
        rs = data.get("list", [])

        if not rs:
            xbmcgui.Dialog().ok("Top Semanal", "No se han encontrado vídeos en tendencia.")
            xbmcplugin.endOfDirectory(h)
            return

        xbmcplugin.setContent(h, 'videos')

        # Cargar IDs vistos para marcar
        watched_ids = core_settings.get_watched_ids()

        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = v.get("duration", 0)
            try:
                du = int(du)
            except (ValueError, TypeError):
                du = 0
            vw = v.get("views_total", 0)
            try:
                vw = int(vw)
            except (ValueError, TypeError):
                vw = 0
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ICON_MAIN

            # Indicador de visto
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = f"[COLOR orange]{i+1}.[/COLOR] {watched_mark}{vt}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {
                'title': vt,
                'plot': f"Canal: {ow}\nVistas: {vw:,}\nDuración: {du // 60}m {du % 60}s",
                'duration': du
            })
            li.setProperty("IsPlayable", "true")

            # Menú contextual
            cm = []
            cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vi or '')})"))
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
            if vi:
                cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vi)}&title={urllib.parse.quote(vt)})"))
                cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=search&url={urllib.parse.quote(vt)}&title={urllib.parse.quote(vt)}&f_thumb={urllib.parse.quote(dth)})"))
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vi or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar tendencias:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def view_watch_history():
    """Muestra el historial de vídeos reproducidos."""
    import datetime
    h = int(sys.argv[1])
    try:
        history = core_settings.get_watch_history()

        # Botón limpiar historial (solo si hay historial)
        if history:
            li_clear = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial[/COLOR]")
            li_clear.setArt({'icon': 'DefaultIconError.png'})
            li_clear.setInfo('video', {'plot': f"Tienes {len(history)} vídeos en el historial.\nPulsa para borrar todo."})
            li_clear.addContextMenuItems([])
            xbmcplugin.addDirectoryItem(handle=h, url=f"{sys.argv[0]}?action=clear_watch_history", listitem=li_clear, isFolder=True)

        if not history:
            ui_utils.add_item(action="", title="No has reproducido ningún vídeo aún", thumbnail="DefaultIconInfo.png", folder=False)
        else:
            xbmcplugin.setContent(h, 'videos')
            for entry in history:
                vid = entry.get('vid', '')
                vt = entry.get('title', 'Video')
                dth = entry.get('thumb', '') or ICON_MAIN
                du = entry.get('duration', 0)
                try:
                    du = int(du)
                except (ValueError, TypeError):
                    du = 0
                watched_at = entry.get('watched_at', 0)

                # Formatear fecha
                try:
                    dt = datetime.datetime.fromtimestamp(watched_at)
                    date_str = dt.strftime("%d/%m/%Y %H:%M")
                except Exception:
                    date_str = ""

                label = f"[COLOR lime][V][/COLOR] {vt}"
                li = xbmcgui.ListItem(label=label)
                li.setArt({'thumb': dth, 'icon': dth})
                li.setInfo('video', {
                    'title': vt,
                    'plot': f"Visto: {date_str}\nDuración: {du // 60}m {du % 60}s",
                    'duration': du
                })
                li.setProperty("IsPlayable", "true")

                # Menú contextual
                cm = []
                cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vid or '')})"))
                cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
                if vid:
                    cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(vt)})"))
                    cm.append(("Eliminar del historial", f"RunPlugin({sys.argv[0]}?action=del_watch_entry&url={urllib.parse.quote(vid)})"))
                li.addContextMenuItems(cm)

                play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vid or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
                xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar historial:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass


def backup_favs_dialog():
    opts = [
        "Exportar a JSON (para restaurar)",
        "Exportar a Texto (.txt)",
        "Importar Favoritos (JSON)",
    ]
    sel = xbmcgui.Dialog().select("Copia de Seguridad de Favoritos", opts)
    if sel == 0:
        export_favs()
    elif sel == 1:
        export_favs_txt()
    elif sel == 2:
        import_favs()

def export_favs_menu():
    """Submenú con opciones de exportación e importación de favoritos."""
    ui_utils.add_item(action="export_favs_txt", title="[COLOR gold]Exportar a Texto (.txt)[/COLOR]", thumbnail="DefaultAddonRepository.png", folder=False, plot="Genera un archivo de texto plano legible con todos tus favoritos.")
    ui_utils.add_item(action="export_favs", title="[COLOR gold]Exportar a JSON (para restaurar)[/COLOR]", thumbnail="DefaultAddonRepository.png", folder=False, plot="Exporta tus favoritos como archivo JSON que puedes restaurar después.")
    ui_utils.add_item(action="import_favs", title="[COLOR lightblue]Importar Favoritos (JSON)[/COLOR]", thumbnail="DefaultAddonRepository.png", folder=False, plot="Restaura favoritos desde un archivo JSON exportado previamente.")
    ui_utils.close_item_list()

def export_favs():
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return
    
    import shutil
    try:
        shutil.copy2(ui_utils.get_path('favorites.json'), os.path.join(d, 'favorites_backup.json'))
        xbmcgui.Dialog().notification("AtresDaily", "Favoritos exportados con éxito")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo exportar los favoritos: {e}")

def export_favs_txt():
    """Exporta la lista de favoritos a un archivo de texto plano."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("AtresDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    dest = os.path.join(d, 'favoritos_atresdaily.txt')
    try:
        with open(dest, 'w', encoding='utf-8') as f:
            f.write(f"Favoritos AtresDaily — {time.strftime('%d/%m/%Y %H:%M')}\n")
            f.write(f"Total: {len(favs)} favoritos\n")
            f.write("=" * 50 + "\n\n")
            for fav in favs:
                title = fav.get('title', 'Sin título')
                url = fav.get('url', '')
                action = fav.get('action', '')
                f.write(f"{title}\n")
                if url:
                    f.write(f"  URL: {url}\n")
                if action:
                    f.write(f"  Tipo: {action}\n")
                f.write("\n")
        xbmcgui.Dialog().notification("AtresDaily", f"Exportados {len(favs)} favoritos a TXT")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo exportar: {e}")

def multi_search():
    """Búsqueda múltiple: varios términos separados por comas."""
    if connector is None:
        xbmcgui.Dialog().ok("AtresDaily", "El conector no está disponible.")
        return

    kb = xbmc.Keyboard('', 'Términos separados por comas')
    kb.doModal()
    if not kb.isConfirmed(): return

    raw = kb.getText().strip()
    if not raw: return

    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("AtresDaily", "No se encontraron términos válidos", xbmcgui.NOTIFICATION_WARNING)
        ui_utils.close_item_list()
        return

    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("AtresDaily", "Limitado a 10 términos", xbmcgui.NOTIFICATION_INFO)

    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Búsqueda Múltiple", f"Buscando {len(terms)} términos...")

    all_results = []
    seen_ids = set()

    for idx, term in enumerate(terms):
        if dp.iscanceled(): break
        dp.update(int((idx / len(terms)) * 100), f"Buscando: {term}")

        try:
            params = {
                "search": term,
                "sort": "relevance",
                "language": "es",
                "limit": 10,
                "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
            }
            resp = requests.get(_E3, params=params, timeout=15)
            data = resp.json()
            for item in data.get("list", []):
                vid = item.get("id", "")
                if vid and vid not in seen_ids:
                    seen_ids.add(vid)
                    all_results.append((term, item))
        except Exception:
            pass

    dp.close()

    if not all_results:
        xbmcgui.Dialog().ok("Búsqueda Múltiple", "No se encontraron resultados para ningún término.")
        xbmcplugin.endOfDirectory(h)
        return

    # Agrupar por término de búsqueda
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "")
        try:
            dur = int(item.get("duration", 0))
        except (ValueError, TypeError):
            dur = 0
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        try:
            views = int(item.get("views_total", 0))
        except (ValueError, TypeError):
            views = 0

        dur_min = dur // 60 if dur else 0
        label = f"{title} [COLOR gray]({term})[/COLOR]"
        if dur_min:
            label += f" [COLOR cyan]{dur_min}min[/COLOR]"

        plot = f"Canal: {owner}\nBúsqueda: {term}\nDuración: {dur_min}min\nVisitas: {views:,}"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb or 'DefaultVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': plot, 'duration': dur})

        cm = []
        cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vid)})"))
        cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(title)}&url={urllib.parse.quote(term)}&thumbnail={urllib.parse.quote(thumb)}&extra=&fav_action=search)"))
        li.addContextMenuItems(cm)

        play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(title)}&thumb={urllib.parse.quote(thumb)}&duration={dur}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("Búsqueda Múltiple", f"{len(all_results)} resultados de {len(terms)} términos")

def import_favs():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo favorites.json', 'files', '.json')
    if not f: return
    
    if xbmcgui.Dialog().yesno("AtresDaily", "¿Deseas importar estos favoritos?\n(Se borrarán los favoritos actuales)"):
        try:
            with open(f, 'r', encoding='utf-8') as src:
                data = json.load(src)
                if isinstance(data, list):
                    ui_utils.save_json('favorites.json', data)
                    xbmcgui.Dialog().notification("AtresDaily", "Favoritos importados")
                    xbmc.executebuiltin("Container.Refresh")
                else: raise Exception()
        except Exception as e:
            xbmcgui.Dialog().ok("Error", f"Archivo no válido o corrupto: {e}")

def add_fav(title, action, url, thumbnail, extra):
    params = {"extra": extra}
    if core_settings.add_favorite(title, url, thumbnail, "atresdaily", action, params):
        xbmcgui.Dialog().notification("AtresDaily", "Añadido a favoritos")
    else:
        xbmcgui.Dialog().notification("AtresDaily", "Ya está en favoritos")

def del_fav(url):
    if core_settings.remove_favorite(url):
        xbmcgui.Dialog().notification("AtresDaily", "Eliminado de favoritos")
        xbmc.executebuiltin("Container.Refresh")

# --- SISTEMA DE DESCARGAS ---
def view_downloads():
    dls = ui_utils.load_json('downloads.json')
    if not isinstance(dls, list): dls = []

    if not dls:
        ui_utils.add_item(action="", title="No hay historial de descargas", thumbnail="DefaultIconInfo.png", folder=False, plot="Cuando descargues algo, aparecerá aquí.\n\n[B]Descargo de responsabilidad:[/B]\nLa función de descarga es una herramienta técnica del reproductor. El usuario es el único responsable del uso que haga de ella y de asegurarse de que cumple con las leyes de su jurisdicción y los derechos de propiedad intelectual aplicables.\n\nEste addon no promueve la descarga de contenido protegido sin autorización.")
    else:
        for d in dls:
            path = d.get('path', '')
            title = d.get('title', 'Desconocido')
            date = d.get('date', '')
            
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {title}"
                is_valid = False
            else:
                label = f"{title} ({date})"
                is_valid = True
            
            # Menú contextual
            cm = [("Quitar del historial", f"RunPlugin({sys.argv[0]}?action=del_dl_history&url={urllib.parse.quote(path)})")]
            if is_valid:
                cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({sys.argv[0]}?action=del_file&url={urllib.parse.quote(path)})"))
                action = "play_local"
            else:
                action = "" # No playable if missing
            
            ui_utils.add_item(action=action, title=label, url=path, thumbnail="DefaultVideo.png", isPlayable=is_valid, folder=False, context=cm, plot=path)

    ui_utils.close_item_list()




def del_dl_history(path):
    dls = ui_utils.load_json('downloads.json')
    new_dls = [d for d in dls if d.get('path') != path]
    ui_utils.save_json('downloads.json', new_dls)
    xbmc.executebuiltin("Container.Refresh")

def del_file(path):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar definitivamente?\n{os.path.basename(path)}"):
        try: 
            if os.path.exists(path): os.remove(path)
            del_dl_history(path) # Quitar también del historial
            xbmcgui.Dialog().notification("AtresDaily", "Archivo borrado", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().notification("AtresDaily", f"Error al borrar: {e}", xbmcgui.NOTIFICATION_ERROR)

def play_local(path):
    li = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def _search_elementum(query):
    """Busca en Elementum con verificación de instalación."""
    if not query: return
    
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.elementum)"):
        xbmcgui.Dialog().ok("AtresDaily", 
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub.")
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = f"plugin://plugin.video.elementum/search?q={urllib.parse.quote(query)}"
    
    # Container.Update mantiene historial de navegación (vs ActivateWindow)
    xbmc.executebuiltin(f'Container.Update("{elementum_url}")')

def _search_external_prompt():
    kb = xbmc.Keyboard('', 'Búsqueda externa')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        _search_elementum_prompt(kb.getText().strip())

def _search_elementum_prompt(query):
    """Menú de opciones al pulsar '¿No es lo que buscas?'."""
    opciones = ["[COLOR white]Buscar en webs de torrent[/COLOR]"]
    acciones = ["elementum"]

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        opciones.append("[COLOR deepskyblue]Buscar en addon Dailymotion (Gujal)[/COLOR]")
        acciones.append("dm_gujal")

    palantir_id = core_settings.get_palantir_addon_id()
    if palantir_id:
        opciones.append("[COLOR orange]Buscar en Palantir[/COLOR]")
        acciones.append("palantir")

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        opciones.append("[COLOR red]Buscar en YouTube[/COLOR]")
        acciones.append("youtube")

    if xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
        opciones.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
        acciones.append("balandro")

    # Si solo hay Elementum, ir directo al teclado sin diálogo
    if len(acciones) == 1:
        kb = xbmc.Keyboard(query, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_elementum(kb.getText())
        return

    if xbmcaddon.Addon().getSetting('ext_search_dialog') == 'false':
        _search_elementum(query)
        return

    sel = xbmcgui.Dialog().select(f"¿Dónde quieres buscar '{query}'?", opciones)
    if sel < 0:
        return
    accion = acciones[sel]

    if accion == "elementum":
        kb = xbmc.Keyboard(query, 'Buscar en webs de torrent')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            _search_elementum(kb.getText())
    elif accion == "dm_gujal":
        _search_dailymotion_gujal(query)
    elif accion == "palantir":
        _search_palantir_from_results(query)
    elif accion == "youtube":
        _search_youtube_from_results(query)
    elif accion == "balandro":
        _search_balandro_from_results(query)

def _ep_fix_disk_state():
    """Lee Includes.xml de la skin y devuelve True si el parche está físicamente aplicado."""
    try:
        includes_xml = os.path.join(
            xbmcvfs.translatePath('special://skin/'), 'xml', 'Includes.xml')
        if not os.path.exists(includes_xml):
            return False
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        return 'ATRESDAILY_PATCH_VIDEOS' in content or 'ESPADAILY_PATCH_VIDEOS' in content
    except Exception:
        return False

def _ep_sync_state():
    """Verifica el disco y devuelve el estado real, resincronizando el setting si hay desfase."""
    _addon = xbmcaddon.Addon()
    real_applied = _ep_fix_disk_state()
    cached = _addon.getSetting('ep_fix_state')
    if real_applied and cached != 'applied':
        _addon.setSetting('ep_fix_state', 'applied')
    elif not real_applied and cached == 'applied':
        # La skin se actualizó y borró el parche -> resetear para volver a preguntar
        _addon.setSetting('ep_fix_state', '')
    return real_applied

def _check_estuary_palantir_fix():
    """
    Comprueba si el fix de Estuary Palantir es necesario y lo ofrece al usuario.
    Usa un setting interno para no leer el disco en cada búsqueda.
    Estados: '' = nunca preguntado, 'applied' = aplicado, 'skipped' = usuario rechazó.
    """
    if xbmc.getSkinDir() != 'skin.estuary.palantir':
        return

    _addon = xbmcaddon.Addon()
    state = _addon.getSetting('ep_fix_state')

    if state == 'applied' or state == 'skipped':
        return

    # Primera vez o estado desconocido: verificar en disco
    if _ep_fix_disk_state():
        _addon.setSetting('ep_fix_state', 'applied')
        return

    # No está aplicado: preguntar al usuario con explicación completa
    apply = xbmcgui.Dialog().yesno(
        "AtresDaily - Compatibilidad Palantir",
        "Usas la skin [B]Estuary Palantir[/B] y sin el parche de compatibilidad "
        "los resultados de Palantir aparecen en pantalla negra.\n\n"
        "[B]Que hace el parche:[/B] Modifica un archivo XML de la skin (con backup automatico) "
        "para que reconozca el contenido enviado desde AtresDaily.\n\n"
        "[B]Como cambiarlo despues:[/B] Configuracion del addon -> 'Fix Estuary Palantir'. "
        "Desde ahi puedes aplicarlo o desinstalarlo cuando quieras.\n\n"
        "[COLOR grey]Si pulsas 'Ahora no' no preguntaremos otra vez en busquedas, "
        "pero podras activarlo desde Configuracion.[/COLOR]",
        nolabel="Ahora no",
        yeslabel="Aplicar parche"
    )
    if apply:
        _toggle_estuary_palantir_fix()
    else:
        _addon.setSetting('ep_fix_state', 'skipped')

def _search_palantir_from_results(query):
    """Búsqueda en Palantir (dinámico) desde resultados, con detección de parche Estuary."""
    palantir_id = core_settings.get_palantir_addon_id()
    if not palantir_id:
        xbmcgui.Dialog().ok("AtresDaily",
            "Palantir no está instalado.\n\n"
            "Instala Palantir para usar esta función.")
        return

    _check_estuary_palantir_fix()

    # Teclado con consulta pre-rellenada
    kb = xbmc.Keyboard(query, 'Buscar en Palantir (Detectado)')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        _search_palantir(kb.getText())

def _search_youtube_from_results(query):
    """Búsqueda en YouTube desde resultados."""
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
        xbmcgui.Dialog().ok("AtresDaily",
            "El plugin de YouTube no está instalado.\n\n"
            "Instálalo desde el repositorio oficial de Kodi para usar esta función.")
        return
    # Teclado con consulta pre-rellenada
    kb = xbmc.Keyboard(query, 'Buscar en YouTube')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        youtube_url = (
            f"plugin://plugin.video.youtube/kodion/search/query/"
            f"?q={urllib.parse.quote(kb.getText())}"
        )
        xbmc.executebuiltin(f"Container.Update({youtube_url})")

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en AtresDaily que permite
# abrir la función de búsqueda del addon Balandro desde este menú rápido.
# AtresDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon Balandro,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_balandro_from_results(query):
    """Búsqueda en Balandro desde resultados."""
    balandro_id = 'plugin.video.balandro'
    if not xbmc.getCondVisibility(f"System.HasAddon({balandro_id})"):
        xbmcgui.Dialog().ok("AtresDaily",
            "El plugin de Balandro no está instalado.\n\n"
            "Instala Balandro para usar esta función.")
        return

    # Teclado con consulta pre-rellenada
    kb = xbmc.Keyboard(query, 'Buscar en Balandro')
    kb.doModal()
    
    if kb.isConfirmed() and kb.getText().strip():
        texto = kb.getText().strip()
        # Reutilizamos el sistema de codificación de BuscaBalandro (JSON + Base64)
        item_data = {
            'channel': 'search',
            'action': 'search',
            'search_type': 'all',
            'buscando': texto,
        }
        payload = base64.b64encode(json.dumps(item_data).encode('utf-8')).decode('utf-8')
        balandro_url = f"plugin://{balandro_id}/?{urllib.parse.quote_plus(payload)}"
        xbmc.executebuiltin(f"Container.Update({balandro_url})")

def _search_dailymotion_gujal(query):
    """Búsqueda en el addon de Dailymotion de Gujal (plugin.video.dailymotion_com)."""
    if not query: return

    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
        xbmcgui.Dialog().ok("AtresDaily",
            "El addon de Dailymotion (Gujal) no está instalado.\n\n"
            "Puedes instalarlo desde el repositorio de Gujal en GitHub:\n"
            "https://github.com/Gujal00/Kodi-Official")
        return

    kb = xbmc.Keyboard(query, 'Buscar en addon Dailymotion')
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        dm_url = (
            f"plugin://plugin.video.dailymotion_com/"
            f"?action=search&query={urllib.parse.quote(kb.getText())}"
        )
        xbmc.executebuiltin(f"Container.Update({dm_url})")

def _search_palantir_prompt(query):
    # Abrir teclado para modificar la búsqueda de Palantir
    kb = xbmc.Keyboard(query, 'Buscar en Palantir (Detectado)')
    kb.doModal()
    if kb.isConfirmed():
        nq = kb.getText()
        if nq:
             _search_palantir(nq)

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3 (Créditos: EspaDaily)"""
    import base64
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = length // 4
    value = re.sub(b'=', b'', value)
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _search_palantir(query):
    if not query: return
    
    # Verificar si Palantir esta instalado mediante deteccion dinamica
    palantir_id = core_settings.get_palantir_addon_id()
    if not palantir_id:
        xbmcgui.Dialog().ok("AtresDaily", "El addon Palantir no parece estar instalado.\n\nEsta función requiere Palantir para funcionar.")
        return

    # Preparar el objeto ITEM que espera Palantir
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    encoded_item = _p3_b64encode(str(item_dict))
    
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar la búsqueda usando el ID detectado dinámicamente
    plugin_url = f"plugin://{palantir_id}/?{encoded_item}"
    
    xbmc.log(f"[AtresDaily] Enviando búsqueda a Palantir ({palantir_id}): {query}", xbmc.LOGINFO)
    xbmc.log(f"[AtresDaily] URL generada: {plugin_url}", xbmc.LOGINFO)
    
    # Usamos Container.Update para que al volver atrás regrese a nuestro addon
    # Se ha pensado en que se quede en Palantir para que los usuarios vean el addon completo por respeto
    # Sin embargo el proceso de busqueda, fallo... se vuelve extremadamente tedioso y hace que esta funcionalidad 
    # sea poco útil y desesperante.
    xbmc.executebuiltin(f"Container.Update({plugin_url})")

# =====================================================================
# OPCIÓN OCULTA - NO PARA USUARIO FINAL
# Fix de compatibilidad con skin Estuary Palantir
# Esta función parchea la skin para evitar pantalla negra en resultados de Palantir
# Este parche es respetuoso con el addon, no modifica nada que no sea necesario
# y se puede desinstalar sin dejar rastro.
# =====================================================================
def _toggle_estuary_palantir_fix():
    """
    Instala o desinstala el parche de compatibilidad para skin.estuary.palantir.
    Usa un sistema de backup: al instalar guarda una copia del archivo original,
    al desinstalar restaura la copia para garantizar una desinstalación limpia.
    """
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        xbmcgui.Dialog().ok("AtresDaily",
            "Este fix solo es necesario si usas la skin 'Estuary Palantir'.\n\n"
            f"Tu skin actual es: {skin_id}")
        return

    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')
    backup_xml = includes_xml + '.atresdaily_backup'

    if not os.path.exists(includes_xml):
        xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo Includes.xml de la skin.")
        return

    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()

        patch_marker = '<!-- ATRESDAILY_PATCH_VIDEOS -->'
        espadaily_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'

        is_patched = patch_marker in content or espadaily_marker in content

        if is_patched:
            if xbmcgui.Dialog().yesno("AtresDaily - Desinstalar Fix",
                "El fix de compatibilidad está instalado.\n\n¿Quieres desinstalarlo?"):

                restored = False

                if os.path.exists(backup_xml):
                    try:
                        with open(backup_xml, 'r', encoding='utf-8') as f:
                            original_content = f.read()
                        with open(includes_xml, 'w', encoding='utf-8') as f:
                            f.write(original_content)
                        os.remove(backup_xml)
                        restored = True
                    except Exception as backup_err:
                        xbmc.log(f"[AtresDaily] No se pudo restaurar backup: {backup_err}", xbmc.LOGWARNING)

                if not restored:
                    content = content.replace('\n\t' + patch_marker, '')
                    content = content.replace(patch_marker, '')
                    content = content.replace('\n\t' + espadaily_marker, '')
                    content = content.replace(espadaily_marker, '')
                    content = re.sub(
                        r'\s*\[Container\.Content\(videos\)\s*\|\s*Container\.Content\(\)\]\s*\|',
                        '', content)
                    with open(includes_xml, 'w', encoding='utf-8') as f:
                        f.write(content)

                xbmcaddon.Addon().setSetting('ep_fix_state', '')
                xbmcgui.Dialog().notification('AtresDaily', 'Fix desinstalado. Recargando skin...',
                    xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin('ReloadSkin()')
        else:
            if xbmcgui.Dialog().yesno("AtresDaily - Instalar Fix",
                "¿Quieres instalar el fix de compatibilidad para Estuary Palantir?\n\n"
                "Esto corrige la pantalla negra al mostrar resultados de Palantir."):

                import shutil
                try:
                    shutil.copy2(includes_xml, backup_xml)
                except Exception as bk_err:
                    xbmc.log(f"[AtresDaily] No se pudo crear backup: {bk_err}", xbmc.LOGWARNING)

                modified = False
                vistas_palantir = [
                    'Vista50', 'Vista54', 'Vista55', 'Vista500',
                    'Vista504', 'Vista505', 'Vista506', 'Vista507'
                ]

                for vista in vistas_palantir:
                    pattern = (
                        r'(<expression name="' + vista +
                        r'">\s*\[\s*\$EXP\[IsPalantirVistas\]\s*\+)'
                    )
                    if re.search(pattern, content):
                        replacement = r'\1\n\t\t\t[Container.Content(videos) | Container.Content()] |'
                        new_content = re.sub(pattern, replacement, content)
                        if new_content != content:
                            content = new_content
                            modified = True

                if modified:
                    content = content.replace('<includes>', '<includes>\n\t' + patch_marker)
                    with open(includes_xml, 'w', encoding='utf-8') as f:
                        f.write(content)
                    xbmcaddon.Addon().setSetting('ep_fix_state', 'applied')
                    xbmcgui.Dialog().notification('AtresDaily', 'Fix instalado. Recargando skin...',
                        xbmcgui.NOTIFICATION_INFO, 3000)
                    xbmc.executebuiltin('ReloadSkin()')
                else:
                    xbmcgui.Dialog().ok("AtresDaily",
                        "No se encontraron las expresiones a parchear.\n"
                        "Puede que tu versión de Estuary Palantir sea diferente.")

    except Exception as e:
        xbmc.log(f"[AtresDaily] Error en toggle_estuary_palantir_fix: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error: {str(e)}")

# --- DESPACHO ---
if not check_validity():
    xbmcgui.Dialog().ok("AtresDaily", "Addon desactivado o versión obsoleta.")
else:
    p = get_params()
    a = p.get("action")
    u = p.get("url")
    e = p.get("extra")
    d = p.get("direct")

    # --- PROTECTOR DEL CONECTOR ---
    # Protege contra llamadas a funciones del conector si este no se ha cargado (ej: términos no aceptados)
    if connector is None and a in [
        "list_cat", "list_details", "download_video", "play_media",
        "search_movie", "live_tv", "play_live_channel", "search", "play_dm",
        "input_search", "catalog_search", "view_playlist",
        "list_user_playlists", "search_user_playlists", "execute_adv_search",
        "catalog_menu", "fav_news", "show_trending",
        "list_live_cats"
    ]:
         # Si tratamos de usar una función del conector sin tenerlo, mostramos aviso y vamos al inicio
         # Esto forzará que salte el check_legal_compliance() en menu_root()
         xbmcgui.Dialog().notification("AtresDaily", "Función restringida", xbmcgui.NOTIFICATION_WARNING)
         menu_root()
         # Aseguramos que no sigue ejecutando
         a = None 

    # Telemetría anónima
    try:
        import stats; stats.ping()
    except Exception:
        pass

    if not a: menu_root()
    elif a == "list_cat": connector.list_cat(u, int(e) if e else 0)
    elif a == "list_live_cats": connector.list_live_cats()
    elif a == "play_live_channel": connector.play_live_channel(u)
    elif a == "list_details": connector.list_details(u, e)
    elif a == "catalog_menu": catalog_menu()
    elif a == "history_menu": history_menu()
    elif a == "view_favorites": view_favorites()
    elif a == "flowfav_launch": _flowfav_launch()
    elif a == "add_fav": add_fav(title=p.get("title", "Favorito"), action=p.get("f_action", "search"), url=u, thumbnail=p.get("f_thumb", ICON_MAIN), extra=e)
    elif a == "fav_news": show_fav_news()
    elif a == "trending": show_trending()
    elif a == "del_fav": 
        if core_settings.remove_favorite(u): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
        kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
        kb.doModal()
        if kb.isConfirmed():
            new_t = kb.getText()
            if new_t:
                core_settings.rename_favorite(p.get("fav_url"), new_t)
                xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"): xbmc.executebuiltin("Container.Refresh")
    
    # --- CATEGORY MANAGER ROUTING ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_backup_menu": category_manager.cat_backup_menu()
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if removed:
                 time.sleep(0.2) 
                 xbmc.executebuiltin("Container.Refresh")
                 
    # --- EXPLORATION HISTORY ROUTING ---
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))

    # --- EPG TEXTO ROUTING ---
    elif a == "epg_texto_menu": epg_texto.epg_texto_menu()
    elif a == "epg_texto_atres": epg_texto.epg_texto_atres()
    elif a == "epg_texto_grupo": epg_texto.epg_texto_grupo(p.get("grupo"))
    elif a == "epg_texto_canal": epg_texto.epg_texto_canal(p.get("ch_id"), p.get("ch_name"))
    elif a == "epg_texto_programa": epg_texto.epg_texto_programa(p.get("title"), p.get("plot"))
    elif a == "epg_texto_refresh": epg_texto.epg_texto_refresh()
    elif a == "vpn_nota":
        quitar = xbmcgui.Dialog().yesno(
            "Directos y VPN",
            "Las emisiones en directo de A3Player tienen sistemas de detección que suelen bloquear las conexiones a través de VPN.\n\nSi tienes problemas, prueba a desactivarla.",
            nolabel="Quitar mensaje",
            yeslabel="OK",
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
        )
        if not quitar:
            xbmcaddon.Addon().setSetting('hide_vpn_nota', 'true')
            xbmc.executebuiltin("Container.Refresh")
    elif a == "restore_warnings":
        addon = xbmcaddon.Addon()
        addon.setSetting('hide_vpn_nota', 'false')
        addon.setSetting('hide_vpn_info', 'false')
        xbmcgui.Dialog().notification("AtresDaily", "Mensajes de advertencia restaurados", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")

    elif a == "dm_open_browser":
        try:
            dm_url = f"https://www.dailymotion.com/video/{u}"
            if xbmc.getCondVisibility("System.Platform.Android"):
                xbmc.executebuiltin(f'StartAndroidActivity(,"android.intent.action.VIEW","","{dm_url}")')
            else:
                import webbrowser; webbrowser.open(dm_url)
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            xbmcgui.Dialog().ok("AtresDaily", f"Abre esta URL:\n\nhttps://www.dailymotion.com/video/{u}")
    elif a == "view_downloads": view_downloads()
    elif a == "download_video": connector.download_video(vid=u, title=p.get('title', 'Video'))
    elif a == "del_dl_history": del_dl_history(u)
    elif a == "del_file": del_file(u)
    elif a == "play_local": play_local(u)
    elif a == "export_favs": export_favs()
    elif a == "backup_favs_dialog": backup_favs_dialog()
    elif a == "export_favs_menu": export_favs_menu()
    elif a == "export_favs_txt": export_favs_txt()
    elif a == "multi_search": multi_search()
    elif a == "import_favs": import_favs()
    elif a == "play_media": connector.play_media(u, e)
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "live_tv": connector.list_live()
    elif a == "tdt_channels": tdt_channels()
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(u)
    elif a == "search_acestream": search_acestream()
    elif a == "play_ace": url_player.play_url_action(u)
    elif a == "play_tdt": play_tdt(u, p.get("title", ""))
    elif a == "open_browser_url": open_browser_url(u)
    elif a == "add_custom_iptv": add_custom_iptv()
    elif a == "view_custom_iptv": view_custom_iptv(u)
    elif a == "delete_custom_iptv": delete_custom_iptv(u)
    elif a == "search": connector.search_internet(u, direct=(p.get('direct') == 'true'))
    elif a == "search_movie": connector.search_internet(e)
    elif a == "search_external": _search_external_prompt()
    elif a == "play_dm":
        # Registrar en historial antes de reproducir
        if u:
            title_for_history = p.get('title', u)
            thumb_for_history = p.get('thumb', '')
            dur_for_history = p.get('duration', 0)
            try: dur_for_history = int(dur_for_history)
            except Exception: dur_for_history = 0
            try:
                core_settings.add_to_watch_history(u, title_for_history, thumb_for_history, dur_for_history)
            except Exception: pass
        # Reproducción DM: Windows tiene problemas con CDN, resto usa connector directamente
        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")
        if not _is_windows:
            # En Android/Fire Stick el connector funciona perfectamente
            connector.play_dm(u)
        else:
            # En Windows/PC: el CDN de Dailymotion bloquea por IP/plataforma
            # Cascada: yt-dlp → navegador → connector → addon DM
            _dm_ok = False
            dm_web_url = f"https://www.dailymotion.com/video/{u}"
            # Método 1: yt-dlp via subprocess (usa Python del sistema, no el de Kodi)
            try:
                import subprocess, json as _json
                xbmc.log("[AtresDaily] DM: Trying yt-dlp via subprocess...", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                _proc = subprocess.run(
                    ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                     '--format', 'best[ext=mp4]/best', '--no-playlist',
                     f'https://www.dailymotion.com/video/{u}'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=0x08000000  # CREATE_NO_WINDOW
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    info = _json.loads(_proc.stdout)
                    stream_url = info.get('url', '')
                    if stream_url:
                        xbmc.log(f"[AtresDaily] DM yt-dlp OK: {stream_url[:80]}...", xbmc.LOGINFO)
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        try:
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                        except Exception:
                            xbmc.Player().play(stream_url, li)
                        _dm_ok = True
                    else:
                        xbmc.log("[AtresDaily] DM: yt-dlp returned no URL", xbmc.LOGWARNING)
                else:
                    _err = _proc.stderr[:200] if _proc.stderr else 'no output'
                    xbmc.log(f"[AtresDaily] DM: yt-dlp exit={_proc.returncode}: {_err}", xbmc.LOGWARNING)
            except FileNotFoundError:
                xbmc.log("[AtresDaily] DM: python not found in PATH", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[AtresDaily] DM: yt-dlp subprocess failed: {e}", xbmc.LOGWARNING)
            # Método 2: abrir en navegador
            if not _dm_ok:
                if xbmcgui.Dialog().yesno("AtresDaily - Dailymotion",
                        "No se pudo reproducir en Kodi.\n\n"
                        "¿Quieres abrirlo en el navegador?\n\n"
                        "(Si eliges 'No' se intentarán otros métodos)",
                        yeslabel="Navegador", nolabel="Intentar en Kodi"):
                    try:
                        import webbrowser
                        webbrowser.open(dm_web_url)
                        xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
                    except Exception:
                        xbmcgui.Dialog().ok("AtresDaily", f"Abre esta URL en tu navegador:\n\n{dm_web_url}")
                    _dm_ok = True
            # Método 3: connector.play_dm
            if not _dm_ok:
                try:
                    xbmc.log("[AtresDaily] DM: Trying connector.play_dm...", xbmc.LOGINFO)
                    connector.play_dm(u)
                    import time as _t; _t.sleep(2)
                    if xbmc.Player().isPlaying():
                        _dm_ok = True
                        xbmc.log("[AtresDaily] DM: connector.play_dm OK", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[AtresDaily] DM: connector.play_dm failed: {e}", xbmc.LOGWARNING)
            # Método 4: plugin.video.dailymotion_com (addon externo)
            if not _dm_ok and xbmc.getCondVisibility("System.HasAddon(plugin.video.dailymotion_com)"):
                try:
                    xbmc.log("[AtresDaily] DM: Trying plugin.video.dailymotion_com...", xbmc.LOGINFO)
                    dm_plugin_url = f"plugin://plugin.video.dailymotion_com/?url={u}&mode=playVideo"
                    xbmc.executebuiltin(f'PlayMedia("{dm_plugin_url}")')
                    import time as _t; _t.sleep(3)
                    if xbmc.Player().isPlaying():
                        _dm_ok = True
                        xbmc.log("[AtresDaily] DM: plugin.video.dailymotion_com OK", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"[AtresDaily] DM: DM addon failed: {e}", xbmc.LOGWARNING)
            # Resolver URL vacía para que Kodi no se quede colgado
            if not _dm_ok:
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except Exception:
                    pass
    elif a == "input_search": input_search()
    elif a == "view_history": view_history()
    elif a == "del_history": del_history()
    elif a == "settings_menu": settings_menu()
    elif a == "watch_history": view_watch_history()
    elif a == "clear_watch_history":
        if xbmcgui.Dialog().yesno("Borrar Historial", "¿Seguro que quieres borrar todo el historial de reproducciones?"):
            core_settings.clear_watch_history()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "del_watch_entry":
        core_settings.remove_watch_entry(u)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "set_cache_config": set_cache_config()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "execute_adv_search": _execute_adv_search(u)
    elif a == "catalog_search": connector.catalog_search(u)
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_catalog_snapshot": create_catalog_snapshot()
    elif a == "view_snapshot": view_snapshot(u, e)
    elif a == "delete_snapshot_menu": delete_snapshot_menu()
    elif a == "delete_single_snap": delete_single_snap(u)
    elif a == "toggle_snapshot_precision": toggle_snapshot_precision()
    elif a == "backups_menu": backups_menu()
    elif a == "create_backup": create_backup()
    elif a == "create_backup_full": create_backup(include_cache=True)
    elif a == "list_backups": _list_backups()
    elif a == "restore_backup": restore_backup(u)
    elif a == "del_backups_menu": _del_backups_menu()
    elif a == "export_backups_menu": _export_backups_menu()
    elif a == "export_single_backup": export_single_backup(u)
    elif a == "delete_single_backup": delete_single_backup(u)
    elif a == "set_download_path": set_download_path()
    elif a == "set_dm_safe_level": set_dm_safe_level()
    elif a == "set_dl_mode": set_dl_mode()
    elif a == "toggle_inputstream": _toggle_inputstream()
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "acc_menu": acc_menu()
    elif a == "acc_set_color_mode": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()
    elif a == "list_user_playlists": connector.list_user_playlists(p.get("user"))
    elif a == "view_playlist": connector.view_playlist(p.get("id"))
    elif a == "search_user_playlists": connector.search_user_playlists()
    elif a == "show_legal_txt": show_legal_txt()
    elif a == "revoke_legal": revoke_legal()
    elif a == "set_precision": set_precision()
    elif a == "clear_ui_cache": clear_ui_cache()
    elif a == "export_cache": export_cache()
    elif a == "clear_full_cache": clear_full_cache()
    elif a == "show_info": show_info()
    elif a == "show_web_info": show_web_info()
    elif a == "info_menu": info_menu()
    elif a == "espadaily_launch": _espadaily_launch()
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "elementum_search_prompt": _search_elementum_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))
    elif a == "atresplayer_catalog_search": _search_atresplayer_catalog()
    elif a == "palantir_search_prompt": _search_palantir_prompt(p.get("q"))
    elif a == "toggle_estuary_palantir_fix": _toggle_estuary_palantir_fix()
    elif a == "view_kodi_log": view_kodi_log()
    # --- TRAKT / MEJORES PELÍCULAS ---
    elif a == "trakt_root":
        import trakt_manager; trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager; trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager; trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager; trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager; trakt_manager.import_list()
    elif a == "trakt_import_espatv":
        import trakt_manager; trakt_manager.import_from_espatv()
    elif a == "trakt_view_list":
        import trakt_manager; trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager; trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_cache_covers":
        import trakt_manager; trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager; trakt_manager.clear_cache(p.get("list_id"))
    elif a == "top_movies":
        import trakt_manager; trakt_manager.top_movies(p.get("page"))
    elif a == "cache_top_movies_covers":
        import trakt_manager; trakt_manager.cache_top_movies_covers()
    elif a == "clear_top_movies_cache":
        import trakt_manager; trakt_manager.clear_top_movies_cache()
    elif a == "trakt_search_dialog":
        import trakt_manager; trakt_manager.search_dialog(p.get("q") or u)
    # --- ENRUTAMIENTO DEL REPRODUCTOR DE URL ---
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(u)
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(u)
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(u)
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(u)
    elif a == "url_play":
        import url_player; url_player.play_url_action(u)
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()
    elif a == "slyguy_install": _slyguy_install(u, p.get("title", "Addon"))
    elif a == "espatv_install": _espatv_install()
    elif a == "espatv_launch": _espatv_launch()
    elif a == "show_vpn_info": show_vpn_info()
    elif a == "loiolog_install": _loiolog_install()
    elif a == "loiolog_launch": _loiolog_launch()
    elif a == "streamninja_launch": _streamninja_launch()
    elif a == "atresdaily_launch": _atresdaily_launch()
    elif a == "espakodi_addons_menu": espakodi_addons_menu()
    elif a == "open_addon_settings": xbmc.executebuiltin("Addon.OpenSettings(plugin.video.atresdaily)")
    elif a == "check_atres_repo": ui_utils.check_repo_status()
    else: menu_root()