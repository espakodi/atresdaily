# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en YouTube por scraping HTML, sin API key.
# Adaptado del enfoque usado por TopZilla y EspaTV (mismo proyecto, GPL-2.0).
# Reproduce los videos vía plugin.video.youtube/play (no requiere API key).
import gzip
import hashlib
import io
import json
import os
import re
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_YT_SEARCH_URL = "https://www.youtube.com/results?search_query={0}"
_YT_THUMB = "https://i.ytimg.com/vi/{0}/hqdefault.jpg"
_YT_PLAY  = "plugin://plugin.video.youtube/play/?video_id={0}"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, identity",
    # CONSENT/SOCS evitan el redireccionamiento a consent.youtube.com en la UE
    "Cookie": "CONSENT=YES+1; SOCS=CAI",
}

_RE_INITIAL = re.compile(r'var ytInitialData\s*=\s*(\{.*?\});\s*</script>', re.DOTALL)
_RE_INITIAL_ALT = re.compile(r'ytInitialData"\]\s*=\s*(\{.*?\});', re.DOTALL)
_RE_FALLBACK = re.compile(
    r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}',
    re.DOTALL,
)

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.atresdaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, key + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _fetch_html(url, timeout=15):
    req = urllib.request.Request(url, headers=_HEADERS)
    resp = urllib.request.urlopen(req, timeout=timeout)
    raw = resp.read()
    if (resp.headers.get("Content-Encoding") or "").lower() == "gzip":
        try:
            raw = gzip.GzipFile(fileobj=io.BytesIO(raw)).read()
        except OSError:
            pass
    return raw.decode("utf-8", errors="replace")


def _parse_initial_data(html):
    m = _RE_INITIAL.search(html) or _RE_INITIAL_ALT.search(html)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _parse_video_renderer(vr):
    vid = vr.get("videoId", "")
    if not vid or len(vid) != 11:
        return None
    title = ""
    runs = vr.get("title", {}).get("runs", [])
    if runs:
        title = runs[0].get("text", "")
    else:
        title = vr.get("title", {}).get("simpleText", "")
    dur = vr.get("lengthText", {}).get("simpleText", "") or ""
    chan_runs = vr.get("ownerText", {}).get("runs", [])
    channel = chan_runs[0].get("text", "") if chan_runs else ""
    views = (vr.get("viewCountText", {}).get("simpleText", "")
             or vr.get("shortViewCountText", {}).get("simpleText", "")
             or "")
    published = vr.get("publishedTimeText", {}).get("simpleText", "") or ""
    return {"vid": vid, "title": title or "Video", "duration": dur,
            "channel": channel, "views": views, "published": published}


def _extract_videos(data):
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError):
        return []
    results = []
    for section in sections or []:
        if not isinstance(section, dict):
            continue
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            if not isinstance(item, dict):
                continue
            vr = item.get("videoRenderer")
            if vr:
                parsed = _parse_video_renderer(vr)
                if parsed:
                    results.append(parsed)
    return results


def _fallback_parse(html):
    results = []
    seen = set()
    for m in _RE_FALLBACK.finditer(html):
        vid = m.group(1)
        if vid in seen:
            continue
        try:
            title = json.loads('"' + m.group(2) + '"')
        except (ValueError, TypeError):
            title = m.group(2)
        seen.add(vid)
        results.append({"vid": vid, "title": title, "duration": "",
                        "channel": "", "views": "", "published": ""})
        if len(results) >= 30:
            break
    return results


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "youtube_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    encoded = urllib.parse.quote_plus(query)
    html = _fetch_html(_YT_SEARCH_URL.format(encoded))
    data = _parse_initial_data(html)
    results = _extract_videos(data) if data else []
    if not results:
        results = _fallback_parse(html)
    _cache_set(key, results)
    return results


def render_results(handle, query):
    """Busca y lista los resultados en Kodi."""
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", f"Buscando en YouTube: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error buscando en YouTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error al buscar en YouTube:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("AtresDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        vid = r["vid"]
        title = r["title"]
        thumb = _YT_THUMB.format(vid)
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):   plot_lines.append(f"Canal: {r['channel']}")
        if r.get("duration"):  plot_lines.append(f"Duración: {r['duration']}")
        if r.get("views"):     plot_lines.append(f"Vistas: {r['views']}")
        if r.get("published"): plot_lines.append(f"Subido: {r['published']}")
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title,
                             'title': title, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle,
                                    url=_YT_PLAY.format(vid),
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
