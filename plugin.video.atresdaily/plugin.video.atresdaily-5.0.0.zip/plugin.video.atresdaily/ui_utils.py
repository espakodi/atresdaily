# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import os
import sys

try:
    import repository
except Exception:
    pass

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import urllib.parse
import zipfile
from concurrent.futures import ThreadPoolExecutor

import requests

_title_transform = None

ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')
_MEDIA_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')

def media_icon(filename):
    """Ruta del icono en resources/media, o '' si no existe."""
    p = os.path.join(_MEDIA_DIR, filename)
    return p if os.path.exists(p) else ""


PUNTO_NUEVO = "[COLOR lime]●[/COLOR] "
# Lo nuevo que ya se ha abierto: un archivo vacío por clave. No va en los ajustes porque
# cada xbmcaddon.Addon() tiene su propia copia y setSetting reescribe el settings.xml
# entero, así que una instancia creada antes borraría la marca (y cargar esa copia cuesta
# leer dos XML por cada punto).
_VISTOS = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'vistos')


def punto(clave):
    """El punto verde de lo nuevo mientras no se haya abierto (ver visto). Para volver a
    encender el de un menú porque tiene algo nuevo dentro, se le cambia la clave."""
    return "" if os.path.exists(os.path.join(_VISTOS, clave)) else PUNTO_NUEVO


def visto(clave):
    """Apaga el punto verde. Devuelve True si lo ha apagado ahora; con dos llamadas a la
    vez, solo una, porque el archivo se crea en exclusiva."""
    try:
        os.makedirs(_VISTOS, exist_ok=True)
        with open(os.path.join(_VISTOS, clave), 'x'):
            pass
    except FileExistsError:
        return False
    except OSError as e:
        xbmc.log(f"[AtresDaily] No se puede guardar como visto '{clave}': {e}", xbmc.LOGWARNING)
        return False
    return True


HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",

    "Origin": "https://www.atresplayer.com"
}

_DM_OCULTAR = ('dm_filtrar_retirados', 'dm_ocultar_privados', 'dm_ocultar_directos_apagados')


def ajuste_dm(clave):
    """Interruptor de las listas de Dailymotion. Son ajustes nativos, así que la
    pestaña Dailymotion de los ajustes del addon y el submenú de Ajustes
    avanzados cambian lo mismo. Todos valen True por defecto."""
    return xbmcaddon.Addon().getSetting(clave) != 'false'


def dm_firma_filtro():
    """Estado de los interruptores de las listas DM, para la clave de las cachés
    de búsquedas. Sin ella, un cambio de ajuste no se notaría hasta que caducan."""
    return "".join("1" if ajuste_dm(c) else "0" for c in _DM_OCULTAR + ('dm_rellenar_listas',))


def dm_limite_lista(n):
    """Cuántos resultados pedir a la API para poder enseñar n después del filtro.

    En algunas búsquedas 16 de cada 20 resultados están retirados. Con "Rellenar
    las listas" se piden hasta cinco veces más (la API da 100 como mucho) y
    filtrar_dm_borrados recorta a n, así que la lista sale llena sin consultas de más.
    """
    if any(ajuste_dm(c) for c in _DM_OCULTAR) and ajuste_dm('dm_rellenar_listas'):
        return max(n, min(100, n * 5))
    return n


# access_error de un vídeo que ya no existe. Es el que traen los retirados en las
# búsquedas; los vivos nunca lo llevan.
_DM_RETIRADO = "DM005"
# Tope de privados que se comprueban por lista. Un canal que restringe sus vídeos
# los tiene todos así, y sin tope su playlist tardaría decenas de segundos.
_DM_MAX_PRIVADOS = 20


def dm_api_videos(url, params, timeout=10):
    """GET a la API de vídeos de DM pidiendo también access_error, para que
    filtrar_dm_borrados sepa qué no se puede ver sin hacer otra consulta (unos
    0,3 s menos por lista). Si la API rechazara el campo, se repite sin él."""
    cabeceras = {"User-Agent": HEADERS["User-Agent"]}
    con_error = dict(params, fields=f"{params.get('fields', 'id')},access_error")
    r = requests.get(url, params=con_error, headers=cabeceras, timeout=timeout)
    if r.status_code == 400:
        r = requests.get(url, params=params, headers=cabeceras, timeout=timeout)
    return r


def _dm_codigo(v):
    ae = v.get("access_error")
    return ae.get("code") if isinstance(ae, dict) else None


def _dm_privado(vid):
    """True si el vídeo no se puede ver ni pidiéndolo como la web de DM.

    La API marca con DM016 tanto los que su autor solo deja ver en dailymotion.com,
    que el addon sí reproduce, como los privados, y solo la metadata pedida así los
    distingue. Ante un fallo de red se deja el vídeo a la vista.
    """
    try:
        r = requests.get(f"https://www.dailymotion.com/player/metadata/video/{vid}",
                         params={"app": "com.dailymotion.neon"},
                         headers={"User-Agent": HEADERS["User-Agent"],
                                  "Referer": "https://www.dailymotion.com/"}, timeout=4)
        return bool(r.json().get("error"))
    except (requests.RequestException, ValueError) as e:
        xbmc.log(f"[AtresDaily] filtro DM, comprobando {vid}: {e}", xbmc.LOGINFO)
        return False


def _dm_privados(vids):
    """Los de `vids` (todos DM016) que son privados, comprobados a la vez."""
    if not vids:
        return set()
    with ThreadPoolExecutor(max_workers=min(8, len(vids))) as ex:
        return {vid for vid, es in zip(vids, ex.map(_dm_privado, vids)) if es}


def _dm_codigos_por_lote(ids):
    """{id: código de access_error} de los vídeos que siguen existiendo, o None si
    la API falla. Es el camino de las listas pedidas sin dm_api_videos."""
    codigos = {}
    for inicio in range(0, len(ids), 100):
        lote = ",".join(ids[inicio:inicio + 100])
        try:
            for campos in ("id,access_error", "id"):
                r = requests.get("https://api.dailymotion.com/videos",
                                 params={"ids": lote, "fields": campos, "limit": 100},
                                 headers={"User-Agent": HEADERS["User-Agent"]}, timeout=8)
                if r.status_code != 400:
                    break
            if r.status_code != 200:
                return None
            for v in r.json().get("list", []):
                codigos[str(v.get("id"))] = _dm_codigo(v)
        except Exception as e:
            # Un filtro no puede romper la lista: cualquier fallo, sin filtrar.
            xbmc.log(f"[AtresDaily] filtro DM: {e}", xbmc.LOGWARNING)
            return None
    return codigos


def filtrar_dm_borrados(videos, id_key="id", cuantos=None):
    """Quita de una lista de resultados de Dailymotion lo que no se puede ver.

    Según los ajustes: retirados, privados y directos que no están emitiendo. Con
    `cuantos` devuelve como mucho esos, para las listas pedidas de más con
    dm_limite_lista.

    El índice de búsqueda de DM sigue devolviendo vídeos borrados. Su campo
    access_error dice qué error daría cada uno: DM005 retirado, DM003 directo sin
    emisión y DM016 posible privado. Si la lista se pidió con dm_api_videos ya lo
    trae y no hace falta consultar nada; si no, se piden los ids por lote, que
    omite los retirados. Los DM016 se comprueban a la vez, hasta _DM_MAX_PRIVADOS.

    Ante cualquier fallo devuelve la lista intacta: mostrar algún vídeo muerto es
    mucho menos grave que vaciar los resultados del usuario.
    """
    intacta = videos if cuantos is None else videos[:cuantos]
    retirados = ajuste_dm('dm_filtrar_retirados')
    privados = ajuste_dm('dm_ocultar_privados')
    apagados = ajuste_dm('dm_ocultar_directos_apagados')
    if not (retirados or privados or apagados) or not videos:
        return intacta

    if all(isinstance(v, dict) and "access_error" in v for v in videos):
        codigos = {str(v.get(id_key)): _dm_codigo(v) for v in videos}
    else:
        ids = [str(v.get(id_key)) for v in videos if v.get(id_key)]
        # Por lote, una respuesta vacía no distingue "todos retirados" de un fallo
        # de la API; ante la duda, sin filtrar.
        codigos = _dm_codigos_por_lote(ids) if len(ids) >= 2 else None
        if not codigos:
            return intacta

    dudosos = [str(v.get(id_key)) for v in videos
               if codigos.get(str(v.get(id_key))) == "DM016"] if privados else []
    son_privados = _dm_privados(dudosos[:_DM_MAX_PRIVADOS])

    visibles = []
    n_retirados = n_privados = n_apagados = 0
    for v in videos:
        if cuantos is not None and len(visibles) >= cuantos:
            break
        vid = str(v.get(id_key))
        codigo = codigos.get(vid, _DM_RETIRADO)  # por lote, el que falta es retirado
        if codigo == _DM_RETIRADO:
            if retirados:
                n_retirados += 1
                continue
        elif codigo == "DM003" and apagados:
            n_apagados += 1
            continue
        elif vid in son_privados:
            n_privados += 1
            continue
        visibles.append(v)

    if n_retirados or n_privados or n_apagados:
        xbmc.log(f"[AtresDaily] filtro DM: ocultos {n_retirados} retirados, {n_privados} "
                 f"privados y {n_apagados} directos sin emisión", xbmc.LOGINFO)
    return visibles


def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url="", thumbnail="", extra="", folder=True, isPlayable=False, plot="", fanart="", context=None, nuevo="", **kwargs):
    # nuevo: clave del punto verde (ver punto). Va solo en la etiqueta; en la URL, al apagarse
    # cambiaría la dirección del botón y Kodi no sabría devolverle el foco al volver atrás.
    li = xbmcgui.ListItem(punto(nuevo) + title if nuevo else title)

    art = {}
    if thumbnail:
        art['icon'] = thumbnail
        art['thumb'] = thumbnail

    if not fanart:
        fanart = ADDON.getAddonInfo("fanart")
        if not fanart:
            addon_path = ADDON.getAddonInfo("path")
            local_fanart = os.path.join(addon_path, "fanart.jpg")
            if os.path.exists(local_fanart):
                fanart = local_fanart
    if fanart:
        art['fanart'] = fanart
        
    li.setArt(art)

    info = {"title": title}
    if plot: info["plot"] = plot
    li.setInfo("video", info)
    
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
        
    # Menú contextual para reproducción externa en navegador
    if action == "play_dm" and url:
        _browser_item = ("[COLOR lime]Abrir en navegador[/COLOR]",
                         f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(url)})")
        if context:
            context = [_browser_item] + list(context)
        else:
            context = [_browser_item]

    if context:
        li.addContextMenuItems(context)
        
    u = f"{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}"
    for key, value in kwargs.items():
        u += f"&{key}={urllib.parse.quote(str(value))}"
        
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def menu_contextual(entradas):
    """Las entradas de un menú contextual. Con el Modo Fantasía abierto pasan por su puente.

    default.py solo importa fantasia con el modo abierto (Kodi compila cada módulo en cada
    llamada), así que con el modo cerrado esto no importa ni cambia nada.
    """
    fantasia = sys.modules.get('fantasia')
    return list(entradas) if fantasia is None else fantasia.menu_contextual(entradas)

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

# Elección teclado/web del modo 'ask', cacheada durante una misma acción del plugin.
# Cada invocación del plugin es un proceso nuevo (reuselanguageinvoker no está activo en
# addon.xml), así que se reinicia sola entre búsquedas; evita preguntar dos veces en las
# búsquedas de dos campos (por usuario, inversa).
_ask_choice = None

def get_text(title, default=''):
    """Pide texto al usuario según 'web_input_mode' (settings.json). 'keyboard' usa el
    teclado de Kodi, 'web' la web efímera (móvil/PC), 'ask' pregunta cada vez.
    Devuelve el texto o '' si se cancela."""
    global _ask_choice
    mode = load_json('settings.json').get('web_input_mode', 'keyboard')
    use_web = mode == 'web'
    if mode == 'ask':
        if _ask_choice is None:
            sel = xbmcgui.Dialog().select('¿Cómo quieres escribir?',
                                          ['Teclado de Kodi', 'Escribir desde el móvil/PC'])
            if sel < 0:
                return ''  # cancelar la elección = cancelar la entrada
            _ask_choice = sel
        use_web = _ask_choice == 1
    if use_web:
        try:
            import web_input
            r = web_input.receive_text(title, default)
            if r is not None:
                return r
        except Exception as e:
            xbmc.log(f"[AtresDaily] web_input no disponible, uso teclado: {e}", xbmc.LOGWARNING)
    kb = xbmc.Keyboard(default, title)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else ''

def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    """Carga y deserializa un archivo JSON del perfil del addon."""
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f: return json.load(f)
    except Exception:
        if default is not None: return default
        # Sin archivo, dict para los de ajustes y lista para el resto
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    # tmp único por proceso/hilo + os.replace, para que un corte o
    # dos guardados solapados no dejen el archivo a medias (perdería datos del usuario).
    path = get_path(name)
    import threading
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f: json.dump(data, f)
        os.replace(tmp, path)
    except Exception as e:
        try: os.remove(tmp)
        except OSError: pass
        xbmc.log(f"[AtresDaily] Error guardando {name}: {e}", xbmc.LOGERROR)

def fix_img(url):
    if not url: return ICON_MAIN
    if url.startswith("//"): url = "https:" + url
    elif url.startswith("/"): url = "https://www.atresplayer.com" + url
    if url.endswith("/"): url += "1280x720.jpg"
    return url

# Para instalar StreamNinja desde su repositorio
_SN_ID   = "plugin.video.streamninja"
_SN_REPO = "repository.streamninja"
_SN_ZIP  = "https://fullstackcurso.github.io/estreamninja/repository.streamninja-1.0.0.zip"

def is_repo_installed(keyword="atresdaily", target_id="repository.atresdaily"):
    """Comprueba si el repo atresdaily está instalado, con el detector o, si falla, con Kodi."""
    try:
        return repository.detector.is_installed(keyword, target_id)
    except Exception:
        # Sin detector, lo que diga Kodi
        return xbmc.getCondVisibility(f"System.HasAddon({target_id})")

def check_repo_status():
    """Muestra el estado de actualizaciones del repositorio oficial."""
    installed = is_repo_installed()
    
    if installed:
        if xbmcgui.Dialog().yesno(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "¿Deseas desinstalarlo y eliminarlo atómicamente del sistema?"
        ):
            if repository.detector.uninstall():
                xbmcgui.Dialog().notification("AtresDaily", "Repositorio eliminado con éxito", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("Error", "No se pudo desinstalar el repositorio.")
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de AtresDaily.\n\n"
            "¿Deseas instalarlo ahora mismo (autocontenido)?"
        ):
            if repository.detector.install():
                xbmcgui.Dialog().notification("AtresDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                # Si no, descarga directa
                if xbmcgui.Dialog().yesno(
                    "Error de Sistema de Archivos",
                    "La instalación local falló (probablemente por restricciones del dispositivo Android/UWP).\n\n"
                    "¿Deseas intentar descargarlo directamente desde el servidor oficial?"
                ):
                    dp = xbmcgui.DialogProgress()
                    dp.create("AtresDaily", "Preparando descarga...")
                    if _remote_repo_fallback(dp):
                        xbmcgui.Dialog().notification("AtresDaily", "Repositorio descargado", xbmcgui.NOTIFICATION_INFO)
                        xbmc.executebuiltin("Container.Refresh")
                else:
                    # Si tampoco, instrucciones para hacerlo a mano
                    xbmcgui.Dialog().ok(
                        "Instalación Manual", 
                        "Para instalar el repositorio manualmente añade esta fuente al gestor de archivos de Kodi:\n\n"
                        "[B][COLOR yellow]https://fullstackcurso.github.io/atresdaily/[/COLOR][/B]"
                    )


def _entrada_zip_segura(nombre):
    """False si la entrada del zip saldría de special://home/addons (.., ruta absoluta o
    unidad). Las instalaciones por VFS escriben donde diga el nombre de la entrada."""
    partes = nombre.replace('\\', '/').split('/')
    return not (nombre.startswith(('/', '\\')) or ':' in partes[0] or '..' in partes)


def _remote_repo_fallback(dp):
    """Descarga el zip del repositorio y lo instala por el VFS de Kodi."""
    url = "https://fullstackcurso.github.io/atresdaily/repository.atresdaily-1.0.1.zip"
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "atresdaily_repo_fallback.zip")
    try:
        r = requests.get(url, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError("Servidor no disponible (Error HTTP).")

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(zip_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if dp.iscanceled():
                    raise InterruptedError("Cancelado por el usuario.")
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        dp.update(int((downloaded * 90) / total_size), "Descargando desde GitHub...")

        dp.update(95, "Instalando en Kodi (VFS)...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                if not _entrada_zip_segura(member.filename):
                    raise IOError(f"ZIP con ruta sospechosa: {member.filename}")

                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                    
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                success = v_file.write(content)
                v_file.close()
                
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {vfs_dest}")
            
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1000)
        xbmc.executebuiltin("InstallAddon(repository.atresdaily)")
        if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
            sys.modules['repository'].detector._enable_addon("repository.atresdaily")
        else:
            rpc_payload = json.dumps({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": "repository.atresdaily", "enabled": True}, "id": 1})
            xbmc.executeJSONRPC(rpc_payload)
        dp.close()
        return True
    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Fallback remoto falló: {e}", xbmc.LOGERROR)
        
        # Si la instalación falla, se borra la carpeta a medias
        try:
            dest_vfs = "special://home/addons/repository.atresdaily"
            if xbmcvfs.exists(dest_vfs):
                if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
                    sys.modules['repository'].detector._vfs_rmtree(dest_vfs)
        except Exception as rb:
            xbmc.log(f"[AtresDaily] Rollback del repositorio fallido: {rb}", xbmc.LOGWARNING)

        xbmcgui.Dialog().ok(
            "Error Crítico", 
            f"La descarga de rescate también falló:\n{e}\n\n"
            "Solución:\n1. Ve al Gestor de Archivos de Kodi.\n"
            "2. Añade: https://fullstackcurso.github.io/atresdaily/\n"
            "3. Instala desde el archivo ZIP."
        )
        return False
    finally:
        if os.path.exists(zip_path):
            try: os.remove(zip_path)
            except OSError: pass


def _sn_download_and_install_repo(dp):
    """Descarga y extrae el repositorio de StreamNinja y lanza la instalación del addon,
    con el DialogProgress que recibe. True si la instalación ha empezado."""
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "sn_repo.zip")
    try:
        r = requests.get(_SN_ZIP, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError(f"Error HTTP {r.status_code} al descargar el repositorio.")

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        content = bytearray()

        for chunk in r.iter_content(chunk_size=65536):
            if dp.iscanceled():
                raise InterruptedError("Cancelado por el usuario.")
            if chunk:
                content.extend(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    dp.update(
                        10 + int((downloaded * 80) / total_size),
                        "Descargando repositorio...",
                    )

        raw_b = bytes(content)
        if not raw_b.startswith(b"PK\x03\x04"):
            raise ValueError("El archivo descargado no es un ZIP válido.")

        dp.update(90, "Extrayendo...")
        with open(zip_path, "wb") as f:
            f.write(raw_b)

        dp.update(92, "Instalando en Kodi (VFS)...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                if not _entrada_zip_segura(member.filename):
                    raise IOError(f"ZIP con ruta sospechosa: {member.filename}")
                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                success = v_file.write(content)
                v_file.close()
                
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {vfs_dest}")

        dp.update(95, "Actualizando sistema de addons...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        
        # Espera sin bloquear la interfaz
        monitor = xbmc.Monitor()
        monitor.waitForAbort(2.0)
        
        dp.update(97, "Habilitando repositorio en Kodi 19+...")
        try:
            if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
                sys.modules['repository'].detector._enable_addon(_SN_REPO)
            else:
            # Se activa el repositorio por JSON-RPC
                rpc_payload = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "Addons.SetAddonEnabled",
                    "params": {"addonid": _SN_REPO, "enabled": True},
                    "id": 1
                })
                for _ in range(5):
                    response = xbmc.executeJSONRPC(rpc_payload)
                    if '"error"' not in response:
                        xbmc.log(f"[AtresDaily] Repositorio {_SN_REPO} habilitado vía JSON-RPC.", xbmc.LOGINFO)
                        break
                    monitor.waitForAbort(1.0)
        except Exception as repo_err:
            xbmc.log(f"[AtresDaily] Fallo tolerado en habilitación de {_SN_REPO}: {repo_err}", xbmc.LOGWARNING)
            
        monitor.waitForAbort(1.5)
        
        dp.update(99, "Solicitando instalación del addon...")
        xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
        
        # Espera a que el addon quede instalado
        installed = False
        for _ in range(6):
            if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
                installed = True
                break
            monitor.waitForAbort(1.0)
                
        dp.close()
        
        if installed:
            xbmcgui.Dialog().notification("AtresDaily", "Proceso completado con éxito", xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "StreamNinja se ha instalado y activado con éxito.\n\n"
                "Vuelve a pulsar el contenido para reproducirlo."
            )
        else:
            xbmcgui.Dialog().ok(
                "AtresDaily - Instalación Pendiente",
                "El repositorio se ha instalado e indexado correctamente.\n\n"
                "Acepta cualquier ventana emergente de Kodi para finalizar la instalación de StreamNinja.\n\n"
                "Si no aparece nada, puedes instalarlo manualmente en:\n"
                "[B]Addons -> Instalar desde repositorio -> StreamNinja[/B]."
            )
        return True

    except Exception as e:
        dp.close()
        msg = str(e)
        if "Cancelado" in msg:
            xbmcgui.Dialog().notification("AtresDaily", msg, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f"[AtresDaily] Error instalando StreamNinja: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", f"No se pudo instalar StreamNinja:\n{e}")
        return False

    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass

def addon_listo(addon_id, nombre, aviso_si_falta=None):
    """True si el addon está instalado y activado. Si está desactivado, ofrece activarlo; si no
    está instalado, enseña aviso_si_falta (si lo hay) y devuelve False.

    Desde Kodi 19 System.HasAddon es cierto también con el addon desactivado, y uno desactivado
    no abre ni reproduce nada. InstallAddon tampoco hace nada con él."""
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
        return True
    if not xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
        if aviso_si_falta:
            xbmcgui.Dialog().ok("AtresDaily", aviso_si_falta)
        return False
    if not xbmcgui.Dialog().yesno("AtresDaily", f"{nombre} está instalado pero desactivado.\n\n¿Activarlo ahora?",
                                  nolabel="Cerrar", yeslabel="Activar"):
        return False
    import espakodi_installer
    if espakodi_installer.reactivar(addon_id):
        xbmcgui.Dialog().notification("AtresDaily", f"{nombre} activado", xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().ok("AtresDaily", f"Kodi no ha podido activar {nombre}. Actívalo en Addons > Mis addons.")
    return False


def streamninja_check_or_install():
    """True si StreamNinja está listo; si no, ofrece instalarlo o activarlo."""
    if addon_listo(_SN_ID, "StreamNinja"):
        return True
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        return False  # desactivado y no se quiso activar

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja Requerido",
            "StreamNinja no está instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a intentarlo.",
            )
        return False

    if not xbmcgui.Dialog().yesno(
        "StreamNinja Requerido",
        "Para reproducir este contenido se necesita el complemento StreamNinja.\n"
        "¿Descargar e instalar automáticamente?",
    ):
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Preparando instalación de StreamNinja...")
    dp.update(10, "Configurando conexión...")
    _sn_download_and_install_repo(dp)
    return False


def streamninja_open_or_install():
    """Abre StreamNinja o, si no está, ofrece instalarlo (botón de Abrir URL)."""
    if addon_listo(_SN_ID, "StreamNinja"):
        xbmc.executebuiltin(f"RunAddon({_SN_ID})")
        return
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        return

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja",
            "Addon no instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a pulsar el botón.",
            )
        return

    if not xbmcgui.Dialog().yesno(
        "Instalar StreamNinja",
        "StreamNinja no está instalado.\n¿Descargar e instalar el repositorio oficial?",
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Descargando StreamNinja...")
    dp.update(5, "Iniciando descarga...")
    _sn_download_and_install_repo(dp)

