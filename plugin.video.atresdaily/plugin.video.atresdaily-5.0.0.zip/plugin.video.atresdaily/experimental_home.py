# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import copy
import os
import sys
import time
import hashlib
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui
import xbmcaddon

import categorias
import connectorexperimental as ce
import ui_utils

_LOG_TAG = "[AtresDaily/ExpHome]"

# Filas de la home, en el orden del catálogo: de lo que más se ve sin cuenta a lo que es
# casi todo de pago. Los rótulos del XML se rellenan desde aquí (Window.Property
# row_label_N), así que reordenar esta lista basta.
_ROW_CATS = ["Infantil", "Actualidad", "Cine", "Programas", "Series", "Documentales", "Extra"]

# Categorías candidatas para la cabecera (hero). Solo entran las que tengan un
# episodio libre reproducible directo; el resto se omiten.
_HERO_CATS = ("Series", "Cine", "Programas", "Actualidad", "Infantil")

_ID_HERO = 200
_ID_HOME_ROWS_BASE = 310  # 310..316, uno por categoría
_ID_LOADING = 500
_ID_GRID = 600
_ID_SEASONS = 700
_ID_EPISODES = 710
_ID_SEARCH_BTN = 900
_ID_CLOSE_BTN = 901
_LISTAS = (_ID_HERO, *range(_ID_HOME_ROWS_BASE, _ID_HOME_ROWS_BASE + len(_ROW_CATS)),
           _ID_GRID, _ID_SEASONS, _ID_EPISODES)
_FOCO_POR_VISTA = {"home": _ID_HERO, "grid": _ID_GRID, "detail": _ID_EPISODES}

_FOCUS_POLL_MS = 250

# La llamada al plugin que lleva el Modo Cine. Si se abre otra vez mientras un vídeo lo tiene
# cerrado, la nueva se queda con el turno y la anterior ya no lo vuelve a abrir.
_TURNO = "atresdaily.cine.turno"
# Los del Modo Fantasía (fantasia.py): el id de su ventana abierta y su turno.
_FANTASIA = "atresdaily.fantasia"
_FANTASIA_TURNO = "atresdaily.fantasia.turno"
_PASO_S = 0.25
# Sin vídeo durante _FIN_S, se ha acabado (una cola encadena varios). Sin vídeo ni diálogos
# delante durante _SIN_VIDEO_S, el capítulo no ha llegado a empezar.
_FIN_S = 2
_SIN_VIDEO_S = 2
# Lo que se espera a que se vayan los diálogos que queden (Kodi no abre una ventana con uno
# delante) o a que el Modo Fantasía de debajo vuelva a abrirse.
_DIALOGOS_S = 10
_FANTASIA_S = 15
# Cuándo pasó el conector el capítulo a StreamNinja, que lo resuelve sin diálogos, y lo que se
# le espera antes de dar el vídeo por perdido.
_STREAMNINJA = "atresdaily.streamninja"
_STREAMNINJA_S = 20

# Cuántos pósters precargar por fila en la home. Las filas son una vista previa;
# el catálogo completo se ve en la rejilla "Ver todo".
_HOME_ROW_LIMIT = 20
# Las páginas del catálogo (de 50) traen a menudo algo menos sin ser la última, así que
# se da por hecho que hay más con 40 o más.
_PAGINA_CASI_LLENA = 40

# Cache local de imágenes, persiste 2 días. Mejor que confiar solo en el cache de
# texturas de Kodi (textures.db), que es global y puede expirar por presión de
# espacio o reinstalación.
_IMG_CACHE_DIR_NAME = "imgcache"
_IMG_CACHE_TTL_SECS = 2 * 24 * 3600


def _img_cache_dir():
    p = ui_utils.get_path(_IMG_CACHE_DIR_NAME)
    if not os.path.exists(p):
        try: os.makedirs(p)
        except Exception: pass
    return p


def _url_to_local(url):
    h = hashlib.md5(url.encode('utf-8')).hexdigest()
    return os.path.join(_img_cache_dir(), h + ".jpg")


def _local_if_fresh(url):
    local = _url_to_local(url)
    try:
        if os.path.exists(local):
            age = time.time() - os.path.getmtime(local)
            if age < _IMG_CACHE_TTL_SECS and os.path.getsize(local) > 200:
                return local
    except Exception:
        pass
    return None


def _download_to_local(url):
    local = _url_to_local(url)
    if _local_if_fresh(url):
        return local
    return ce.download_file(url, local)


def _cleanup_old_cache():
    # Elimina imágenes con más de TTL de antigüedad. Se ejecuta en background al
    # abrir la home, no bloquea nada.
    cache_dir = _img_cache_dir()
    if not os.path.exists(cache_dir): return
    now = time.time()
    removed = 0
    try:
        for fname in os.listdir(cache_dir):
            path = os.path.join(cache_dir, fname)
            try:
                if now - os.path.getmtime(path) > _IMG_CACHE_TTL_SECS:
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
    except Exception:
        pass
    if removed:
        xbmc.log(f"{_LOG_TAG} cache cleanup: {removed} imágenes expiradas eliminadas", xbmc.LOGINFO)


_CLOSE_ACTIONS = {xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK}

_PREMIUM_TAGS = ("EXCLUSIVE", "ORIGINAL", "PREVIEW")


def _is_premium_catalog(row):
    return row.get("tagType") in _PREMIUM_TAGS and not row.get("open", False)


def _is_premium_episode(ep):
    return ep.get("tagType") in _PREMIUM_TAGS


def _etiqueta(ep):
    """Lo que dicen del acceso las marcas de un capítulo, lo mismo que en las listas de Kodi."""
    tag = ep.get("tagType", "")
    if ep.get("open"):
        return "Cuenta gratis" if tag in _PREMIUM_TAGS else "Sin cuenta"
    if tag in _PREMIUM_TAGS or ep.get("claim") == "PREMIUM":
        return {"ORIGINAL": "ATP Original", "PREVIEW": "ATP Avance"}.get(tag, "ATP+")
    return "Sin cuenta" if ep.get("vertical") else ""


def _free_first(rows, premium_fn):
    # Sort estable, los no-premium conservan su orden THE_MOST y van delante.
    return sorted(rows, key=lambda r: 1 if premium_fn(r) else 0)


def _shrink_img(img_url):
    # ui_utils.fix_img pide 1280x720; con 480x270 sobra para fila y rejilla, y el JPG
    # pesa unas seis veces menos.
    if img_url and img_url.endswith("1280x720.jpg"):
        return img_url[:-len("1280x720.jpg")] + "480x270.jpg"
    return img_url


# --- Peticiones a la API ---

_fetch_json = ce.fetch_json
_fetch_cat_rows = ce.fetch_cat_rows


def _episodes_from_show_data(data, size=100):
    # Un show o una temporada devuelven la misma forma, una fila type=EPISODE que
    # apunta a otro href, o itemRows con los episodios directamente.
    if not isinstance(data, dict):
        return []
    capitulos = getattr(ce, "episodes_from_show", None)
    if capitulos:
        return capitulos(data, size)
    for row in data.get("rows", []):
        if row.get("type") == "EPISODE" and row.get("href"):
            eps = _fetch_json(row["href"])
            return eps.get("itemRows", []) if isinstance(eps, dict) else []
    return data.get("itemRows", []) if "itemRows" in data else []


def _gratis_primero():
    """La función del conector de Kodi que ordena los capítulos con lo gratis delante, si el
    ajuste Lo gratis primero está activado y el conector la trae."""
    if xbmcaddon.Addon().getSetting("gratis_primero") != "true":
        return None
    return getattr(sys.modules.get("connector"), "gratis_primero", None)


def _capitulos(data):
    """Los capítulos de un programa o una temporada para la vista de detalle, con lo que se
    puede ver delante."""
    eps = _episodes_from_show_data(data)
    ordenar = _gratis_primero()
    if ordenar:
        try:
            return ordenar(eps)
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} gratis_primero: {e}", xbmc.LOGWARNING)
    return sorted(eps, key=lambda e: 1 if _is_premium_episode(e) else 0)


def _normalize_episode(ep):
    t = ep.get("title", "Episodio")
    n = ep.get("name", "")
    full = f"{n} - {t}" if n else t
    # El id reproducible es contentId; si falta, se saca del href
    # (.../page/episode/{contentId}).
    vid = ep.get("contentId")
    if not vid:
        href = (ep.get("link") or {}).get("href", "")
        if "/episode/" in href:
            vid = href.split("/episode/")[1].split("/")[0]
    img = _shrink_img(ui_utils.fix_img((ep.get("image") or {}).get("pathHorizontal")
                                       or (ep.get("image") or {}).get("pathVertical")))
    du = ep.get("duration", 0) or 0
    if du > 10000: du = du // 1000  # a veces viene en ms
    return {
        "title": full,
        "vid": vid,
        "premium": _is_premium_episode(ep),
        "etiqueta": _etiqueta(ep),
        "img": img,
        "plot": (ep.get("description") or "")[:600],
        "duration": int(du),
    }


def _latest_free_episode(show_href):
    # Episodio libre más reciente de un programa, para que la cabecera reproduzca
    # directamente. La temporada 0 (seasons[0]) es la más reciente; si no hay
    # temporadas, se usan los episodios directos del programa.
    data = _fetch_json(show_href)
    if not isinstance(data, dict):
        return None
    # Con los 10 primeros basta para dar con uno libre; la cabecera lo pide para varios programas.
    eps = []
    seasons = data.get("seasons", [])
    if seasons:
        sh = (seasons[0].get("link") or {}).get("href")
        if sh:
            sd = _fetch_json(sh)
            if isinstance(sd, dict):
                eps = _episodes_from_show_data(sd, size=10)
    if not eps:
        eps = _episodes_from_show_data(data, size=10)
    for e in eps:
        if not _is_premium_episode(e):
            n = _normalize_episode(e)
            if n.get("vid"):
                return n
    return None


# --- Constructores de ListItem ---

def _build_show_li(item, cat_name=""):
    title = item.get("title", "Sin título")
    href = item.get("link", {}).get("href", "")
    if not href: return None
    img_url = _shrink_img(ui_utils.fix_img(item.get("image", {}).get("pathHorizontal")))
    img = _local_if_fresh(img_url) or img_url
    plot = (item.get("description") or "")[:600]
    badge = ""
    if _is_premium_catalog(item):
        badge = {"ORIGINAL": "ATP Original", "PREVIEW": "ATP Avance"}.get(item.get("tagType", ""), "ATP+")

    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "show")
    li.setProperty("ad_title", title)
    li.setProperty("ad_plot", plot)
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_href", href)
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_badge", badge)
    return li


def _build_hero_play_li(show_row, ep, cat_name=""):
    # Ítem de cabecera con la carátula del programa pero que reproduce directo su
    # último episodio libre (ad_action=episode + ad_vid). Visualmente idéntico al
    # póster del programa.
    title = show_row.get("title", "Sin título")
    img_url = _shrink_img(ui_utils.fix_img(show_row.get("image", {}).get("pathHorizontal")))
    img = _local_if_fresh(img_url) or img_url
    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", title)
    li.setProperty("ad_plot", ep.get("plot") or (show_row.get("description") or "")[:600])
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_vid", ep.get("vid") or "")
    li.setProperty("ad_ctx", f"{title}|{ep.get('title') or ''}")
    li.setProperty("ad_is_premium", "0")
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_badge", "")
    return li


def _build_nav_li(action, label, cat_name="", page=""):
    # Centinela de navegación (Ver todo / Siguiente). Reusa el layout de póster.
    img = ui_utils.media_icon("catalogo.png") or "DefaultFolder.png"
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": img, "icon": img, "poster": img, "landscape": img})
    li.setProperty("ad_action", action)
    li.setProperty("ad_title", label)
    li.setProperty("ad_image", img)
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_page", str(page))
    li.setProperty("ad_badge", "")
    return li


def _build_episode_li(ep, show=""):
    img = _local_if_fresh(ep["img"]) or ep["img"]
    etiqueta = ep["etiqueta"]
    li = xbmcgui.ListItem(label=f"[{etiqueta}] {ep['title']}" if etiqueta else ep["title"])
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", ep["title"])
    li.setProperty("ad_plot", ep["plot"])
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_vid", ep["vid"] or "")
    # Programa y capítulo, para buscarlo fuera si no se puede ver
    li.setProperty("ad_ctx", f"{show}|{ep['title']}" if show else ep["title"])
    li.setProperty("ad_is_premium", "1" if ep["premium"] else "0")
    li.setProperty("ad_badge", etiqueta)
    return li


def _build_season_li(title, href):
    li = xbmcgui.ListItem(label=title)
    li.setProperty("ad_action", "season")
    li.setProperty("ad_title", title)
    li.setProperty("ad_href", href)
    return li


# Lo que la ventana se lleva al cerrarse para un vídeo y se devuelve a la siguiente (show()).
_ESTADO = ("_cat_rows", "_hero", "_hero_resuelta", "_view_stack", "_foco_vista", "_grid_cat",
           "_grid_cid", "_grid_page", "_grid_rows", "_grid_last_count", "_detail_href",
           "_detail_title", "_seasons", "_season_href", "_episodes", "_posiciones", "_foco")


class ExperimentalHome(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.selected_action = None
        self.selected_query = ""
        self.selected_vid = ""
        self.selected_title = ""
        self.selected_ctx = ""
        # estado() de la ventana que cerró un vídeo, para abrir esta tal como estaba aquella.
        self.anterior = None
        self._cat_rows = {}
        # Cabecera: (programa, capítulo que reproduce o None, categoría) de cada elemento.
        self._hero = []
        self._hero_resuelta = False
        self._loaded = False
        self._closing = False
        self._view_stack = ["home"]
        # Control con el foco al dejar cada vista, para volver a él con Atrás.
        self._foco_vista = {}
        # Estado de la rejilla "Ver todo"
        self._grid_cat = ""
        self._grid_cid = ""
        self._grid_page = 0
        self._grid_rows = []
        self._grid_last_count = 0
        self._grid_busy = False
        # Programa y temporada abiertos. Lo que llega tarde de otros ya no se pinta.
        self._detail_href = ""
        self._detail_title = ""
        self._seasons = []
        self._season_href = ""
        self._episodes = []
        # Al cerrarse para un vídeo: el elegido de cada lista y el control con el foco.
        self._posiciones = {}
        self._foco = 0

    # --- Ciclo de vida ---

    def onInit(self):
        anterior, self.anterior = self.anterior, None
        for clave, valor in (anterior or {}).items():
            setattr(self, clave, valor)
        self.setProperty("view", self._view_stack[-1] if anterior else "home")
        self._set_focus_props(title="Cargando...", plot="", fanart="")
        if anterior:
            threading.Thread(target=self._repintar, daemon=True).start()
        else:
            threading.Thread(target=_cleanup_old_cache, daemon=True).start()
            threading.Thread(target=self._load_all, daemon=True).start()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()

    def estado(self):
        """Lo que hace falta para abrir otra ventana tal como está esta."""
        return {clave: copy.copy(getattr(self, clave)) for clave in _ESTADO}

    def _repintar(self):
        """Pinta lo que se veía antes del vídeo, sin pedir nada a la API, y deja el foco donde estaba."""
        self._pintar_home()
        if "grid" in self._view_stack:
            self.setProperty("grid_title", f"{self._grid_cat}  ·  Todo")
            self._render_grid(self._grid_last_count, enfocar=False)
        if "detail" in self._view_stack:
            self.setProperty("detail_title", self._detail_title)
            if self._seasons:
                self._populate_seasons(self._seasons)
            self._pintar_episodios(enfocar=False)
        try:
            for cid, pos in self._posiciones.items():
                if pos >= 0:
                    self.getControl(cid).selectItem(pos)
            self.setFocusId(self._foco or _FOCO_POR_VISTA.get(self._view_stack[-1], _ID_HERO))
        except RuntimeError as e:
            xbmc.log(f"{_LOG_TAG} repintar: {e}", xbmc.LOGWARNING)
        self._loaded = True
        self._refresh_focus_props()
        if not self._hero_resuelta and any(self._cat_rows.get(n) for n in _HERO_CATS):
            threading.Thread(target=self._resolve_hero, daemon=True).start()

    def _foco_actual(self):
        try:
            return self.getFocusId()
        except RuntimeError:
            return 0

    def _cerrar(self):
        """Cierra la ventana apuntando lo elegido en cada lista, por si vuelve tras un vídeo."""
        self._foco = self._foco_actual()
        self._posiciones = {}
        for cid in _LISTAS:
            try:
                self._posiciones[cid] = self.getControl(cid).getSelectedPosition()
            except RuntimeError:
                pass
        self._closing = True
        self.close()

    def cerrar_por_video(self):
        """Ha empezado un vídeo con la ventana abierta, que lo taparía. Vuelve al acabar (show())."""
        if self._closing:
            return
        self.selected_action = "video"
        self._cerrar()

    def _load_all(self):
        try:
            results = {}
            lock = threading.Lock()

            def worker(name):
                cid = self._cid_for(name)
                if not cid: return
                try:
                    rows = _fetch_cat_rows(cid, page=0)
                except Exception as e:
                    xbmc.log(f"{_LOG_TAG} fetch {name} fallo: {e}", xbmc.LOGWARNING)
                    rows = []
                with lock:
                    results[name] = rows or []

            threads = [threading.Thread(target=worker, args=(n,), daemon=True) for n in _ROW_CATS]
            for t in threads: t.start()
            for t in threads: t.join(timeout=20)

            self._cat_rows = results
            if self._closing: return
            self._populate_home()
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} _load_all error: {e}", xbmc.LOGERROR)
            self._set_loading_text("[COLOR red]Error al cargar el catálogo. Pulsa Atrás para cerrar.[/COLOR]")

    def _cid_for(self, name):
        # CATS es lista de (nombre, id). Los pósters llevan el nombre que se enseña.
        return next((c for n, c in ce.CATS if name in (n, categorias.nombre(n))), None)

    # --- Vista HOME ---

    def _populate_home(self):
        # Placeholder inmediato del hero, primer programa libre de cada categoría
        # (abre detalle si se pulsa antes de que _resolve_hero lo haga reproducible).
        self._hero = []
        for name in _HERO_CATS:
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            first_free = next((r for r in rows if not _is_premium_catalog(r)), None)
            if first_free:
                self._hero.append((first_free, None, categorias.nombre(name)))
        hero_items, any_row = self._pintar_home()

        if hero_items:
            try: self.setFocusId(_ID_HERO)
            except Exception: pass
        elif any_row:
            try: self.setFocusId(_ID_HOME_ROWS_BASE)
            except Exception: pass
        else:
            self._set_loading_text("[COLOR orange]No hay contenido disponible. Revisa tu conexión.[/COLOR]")

        self._loaded = True
        self._refresh_focus_props()
        if hero_items or any_row:
            threading.Thread(target=self._prefetch_images, daemon=True).start()
        if any(self._cat_rows.get(n) for n in _HERO_CATS):
            threading.Thread(target=self._resolve_hero, daemon=True).start()

    def _hero_items(self):
        items = (_build_hero_play_li(fila, ep, cat) if ep else _build_show_li(fila, cat_name=cat)
                 for fila, ep, cat in self._hero)
        return [li for li in items if li]

    def _pintar_home(self):
        """Cabecera y filas de la portada con lo ya cargado. Devuelve si hay algo en cada parte."""
        hero_items = self._hero_items()
        if hero_items:
            try: self.getControl(_ID_HERO).addItems(hero_items)
            except Exception as e: xbmc.log(f"{_LOG_TAG} hero: {e}", xbmc.LOGWARNING)

        any_row = False
        for idx, name in enumerate(_ROW_CATS):
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            visible = categorias.nombre(name)
            items = [li for li in (_build_show_li(r, cat_name=visible) for r in rows[:_HOME_ROW_LIMIT]) if li]
            # Rótulo vacío si la fila no tiene contenido, para no dejar un encabezado huérfano.
            self.setProperty(f"row_label_{idx}", visible if items else "")
            if not items: continue
            items.append(_build_nav_li("view_all", "Ver todo  »", cat_name=visible))
            try:
                self.getControl(_ID_HOME_ROWS_BASE + idx).addItems(items)
                any_row = True
            except Exception as e:
                xbmc.log(f"{_LOG_TAG} fila {name}: {e}", xbmc.LOGWARNING)

        try: self.getControl(_ID_LOADING).setVisible(False)
        except Exception: pass
        return bool(hero_items), any_row

    def _resolve_hero(self):
        results = {}
        lock = threading.Lock()

        def work(name):
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            for show in rows[:8]:
                if _is_premium_catalog(show):
                    continue
                href = (show.get("link") or {}).get("href", "")
                ep = _latest_free_episode(href) if href else None
                if ep and ep.get("vid"):
                    with lock:
                        results[name] = (show, ep, categorias.nombre(name))
                    return

        threads = [threading.Thread(target=work, args=(n,), daemon=True) for n in _HERO_CATS]
        for t in threads: t.start()
        for t in threads: t.join(timeout=18)
        if self._closing: return
        self._hero_resuelta = True

        hero = [results[n] for n in _HERO_CATS if n in results]
        if not hero:
            return
        self._hero = hero
        try:
            ctrl = self.getControl(_ID_HERO)
            pos = ctrl.getSelectedPosition()
            ctrl.reset()
            ctrl.addItems(self._hero_items())
            if 0 <= pos < len(hero):
                ctrl.selectItem(pos)
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} resolve_hero: {e}", xbmc.LOGWARNING)

    def _prefetch_images(self):
        urls = set()
        for rows in self._cat_rows.values():
            for r in rows[:_HOME_ROW_LIMIT]:
                img = _shrink_img(ui_utils.fix_img(r.get("image", {}).get("pathHorizontal", "")))
                if img and not _local_if_fresh(img):
                    urls.add(img)
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=10) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} prefetch error: {e}", xbmc.LOGWARNING)

    # --- Vista GRID (Ver todo) ---

    def _open_grid(self, cat_name):
        cid = self._cid_for(cat_name)
        if not cid: return
        self._grid_cat = cat_name
        self._grid_cid = cid
        self._grid_page = 0
        self._grid_rows = []
        self.setProperty("grid_title", f"{cat_name}  ·  Cargando...")
        self._navigate_to("grid")
        threading.Thread(target=self._grid_fetch_first, args=(cid,), daemon=True).start()

    def _grid_fetch_first(self, cid):
        rows = _fetch_cat_rows(cid, page=0) or []
        if cid != self._grid_cid:
            return
        # Cada página va con lo libre delante, sin reordenar las anteriores: así, al pedir
        # la siguiente, lo ya visto no cambia de sitio y el foco cae en lo nuevo.
        self._grid_rows = _free_first(rows, _is_premium_catalog)
        self.setProperty("grid_title", f"{self._grid_cat}  ·  Todo")
        self._render_grid(last_count=len(rows), focus_pos=0)

    def _render_grid(self, last_count, focus_pos=0, enfocar=True):
        self._grid_last_count = last_count
        try:
            ctrl = self.getControl(_ID_GRID)
        except Exception:
            return
        ctrl.reset()
        items = [li for li in (_build_show_li(r, cat_name=self._grid_cat) for r in self._grid_rows) if li]
        # Con una página casi llena probablemente hay más; si no la hay, "Siguiente"
        # avisa de que no hay más contenido.
        if last_count >= _PAGINA_CASI_LLENA:
            items.append(_build_nav_li("load_more", "Siguiente  »", cat_name=self._grid_cat,
                                       page=self._grid_page + 1))
        if not items:
            self.setProperty("grid_title", f"{self._grid_cat}  ·  Sin contenido")
            return
        ctrl.addItems(items)
        if enfocar:
            try:
                ctrl.selectItem(min(focus_pos, len(items) - 1))
                self.setFocusId(_ID_GRID)
            except Exception:
                pass
        # Precargar las imágenes nuevas de la rejilla en background.
        threading.Thread(target=self._prefetch_grid, daemon=True).start()

    def _prefetch_grid(self):
        urls = set()
        for r in self._grid_rows:
            img = _shrink_img(ui_utils.fix_img(r.get("image", {}).get("pathHorizontal", "")))
            if img and not _local_if_fresh(img):
                urls.add(img)
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=10) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception:
            pass

    def _grid_load_more(self):
        if self._grid_busy: return
        self._grid_busy = True
        cid = self._grid_cid

        def work():
            try:
                next_page = self._grid_page + 1
                new_rows = _fetch_cat_rows(cid, page=next_page)
                if cid != self._grid_cid:
                    return
                if not new_rows:
                    xbmcgui.Dialog().notification("AtresDaily", "No hay más contenido",
                                                  xbmcgui.NOTIFICATION_INFO, 1500)
                    # Repintar sin centinela (last_count 0) para quitar "Siguiente".
                    self._render_grid(last_count=0, focus_pos=len(self._grid_rows) - 1)
                    return
                # Una página repite a veces algún título de la anterior.
                vistos = {(r.get("link") or {}).get("href") for r in self._grid_rows}
                nuevas = [r for r in new_rows if (r.get("link") or {}).get("href") not in vistos]
                focus_at = len(self._grid_rows)  # primer ítem nuevo
                self._grid_rows.extend(_free_first(nuevas, _is_premium_catalog))
                self._grid_page = next_page
                self._render_grid(last_count=len(new_rows), focus_pos=focus_at)
            finally:
                self._grid_busy = False

        threading.Thread(target=work, daemon=True).start()

    # --- Vista DETAIL (temporadas + episodios) ---

    def _open_detail(self, href, title, cat_name=""):
        self._detail_href = href
        self._detail_title = title
        self._seasons, self._season_href, self._episodes = [], "", []
        self.setProperty("detail_title", title)
        self.setProperty("detail_plot", "")
        self.setProperty("seasons_visible", "0")
        # Los capítulos del programa anterior se podrían pulsar mientras carga este.
        for cid in (_ID_SEASONS, _ID_EPISODES):
            try:
                self.getControl(cid).reset()
            except RuntimeError:
                pass
        self._navigate_to("detail")
        threading.Thread(target=self._load_detail, args=(href, title), daemon=True).start()

    def _load_detail(self, href, title):
        data = _fetch_json(href)
        if href != self._detail_href:
            return
        if not isinstance(data, dict):
            xbmcgui.Dialog().notification("AtresDaily", "No se pudo abrir el programa",
                                          xbmcgui.NOTIFICATION_WARNING, 2000)
            self._go_back()
            return
        self._detail_title = data.get("title") or title
        self.setProperty("detail_title", self._detail_title)

        seasons = data.get("seasons", [])
        # Con varias temporadas mostramos la tira de temporadas (archivo completo);
        # si no, los episodios directos del programa.
        if len(seasons) > 1:
            self._populate_seasons(seasons)
            first_href = (seasons[0].get("link") or {}).get("href", "")
            if first_href:
                self._load_season(first_href)
            return

        self.setProperty("seasons_visible", "0")
        eps = _capitulos(data)
        if href == self._detail_href:
            self._populate_episodes(eps)

    def _populate_seasons(self, seasons):
        self._seasons = seasons
        items = []
        for s in seasons:
            t = s.get("title", "Temporada")
            link = (s.get("link") or {}).get("href", "")
            if link:
                items.append(_build_season_li(t, link))
        try:
            ctrl = self.getControl(_ID_SEASONS)
            ctrl.reset()
            ctrl.addItems(items)
            self.setProperty("seasons_visible", "1")
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} temporadas: {e}", xbmc.LOGWARNING)

    def _load_season(self, href):
        self._season_href = href
        programa = self._detail_href

        def work():
            eps = _capitulos(_fetch_json(href))
            # Con dos temporadas pulsadas seguidas, la primera en llegar podría ser la vieja.
            if href == self._season_href and programa == self._detail_href:
                self._populate_episodes(eps)
        threading.Thread(target=work, daemon=True).start()

    def _populate_episodes(self, raw_eps):
        norm = [n for n in (_normalize_episode(e) for e in raw_eps) if n.get("vid")]
        self._episodes = norm
        if not self._pintar_episodios():
            xbmcgui.Dialog().notification("AtresDaily", "Sin episodios disponibles",
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        threading.Thread(target=lambda: self._prefetch_episode_imgs(norm), daemon=True).start()

    def _pintar_episodios(self, enfocar=True):
        """Pinta self._episodes. Devuelve si hay alguno."""
        items = [_build_episode_li(e, self._detail_title) for e in self._episodes]
        try:
            ctrl = self.getControl(_ID_EPISODES)
            ctrl.reset()
            if items:
                ctrl.addItems(items)
            if enfocar:
                self.setFocusId(_ID_EPISODES if items else _ID_SEASONS)
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} episodios: {e}", xbmc.LOGWARNING)
        return bool(items)

    def _prefetch_episode_imgs(self, norm):
        urls = {e["img"] for e in norm if e["img"] and not _local_if_fresh(e["img"])}
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=8) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception:
            pass

    # --- Reproducción ---

    def _play_episode(self, vid, title, ctx=""):
        # Cerramos la ventana y dejamos que show() delegue en connector.play_media:
        # un diálogo se pinta sobre el vídeo, así que no se puede reproducir con la
        # ventana abierta.
        if not vid: return
        self.selected_action = "play"
        self.selected_vid = vid
        self.selected_title = title
        self.selected_ctx = ctx
        self._cerrar()

    def _do_search(self):
        kb = xbmc.Keyboard('', 'Buscar en Atresplayer')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            return
        self.selected_action = "search"
        self.selected_query = kb.getText().strip()
        self._closing = True
        self.close()

    # --- Navegación entre vistas ---

    def _navigate_to(self, view):
        # No forzamos foco aquí; el contenido se puebla en background y enfocar un
        # control aún vacío genera ruido en el log de Kodi. El método de poblado
        # (_render_grid / _populate_episodes) fija el foco cuando ya hay ítems.
        self._foco_vista[self._view_stack[-1]] = self._foco_actual()
        self._view_stack.append(view)
        self.setProperty("view", view)
        self._refresh_focus_props()

    def _go_back(self):
        if len(self._view_stack) > 1:
            saliendo = self._view_stack.pop()
            # Lo que siga cargándose para la vista que se deja ya no se pinta.
            if saliendo == "detail":
                self._detail_href = self._season_href = ""
            elif saliendo == "grid":
                self._grid_cid = ""
            target = self._view_stack[-1]
            self.setProperty("view", target)
            # Al volver, la vista destino ya está poblada; enfocar es seguro.
            fid = self._foco_vista.get(target) or _FOCO_POR_VISTA.get(target, _ID_HERO)
            try: self.setFocusId(fid)
            except Exception: pass
            self._refresh_focus_props()
        else:
            self._closing = True
            self.close()

    # --- Eventos ---

    def onAction(self, action):
        if action.getId() in _CLOSE_ACTIONS:
            self._go_back()

    def onClick(self, controlId):
        if not self._loaded: return
        if controlId == _ID_CLOSE_BTN:
            self._closing = True
            self.close()
            return
        if controlId == _ID_SEARCH_BTN:
            self._do_search()
            return
        try:
            ctrl = self.getControl(controlId)
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
        except Exception:
            return
        action = li.getProperty("ad_action")
        if action == "view_all":
            self._open_grid(li.getProperty("ad_cat"))
        elif action == "load_more":
            self._grid_load_more()
        elif action == "season":
            self._load_season(li.getProperty("ad_href"))
        elif action == "episode":
            # Todos (libres y ATP+) se delegan al connector vía play_media; él
            # decide si hay fuente reproducible. Los premium solo van ordenados al
            # final y con badge.
            self._play_episode(li.getProperty("ad_vid"), li.getProperty("ad_title"), li.getProperty("ad_ctx"))
        else:  # show
            href = li.getProperty("ad_href")
            if href:
                self._open_detail(href, li.getProperty("ad_title"), li.getProperty("ad_cat"))

    # --- Propiedades de foco (título/plot/fanart inferior) ---

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last_key = None
        while not self._closing and not monitor.abortRequested():
            try:
                key = self._current_focus_key()
                if key != last_key:
                    self._refresh_focus_props()
                    last_key = key
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000.0):
                break

    # getFocus() sin nada enfocado (al abrirse la ventana) deja "Non-Existent Control 0" en el
    # log de Kodi; getFocusId() da 0 sin quejarse.
    def _current_focus_key(self):
        cid = self._foco_actual()
        if not cid:
            return None
        try:
            return (cid, self.getControl(cid).getSelectedPosition())
        except (RuntimeError, AttributeError):
            return None

    def _refresh_focus_props(self):
        cid = self._foco_actual()
        if not cid:
            return
        try:
            ctrl = self.getControl(cid)
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
            if li is None: return
            self._set_focus_props(
                title=li.getProperty("ad_title") or li.getLabel() or "",
                plot=li.getProperty("ad_plot") or "",
                fanart=li.getProperty("ad_fanart") or li.getProperty("ad_image") or "",
            )
        except Exception:
            pass

    def _set_focus_props(self, title="", plot="", fanart=""):
        self.setProperty("focused_title", title)
        self.setProperty("focused_plot", plot)
        self.setProperty("focused_fanart", fanart)

    def _set_loading_text(self, msg):
        try:
            ctrl = self.getControl(_ID_LOADING)
            ctrl.setLabel(msg)
            ctrl.setVisible(True)
        except Exception:
            pass


class _Vigia(xbmc.Player):
    """Cierra el Modo Cine si empieza un vídeo con la ventana abierta, porque lo taparía."""

    def __init__(self):
        super().__init__()
        self.ventana = None

    def onAVStarted(self):
        ventana = self.ventana
        if ventana is not None and self.isPlayingVideo():
            ventana.cerrar_por_video()


def _fantasia_de_vuelta(fantasia, esperar):
    """Espera a que el Modo Fantasía de debajo, que se cierra con el vídeo, se abra otra vez.
    False si no lo hace o si ya no es el mismo."""
    casa = xbmcgui.Window(10000)
    for _ in range(int(_FANTASIA_S / _PASO_S)):
        if casa.getProperty(_FANTASIA_TURNO) != fantasia:
            return False
        ventana = casa.getProperty(_FANTASIA)
        if ventana and xbmc.getCondVisibility(f"Window.IsVisible({ventana})"):
            return True
        if esperar():
            return False
    return False


def _volver(monitor, jugador, origen, ruta, fantasia, es_mio):
    """True si hay que abrir otra vez el Modo Cine: el vídeo ha acabado o no ha llegado a
    empezar (el aviso de un capítulo que no se puede ver, cerrado), y se sigue donde se
    estaba. fantasia es el turno del Modo Fantasía de debajo, o "" si no lo hay."""

    def esperar():
        return monitor.waitForAbort(_PASO_S) or not es_mio()

    casa, desde = xbmcgui.Window(10000), time.time()

    def en_marcha():
        """Si aún puede empezar el vídeo: hay un diálogo delante (el vídeo abriéndose, el aviso de
        un capítulo de pago) o StreamNinja lo está resolviendo desde el aviso."""
        if xbmc.getCondVisibility("System.HasActiveModalDialog"):
            return True
        try:
            pasado = float(casa.getProperty(_STREAMNINJA) or 0)
        except ValueError:
            return False
        return desde <= pasado and time.time() - pasado < _STREAMNINJA_S

    # Mientras esté en marcha, el tiempo sin vídeo no cuenta. Solo cuenta el vídeo, porque la
    # música que ya sonara por detrás no tapa nada.
    empezado, quieto = False, 0
    while quieto < _SIN_VIDEO_S:
        if jugador.isPlayingVideo():
            empezado = True
            break
        if esperar():
            return False
        quieto = 0 if en_marcha() else quieto + _PASO_S
    if empezado:
        quieto = 0
        while quieto < _FIN_S:
            if esperar():
                return False
            quieto = 0 if jugador.isPlayingVideo() else quieto + _PASO_S
    elif fantasia:
        # "Buscar" en el aviso abre la búsqueda en el Modo Fantasía, y volver encima la taparía.
        return False
    if fantasia:
        if not _fantasia_de_vuelta(fantasia, esperar):
            return False
    else:
        # Kodi no abre una ventana con un diálogo modal delante, y el que quede tarda en irse
        # por su animación.
        for _ in range(int(_DIALOGOS_S / _PASO_S)):
            if not xbmc.getCondVisibility("System.HasActiveModalDialog"):
                break
            if esperar():
                return False
        # "Buscar" en el aviso abre la búsqueda en Vídeos, y volver encima la taparía.
        if xbmc.getInfoLabel("Container.FolderPath") != ruta:
            return False
    return xbmcgui.getCurrentWindowId() == origen and es_mio()


def show():
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    casa = xbmcgui.Window(10000)
    turno = os.urandom(8).hex()
    casa.setProperty(_TURNO, turno)

    def es_mio():
        return casa.getProperty(_TURNO) == turno

    # Tras un vídeo solo se vuelve si se sigue donde se abrió. Dentro del Modo Fantasía, que
    # también se cierra con el vídeo, se vuelve encima de él cuando se abre otra vez.
    origen = xbmcgui.getCurrentWindowId()
    ruta = xbmc.getInfoLabel("Container.FolderPath")
    fantasia = casa.getProperty(_FANTASIA_TURNO) if casa.getProperty(_FANTASIA) else ""
    monitor, jugador = xbmc.Monitor(), _Vigia()
    anterior = None
    try:
        while True:
            win = ExperimentalHome("experimental_home.xml", addon_path, "Default", "1080i")
            win.anterior = anterior
            jugador.ventana = win
            try:
                win.doModal()
            finally:
                jugador.ventana = None
                # Sin esto, si la ventana se cierra por una vía distinta de sus manejadores, el hilo
                # de _focus_poll_loop sigue vivo y Kodi mantiene la invocación esperándolo.
                win._closing = True
            action, query, vid = win.selected_action, win.selected_query, win.selected_vid
            title, ctx = win.selected_title, win.selected_ctx
            # Una ventana que se cierra a medio cargar se abriría vacía; esa vuelve a cargarse.
            anterior = win.estado() if win._loaded else None
            del win

            if action == "play" and vid:
                qs = {"action": "play_media", "url": vid, "title": title}
                if ctx:
                    qs["extra"] = ctx
                play_url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
                xbmc.executebuiltin(f"PlayMedia({play_url})")
            elif action != "video":
                if action == "search" and query:
                    qs = {"action": "atresplayer_catalog_search", "q": query}
                    next_url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
                    xbmc.executebuiltin(f"Container.Update({next_url})")
                break
            if not _volver(monitor, jugador, origen, ruta, fantasia, es_mio):
                break
    finally:
        if es_mio():
            casa.clearProperty(_TURNO)
