# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Nombres que se enseñan de las categorías del catálogo."""

# Los conectores las siguen llamando como antes porque el Modo Cine de la 4.0.0 las busca
# por ese nombre; aquí se les da el de A3Player.
_VISIBLES = {"Actualidad": "Noticias", "Extra": "Premium"}


def nombre(categoria):
    return _VISIBLES.get(categoria, categoria)
