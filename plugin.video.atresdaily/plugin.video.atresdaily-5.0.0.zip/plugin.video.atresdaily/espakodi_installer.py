# -*- coding: utf-8 -*-
# AtresDaily - Copyright (C) 2024-2026 RubénSDFA1laberot
# Instalación y menú de los addons del ecosistema EspaKodi, portado de EKHorus
# (script.module.horus, lib/espakodi_installer.py).

import json
import os
import re
import sys
import time
import urllib.parse
import webbrowser
import xml.etree.ElementTree as ET
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import list_screen

HEADING = "AtresDaily"

EK_REPO_POLL_TIMEOUT_S  = 20
EK_PROXY_POLL_TIMEOUT_S = 25  # repository.elementumorg levanta su proxy local a su ritmo
EK_MAX_REPO_ZIP_BYTES   = 50 * 1024 * 1024
EK_MAX_ADDON_ZIP_BYTES  = 200 * 1024 * 1024
EK_HTTP_TIMEOUT_S       = 30

# Lo que tiene el índice de un repo para ofrecer el addon. UpdateAddonRepos consulta todos los
# repos activos, el oficial incluido, y en un aparato lento tarda.
EK_INDICE_TIMEOUT_S     = 45
# Para que Kodi registre lo que se acaba de extraer en addons/
EK_ACTIVAR_TIMEOUT_S    = 10
# Del cierre del sí/no a que se abre el progreso pasa un cuarto de segundo. Con los dos
# diálogos cerrados EK_QUIETO_S, la instalación ha terminado.
EK_PREGUNTA_TIMEOUT_S   = 8
EK_QUIETO_S             = 2
# Una mirada así de lenta es que el hilo de la interfaz de Kodi está instalando. Una normal no
# llega a 50 ms; en el móvil, el diálogo de progreso puede no llegar a verse abierto.
EK_MIRADA_LENTA_S       = 0.4
EK_INSTALACION_MAX_S    = 15 * 60

EK_ELEMENTUM_REPO = "repository.elementumorg"
EK_REPO_OFICIAL = "repository.xbmc.org"
EK_OWN_ADDON_ID = "plugin.video.atresdaily"

# Los que no son plugin.* pero tienen menú propio que abrir
_EK_CON_MENU = {"script.module.horus"}

_EK_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) "
                        "Gecko/20100101 Firefox/128.0"}

# Cómo se instala cada uno:
#   "repo":     se baja el zip de su repositorio, se registra y se instala el addon
#   "official": está en el repositorio oficial de Kodi (o en uno que ya trae EspaKodi) y basta
#               con pedírselo a Kodi
#   "proxy":    como "repo", pero los addons los publica un servicio del propio repositorio, que
#               arranca a su ritmo, y hay que esperarlo
#
# (addon_id, repo_id, zip_url, source_url, name, plot, fallback_icon, mode, kind)
# kind = apartado del repositorio donde lo coloca Kodi, solo para las instrucciones a mano
EK_ADDONS = [
    (
        "plugin.video.espatv",
        "repository.espatv",
        "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip",
        "https://espakodi.github.io/espatv/",
        "EspaTV",
        "TDT, RTVE a la carta, búsqueda en YouTube y Dailymotion, catálogo de vídeos, radio, podcasts, reproducción de enlaces, noticias, meteorología, agenda deportiva y mucho más.",
        "directo.png",
        "repo",
        "vídeo",
    ),
    (
        "plugin.video.espadaily",
        "repository.espadaily",
        "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip",
        "https://fullstackcurso.github.io/espadaily/",
        "EspaDaily",
        "EspaDaily permite explorar catálogos de televisión española y buscar vídeos públicos en internet que coincidan.",
        "busqueda.png",
        "repo",
        "vídeo",
    ),
    (
        EK_OWN_ADDON_ID,
        "repository.atresdaily",
        "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip",
        "https://espatv.github.io/atresdaily/",
        "AtresDaily",
        "Disfruta del contenido de A3Player con la potencia de AtresDaily. Búsquedas inteligentes y programación en directo.",
        "play_generic.png",
        "repo",
        "vídeo",
    ),
    (
        "script.module.horus",
        "repository.ekhorus",
        "https://espakodi.github.io/EKHorus/repository.ekhorus-1.0.0.zip",
        "https://espakodi.github.io/EKHorus/",
        "EKHorus",
        "Reproductor AceStream para Kodi, adaptado para EspaKodi: canales por categoría, país e idioma, favoritos, historial, guía y descarga de APKs (AceStream, AceServe y VLC).\n\nFunciona con el motor de AceStream o con AceServe en Android, y con el motor que instala él mismo en Windows y Linux. AtresDaily lo usa para abrir magnets y torrents cuando no tienes Elementum.",
        "adv_acestream.png",
        "repo",
        "programa",
    ),
    (
        "plugin.program.loiolog",
        "repository.loiolog",
        "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip",
        "https://loioloio.github.io/loiolog/",
        "loiolog",
        "Visualiza y busca en el log de Kodi con un visor de colores por severidad. Filtra por addon, texto o expresiones regulares. Exporta a TXT o JSON, comparte el log subiéndolo a internet o ábrelo en el móvil desde tu red local. Consulta estadísticas del log, compara errores entre sesiones y gestiona los logs anteriores.",
        "adv_log.png",
        "repo",
        "programa",
    ),
    (
        "plugin.program.flowfavmanager",
        "repository.flowfavmanager",
        "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip",
        "https://loioloio.github.io/flowfav/",
        "Flow FavManager",
        "Flow FavManager mejora la experiencia de gestión de favoritos en Kodi.\nPermite organizarlos, personalizar su apariencia y las acciones que realizan. Incluye herramientas de copia de seguridad, un editor intuitivo, perfiles y ordenación por secciones, entre otras funciones.",
        "favoritos.png",
        "repo",
        "programa",
    ),
    (
        "plugin.video.streamninja",
        "repository.streamninja",
        "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip",
        "https://fullstackcurso.github.io/estreamninja/",
        "StreamNinja",
        "StreamNinja permite enviar URLs a Kodi desde un móvil o PC mediante una web local efímera, o bien recibirlas directamente desde otros addons. Soporta Dailymotion, YouTube, AceStream, Torrents y casi cualquier enlace de vídeo.",
        "srch_externa.png",
        "repo",
        "vídeo",
    ),
    (
        "plugin.video.topzilla",
        "repository.topzilla",
        "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip",
        "https://espatv.github.io/topzilla/",
        "TopZilla",
        "TopZilla muestra rankings, información y vídeos relacionados de películas y series. Además permite buscarlas, filtrarlas y guardarlas en tu biblioteca o consultar sus fichas con solo dos clics, estés donde estés en tu Kodi.",
        "busqueda.png",
        "repo",
        "vídeo",
    ),
    (
        "plugin.program.loiolink",
        "repository.loiolink",
        "https://loiolo.io/repository.loiolink-1.0.0.zip",
        "https://loiolo.io/",
        "loiolink",
        "• Mando a distancia: controla lo que estás viendo, navega por los menús o gestiona tus addons desde la web.\n• Toda tu colección: navega por tus películas, series y música desde el navegador y reprodúcelas en la TV.\n• Streaming al móvil: envía el vídeo desde el televisor a tu móvil, tablet o PC.\n• Favoritos: elimina, reordena o edita accesos directos desde el navegador.\n• Escribe sin el mando: escribe búsquedas o enlaces largos en el navegador y aparecerán al instante en Kodi.\n• Envío de vídeos, torrents, listas M3U o enlaces AceStream para reproducirlos al vuelo o grabarlos.\n• Escáner web y Telegram: rastrea páginas o canales para recopilar y reproducir torrents, vídeos y enlaces.\n• Instalación de addons y archivos: envía ZIPs de addons o APKs desde el navegador para instalarlos al instante.\n• Grabación HLS, explorador de archivos, apagado remoto y copia de seguridad.",
        "loiolink.png",
        "repo",
        "programa",
    ),
    (
        "plugin.program.ekgames",
        "repository.ekgames",
        "https://espatv.github.io/ekgames/repository.ekgames-1.0.0.zip",
        "https://espatv.github.io/ekgames/",
        "EKGames",
        "Catorce minijuegos clásicos para echar una partida sin salir de Kodi: Snake, 2048, Tetris, Buscaminas, Memoria, Solitario, Flappy, Pong, Invaders, Burbujas, Frogger, Galaga, Asteroids y Pac-Man.\nSe juegan con el mando a distancia, con un mando de juego, con el teclado o con los dedos, guardan su récord y tienen cuatro niveles de dificultad.\nIncluye además Gamesek entero, sin instalar nada más: emuladores por sistema, tus carpetas de juegos, juegos libres que se descargan solos y el Modo Juego a pantalla completa.",
        "ek_juegos.png",
        "repo",
        "programa",
    ),
    (
        "plugin.program.gamesek",
        "repository.gamesek",
        "https://espakodi.github.io/gamesek/repository.gamesek-1.0.0.zip",
        "https://espakodi.github.io/gamesek/",
        "Gamesek",
        "Juegos y emuladores para Kodi, en español. Trae catorce clásicos que se abren al momento, sin descargar nada y sin emulador, y otros tantos que se descargan e instalan solos.\nTambién puedes importar tus juegos, enviarlos desde el móvil por la red de casa o pedirle que los busque por tus discos. El Modo Juego lo enseña todo a pantalla completa.",
        "ek_juegos.png",
        "repo",
        "programa",
    ),
    (
        "script.module.youtube.dl",
        EK_REPO_OFICIAL,
        "",
        "https://github.com/xbmc/repo-scripts",
        "youtube-dl",
        "Módulo youtube-dl/yt-dlp para Kodi: resuelve la URL reproducible de cientos de webs de vídeo. Lo usan otros addons como motor de extracción, no tiene interfaz propia.\n\nSe instala desde el repositorio oficial de Kodi.",
        "ek_modulo.png",
        "official",
        "programa",
    ),
    (
        "plugin.video.elementum",
        EK_ELEMENTUM_REPO,
        "https://github.com/ElementumOrg/repository.elementumorg/releases/download/v0.0.7/repository.elementumorg-0.0.7.zip",
        "https://github.com/elgatito/plugin.video.elementum",
        "Elementum",
        'Elementum es un motor de búsqueda y reproducción de torrents para Kodi. Reproduce películas y series por streaming desde la red BitTorrent mediante providers que se instalan aparte. AtresDaily lo usa en "Buscar en webs de torrent".\n\nAtresDaily baja su repositorio de GitHub al instalarlo, así que no hace falta añadir ninguna fuente.',
        "srch_torrent.png",
        "proxy",
        "vídeo",
    ),
    (
        "inputstream.adaptive",
        EK_REPO_OFICIAL,
        "",
        "https://github.com/xbmc/inputstream.adaptive",
        "InputStream Adaptive",
        "Motor de reproducción para streaming adaptativo (DASH, HLS, Smooth Streaming). Lo usan muchos addons de vídeo (TV a la carta, directos) para reproducir, y AtresDaily en el Motor TDT. Normalmente se instala solo al instalar un addon que lo necesite; esta opción lo trae del repositorio oficial de Kodi sin esperar a que otro addon lo pida.",
        "adv_motor_tdt.png",
        "official",
        "InputStream",
    ),
    (
        "script.module.resolveurl",
        "repository.resolveurl",
        "",
        "https://github.com/Gujal00/ResolveURL",
        "ResolveURL",
        "Módulo que resuelve el enlace reproducible de cientos de servidores de vídeo. Lo usan muchos addons para reproducir enlaces de hosters, AtresDaily entre ellos al abrir una URL. Normalmente se instala solo al instalar un addon que lo declare; esta opción lo trae de su repositorio (incluido en EspaKodi) sin esperar a que otro addon lo pida.",
        "ek_modulo.png",
        "official",
        "programa",
    ),
]

_EK_BY_ID = {row[0]: row for row in EK_ADDONS}

# El orden de pantalla vive aparte del catálogo para poder mover cosas sin tocar las tuplas.
EK_BLOQUE_ECOSISTEMA = "Addons de EspaKodi"

EK_BLOQUES = [
    (EK_BLOQUE_ECOSISTEMA, [
        "plugin.video.espatv",
        "plugin.video.espadaily",
        EK_OWN_ADDON_ID,
        "script.module.horus",
        "plugin.program.loiolink",
        "plugin.program.flowfavmanager",
        "plugin.video.streamninja",
        "plugin.video.topzilla",
        "plugin.program.loiolog",
        "plugin.program.ekgames",
        "plugin.program.gamesek",
    ]),
    ("Dependencias y motores", [
        "script.module.youtube.dl",
        "plugin.video.elementum",
        "inputstream.adaptive",
        "script.module.resolveurl",
    ]),
]


class ErrorInstalacion(Exception):
    """Fallo con un mensaje que se enseña tal cual al usuario."""


class _Cancelado(Exception):
    """Cancelar en un diálogo, o Kodi cerrándose. De ninguno de los dos hay nada que decir."""


def _log(msg, nivel=xbmc.LOGINFO):
    xbmc.log(f"[AtresDaily] EspaKodi addons: {msg}", nivel)


def _ek_bloques():
    """(título, entradas) de cada bloque. Lo que esté en el catálogo y en ningún bloque cae en uno
    final, para que añadir un addon y olvidarse de la lista no lo esconda."""
    colocados = set()
    bloques = []
    for titulo, ids in EK_BLOQUES:
        entradas = [_EK_BY_ID[i] for i in ids if i in _EK_BY_ID]
        colocados.update(row[0] for row in entradas)
        if entradas:
            bloques.append((titulo, entradas))
    sueltos = [row for row in EK_ADDONS if row[0] not in colocados]
    if sueltos:
        bloques.append(("Otros", sueltos))
    return bloques


def _ek_download_bytes(url, max_bytes, timeout=EK_HTTP_TIMEOUT_S):
    """El zip entero en memoria. Lanza ErrorInstalacion si no llega un zip de tamaño razonable."""
    demasiado = f"Tamaño sospechoso: más de {max_bytes // (1024 * 1024)} MB"
    r = requests.get(url, headers=_EK_UA, timeout=timeout, stream=True)
    try:
        if r.status_code != 200:
            raise ErrorInstalacion(f"Error HTTP {r.status_code}")
        # Un tamaño anunciado por encima del tope se rechaza sin leer nada, porque leerlo haría
        # esperar a que llegue todo, o a que venza el plazo, para tirarlo después
        largo = (r.headers.get("Content-Length") or "").strip()
        if largo.isdigit() and int(largo) > max_bytes:
            raise ErrorInstalacion(demasiado)
        datos = bytearray()
        for trozo in r.iter_content(64 * 1024):
            datos.extend(trozo)
            if len(datos) > max_bytes:
                raise ErrorInstalacion(demasiado)
    finally:
        r.close()
    # Que una respuesta cortada dé error depende de la versión de urllib3 (la 2 lo da, la 1.26 no),
    # y aquí tiene que darlo siempre
    if largo.isdigit() and len(datos) < int(largo):
        raise ErrorInstalacion(f"Descarga incompleta ({len(datos)} de {largo} bytes)")
    if len(datos) < 4 or datos[:2] != b"PK":
        raise ErrorInstalacion("El archivo descargado no es un ZIP válido")
    return bytes(datos)


def _ek_download_text(url, timeout=20):
    r = requests.get(url, headers=_EK_UA, timeout=timeout)
    r.raise_for_status()
    return r.text


def _ek_extract_zip(zip_path, addons_dir):
    # Un zip con rutas tipo ../../ saldría de addons/. Se compara con el separador al final porque,
    # sin él, una carpeta hermana como ../addons_x/ pasaría el filtro por empezar igual que addons.
    addons_dir_real = os.path.realpath(addons_dir)
    with zipfile.ZipFile(zip_path, "r") as zf:
        for entry in zf.namelist():
            resolved = os.path.realpath(os.path.join(addons_dir, entry))
            if resolved != addons_dir_real and not resolved.startswith(addons_dir_real + os.sep):
                raise ErrorInstalacion(f"ZIP contiene ruta sospechosa: {entry}")
        zf.extractall(addons_dir)


def _ek_mirar(condicion):
    # (lo que contesta Kodi, lo que tardó en contestar). Mientras Kodi instala, el hilo de su
    # interfaz está ocupado y la pregunta espera, y esa espera ya es una señal de la instalación.
    antes = time.monotonic()
    valor = bool(xbmc.getCondVisibility(condicion))
    return valor, time.monotonic() - antes


def _ek_addon_is_installed(addon_id):
    # Instalado y activado; System.HasAddon solo responde a lo primero, y un addon desactivado no
    # abre ni reproduce nada. Mejor que xbmcaddon.Addon(), que deja un "Unknown addon id" en el log
    # por cada addon que falta y es más lento.
    return xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})")


def _ek_addon_registrado(addon_id):
    # Lo que Kodi tiene registrado como instalado, activado o no
    return xbmc.getCondVisibility(f"System.HasAddon({addon_id})")


def _ek_addon_dir_present(addon_id):
    addon_dir = xbmcvfs.translatePath(f"special://home/addons/{addon_id}/")
    return os.path.isdir(addon_dir) and os.path.isfile(os.path.join(addon_dir, "addon.xml"))


def _ek_jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except ValueError:
        return {}


def _ek_enabled_ids():
    # Los addonid instalados y activados, en una sola llamada, para pintar el menú entero sin
    # preguntar addon por addon.
    resp = _ek_jsonrpc("Addons.GetAddons", {"enabled": True})
    addons = resp.get("result", {}).get("addons", []) if "result" in resp else []
    return {a.get("addonid") for a in addons}


def _ek_addon_available_in_repos(addon_id):
    # Lo que ofrecen los repositorios y no está instalado. Dice si el índice del repo ya está
    # listo; en Elementum, que salga aquí es que su proxy local ya contesta.
    resp = _ek_jsonrpc("Addons.GetAddons", {"installed": False, "properties": ["name"]})
    addons = resp.get("result", {}).get("addons", []) if "result" in resp else []
    return any(a.get("addonid") == addon_id for a in addons)


def _ek_enable_addon_jsonrpc(addon_id):
    resp = _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    return resp.get("result") == "OK"


def _ek_esperar(condicion, plazo, monitor, dp=None, paso=0.5):
    """True cuando se cumple condicion(), False si se acaba el plazo; _Cancelado si el usuario
    cancela dp o Kodi se cierra.

    waitForAbort() y no xbmc.sleep(), porque suelta el GIL de Kodi y vuelve al momento cuando Kodi
    se cierra, así que ninguna espera de este fichero retrasa el cierre."""
    limite = time.monotonic() + plazo
    while True:
        # Antes de la condición, para que cuente un Cancelar pulsado durante el último paso aunque
        # ya no quede nada que esperar.
        if dp is not None and dp.iscanceled():
            raise _Cancelado()
        if monitor.abortRequested():
            raise _Cancelado()
        if condicion():
            return True
        if time.monotonic() >= limite:
            return False
        if monitor.waitForAbort(paso):
            raise _Cancelado()


def _ek_activar(addon_id, monitor, plazo=EK_ACTIVAR_TIMEOUT_S, dp=None):
    """Enciende el addon sin preguntar nada. True solo si acaba encendido.

    Lo que cae en addons/ se registra apagado (CAddonDatabase::SyncInstalled), y el builtin
    EnableAddon pregunta sí/no cada vez, incluso con uno ya encendido. SetAddonEnabled contesta OK
    siempre que el addon esté instalado, se encienda o no (CAddonMgr::EnableAddon), así que se
    pide una vez y cuenta lo que diga Kodi después; repetirlo con un addon que Kodi rechaza solo
    apilaría sus avisos de error."""
    if not _ek_esperar(lambda: _ek_addon_registrado(addon_id), plazo, monitor, dp):
        return False
    if _ek_addon_is_installed(addon_id):
        return True
    _ek_enable_addon_jsonrpc(addon_id)
    return _ek_esperar(lambda: _ek_addon_is_installed(addon_id), 3, monitor, dp)


def _ek_try_recover_addon(addon_id, monitor):
    """Enciende un addon que ya está en el aparato. No hay que bajar nada, así que va primero."""
    if _ek_addon_registrado(addon_id):
        return _ek_activar(addon_id, monitor)
    if not _ek_addon_dir_present(addon_id):
        return False
    xbmc.executebuiltin("UpdateLocalAddons()")
    return _ek_activar(addon_id, monitor)


def reactivar(addon_id):
    """Enciende sin preguntar un addon que ya está en el aparato, esté o no en la tabla.
    True si queda encendido; False si no está instalado, Kodi no lo enciende o se cierra."""
    try:
        return _ek_addon_is_installed(addon_id) or _ek_try_recover_addon(addon_id, xbmc.Monitor())
    except _Cancelado:
        return False


def _ek_instalar_con_kodi(addon_id, monitor):
    """Le pasa la instalación a Kodi y vigila cómo va: 'instalado', 'no' (el usuario le dijo que
    no a Kodi) o 'fallo'. Antes hay que cerrar el DialogProgress propio, porque Kodi instala con
    esa misma ventana.

    Nunca executebuiltin(..., True). El builtin con espera retiene el GIL de Kodi y todo el
    Python de Kodi se para hasta que acaba la instalación, así que un repositorio que sirve
    sus zips desde Python, como el de Elementum, no podría servirlos."""
    xbmc.executebuiltin(f"InstallAddon({addon_id})")
    pregunta = instalando = abierta_antes = False
    quietas_desde = None
    limite = time.monotonic() + EK_INSTALACION_MAX_S

    while time.monotonic() < limite:
        if monitor.waitForAbort(0.25):
            raise _Cancelado()

        activo, t_activo = _ek_mirar(f"System.AddonIsEnabled({addon_id})")
        abierta, t_pregunta = _ek_mirar("Window.IsActive(yesnodialog)")
        abierto, t_progreso = _ek_mirar("Window.IsActive(progressdialog)")

        if activo:
            # Kodi lo enciende antes de cerrar su progreso, y el siguiente puede querer esa ventana
            _ek_esperar(lambda: not _ek_mirar("Window.IsActive(progressdialog)")[0], 5, monitor)
            return "instalado"

        # Una mirada lenta indica instalación solo si Kodi no está esperando a su pregunta. Con el
        # sí/no en pantalla aún no se instala nada, y la mirada que coincide con su cierre espera
        # solo por eso. En un aparato lento, contarlas convertiría un no en 'fallo' y el plan B lo
        # instalaría a espaldas de la respuesta.
        lenta = max(t_activo, t_pregunta, t_progreso) >= EK_MIRADA_LENTA_S
        pregunta = pregunta or abierta
        instalando = instalando or abierto or (lenta and not abierta and not abierta_antes)
        abierta_antes = abierta

        if abierta or abierto:
            quietas_desde = None
            continue
        if quietas_desde is None:
            quietas_desde = time.monotonic()
            continue
        if time.monotonic() - quietas_desde >= (EK_QUIETO_S if pregunta else EK_PREGUNTA_TIMEOUT_S):
            break

    return "no" if pregunta and not instalando else "fallo"


def _media_dir():
    return os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")


def _addon_fanart():
    return xbmcaddon.Addon().getAddonInfo("fanart")


def _ek_addon_icon(addon_id, fallback=None, installed=None):
    # Addon() solo se instancia si está instalado, para no llenar el log con los que faltan
    if installed is None:
        installed = _ek_addon_is_installed(addon_id)
    if installed:
        try:
            path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
            for name in ("icon.png", "icon.jpg"):
                p = os.path.join(path, name)
                if os.path.exists(p):
                    return p
        except RuntimeError as e:
            _log(f"icono de {addon_id}: {e}", xbmc.LOGDEBUG)
    return fallback or os.path.join(_media_dir(), "play_generic.png")


def _ek_get_repo_datadir(repo_id):
    repo_xml = xbmcvfs.translatePath(f"special://home/addons/{repo_id}/addon.xml")
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, "r", encoding="utf-8") as f:
            content = f.read()
    except OSError as e:
        _log(f"no se pudo leer datadir del repo {repo_id}: {e}", xbmc.LOGWARNING)
        return None
    m = re.search(r"<datadir[^>]*>\s*([^<\s]+)\s*</datadir>", content)
    if not m:
        return None
    url = m.group(1).strip()
    return url if url.endswith("/") else url + "/"


def _ek_find_addon_version_in_index(addons_xml_text, addon_id):
    for pattern in (
        r'<addon[^>]*\bid="' + re.escape(addon_id) + r'"[^>]*\bversion="([^"]+)"',
        r'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="' + re.escape(addon_id) + r'"',
    ):
        m = re.search(pattern, addons_xml_text)
        if m:
            return m.group(1)
    return None


def _ek_dependencias_listas(addons_xml, addon_id, version):
    """Si todo lo que necesita esa versión del addon ya está instalado.

    EnableAddon de Kodi solo escribe una línea en el log por una dependencia que falta
    (CAddonMgr::EnableAddon) y enciende el addon igual, así que sin esto el plan B dejaría un
    addon que dice "instalado" y falla al abrirlo. Un índice que no se puede leer no para nada,
    y se sigue como antes."""
    try:
        raiz = ET.fromstring(addons_xml)
    except ET.ParseError as e:
        _log(f"plan B ({addon_id}): no se pudo leer el índice: {e}")
        return True

    for addon in raiz.findall("addon"):
        if addon.get("id") != addon_id or addon.get("version") != version:
            continue
        for importa in addon.findall("requires/import"):
            necesita = importa.get("addon") or ""
            if not necesita or importa.get("optional") == "true":
                continue
            if not _ek_addon_registrado(necesita):
                _log(f"plan B ({addon_id}): falta {necesita}")
                return False
    return True


def _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name, monitor):
    # Plan B cuando InstallAddon() no cuaja. Se lee el datadir del repo ya instalado, se busca la
    # versión en su addons.xml y se baja el zip del addon directamente.
    zip_path = None
    try:
        datadir = _ek_get_repo_datadir(repo_id)
        if not datadir:
            _log(f"plan B ({friendly_name}): sin datadir de {repo_id}")
            return False
        # Los repos con proxy local (Elementum sirve en 127.0.0.1) no publican un datadir
        # descargable, así que si el proxy no contestó, bajar el zip a mano tampoco funcionaría.
        if "127.0.0.1" in datadir or "localhost" in datadir:
            _log(f"plan B ({friendly_name}): datadir local, no aplica")
            return False

        try:
            addons_xml = _ek_download_text(datadir + "addons.xml")
        except requests.RequestException as e:
            _log(f"plan B ({friendly_name}): no se pudo leer addons.xml: {e}")
            return False

        version = _ek_find_addon_version_in_index(addons_xml, addon_id)
        if not version or not _ek_dependencias_listas(addons_xml, addon_id, version):
            return False

        try:
            content = _ek_download_bytes(f"{datadir}{addon_id}/{addon_id}-{version}.zip",
                                         EK_MAX_ADDON_ZIP_BYTES, timeout=60)
        except (requests.RequestException, ErrorInstalacion) as e:
            _log(f"plan B ({friendly_name}): no se pudo bajar el zip: {e}")
            return False

        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{addon_id}-{version}.zip")
        with open(zip_path, "wb") as f:
            f.write(content)
        _ek_extract_zip(zip_path, xbmcvfs.translatePath("special://home/addons/"))

        xbmc.executebuiltin("UpdateLocalAddons()")
        if not _ek_activar(addon_id, monitor):
            # Kodi tiene sus motivos (un addon para un Kodi más nuevo, por ejemplo) y los dice él
            _log(f"plan B ({friendly_name}): Kodi no lo ha activado", xbmc.LOGERROR)
            return False
        return True

    except _Cancelado:
        raise
    except (OSError, zipfile.BadZipFile, ErrorInstalacion) as e:
        _log(f"plan B ({friendly_name}): {e}", xbmc.LOGERROR)
        return False

    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def _ek_notify_done(friendly_name):
    xbmcgui.Dialog().notification(HEADING, f"{friendly_name} instalado correctamente",
                                  xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")


def _ek_install_error(friendly_name, err):
    _log(f"error instalando {friendly_name}: {err}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok(
        "Error de instalación",
        f"No se pudo instalar {friendly_name} automáticamente.\n\nError: {err}\n\n"
        "Puede que necesites activar Orígenes desconocidos en Ajustes."
    )


def _ek_plan_b(addon_id, repo_id, friendly_name, monitor):
    """El plan B en su propia barra, con el zip del addon sacado del datadir de su repo."""
    bg = xbmcgui.DialogProgressBG()
    bg.create(HEADING, f"Instalación automática de {friendly_name} (alternativa)...")
    bg.update(50)
    try:
        return _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name, monitor)
    finally:
        bg.close()


def _ek_esperar_indice(addon_id, dp, monitor, plazo=EK_INDICE_TIMEOUT_S):
    """Si los repos ofrecen el addon, refrescando su índice solo si no lo hacen.

    La pregunta recorre todos los repos del aparato cada dos segundos y es rápida. Lo caro es
    refrescar, porque Kodi pregunta a cada repositorio y uno que contesta preguntando a GitHub,
    como el de Elementum, gasta parte de las sesenta llamadas por hora que GitHub da a una
    dirección antes de cortarla."""
    # Kodi nunca ofrece lo que ya está, encendido o no, así que uno que Kodi no quiso encender va
    # directo al plan B en vez de esperar a un índice que nunca lo nombrará.
    if _ek_addon_registrado(addon_id):
        return False

    def ofrecido():
        return _ek_addon_available_in_repos(addon_id)

    # Sin tiempo de espera, una sola mirada; un Cancelar ya pulsado cuenta
    if _ek_esperar(ofrecido, 0, monitor, dp):
        return True

    xbmc.executebuiltin("UpdateAddonRepos()")
    return _ek_esperar(ofrecido, plazo, monitor, dp, paso=2)


def _ek_pedir_a_kodi(addon_id, friendly_name, monitor):
    """Lo instala Kodi, preguntando él mismo: 'instalado', 'no' o 'fallo'."""
    xbmcgui.Dialog().notification(HEADING, f"Confirma la instalación de {friendly_name}",
                                  xbmcgui.NOTIFICATION_INFO, 4000)
    resultado = _ek_instalar_con_kodi(addon_id, monitor)
    if resultado == "instalado":
        _ek_notify_done(friendly_name)
    return resultado


# --- Modo repo (caso general) ----------------------------------------------------------------

def _ek_asegurar_repo(repo_id, repo_zip_url, dp, monitor):
    """Deja el repo instalado y encendido. Devuelve el zip que bajó, para que lo borre quien llama.

    Tres entradas: encendido ya, no hay nada que hacer; está pero apagado (o sin registrar), se
    enciende sin extraer nada encima; falta, se baja."""
    if _ek_addon_is_installed(repo_id):
        return None

    zip_path = None
    if not _ek_addon_dir_present(repo_id):
        dp.update(5, "Descargando repositorio...")
        content = _ek_download_bytes(repo_zip_url, EK_MAX_REPO_ZIP_BYTES)
        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{repo_id}.zip")
        with open(zip_path, "wb") as f:
            f.write(content)
        dp.update(20, "Extrayendo repositorio...")
        _ek_extract_zip(zip_path, xbmcvfs.translatePath("special://home/addons/"))

    dp.update(35, "Activando el repositorio...")
    xbmc.executebuiltin("UpdateLocalAddons()")
    if not _ek_activar(repo_id, monitor, EK_REPO_POLL_TIMEOUT_S, dp):
        raise ErrorInstalacion(f"Kodi no ha activado {repo_id} en {EK_REPO_POLL_TIMEOUT_S}s")
    return zip_path


def _ek_install_repo_and_addon(addon_id, repo_id, repo_zip_url, friendly_name):
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, f"Instalando {friendly_name}...")
    zip_path = None
    try:
        zip_path = _ek_asegurar_repo(repo_id, repo_zip_url, dp, monitor)

        dp.update(65, "Actualizando índice del repositorio...")
        ofrecido = _ek_esperar_indice(addon_id, dp, monitor)
        # Se cierra antes de pedírselo a Kodi, que instala con esta misma ventana
        dp.close()

        if ofrecido:
            resultado = _ek_pedir_a_kodi(addon_id, friendly_name, monitor)
            if resultado == "instalado":
                return True
            if resultado == "no":
                # Acaba de decirle que no a Kodi; no hay nada más que probar ni que decir
                return False

        # Kodi no ha preguntado, o lo intentó y no pudo. El addon puede estar ahí apagado, y si
        # no, su zip sigue donde lo publica su repo.
        if _ek_try_recover_addon(addon_id, monitor) or _ek_plan_b(addon_id, repo_id,
                                                                  friendly_name, monitor):
            _ek_notify_done(friendly_name)
            return True

        xbmcgui.Dialog().ok(
            HEADING,
            f"El repositorio de {friendly_name} se instaló, pero la instalación del addon no se completó.\n\n"
            f"Para terminarla a mano:\nAddons - Instalar desde repositorio - {friendly_name} - Instalar"
        )
        return False

    except _Cancelado:
        return False

    except Exception as e:  # red, disco o zip acaban en el mismo diálogo de error
        _ek_install_error(friendly_name, e)
        return False

    finally:
        dp.close()
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


# --- Modo oficial (el repositorio oficial de Kodi, siempre presente) --------------------------

def _ek_falta_su_repo(friendly_name, source_url):
    xbmcgui.Dialog().ok(
        HEADING,
        f"{friendly_name} se instala desde su propio repositorio, que ya trae la app EspaKodi.\n\n"
        f"En otro Kodi puedes añadirlo desde su página:\n{source_url}"
    )


def _ek_install_official(addon_id, repo_id, source_url, friendly_name):
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, f"Instalando {friendly_name}...")
    try:
        # No todos los "oficiales" vienen del repo de Kodi. ResolveURL viene del suyo, que viaja
        # dentro de la app EspaKodi.
        if repo_id != EK_REPO_OFICIAL and not _ek_addon_is_installed(repo_id):
            if not (_ek_addon_registrado(repo_id) or _ek_addon_dir_present(repo_id)):
                dp.close()
                _ek_falta_su_repo(friendly_name, source_url)
                return False
            dp.update(20, "Activando el repositorio...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            _ek_activar(repo_id, monitor, EK_REPO_POLL_TIMEOUT_S, dp)

        dp.update(40, "Actualizando índice del repositorio...")
        ofrecido = _ek_esperar_indice(addon_id, dp, monitor)
        dp.close()

        if ofrecido:
            resultado = _ek_pedir_a_kodi(addon_id, friendly_name, monitor)
            if resultado == "instalado":
                return True
            if resultado == "no":
                return False

        if _ek_try_recover_addon(addon_id, monitor):
            _ek_notify_done(friendly_name)
            return True

        donde = ("el repositorio oficial de Kodi" if repo_id == EK_REPO_OFICIAL
                 else f"su repositorio, {repo_id},")
        texto = (f"No se pudo instalar {friendly_name}.\n\nComprueba que {donde} está habilitado\n"
                 "(Addons - Mis addons - Repositorios) e inténtalo de nuevo.")
        if xbmc.getCondVisibility("System.Platform.Linux") \
                and not xbmc.getCondVisibility("System.Platform.Android"):
            texto += "\n\nEn Linux puede que venga del gestor de paquetes."
        xbmcgui.Dialog().ok(HEADING, texto)
        return False

    except _Cancelado:
        return False

    except Exception as e:  # red, disco o zip acaban en el mismo diálogo de error
        _ek_install_error(friendly_name, e)
        return False

    finally:
        dp.close()


# --- Modo proxy (un repositorio cuyo servicio publica los addons, como el de Elementum) -------

def _ek_install_proxy(addon_id, repo_id, repo_zip_url, friendly_name):
    monitor = xbmc.Monitor()
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, f"Preparando {friendly_name}...")
    zip_path = None
    try:
        # El repositorio en su sitio. Si el usuario ya lo tiene, no se toca, porque el suyo puede
        # ser más nuevo o llevar sus propios ajustes.
        if not _ek_addon_dir_present(repo_id):
            dp.update(10, f"Descargando el repositorio de {friendly_name}...")
            content = _ek_download_bytes(repo_zip_url, EK_MAX_REPO_ZIP_BYTES)
            zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), f"{repo_id}.zip")
            with open(zip_path, "wb") as f:
                f.write(content)
            dp.update(25, f"Instalando el repositorio de {friendly_name}...")
            _ek_extract_zip(zip_path, xbmcvfs.translatePath("special://home/addons/"))

        dp.update(40, "Activando el repositorio...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        if not _ek_activar(repo_id, monitor, EK_REPO_POLL_TIMEOUT_S, dp):
            raise ErrorInstalacion(f"Kodi no ha activado {repo_id} en {EK_REPO_POLL_TIMEOUT_S}s")

        if not _ek_addon_available_in_repos(addon_id):
            # Kodi registra un repositorio dejado en addons/ pero no arranca su servicio hasta que
            # se reinicia o lo ve activarse. Apagarlo y encenderlo lo arranca al momento y ahorra el
            # reinicio.
            _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": repo_id, "enabled": False})
            xbmc.sleep(1000)
            _ek_enable_addon_jsonrpc(repo_id)

        # Se espera a que el proxy publique el addon. Es un servicio que arranca a su ritmo, así
        # que InstallAddon() demasiado pronto no encuentra nada.
        dp.update(60, f"Esperando al repositorio de {friendly_name}...")
        proxy_ready = _ek_esperar_indice(addon_id, dp, monitor, EK_PROXY_POLL_TIMEOUT_S)
        dp.close()

        # Si el proxy no llegó a publicarlo, lo arregla reiniciar Kodi.
        if not proxy_ready:
            xbmcgui.Dialog().ok(
                HEADING,
                f"El repositorio de {friendly_name} se instaló, pero su servicio aún no responde.\n\n"
                f"Reinicia Kodi y vuelve a pulsar {friendly_name} para completar la instalación."
            )
            return False

        resultado = _ek_pedir_a_kodi(addon_id, friendly_name, monitor)
        if resultado == "instalado":
            return True
        if resultado == "no":
            return False

        if _ek_try_recover_addon(addon_id, monitor):
            _ek_notify_done(friendly_name)
            return True

        xbmcgui.Dialog().ok(
            HEADING,
            f"No se pudo completar la instalación de {friendly_name}.\n\n"
            f"Reinicia Kodi e inténtalo de nuevo, o instálalo desde\n"
            f"Addons - Instalar desde repositorio - {friendly_name}."
        )
        return False

    except _Cancelado:
        return False

    except Exception as e:  # red, disco o zip acaban en el mismo diálogo de error
        _ek_install_error(friendly_name, e)
        return False

    finally:
        dp.close()
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


# --- Despacho ---------------------------------------------------------------------------------

def _ek_dispatch_install(entry):
    addon_id, repo_id, zip_url, source, name, _plot, _icon, mode, _kind = entry
    if mode == "official":
        return _ek_install_official(addon_id, repo_id, source, name)
    if mode == "proxy":
        return _ek_install_proxy(addon_id, repo_id, zip_url, name)
    return _ek_install_repo_and_addon(addon_id, repo_id, zip_url, name)


def _ek_se_abre(addon_id):
    """Si tiene menú propio. Un módulo (youtube-dl, ResolveURL) no se puede abrir."""
    return addon_id != EK_OWN_ADDON_ID and (addon_id.startswith("plugin.") or addon_id in _EK_CON_MENU)


def _ek_open_installed(entry):
    addon_id, name = entry[0], entry[4]
    if addon_id == EK_OWN_ADDON_ID:
        xbmcgui.Dialog().notification(HEADING, "Ya estás en AtresDaily", xbmcgui.NOTIFICATION_INFO, 3000)
    elif _ek_se_abre(addon_id):
        xbmcgui.Dialog().notification(HEADING, f"Abriendo {name}...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({addon_id})")
    else:
        xbmcgui.Dialog().notification(HEADING, f"{name} ya está instalado",
                                      xbmcgui.NOTIFICATION_INFO, 3000)


def _ek_manual_instructions(entry):
    _addon_id, _repo_id, zip_url, source, name, _plot, _icon, mode, kind = entry

    if mode == "official":
        text = (
            f"[B]Cómo instalar {name} a mano[/B]\n\n"
            "Viene del repositorio oficial de Kodi, no hace falta añadir ninguna fuente.\n\n"
            "1. Addons - Instalar desde repositorio - Repositorio oficial de Kodi\n\n"
            f"2. Addons de {kind} - {name} - Instalar"
        )
    elif mode == "proxy":
        text = (
            f"[B]Cómo instalar {name} a mano[/B]\n\n"
            "Su repositorio se instala desde su zip, no hace falta añadir ninguna fuente.\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            f"2. Pulsa {name} en este menú. AtresDaily baja el repositorio de GitHub y espera a "
            "su servicio\n\n"
            f"3. Si el servicio no responde, reinicia Kodi y vuelve a pulsar {name}\n\n"
            f"4. Sin este menú, baja el zip de\n   {zip_url}\n   y ve a Addons - Instalar desde un "
            f"archivo zip. Después, Instalar desde repositorio - ElementumOrg repository - Addons "
            f"de {kind} - {name}"
        )
    else:
        text = (
            f"[B]Cómo instalar {name} a mano[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            f"2. Ajustes - Explorador de archivos - Añadir fuente:\n   {source}\n\n"
            f"3. Addons - Instalar desde un archivo zip - {name}\n   repository.xxx-x.x.x.zip\n\n"
            f"4. Instalar desde repositorio - {name} - Addons de {kind} - {name}"
        )

    xbmcgui.Dialog().textviewer(f"Instrucciones - {name}", text)


def _ek_elegir_instalacion(entry, preguntar):
    idx = xbmcgui.Dialog().select(
        f"{entry[4]} - instalación",
        ["Instalar automáticamente", "Ver instrucciones de instalación manual"]
    )
    if idx == 0:
        if not preguntar or xbmcgui.Dialog().yesno(
                HEADING, f"{entry[4]} no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_dispatch_install(entry)
    elif idx == 1:
        _ek_manual_instructions(entry)


def launch_by_id(addon_id):
    entry = _EK_BY_ID.get(addon_id)
    if not entry:
        _log(f"launch_by_id: addon desconocido {addon_id}")
        return

    if _ek_addon_is_installed(addon_id):
        _ek_open_installed(entry)
        return

    # Si está pero desactivado, basta con reactivarlo
    if _ek_try_recover_addon(addon_id, xbmc.Monitor()):
        xbmcgui.Dialog().notification(HEADING, f"{entry[4]} reactivado correctamente",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return

    _ek_elegir_instalacion(entry, preguntar=True)


def instalar_si_falta(addon_id):
    """Se asegura de que un addon del ecosistema está disponible. True si lo está.

    A diferencia de launch_by_id(), no abre el addon si ya está instalado. Aquí solo importa que
    exista, porque quien llama sigue luego con lo suyo."""
    entry = _EK_BY_ID.get(addon_id)
    if not entry:
        _log(f"instalar_si_falta: addon desconocido {addon_id}")
        return False

    if _ek_addon_is_installed(addon_id):
        return True

    # Puede estar instalado y desactivado, y reactivarlo es más rápido que reinstalarlo
    if _ek_try_recover_addon(addon_id, xbmc.Monitor()):
        xbmcgui.Dialog().notification(HEADING, f"{entry[4]} reactivado correctamente",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return True

    _ek_elegir_instalacion(entry, preguntar=False)
    return _ek_addon_is_installed(addon_id)


# --- Enlaces ----------------------------------------------------------------------------------

def abrir_url(url, titulo, pregunta, aviso_android):
    """Pregunta si abrir la URL en el navegador y la abre (en Android, con la app que la maneje)."""
    abrir = xbmcgui.Dialog().yesno(
        titulo,
        f"{pregunta}\n\n[B]{url}[/B]\n\n¿Abrir en el navegador?",
        nolabel="Cerrar",
        yeslabel="Abrir navegador",
    )
    if not abrir:
        return

    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
        xbmcgui.Dialog().notification(HEADING, aviso_android, xbmcgui.NOTIFICATION_INFO, 2000)
        return

    try:
        ok = webbrowser.open(url)
    except webbrowser.Error:
        ok = False
    if not ok:
        xbmcgui.Dialog().ok(HEADING, f"No se pudo abrir el navegador.\n\nAccede a mano a:\n{url}")


def open_web():
    abrir_url(
        "https://espatv.github.io",
        "EspaKodi en la web",
        "Todos los addons del ecosistema y la app, en un sitio:",
        "Abriendo la web...",
    )


def open_repo_unificado():
    abrir_url(
        "https://loiolo.io",
        "Repositorio Unificado",
        "Añade esta URL como fuente en Kodi e instala desde ella el repositorio de loiolink, "
        "que trae EspaTV, TopZilla, loiolog, Flow FavManager y loiolink:",
        "Abriendo repositorio...",
    )


_PLOT_PORTAL = (
    "El portal de EspaKodi, con todos los addons del ecosistema y la app EspaKodi lista "
    "para usar. Se abre en el navegador (espatv.github.io)."
)

_PLOT_REPO_UNIFICADO = (
    "Una sola fuente para instalar EspaTV, TopZilla, loiolog, Flow FavManager y loiolink. "
    "Con Orígenes desconocidos activado (Ajustes - Sistema - Add-ons), son tres pasos:\n\n"
    "1. Ajustes - Explorador de archivos - Añadir fuente: https://loiolo.io\n"
    "2. Add-ons - Instalar desde un archivo .zip - esa fuente - repository.loiolink-1.0.0.zip\n"
    "3. Add-ons - Instalar desde repositorio - loiolink Repository\n\n"
    "Los cinco están ahí dentro, cada uno en su apartado. Los demás addons de EspaKodi se "
    "instalan desde esta misma pantalla."
)

_PLOT_APP = (
    "La app EspaKodi es Kodi en español con los addons del ecosistema ya instalados, "
    "AtresDaily incluido.\n\n"
    "Aquí se descarga sin salir de Kodi la última versión del APK para Android, de 32 o de 64 "
    "bits, EspaKodi LaRoja, vestida de selección, y el instalador de EspaKodi para Windows.\n\n"
    "En el Telegram de EspaKodi (t.me/espakodi) hay más versiones, para LibreELEC, CoreELEC y una "
    "distribución Linux, y variantes de la app de Android."
)

_PLOT_SECCION = {
    EK_BLOQUE_ECOSISTEMA: "Los addons del ecosistema EspaKodi. Cada uno hace lo suyo y ninguno "
                          "depende de los demás; instala solo los que vayas a usar.",
    "Dependencias y motores": "Piezas que otros addons necesitan por debajo. No tienen menú "
                              "propio; se instalan y ya está.",
    "Otros": "Lo que hay en el catálogo y no encaja en las secciones de arriba.",
}


# --- Lista clásica ----------------------------------------------------------------------------

def _ek_url(**params):
    return sys.argv[0] + "?" + urllib.parse.urlencode(params)


def _ek_estado_texto(addon_id, installed):
    if installed:
        return "[COLOR lime]Instalado[/COLOR]"
    if _ek_addon_dir_present(addon_id):
        return "[COLOR orange]Deshabilitado[/COLOR]"
    return "[COLOR gray]No instalado[/COLOR]"


def render_menu(handle):
    """EspaKodi addons como lista de Kodi, para cuando no se usa la ventana propia."""
    media_dir = _media_dir()
    fanart = _addon_fanart()

    def fila(label, icono, plot, carpeta=False, **params):
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icono, "fanart": fanart})
        li.setInfo("video", {"plot": plot})
        xbmcplugin.addDirectoryItem(handle=handle, url=_ek_url(**params), listitem=li, isFolder=carpeta)

    fila("EspaKodi en la web", os.path.join(media_dir, "ek_web.png"), _PLOT_PORTAL,
         action="ek_open_web")
    fila("Repositorio Unificado", os.path.join(media_dir, "info_repo.png"), _PLOT_REPO_UNIFICADO,
         action="ek_open_repo")
    fila("Descargar EspaKodi (Android y Windows)", os.path.join(media_dir, "ek_apk.png"), _PLOT_APP,
         carpeta=True, action="espakodi_app_menu", clasico="1")

    enabled_ids = _ek_enabled_ids()
    for titulo, entradas in _ek_bloques():
        # Kodi no admite filas inertes en un listado de plugin, así que el separador es una fila
        # normal con la acción de todos los separadores.
        fila(f"[COLOR FFFF9A1F]————  {titulo}  ————[/COLOR]",
             os.path.join(media_dir, "transparent.png"), _PLOT_SECCION.get(titulo, ""),
             action="separador")
        for addon_id, _repo, _zip, _src, name, plot, fallback_icon, _mode, _kind in entradas:
            installed = addon_id in enabled_ids
            icon = _ek_addon_icon(addon_id, fallback=os.path.join(media_dir, fallback_icon),
                                  installed=installed)
            fila(f"{name} - {_ek_estado_texto(addon_id, installed)}", icon, plot,
                 action="ek_launch", addon_id=addon_id)

    xbmcplugin.endOfDirectory(handle)


# --- Ventana propia ---------------------------------------------------------------------------

def _ek_estado(addon_id, instalado):
    """(texto de la pastilla, color, pista) según cómo está el addon."""
    if instalado:
        if addon_id == EK_OWN_ADDON_ID:
            pista = "Es el que estás usando"
        elif _ek_se_abre(addon_id):
            pista = "Pulsa para abrirlo"
        else:
            pista = "Lo usan otros addons por debajo"
        return list_screen.color("Instalado", list_screen.TINTA_VERDE), "on", pista

    if _ek_addon_dir_present(addon_id):
        return (list_screen.color("Deshabilitado", list_screen.NARANJA), "gris",
                "Está puesto pero apagado")

    return list_screen.color("No instalado", list_screen.GRIS), "gris", "Pulsa para instalarlo"


def _ek_filas():
    media_dir = _media_dir()
    enabled_ids = _ek_enabled_ids()

    filas = [
        list_screen.Fila(clave="web", titulo="EspaKodi en la web", pista="espatv.github.io",
                         icono=os.path.join(media_dir, "ek_web.png"), plot=_PLOT_PORTAL),
        list_screen.Fila(clave="repo", titulo="Repositorio Unificado",
                         pista="Cinco addons desde una sola fuente",
                         icono=os.path.join(media_dir, "info_repo.png"), plot=_PLOT_REPO_UNIFICADO),
        list_screen.Fila(clave="app", titulo="Descargar EspaKodi",
                         pista="EspaKodi, LaRoja y Windows",
                         icono=os.path.join(media_dir, "ek_apk.png"), plot=_PLOT_APP),
    ]

    for titulo, entradas in _ek_bloques():
        filas.append(list_screen.Fila(clave="", titulo=titulo, sep=True,
                                      plot=_PLOT_SECCION.get(titulo, "")))
        for addon_id, _repo, _zip, _src, name, plot, icono, _modo, _tipo in entradas:
            instalado = addon_id in enabled_ids
            etiqueta, tinta, pista = _ek_estado(addon_id, instalado)
            filas.append(list_screen.Fila(
                clave=addon_id, titulo=name, pista=pista,
                icono=_ek_addon_icon(addon_id, fallback=os.path.join(media_dir, icono),
                                     installed=instalado),
                pastilla=(etiqueta, tinta), plot=plot))

    return filas


def mostrar_ventana():
    """EspaKodi addons en ventana propia. False si no se pudo abrir."""
    abrir_luego = []

    def pulsar(fila):
        if fila.clave == "web":
            open_web()
        elif fila.clave == "repo":
            open_repo_unificado()
        elif fila.clave == "app":
            # Solo cabe una ventana propia a la vez, así que esta se cierra y la otra se abre al
            # salir de doModal()
            abrir_luego.append("app")
            return "cerrar"
        elif not _ek_addon_is_installed(fila.clave):
            instalar_si_falta(fila.clave)
        elif _ek_se_abre(fila.clave):
            # Un addon lanzado por debajo de una ventana modal se queda detrás de ella. Se cierra
            # la ventana y se abre al salir de doModal().
            abrir_luego.append(fila.clave)
            return "cerrar"
        else:
            # Un módulo no tiene pantalla propia; cerrar la ventana por él sería una sorpresa
            _ek_open_installed(_EK_BY_ID[fila.clave])
        return None

    abierta = list_screen.mostrar(
        titulo=list_screen.titulo_ventana("EspaKodi Addons"),
        subtitulo="Todo el ecosistema",
        hacer_filas=_ek_filas,
        al_pulsar=pulsar,
        botones=(("EspaKodi en la web", open_web),
                 ("Repositorio", open_repo_unificado)),
        estado="Pulsa un addon para abrirlo, o para instalarlo si te falta")

    for clave in abrir_luego:
        if clave == "app":
            import espakodi_app  # aquí y no arriba porque espakodi_app importa este módulo
            list_screen.abrir_o_lista("espakodi_app_menu", espakodi_app.mostrar_ventana)
        else:
            _ek_open_installed(_EK_BY_ID[clave])

    return abierta
