# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""
EPG en texto, la parrilla de programación.
"""
import gzip
import hashlib
import io
import json
import os
import re
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime, timedelta, timezone

import requests

import _user_agents
import core_settings
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[AtresDaily-EPG]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "epg_texto_cache.json")
_CACHE_TTL       = 7200  # 2 horas
_TIMEOUT         = 30
_EPG_URL         = "https://epgshare01.online/epgshare01/epg_ripper_ES1.xml.gz"
_EPG_URL_FALLBACK = "https://raw.githubusercontent.com/davidmuma/EPG_dobleM/master/guiatv_sincolor.xml.gz"
# Tope de lo que se descomprime, por si una fuente mandara algo desmedido. Las guías
# completas rondan los 50 MB.
_MAX_XML = 200 * 1024 * 1024
# Y de lo que se descarga, porque la guía de una lista de canales la pone quien hizo la lista.
_MAX_DESCARGA = 100 * 1024 * 1024
# Guías propias de las listas de canales (su url-tvg), una por dirección. Se renuevan como las
# listas y se borran las que llevan días sin usarse. Solo sirven para lo que se emite ahora, así que
# se guardan las horas que dura la copia y poco más, porque la de un servidor Xtream trae miles de
# canales.
_GUIAS_LISTAS = os.path.join(_PROFILE, "iptv_epg")
_GUIA_LISTA_TTL = 6 * 3600
_GUIA_LISTA_HORAS = 8
_GUIA_LISTA_OLVIDO = 3 * 86400
# La guía de un servidor Xtream lleva el usuario y la contraseña en la dirección.
_CREDENCIALES_RE = re.compile(r"((?:username|password|pass|token|key)=)[^&\s]+", re.I)


class DescargaCancelada(Exception):
    """Quien descargaba la guía la ha cancelado."""


class GuiaDemasiadoGrande(ValueError):
    """La guía pasa de _MAX_DESCARGA."""


def _sin_credenciales(texto):
    return _CREDENCIALES_RE.sub(r"\1***", str(texto))
# Canales nacionales con programa en emisión que hacen falta para quedarse con una fuente.
# Una guía atrasada solo trae días pasados y no llega a ninguno.
_MIN_NACIONALES = 5
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_GRUPOS_CH = {
    "Nacionales TDT": {
        "La1.es", "La2.es", "Antena.3.es", "Telecinco.es", "Cuatro.es",
        "laSexta.es", "Neox.es", "Nova.es", "FDF.es", "Energy.es",
        "Boing.es", "Divinity.es", "Mega.es", "Atreseries.es",
        "24H.es", "Clan.es", "Teledeporte.es",
        "BeMad.es", "Be Mad.es", "DMAX.es", "Ten.es", "Paramount.es",
        "RealMadrid.es", "GOL.es", "GolPlay.es",
    },
    "Autonómicos": {
        "TV3.es", "324.es", "33.es", "Esport3.es", "SuperC.es",
        "ETB1.es", "ETB2.es", "ETB3.es", "ETB4.es",
        "TVG.gal", "TVG2.gal", "TVG.es", "TVG2.es",
        "CanalSur.es", "CanalSur2.es", "Canal Sur.es", "Canal Sur 2.es",
        "Telemadrid.es", "LaOtra.es", "La Otra.es", "AragonTV.es",
        "Aragon TV.es", "A3-9.es", "Apunt.es", "IB3.es", "TPA.es", "CMM.es",
        "7NN.es", "LaRioja.es",
        "Andalucia TV.es", "7TV Andalucia.es", "8 Madrid.es",
        "13 TV.es", "7 Region de Murcia.es", "Beteve.es", "Castilla La Mancha Media.es",
    },
    "Temáticos": {
        "Disney.es", "Disney Channel.es", "Disney Junior.es",
        "Nickelodeon.es", "Discovery.es", "Discovery Channel.es",
        "NatGeo.es", "Nat Geo.es", "AMC.es", "AMC Break.es", "AMC Crime.es",
        "History.es", "AXN.es", "AXN Movies.es", "Fox.es", "Calle 13.es", "Calle13.es",
        "TCM.es", "Syfy.es", "MGM.es", "Cosmo.es",
        "SundanceTV.es", "Sundance TV.es",
        "BBC Earth.es", "BBC Food.es", "BBC News.es",
        "Baby TV.es", "BeIN Sports.es", "Bloomberg.es",
    },
}

_ATRES_ORDER = ["Antena.3.es", "laSexta.es", "Neox.es", "Nova.es", "Mega.es", "Atreseries.es"]

_ACCENT_MAP = str.maketrans("áéíóúñÁÉÍÓÚÑàèìòùÀÈÌÒÙäëïöüÄËÏÖÜâêîôûÂÊÎÔÛ",
                             "aeiounAEIOUNaeiouAEIOUaeiouAEIOUaeiouAEIOU")


def _normalize_ch_id(ch_id):
    core = ch_id.rsplit(".", 1)[0]
    core = core.lower().replace(".", "").replace(" ", "").translate(_ACCENT_MAP)
    # Una fuente llama "Antena 3 HD" al que la otra llama "Antena.3.es".
    return core[:-2] if core.endswith("hd") and len(core) > 2 else core


_ID_A_GRUPO = {}
for _g, _ids in _GRUPOS_CH.items():
    for _cid in _ids:
        _ID_A_GRUPO[_normalize_ch_id(_cid)] = _g


def _grupo_de(ch_id):
    return _ID_A_GRUPO.get(_normalize_ch_id(ch_id), "Otros")


_ORDEN_GRUPOS = ["Nacionales TDT", "Autonómicos", "Temáticos", "Otros"]
_COLOR_GRUPOS = {
    "Nacionales TDT": "gold",
    "Autonómicos":    "deepskyblue",
    "Temáticos":      "plum",
    "Otros":          "grey",
}


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _utc_to_local(utc_dt):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)


def _parse_epg_dt(s):
    # No usamos strptime porque el bug #7980 lo rompe en threads de Kodi.
    if not s:
        return None
    s = s[:14] if len(s) >= 14 else (s[:12] + "00" if len(s) >= 12 else None)
    if not s or len(s) != 14 or not s.isdigit():
        return None
    try:
        return datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]),
                        int(s[8:10]), int(s[10:12]), int(s[12:14]))
    except (ValueError, TypeError):
        return None


_XMLTV_TS_RE = re.compile(r'^\s*(\d{12}(?:\d{2})?)\s*(?:([+-])(\d{2}):?(\d{2}))?')


def _to_utc14(s):
    """Sello XMLTV ('20260923210000 +0200') a 14 dígitos en UTC, o None si no se entiende.

    Las fuentes publican en hora española (+0200/+0100); tomar los 14 primeros dígitos como
    UTC desplazaría la guía 1-2 horas. Sin desfase se toma como UTC, como dice el formato XMLTV.
    """
    m = _XMLTV_TS_RE.match(s or "")
    if not m:
        return None
    dt = _parse_epg_dt(m.group(1))
    if dt is None:
        return None
    if m.group(2):
        delta = timedelta(hours=int(m.group(3)), minutes=int(m.group(4)))
        dt = dt - delta if m.group(2) == "+" else dt + delta
    return dt.strftime("%Y%m%d%H%M%S")


def _fmt_time(ts_str):
    if ts_str is None:
        return ""
    utc_dt = _parse_epg_dt(ts_str)
    if utc_dt is None:
        return ts_str[:4] if ts_str else ""
    local_dt = _utc_to_local(utc_dt)
    return "{0:02d}:{1:02d}".format(local_dt.hour, local_dt.minute)


# Versión 2, con start/stop en UTC real. Las cachés sin versión llevan la hora local como
# si fuera UTC y se descartan.
_CACHE_VERSION = 2


def _load_cache():
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if obj.get("v") == _CACHE_VERSION and time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("channels", {}), obj.get("programmes", {})
    except (OSError, ValueError, AttributeError):
        pass
    return None, None


def _save_cache(channels, programmes, fuente):
    # Atómico, con tmp por proceso e hilo, porque la leen el menú EPG y los canales en
    # directo a veces a la vez, y un corte a mitad no puede dejarla rota.
    ok = core_settings.atomic_write_json(
        _CACHE_FILE, {"v": _CACHE_VERSION, "ts": time.time(), "fuente": fuente, "channels": channels,
                      "programmes": programmes}, ensure_ascii=False)
    if not ok:
        xbmc.log("{0} No se pudo guardar la caché".format(_LOG), xbmc.LOGWARNING)


def _fuente_anterior():
    """Fuente de la última guía guardada, aunque haya caducado."""
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("fuente")
    except (OSError, ValueError, AttributeError):
        return None


def _download_epg(url, progreso=None):
    """La guía tal como la sirve la fuente, comprimida o no. progreso(leído, total) se llama con
    cada trozo (total es 0 si el servidor no lo dice) y, si devuelve False, la descarga se cancela."""
    headers = {"User-Agent": _user_agents.UA_DESKTOP, "Accept-Encoding": "gzip"}
    with requests.get(url, headers=headers, timeout=_TIMEOUT, stream=True) as resp:
        resp.raise_for_status()
        try:
            total = int(resp.headers.get("Content-Length") or 0)
        except ValueError:
            total = 0
        datos = bytearray()
        for trozo in resp.iter_content(65536):
            datos += trozo
            if len(datos) > _MAX_DESCARGA:
                raise GuiaDemasiadoGrande(f"la guía pasa de {_MAX_DESCARGA // (1024 * 1024)} MB")
            if progreso is not None and not progreso(len(datos), total):
                raise DescargaCancelada()
        return bytes(datos)


# Lo que puede salir mal al bajar y leer una fuente; con cualquiera se prueba la siguiente.
_FALLOS_FUENTE = (requests.RequestException, OSError, EOFError, zlib.error, ET.ParseError, ValueError)


class _LectorConTope:
    """Fichero que da ValueError al pasar de `tope` bytes leídos."""

    def __init__(self, f, tope):
        self._f = f
        self._quedan = tope

    def read(self, n=-1):
        datos = self._f.read(n)
        self._quedan -= len(datos)
        if self._quedan < 0:
            raise ValueError("la guía descomprimida pasa del tope")
        return datos


def _parse_epg(datos, horas=26):
    """(canales, programas) de una guía XMLTV, comprimida con gzip o no, con lo que se emite desde
    2 h antes hasta `horas` después. Se lee por partes, porque una guía completa ronda los 50 MB."""
    channels = {}
    programmes = {}
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    cutoff_start = now_utc - timedelta(hours=2)
    cutoff_end = now_utc + timedelta(hours=horas)
    # Una guía trae la semana entera: lo que cae a más de un día de la ventana se descarta
    # por la fecha del sello, sin más cuentas. El día de margen cubre cualquier desfase horario.
    dia_min = (cutoff_start - timedelta(days=1)).strftime("%Y%m%d")
    dia_max = (cutoff_end + timedelta(days=1)).strftime("%Y%m%d")

    crudo = io.BytesIO(datos)
    with (gzip.GzipFile(fileobj=crudo) if datos[:2] == b"\x1f\x8b" else crudo) as fz:
        eventos = ET.iterparse(_LectorConTope(fz, _MAX_XML), events=("start", "end"))
        _, raiz = next(eventos)
        for evento, el in eventos:
            if evento != "end" or el.tag not in ("channel", "programme"):
                continue
            if el.tag == "channel":
                ch_id = el.get("id", "")
                name_el = el.find("display-name")
                ch_name = (name_el.text or ch_id) if name_el is not None else ch_id
                icon_el = el.find("icon")
                ch_icon = icon_el.get("src", "") if icon_el is not None else ""
                if ch_id:
                    channels[ch_id] = {"name": ch_name, "icon": ch_icon}
            else:
                ch_id = el.get("channel", "")
                inicio = el.get("start", "")
                fin = el.get("stop", "")
                lejos = inicio.lstrip()[:8] > dia_max or (fin and fin.lstrip()[:8] < dia_min)
                start_s = None if lejos else _to_utc14(inicio)
                stop_s = (_to_utc14(fin) or "") if start_s else ""
                if ch_id and start_s:
                    start_dt = _parse_epg_dt(start_s)
                    # Por el final, para no perder lo que empezó hace rato y sigue en emisión.
                    fin_dt = _parse_epg_dt(stop_s) if stop_s else start_dt
                    if fin_dt >= cutoff_start and start_dt <= cutoff_end:
                        title_el = el.find("title")
                        desc_el = el.find("desc")
                        cat_el = el.find("category")
                        programmes.setdefault(ch_id, []).append({
                            "start": start_s,
                            "stop": stop_s,
                            "title": title_el.text if title_el is not None and title_el.text else "Sin título",
                            "desc": desc_el.text if desc_el is not None and desc_el.text else "",
                            "cat": cat_el.text if cat_el is not None and cat_el.text else "",
                        })
            raiz.clear()

    for progs in programmes.values():
        progs.sort(key=lambda x: x["start"])
    return channels, programmes


def _nacionales_en_emision(programmes):
    """Cuántos canales nacionales tienen un programa en emisión ahora."""
    ahora = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    return sum(1 for ch_id, progs in programmes.items()
               if _grupo_de(ch_id) == "Nacionales TDT"
               and any(p["start"] <= ahora and (not p["stop"] or ahora < p["stop"]) for p in progs))


def _fetch_epg(progreso=None):
    channels, programmes = _load_cache()
    if channels is not None:
        return channels, programmes

    # La primera fuente que tenga programas de ahora en los nacionales; si ninguna llega,
    # la que más tenga. Una fuente puede responder bien y traer solo días pasados.
    # La que sirvió la última vez va primero: con la principal atrasada, así no se baja
    # y se lee entera cada dos horas para nada. "Actualizar parrilla" borra la caché y
    # vuelve a empezar por la principal.
    fuentes = [_EPG_URL, _EPG_URL_FALLBACK]
    anterior = _fuente_anterior()
    if anterior in fuentes:
        fuentes.remove(anterior)
        fuentes.insert(0, anterior)
    mejor = None
    for url in fuentes:
        try:
            xbmc.log(f"{_LOG} Descargando EPG desde {url}...", xbmc.LOGINFO)
            chs, progs = _parse_epg(_download_epg(url, progreso))
        except _FALLOS_FUENTE as e:
            xbmc.log(f"{_LOG} Fuente EPG {url} falló: {e}", xbmc.LOGWARNING)
            continue
        en_emision = _nacionales_en_emision(progs)
        if mejor is None or en_emision > mejor[2]:
            mejor = (chs, progs, en_emision, url)
        if en_emision >= _MIN_NACIONALES:
            break
        xbmc.log(f"{_LOG} {url}: {en_emision} canales nacionales con programa ahora", xbmc.LOGINFO)

    if mejor is None:
        xbmc.log(f"{_LOG} Todas las fuentes EPG fallaron; se devuelve vacío", xbmc.LOGERROR)
        return {}, {}

    channels, programmes, _, fuente = mejor
    _save_cache(channels, programmes, fuente)
    return channels, programmes


def epg_texto_menu():
    h = int(sys.argv[1])
    try:
        xbmcgui.Dialog().notification("EPG", "Cargando parrilla...", xbmcgui.NOTIFICATION_INFO, 1500)
        channels, _ = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error: {1}".format(_LOG, e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error cargando la EPG. Comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_epg_texto.png")

    conteo = {g: 0 for g in _ORDEN_GRUPOS}
    for ch_id in channels:
        conteo[_grupo_de(ch_id)] += 1

    for grupo in _ORDEN_GRUPOS:
        color = _COLOR_GRUPOS[grupo]
        n = conteo[grupo]
        label = "[B][COLOR {0}]{1}[/COLOR][/B]  [COLOR grey]({2} canales)[/COLOR]".format(color, grupo, n)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Ver canales de la categoria {0}.".format(grupo)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_grupo", grupo=grupo),
            listitem=li,
            isFolder=True,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar parrilla ][/COLOR]")
    li_r.setArt({"icon": _icon("adv_refrescar.png")})
    li_r.setInfo("video", {"plot": "Recarga la parrilla EPG."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def epg_texto_atres():
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, "Atresplayer - Parrilla")
    try:
        xbmcgui.Dialog().notification("EPG", "Cargando parrilla...", xbmcgui.NOTIFICATION_INFO, 1500)
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error atres: {1}".format(_LOG, e), xbmc.LOGERROR)
        li = xbmcgui.ListItem(label="[COLOR red]Error cargando la EPG. Comprueba la red[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    icon = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    # Cada fuente nombra los canales a su manera ("Antena.3.es", "Antena 3 HD").
    por_nombre = {}
    for cid in channels:
        por_nombre.setdefault(_normalize_ch_id(cid), cid)
    ordered = []
    for buscado in _ATRES_ORDER:
        cid = buscado if buscado in channels else por_nombre.get(_normalize_ch_id(buscado))
        if cid and cid not in ordered:
            ordered.append(cid)

    if not ordered:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin datos EPG para canales Atresplayer[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for ch_id in ordered:
        ch_info = channels[ch_id]
        ch_name = ch_info["name"]
        ch_icon = ch_info.get("icon") or icon
        progs = programmes.get(ch_id, [])
        n_progs = len(progs)

        current = None
        for p in progs:
            s = _parse_epg_dt(p["start"])
            if s is None:
                continue
            e = _parse_epg_dt(p["stop"]) if p["stop"] else s + timedelta(hours=1)
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                current = p
                break

        now_label = ("  [COLOR deepskyblue]{0}[/COLOR]".format(current["title"]) if current else "")
        label = "[B]{0}[/B]{1}  [COLOR grey]({2} prog.)[/COLOR]".format(ch_name, now_label, n_progs)
        plot = "{0}\n{1} programas en parrilla".format(ch_name, n_progs)
        if current:
            plot += "\nAhora: {0}".format(current["title"])
            if current.get("desc"):
                plot += "\n{0}".format(current["desc"])

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ch_icon, "thumb": ch_icon})
        li.setInfo("video", {"title": ch_name, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_canal", ch_id=ch_id, ch_name=ch_name),
            listitem=li,
            isFolder=True,
        )

    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar parrilla ][/COLOR]")
    li_r.setArt({"icon": _icon("adv_refrescar.png")})
    li_r.setInfo("video", {"plot": "Recarga la parrilla EPG."})
    li_r.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="epg_texto_refresh"), listitem=li_r, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def epg_texto_grupo(grupo_nombre):
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, grupo_nombre)
    try:
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error grupo: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    icon = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    ch_with_now = []
    ch_others   = []
    for ch_id, ch_info in sorted(channels.items(), key=lambda x: x[1]["name"]):
        if _grupo_de(ch_id) != grupo_nombre:
            continue
        progs = programmes.get(ch_id, [])
        current = None
        for p in progs:
            s = _parse_epg_dt(p["start"])
            if s is None:
                continue
            e = _parse_epg_dt(p["stop"]) if p["stop"] else s + timedelta(hours=1)
            if e is None:
                e = s + timedelta(hours=1)
            if s <= now_utc < e:
                current = p
                break
        if current:
            ch_with_now.append((ch_id, ch_info, current))
        else:
            ch_others.append((ch_id, ch_info, None))

    if not ch_with_now and not ch_others:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin canales en esta categoria[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for ch_id, ch_info, current in (ch_with_now + ch_others):
        ch_name = ch_info["name"]
        ch_icon = ch_info.get("icon") or icon
        n_progs = len(programmes.get(ch_id, []))

        now_label = ("  [COLOR deepskyblue]{0}[/COLOR]".format(current["title"])
                     if current else "")
        label = "[B]{0}[/B]{1}  [COLOR grey]({2} prog.)[/COLOR]".format(ch_name, now_label, n_progs)
        plot  = "{0}\n{1} programas en parrilla".format(ch_name, n_progs)
        if current:
            plot += "\nAhora: {0}".format(current["title"])
            if current.get("desc"):
                plot += "\n{0}".format(current["desc"])

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": ch_icon, "thumb": ch_icon})
        li.setInfo("video", {"title": ch_name, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_canal", ch_id=ch_id, ch_name=ch_name),
            listitem=li,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def epg_texto_canal(ch_id, ch_name):
    h = int(sys.argv[1])
    if ch_name:
        xbmcplugin.setPluginCategory(h, ch_name)
    try:
        channels, programmes = _fetch_epg()
    except Exception as e:
        xbmc.log("{0} Error canal: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    progs = programmes.get(ch_id)
    if progs is None and ch_id:
        # Si la guía se ha renovado con la otra fuente desde que se listó, el canal se llama distinto.
        clave = _normalize_ch_id(ch_id)
        progs = next((p for c, p in programmes.items() if _normalize_ch_id(c) == clave), None)
    icon  = _icon("cat_epg_texto.png")
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

    if not progs:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin programación disponible[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    prev_date = None
    for p in progs:
        start_utc = _parse_epg_dt(p["start"])
        if start_utc is None:
            continue
        is_now = False
        if p["stop"]:
            stop_utc = _parse_epg_dt(p["stop"])
            if stop_utc is not None:
                is_now = start_utc <= now_utc < stop_utc

        local_start = _utc_to_local(start_utc)
        date_str = "{0:02d}/{1:02d}".format(local_start.day, local_start.month)

        if date_str != prev_date:
            prev_date = date_str
            sep = xbmcgui.ListItem(label=f"[COLOR gold]──  {date_str}  ──[/COLOR]")
            sep.setArt({"icon": _icon("seccion.png")})
            sep.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="separador"), listitem=sep, isFolder=False)

        hora   = _fmt_time(p["start"])
        titulo = p["title"]
        desc   = p.get("desc", "")
        cat    = p.get("cat", "")

        if is_now:
            color = "gold"
            marca = "  [COLOR gold]▶ EN CURSO[/COLOR]"
        else:
            color = "white"
            marca = ""

        label = "[B][COLOR {0}]{1}[/COLOR][/B]  {2}{3}".format(color, hora, titulo, marca)
        plot  = "{0}  {1}\n{2}".format(hora, titulo, desc)
        if cat:
            plot += "\n[{0}]".format(cat)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": titulo, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="epg_texto_programa", title=titulo, plot=plot),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def epg_texto_programa(title, plot):
    xbmcgui.Dialog().textviewer(title, plot)


def epg_texto_refresh():
    try:
        os.remove(_CACHE_FILE)
    except OSError:
        pass
    try:
        channels, _ = _fetch_epg()
        if not channels:
            xbmcgui.Dialog().notification(
                "EPG", "Sin datos disponibles. Reintenta en unos minutos.",
                xbmcgui.NOTIFICATION_WARNING, 3000
            )
    except Exception as e:
        xbmc.log("{0} Refresh falló: {1}".format(_LOG, e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            "EPG", "Error al actualizar (fuente caída)",
            xbmcgui.NOTIFICATION_ERROR, 3000
        )
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="epg_texto_menu")))


_NAME_SUFFIX_RE = re.compile(r'\s+(?:hd|fhd|uhd|sd|4k|1080p?|720p?)$', re.I)


def _norm_name(name):
    base = _NAME_SUFFIX_RE.sub('', str(name or '').strip())
    return base.lower().replace(' ', '').replace('.', '').translate(_ACCENT_MAP)


def _ruta_guia_lista(url):
    return os.path.join(_GUIAS_LISTAS, hashlib.sha1(url.encode("utf-8")).hexdigest()[:16] + ".json")


def _olvidar_guias_viejas():
    limite = time.time() - _GUIA_LISTA_OLVIDO
    try:
        nombres = os.listdir(_GUIAS_LISTAS)
    except OSError:
        return
    for nombre in nombres:
        ruta = os.path.join(_GUIAS_LISTAS, nombre)
        try:
            if os.path.getmtime(ruta) < limite:
                os.remove(ruta)
        except OSError as e:
            xbmc.log(f"{_LOG} No se pudo borrar {ruta}: {e}", xbmc.LOGWARNING)


def _guia_lista(url, download, progreso=None):
    """(canales, programas) de la guía propia de una lista de canales, o (None, None) si no hay
    copia fresca y no se pide descargarla."""
    ruta = _ruta_guia_lista(url)
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if obj.get("v") == _CACHE_VERSION and 0 <= time.time() - obj.get("ts", 0) < _GUIA_LISTA_TTL:
            return obj.get("channels", {}), obj.get("programmes", {})
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    if not download:
        return None, None
    xbmc.log(f"{_LOG} Descargando la guía de una lista desde {_sin_credenciales(url)}", xbmc.LOGINFO)
    channels, programmes = _parse_epg(_download_epg(url, progreso), horas=_GUIA_LISTA_HORAS)
    os.makedirs(_GUIAS_LISTAS, exist_ok=True)
    _olvidar_guias_viejas()
    # Sin la dirección, que puede llevar las credenciales de un servidor Xtream.
    if not core_settings.atomic_write_json(
            ruta, {"v": _CACHE_VERSION, "ts": time.time(), "channels": channels,
                   "programmes": programmes}, ensure_ascii=False):
        xbmc.log(f"{_LOG} No se pudo guardar la guía de una lista", xbmc.LOGWARNING)
    return channels, programmes


def now_playing(keys, download=False, url='', progreso=None):
    """{posición: (título, desde, hasta, descripción)} de lo que se emite ahora en cada canal
    de keys, una lista de (tvg_id, nombre). Empareja por tvg-id y, si no, por nombre.

    Con url, la guía propia de una lista de canales; sin ella, la general, que es de canales
    españoles. Con download=False solo mira la caché fresca y devuelve None si no la hay, porque
    abrir una lista de canales no debe descargar por sorpresa una guía de decenas de MB. Al
    descargar, progreso es el de _download_epg; si se cancela sale DescargaCancelada, y si la guía
    de la lista pasa del tope, GuiaDemasiadoGrande."""
    try:
        if url:
            channels, programmes = _guia_lista(url, download, progreso)
        else:
            channels, programmes = _fetch_epg(progreso) if download else _load_cache()
    except GuiaDemasiadoGrande:
        raise
    except _FALLOS_FUENTE + (AttributeError, TypeError) as e:
        xbmc.log(f"{_LOG} now_playing: {_sin_credenciales(e)}", xbmc.LOGWARNING)
        return None
    if not channels and not programmes:
        return None
    return {pos: (prog.get("title") or "", _fmt_time(prog.get("start")), _fmt_time(prog.get("stop")),
                  prog.get("desc") or "")
            for pos, prog in _en_emision(keys, channels, programmes).items()}


def _en_emision(keys, channels, programmes):
    """{posición: programa} de lo que se emite ahora en cada canal de keys ((tvg_id, nombre)),
    emparejando por tvg-id y, si no, por nombre."""
    by_key = {}
    for ch_id, info in (channels or {}).items():
        by_key.setdefault(_normalize_ch_id(ch_id), ch_id)
        name = info.get("name") if isinstance(info, dict) else ""
        if name:
            by_key.setdefault(_norm_name(name), ch_id)
    # Hay guías sin <channel>; entonces empareja por el canal de cada programa.
    for ch_id in programmes or {}:
        by_key.setdefault(_normalize_ch_id(ch_id), ch_id)
    by_key.pop("", None)

    now = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    out = {}
    for pos, (tvg_id, name) in enumerate(keys):
        ch_id = (by_key.get(_normalize_ch_id(tvg_id)) if tvg_id else None) or by_key.get(_norm_name(name))
        if not ch_id:
            continue
        for prog in (programmes or {}).get(ch_id) or ():
            if prog.get("start", "") <= now < (prog.get("stop") or "99999999999999"):
                out[pos] = prog
                break
    return out


def programa_ahora(tvg_id, name, url=''):
    """(título, fin en segundos desde 1970) de lo que emite ahora un canal según la copia de la
    guía (la de su lista con url, o la general), o None. Nunca descarga: sirve para grabar hasta
    que acabe el programa, y solo si la guía ya está cargada."""
    channels, programmes = _guia_lista(url, False) if url else _load_cache()
    if not channels and not programmes:
        return None
    try:
        prog = _en_emision([(tvg_id, name)], channels, programmes).get(0)
        stop = _parse_epg_dt(prog.get("stop")) if prog else None
    except (AttributeError, TypeError) as e:
        xbmc.log(f"{_LOG} programa_ahora: {e}", xbmc.LOGWARNING)
        return None
    if stop is None:
        return None
    return prog.get("title") or "", stop.replace(tzinfo=timezone.utc).timestamp()
