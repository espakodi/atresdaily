# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Grabaciones en marcha, compartidas entre las llamadas al addon.

Cada grabación (iptv_grabar) corre en su propia llamada y se apunta aquí con un archivo en
<perfil>/grabando y una propiedad de la ventana 10000, que dice si sigue viva y sirve para pedirle
que pare. Las propiedades desaparecen al cerrar Kodi, así que un archivo sin la suya es un resto
de otra sesión. Lo usan los listados (marca REC y "Parar la grabación") y "Mis Descargas", que no
deben cargar el grabador.
"""
import hashlib
import json
import os
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcvfs

import ui_utils

NUEVO = 'iptv_grabar'
MARCA = '[COLOR red]REC[/COLOR] '
_HEADING = 'AtresDaily'
_BASE = 'plugin://plugin.video.atresdaily/'
_DIR = os.path.join(xbmcvfs.translatePath(ui_utils.ADDON.getAddonInfo('profile')), 'grabando')
_PROP = 'atresdaily.grabacion.'
_EN_MARCHA = '1'
_PARAR = 'parar'
# Lo que puede tardar en escribirse el registro de una grabación que empieza. Hasta entonces, un
# archivo que aún no se puede leer es de una grabación viva.
_CREANDO_S = 30


def clave(url):
    """La de un canal: su dirección sin las cabeceras de Kodi (|...)."""
    base = str(url or '').split('|', 1)[0].strip()
    return hashlib.sha1(base.encode('utf-8')).hexdigest()[:16]


def admite(url):
    """Si la dirección de un canal HLS o directo se puede intentar grabar: http(s) y no de Pluto
    TV, que cifra todos sus canales. Se mira con texto y no con urlsplit porque va en cada canal
    de un listado, que puede tener miles."""
    low = str(url or '')[:300].lower()
    return low.startswith(('http://', 'https://')) and 'pluto.tv' not in low and 'jmp2.uk/plu-' not in low


def _ruta(k):
    return os.path.join(_DIR, f'{k}.json')


def _ventana():
    return xbmcgui.Window(10000)


def _leer(ruta):
    try:
        with open(ruta, encoding='utf-8') as f:
            datos = json.load(f)
    except (OSError, ValueError):
        return None
    return datos if isinstance(datos, dict) else None


def _borrar(ruta):
    # En Windows no se puede borrar un archivo que otra llamada tiene abierto para leerlo.
    for intento in range(3):
        try:
            os.remove(ruta)
            return
        except FileNotFoundError:
            return
        except OSError as e:
            if intento == 2:
                xbmc.log(f'[AtresDaily/Grabar] No se pudo borrar {ruta}: {e}', xbmc.LOGWARNING)
            else:
                time.sleep(0.1)


def en_marcha():
    """{clave: datos} de las grabaciones vivas; los datos están vacíos si la grabación acaba de
    empezar y aún no se pueden leer. De paso borra lo que quede de una sesión anterior."""
    try:
        nombres = os.listdir(_DIR)
    except OSError:
        return {}
    vivas = {}
    ventana = _ventana()
    ahora = time.time()
    for nombre in nombres:
        ruta = os.path.join(_DIR, nombre)
        k, ext = os.path.splitext(nombre)
        datos = _leer(ruta) if ext == '.json' else None
        if datos is not None:
            # La propiedad se pone antes de escribir el registro y se quita después de borrarlo,
            # así que un registro entero sin ella es de una grabación que ya no sigue.
            if ventana.getProperty(_PROP + str(datos.get('token'))):
                vivas[k] = datos
            else:
                _borrar(ruta)
            continue
        try:
            reciente = ahora - os.path.getmtime(ruta) < _CREANDO_S
        except OSError:
            continue
        if not reciente:
            _borrar(ruta)
        elif ext == '.json':
            vivas[k] = {}
    return vivas


def estado():
    """(claves de las grabaciones en marcha, punto verde de "Grabar"), una vez por listado. Sin
    grabaciones solo cuesta un listdir."""
    return set(en_marcha()), ui_utils.punto(NUEVO)


def entrada(estado_, url, orden):
    """(marca para la etiqueta, entrada del menú contextual) de un canal que se puede grabar:
    "Parar la grabación" si ya se está grabando y, si no, "Grabar" con orden, la dirección de la
    acción iptv_record del canal."""
    claves, punto = estado_
    k = clave(url) if claves else ''
    if k in claves:
        return MARCA, ('Parar la grabación',
                       f"RunPlugin({_BASE}?action=iptv_record_stop&k={k}&refresh=1)")
    return '', (f'{punto}Grabar', f'RunPlugin({orden})')


def _crear(ruta, datos):
    """Escribe un registro nuevo. False si ya existe; si falla a medias, no deja el archivo."""
    try:
        f = open(ruta, 'x', encoding='utf-8')
    except FileExistsError:
        return False
    try:
        with f:
            json.dump(datos, f, ensure_ascii=False)
    except BaseException:
        _borrar(ruta)
        raise
    return True


def registrar(k, datos):
    """Apunta una grabación nueva del canal k. Devuelve su token, o None si ese canal ya se está
    grabando; si no se puede escribir, sale el OSError. El archivo se crea en exclusiva, así que de
    dos a la vez solo gana una, y la propiedad va antes para que el archivo nunca parezca un resto."""
    token = os.urandom(6).hex()
    ventana = _ventana()
    ventana.setProperty(_PROP + token, _EN_MARCHA)
    ruta = _ruta(k)
    datos = dict(datos, token=token)
    try:
        os.makedirs(_DIR, exist_ok=True)
        # en_marcha() borra el archivo si es un resto, y entonces vale la segunda vuelta.
        if _crear(ruta, datos) or (k not in en_marcha() and _crear(ruta, datos)):
            return token
    except BaseException:
        ventana.clearProperty(_PROP + token)
        raise
    ventana.clearProperty(_PROP + token)
    return None


def actualizar(k, datos):
    """Reescribe el registro (al pasar a otra parte del archivo), sin dejarlo nunca a medias."""
    ruta = _ruta(k)
    tmp = f'{ruta}.{os.getpid()}.tmp'
    for intento in range(3):
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(datos, f, ensure_ascii=False)
            os.replace(tmp, ruta)
            return
        except OSError as e:
            if intento == 2:
                xbmc.log(f'[AtresDaily/Grabar] No se pudo actualizar el registro: {e}', xbmc.LOGWARNING)
                _borrar(tmp)
            else:
                time.sleep(0.1)


def pide_parar(token):
    return _ventana().getProperty(_PROP + token) == _PARAR


def terminar(k, token):
    """Borra el registro, primero el archivo y después la propiedad. Devuelve si queda alguna
    grabación en marcha; la última en acabar siempre ve que no."""
    _borrar(_ruta(k))
    _ventana().clearProperty(_PROP + token)
    return bool(en_marcha())


def _notificar(texto):
    xbmcgui.Dialog().notification(_HEADING, texto, xbmcgui.NOTIFICATION_INFO, 4000)


def parar(params):
    """Pide parar la grabación del canal params['k']. Con ask=1 pregunta antes (al pulsar su fila
    en "Mis Descargas", que si no reproduciría un archivo a medias), y con refresh=1 espera a que
    acabe y refresca la vista para que se vea."""
    k = params.get('k', '')
    datos = en_marcha().get(k)
    refrescar = params.get('refresh') == '1'
    if datos is None:
        _notificar('Esa grabación ya ha terminado.')
        if refrescar:
            xbmc.executebuiltin('Container.Refresh')
        return
    if not datos:
        _notificar('La grabación está empezando. Prueba otra vez en unos segundos.')
        return
    nombre = datos.get('nombre') or 'este canal'
    if params.get('ask') == '1' and not xbmcgui.Dialog().yesno(
            _HEADING, f'¿Parar la grabación de "{nombre}"?', nolabel='Seguir grabando', yeslabel='Parar'):
        return
    ventana = _ventana()
    prop = _PROP + str(datos.get('token'))
    # Si ha acabado entre tanto, no se vuelve a crear la propiedad.
    if ventana.getProperty(prop):
        ventana.setProperty(prop, _PARAR)
    if refrescar:
        monitor = xbmc.Monitor()
        limite = time.monotonic() + 10
        while k in en_marcha() and time.monotonic() < limite:
            if monitor.waitForAbort(0.25):
                return
        xbmc.executebuiltin('Container.Refresh')


def orden_tdt(url, titulo, tvg):
    """La acción iptv_record de un canal de TDT Channels España, que no pasa por las listas."""
    return f"{_BASE}?{urllib.parse.urlencode({'action': 'iptv_record', 'url': url, 'title': titulo, 'tvg': tvg or ''})}"
