# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import sys
import os
import hashlib
import io
import json
import socket
import time
import re
import subprocess
import threading
import urllib.parse
import zipfile
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

import dm_resolver
import ui_utils
import ytdlp_resolver

_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

_STREAM_EXTENSIONS = {
    '.m3u8', '.mp4', '.mkv', '.avi', '.ts', '.flv',
    '.mov', '.wmv', '.webm', '.mpd', '.m3u'
}

_ACESTREAM_RE = re.compile(r"^acestream://[0-9a-fA-F]{40}$")

_DEBRID_CACHE_TTL = 600   # 10 min: los enlaces Debrid caducan, TTL conservador
_DEBRID_CACHE_MAX = 20

# Ordena la lectura y escritura del historial y los marcadores entre hilos (las
# miniaturas se completan en segundo plano). _save_json ya es atómico por fichero; el
# lock evita perder una escritura entre la lectura y el guardado.
_store_lock = threading.Lock()

# Script inline para subprocess (Windows). Similar a dm_resolver pero sin módulo
# externo: usa la API de metadatos de DM + parseo del master HLS con regex.
_DM_SYSPY_SCRIPT = r'''
import sys, json, re
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15)
    _STATUS = lambda r: r.status_code
    _TEXT = lambda r: r.text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15)
    _STATUS = lambda r: r.getcode()
    _TEXT = lambda r: r.read().decode()
vid = sys.argv[1]
hdr = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin":"https://www.dailymotion.com","Referer":"https://www.dailymotion.com/"}
r = _GET("https://www.dailymotion.com/player/metadata/video/"+vid, hdr)
if _STATUS(r) != 200:
    sys.exit(1)
data = json.loads(_TEXT(r))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities",{}).get("auto",[]):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url",""); break
if not hls:
    sys.exit(3)
r2 = _GET(hls, hdr)
if _STATUS(r2) != 200:
    sys.exit(4)
master = _TEXT(r2)
m = re.findall(r"NAME=\"(\d+)\"[^\n]*\n([^\n]+)", master)
m.sort(key=lambda x: int(x[0]), reverse=True)
url = (m[0][1] if m else hls).split("#cell")[0]
print(json.dumps({"url": url}))
'''


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), 'url_history.json')


def _bookmarks_path():
    return os.path.join(_get_profile(), 'url_bookmarks.json')


def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    # Evita dejar el archivo a medias ante un corte o guardado solapado.
    import threading
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, path)
    except (IOError, OSError):
        try: os.remove(tmp)
        except OSError: pass


def parse_url_with_headers(raw_url):
    """
    Separa una URL con headers en formato pipe de Kodi.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", "Referer": "yyy"})

    Si no hay pipe, devuelve la URL limpia y un diccionario vacío.
    """
    if not raw_url:
        return '', {}

    raw_url = raw_url.strip()

    if '|' not in raw_url:
        return raw_url, {}

    parts = raw_url.split('|', 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()

    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            key = key.strip()
            value = value.strip()
            # Quitar comillas simples o dobles envolventes
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = value

    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta directamente a un stream reproducible."""
    try:
        parsed = urllib.parse.urlparse(url)
        path_lower = parsed.path.lower()
        _, ext = os.path.splitext(path_lower)
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def detect_dailymotion_id(url):
    """Extrae el ID de DM de dailymotion.com/video/{ID}, dai.ly/{ID},
    /embed/video/{ID} y geo-subdomains. Devuelve None si no es DM."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        if host.startswith('www.'):
            host = host[4:]

        if host.endswith('dailymotion.com'):
            # /video/x8abc123 o /video/x8abc123_titulo
            match = re.match(r'/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
            # /embed/video/x8abc123
            match = re.match(r'/embed/video/([a-zA-Z0-9]+)', parsed.path)
            if match:
                return match.group(1)
        elif host == 'dai.ly':
            # dai.ly/x8abc123
            vid = parsed.path.strip('/')
            if vid:
                return vid.split('_')[0].split('?')[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extrae el ID de YT de /watch?v=, youtu.be/ y /shorts/. Devuelve None si no es YT."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or '').lower()
        if host.startswith('www.'):
            host = host[4:]

        if host in ('youtube.com', 'm.youtube.com'):
            if '/watch' in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get('v', [])
                if vid_list:
                    return vid_list[0]
            elif '/shorts/' in parsed.path:
                match = re.match(r'/shorts/([a-zA-Z0-9_-]+)', parsed.path)
                if match:
                    return match.group(1)
        elif host == 'youtu.be':
            vid = parsed.path.strip('/')
            if vid:
                return vid
    except Exception:
        pass
    return None


def _clip_via_cmd(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, encoding='utf-8', errors='replace', timeout=2)
        return out.stdout.strip() if out.returncode == 0 else ""
    except Exception:
        return ""


def _get_system_clipboard_text():
    """Lee el portapapeles del sistema operativo, o '' si no se puede (otra
    plataforma, sin xclip/xsel, portapapeles bloqueado). En ese caso el botón
    que lo usa no aparece, sin error."""
    if sys.platform.startswith('win'):
        try:
            import ctypes
            import ctypes.wintypes
            CF_UNICODETEXT = 13
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.GetClipboardData.restype = ctypes.c_void_p
            user32.GetClipboardData.argtypes = [ctypes.wintypes.UINT]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            if not user32.OpenClipboard(None):
                return ""
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.wstring_at(ptr).strip()
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except Exception:
            return ""
    if sys.platform == 'darwin':
        return _clip_via_cmd(['pbpaste'])
    # Linux/Unix. En Android no hay xclip/xsel ni subprocess fiable, así que cortamos antes.
    if xbmc.getCondVisibility('System.Platform.Android'):
        return ""
    return (_clip_via_cmd(['xclip', '-selection', 'clipboard', '-o'])
            or _clip_via_cmd(['xsel', '-b', '-o']))


_PLAYABLE_PREFIXES = ('http://', 'https://', 'magnet:', 'acestream://')


def _looks_like_playable_url(text):
    """True si text parece una URL reproducible: esquema soportado o hash
    AceStream desnudo (40 hex). Mismo criterio que el receptor web."""
    if not text:
        return False
    return text.lower().startswith(_PLAYABLE_PREFIXES) or bool(re.fullmatch(r'[0-9a-fA-F]{40}', text))


def detect_url_type(raw_url):
    """Clasifica raw_url en 'torrent', 'acestream', 'dailymotion', 'youtube',
    'atresplayer', 'direct_stream' o 'web_page'."""
    url, _ = parse_url_with_headers(raw_url)

    # Torrent / magnet
    if url.startswith('magnet:'):
        return 'torrent', url
    try:
        parsed_path = urllib.parse.urlparse(url).path.lower()
    except ValueError:
        parsed_path = ''
    if parsed_path.endswith('.torrent'):
        return 'torrent', url

    # AceStream: protocolo explícito o hash desnudo de 40 hex
    if url.startswith("acestream://"):
        content_id = url.replace("acestream://", "").strip()
        if content_id:
            return 'acestream', content_id
    if re.fullmatch(r'[0-9a-fA-F]{40}', url):
        return 'acestream', url.lower()

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return 'dailymotion', dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return 'youtube', yt_id

    # AtresPlayer
    if re.match(r'https?://(?:www\.)?atresplayer\.com/.+', url):
        return 'atresplayer', url

    if is_direct_stream(url):
        return 'direct_stream', raw_url

    return 'web_page', url


def _add_to_history(raw_url, label=None, thumb=None):
    """Registra en historial al instante (sin peticiones de red) y, si falta
    miniatura o título legible, los obtiene en segundo plano. El guardado va
    bajo _store_lock para no perder entradas si llegan varias URLs a la vez."""
    with _store_lock:
        history = _load_json(_history_path())
        # Reutilizar thumb/label de una entrada previa con la misma URL
        prev = next((h for h in history if h.get('url') == raw_url), None)
        if prev:
            thumb = thumb or prev.get('thumb')
            if not label and prev.get('label') and prev['label'] != raw_url:
                label = prev['label']
        history = [h for h in history if h.get('url') != raw_url]
        entry = {
            'url': raw_url,
            'label': label or raw_url,
            'date': time.strftime('%d/%m/%Y %H:%M'),
            'timestamp': int(time.time())
        }
        if thumb:
            entry['thumb'] = thumb
        history.insert(0, entry)
        _save_json(_history_path(), history[:MAX_HISTORY])

    # Enriquecimiento (oEmbed/og:image) fuera del lock y del hilo de UI.
    if not thumb or not label or label == raw_url:
        threading.Thread(target=_enrich_history_entry,
                         args=(raw_url,), daemon=True).start()


def _enrich_history_entry(raw_url):
    """Obtiene miniatura y título por HTTP y actualiza la entrada si sigue existiendo."""
    thumb = _auto_thumb(raw_url)
    label = _auto_label(raw_url)
    if not thumb and not label:
        return
    with _store_lock:
        history = _load_json(_history_path())
        changed = False
        for h in history:
            if h.get('url') == raw_url:
                if thumb and not h.get('thumb'):
                    h['thumb'] = thumb
                    changed = True
                if label and (not h.get('label') or h['label'] == raw_url):
                    h['label'] = label
                    changed = True
                break
        if changed:
            _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    with _store_lock:
        _save_json(_history_path(), [])


def _remove_from_history(url):
    with _store_lock:
        history = _load_json(_history_path())
        history = [h for h in history if h.get('url') != url]
        _save_json(_history_path(), history)


def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    """Añade el marcador al instante (sin red) y devuelve False si ya existía.
    La miniatura se obtiene en segundo plano."""
    with _store_lock:
        bookmarks = _load_json(_bookmarks_path())
        if any(b.get('url') == url for b in bookmarks):
            return False
        bookmarks.append({
            'name': name,
            'url': url,
            'date': time.strftime('%d/%m/%Y %H:%M')
        })
        _save_json(_bookmarks_path(), bookmarks[:MAX_BOOKMARKS])
    threading.Thread(target=_enrich_bookmark_thumb, args=(url,), daemon=True).start()
    return True


def _enrich_bookmark_thumb(url):
    thumb = _auto_thumb(url)
    if not thumb:
        return
    with _store_lock:
        bookmarks = _load_json(_bookmarks_path())
        changed = False
        for b in bookmarks:
            if b.get('url') == url and not b.get('thumb'):
                b['thumb'] = thumb
                changed = True
                break
        if changed:
            _save_json(_bookmarks_path(), bookmarks)


def _remove_bookmark(url):
    with _store_lock:
        bookmarks = _load_json(_bookmarks_path())
        new_bookmarks = [b for b in bookmarks if b.get('url') != url]
        _save_json(_bookmarks_path(), new_bookmarks)
        return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    with _store_lock:
        bookmarks = _load_json(_bookmarks_path())
        changed = False
        for b in bookmarks:
            if b.get('url') == url:
                b['name'] = new_name
                changed = True
                break
        if changed:
            _save_json(_bookmarks_path(), bookmarks)
        return changed



_YT_RE = re.compile(
    r"(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)"
    r"([A-Za-z0-9_-]{11})"
)
_DM_RE = re.compile(r"(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)")
_VIMEO_RE = re.compile(r"vimeo\.com/(\d+)")
_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_THUMB_TIMEOUT = 3


def _auto_thumb(url):
    """Miniatura de la URL: YT/DM sin HTTP, Vimeo via oEmbed, otras vía og:image. '' si no hay."""
    if not url:
        return ''
    m = _YT_RE.search(url)
    if m:
        return f"https://img.youtube.com/vi/{m.group(1)}/hqdefault.jpg"
    m = _DM_RE.search(url)
    if m:
        return f"https://www.dailymotion.com/thumbnail/video/{m.group(1)}"
    m = _VIMEO_RE.search(url)
    if m:
        return _vimeo_thumb(url)
    if url.startswith('http'):
        return _og_thumb(url)
    return ''


def _vimeo_thumb(url):
    try:
        import requests
        r = requests.get(
            "https://vimeo.com/api/oembed.json",
            params={'url': url, 'width': 480}, timeout=_THUMB_TIMEOUT,
        )
        if r.status_code == 200:
            return r.json().get('thumbnail_url', '')
    except (ImportError, ValueError, OSError):
        pass
    return ''


def _og_thumb(url):
    try:
        import requests
        r = requests.get(
            url, timeout=_THUMB_TIMEOUT,
            headers={'User-Agent': 'Mozilla/5.0'}, stream=True,
        )
        try:
            if r.status_code != 200:
                return ''
            chunk = r.raw.read(8192).decode('utf-8', errors='ignore')
            m = _OG_RE.search(chunk)
            if m:
                return m.group(1) or m.group(2) or ''
        finally:
            r.close()
    except (ImportError, OSError):
        pass
    return ''


def _auto_label(url):
    """Título via oEmbed para YT/DM/Vimeo; nombre del path para el resto."""
    if not url:
        return ''
    try:
        import requests
        m = _YT_RE.search(url)
        if m:
            r = requests.get(
                "https://www.youtube.com/oembed",
                params={'url': url, 'format': 'json'}, timeout=3,
            )
            if r.status_code == 200:
                return r.json().get('title', '')
        m = _DM_RE.search(url)
        if m:
            r = requests.get(
                "https://www.dailymotion.com/services/oembed",
                params={'url': url, 'format': 'json'}, timeout=3,
            )
            if r.status_code == 200:
                return r.json().get('title', '')
        m = _VIMEO_RE.search(url)
        if m:
            r = requests.get(
                "https://vimeo.com/api/oembed.json",
                params={'url': url}, timeout=3,
            )
            if r.status_code == 200:
                return r.json().get('title', '')
    except Exception:
        pass
    # Si no, el título sale del final de la ruta de la URL
    try:
        path = urllib.parse.urlparse(url).path.rstrip('/').rsplit('/', 1)[-1]
        if '.' in path:
            path = path.rsplit('.', 1)[0]
        name = path.replace('-', ' ').replace('_', ' ')
        return name[:80] if name else ''
    except (ValueError, OSError):
        return ''


def _ace_engine_alive(timeout=1):
    """True si el motor AceStream responde en 127.0.0.1:6878."""
    try:
        with socket.create_connection(('127.0.0.1', 6878), timeout=timeout):
            return True
    except OSError:
        return False


def _debrid_cache_path():
    return os.path.join(_get_profile(), 'debrid_resolve_cache.json')


def _debrid_cache_key(provider, url):
    return hashlib.sha1(f"{provider}|{url}".encode('utf-8')).hexdigest()


def _debrid_cache_get(provider, url):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        return None
    entry = data.get(_debrid_cache_key(provider, url))
    if entry and (time.time() - entry.get('ts', 0)) < _DEBRID_CACHE_TTL:
        return entry.get('stream')
    return None


def _debrid_cache_put(provider, url, stream):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        data = {}
    data[_debrid_cache_key(provider, url)] = {'stream': stream, 'ts': int(time.time())}
    if len(data) > _DEBRID_CACHE_MAX:
        recientes = sorted(data.items(), key=lambda kv: kv[1].get('ts', 0), reverse=True)[:_DEBRID_CACHE_MAX]
        data = dict(recientes)
    _save_json(_debrid_cache_path(), data)


def _debrid_active():
    """True si hay un proveedor Debrid activado y con cuenta vinculada."""
    try:
        if xbmcaddon.Addon().getSetting('debrid_enabled') != 'true':
            return False
        r = _get_debrid()
        return r is not None and r.is_authorized()
    except Exception:
        return False


def _get_debrid():
    """Instancia del resolver Debrid. Import defensivo: si fallara, el addon
    sigue funcionando como si Debrid no existiera."""
    try:
        import debrid_resolver
        return debrid_resolver.get_resolver()
    except Exception as e:
        xbmc.log(f"[AtresDaily] Debrid no disponible: {e}", xbmc.LOGWARNING)
        return None


def _play_resolved_stream(stream_url, headers=None, protocol='', strip_generic_headers=True):
    """Reproduce un stream ya resuelto, configurando inputstream.adaptive y headers.
    strip_generic_headers descarta los genéricos de navegador (User-Agent, Accept...) que
    yt-dlp añade pero no son significativos; para URLs con headers que puso el usuario a mano
    (direct_stream) se pasa False para conservarlos todos."""
    li = xbmcgui.ListItem(path=stream_url)
    clean_path = urllib.parse.urlparse(stream_url).path.lower()

    _GENERIC_HEADERS = {
        'user-agent', 'accept', 'accept-language', 'accept-encoding',
        'sec-fetch-dest', 'sec-fetch-mode', 'sec-fetch-site',
        'sec-ch-ua', 'sec-ch-ua-mobile', 'sec-ch-ua-platform',
    }
    meaningful = {}
    if headers:
        meaningful = dict(headers) if not strip_generic_headers else {
            k: v for k, v in headers.items() if k.lower() not in _GENERIC_HEADERS
        }

    header_str = ''
    if meaningful:
        header_str = '&'.join(
            f"{k}={urllib.parse.quote(str(v))}" for k, v in meaningful.items()
        )

    is_mpd = clean_path.endswith('.mpd') or 'mpd' in protocol
    is_m3u8 = clean_path.endswith('.m3u8') or 'm3u8' in protocol

    if is_mpd:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setMimeType('application/dash+xml')
        if header_str:
            li.setProperty('inputstream.adaptive.manifest_headers', header_str)
            li.setProperty('inputstream.adaptive.stream_headers', header_str)
    elif is_m3u8:
        li.setMimeType('application/x-mpegURL')
        # ISA reproduce HLS (sobre todo directos) mejor que el demuxer interno. Sin ISA
        # instalado y sin headers, se usa el demuxer interno.
        if header_str or xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            if header_str:
                li.setProperty('inputstream.adaptive.manifest_headers', header_str)
                li.setProperty('inputstream.adaptive.stream_headers', header_str)
    elif header_str:
        stream_url = f"{stream_url}|{header_str}"
        li = xbmcgui.ListItem(path=stream_url)

    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    xbmc.Player().play(stream_url, li)


def _u(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    h = int(sys.argv[1])

    # StreamNinja: abrirlo o instalarlo
    sn_id = "plugin.video.streamninja"
    is_sn_installed = xbmc.getCondVisibility(f"System.HasAddon({sn_id})")
    
    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    sn_icon = os.path.join(_media, 'sn_logo.jpg')

    if is_sn_installed:
        lbl_sn = "[COLOR orchid]Abrir StreamNinja[/COLOR]"
        plt_sn = "¡Activa el Modo Ninja! Desenvaina la potencia de StreamNinja para dominar cualquier enlace de vídeo con precisión y rapidez."
    else:
        lbl_sn = "[COLOR orange]Instalar StreamNinja[/COLOR]"
        plt_sn = "Instala el Modo Ninja: Desenvaina la potencia necesaria para dominar cualquier enlace de vídeo."
        
    li_sn = xbmcgui.ListItem(label=lbl_sn)
    li_sn.setArt({'icon': sn_icon})
    li_sn.setInfo('video', {'plot': plt_sn})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_player_ensure_sn'), listitem=li_sn, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR limegreen]Pegar URL de vídeo[/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'url_paste.png')})
    li.setInfo('video', {'plot':
        "Pega una URL de vídeo para reproducirla.\n\n"
        "Soportado:\n"
        "• YouTube, Dailymotion, Vimeo, Twitch, Rumble...\n"
        "• a3player\n"
        "• Stream directo: .m3u8, .mpd, .mp4, .mkv...\n"
        "• Torrent: magnet: o archivo .torrent\n"
        "• AceStream: acestream:// o hash de 40 hex\n"
        "• Debrid: AllDebrid, Real-Debrid, TorBox, Premiumize\n"
        "• Otras webs: se intenta resolver automáticamente"
    })
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_input'), listitem=li, isFolder=False)

    # La URL del portapapeles, solo si trae una. Primera línea no vacía: descarta saltos
    # y espacios alrededor sin partir un magnet con espacios en dn= (split() lo truncaría).
    clip = next((ln.strip() for ln in _get_system_clipboard_text().splitlines() if ln.strip()), '')
    if _looks_like_playable_url(clip):
        url_display = clip[:70] + '...' if len(clip) > 70 else clip
        li = xbmcgui.ListItem(label="[COLOR cyan][B]Pegar URL del sistema[/B][/COLOR]")
        li.setArt({'icon': os.path.join(_media, 'url_clipboard.png')})
        li.setInfo('video', {'plot':
            f"Detectada en el portapapeles:\n{url_display}\n\n"
            "Pulsa para reproducirla directamente sin escribir."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_play', url=clip), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR lightsalmon][B]Enviar URL desde móvil/PC[/B][/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'url_remote.png')})
    li.setInfo('video', {'plot':
        "Abre un servidor temporal en la red local.\n\n"
        "Desde el navegador de tu móvil o PC podrás pegar la URL sin escribirla "
        "con el mando.\n\nIdeal para dispositivos sin teclado."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_remote'), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR mediumpurple][B]Escanear web o Telegram[/B][/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'url_scan.png')})
    li.setInfo('video', {'plot':
        "Pega la URL de cualquier web o canal público de Telegram y el addon "
        "detectará todos los vídeos disponibles.\n\n"
        "Debería mostrar título, duración y tamaño de cada uno.\n\n"
        "En PC usa yt-dlp (más completo). En Android, análisis HTML."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_scan'), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR thistle][B]Configuración[/B][/COLOR]")
    li.setArt({'icon': os.path.join(_media, 'url_config.png')})
    li.setInfo('video', {'plot':
        "Ajustes del receptor de URLs (móvil/PC): modo de conexión, puerto, "
        "seguridad, confirmación antes de reproducir, relay de Internet y Debrid."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_player_config'), listitem=li, isFolder=True)

    if _debrid_active():
        provider = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
        li = xbmcgui.ListItem(label=f"[COLOR gold]Mi nube {provider}[/COLOR]")
        li.setArt({'icon': os.path.join(_media, 'url_cloud.png')})
        li.setInfo('video', {'plot':
            f"Vídeos que tienes en tu cuenta {provider}.\n\n"
            "Reproduce o borra el contenido de tu nube."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='debrid_library'), listitem=li, isFolder=True)

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(label=f"[COLOR cyan]Historial de URLs ({len(history)})[/COLOR]")
        li.setArt({'icon': os.path.join(_media, 'url_history.png')})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history'), listitem=li, isFolder=True)

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(label=f"[COLOR khaki]Marcadores ({len(bookmarks)})[/COLOR]")
        li.setArt({'icon': os.path.join(_media, 'url_bookmarks.png')})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_bookmarks'), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


# --- ResolveURL (hosters de streaming) ---

_resolveurl_mod = None
_resolveurl_tried = False


def _get_resolveurl():
    """Devuelve el módulo resolveurl si está instalado (Kodi lo pone en sys.path
    al declararlo en addon.xml), o None. Cachea el resultado; no reintenta tras un
    fallo. El import es pesado (carga 285 plugins), por eso se hace una sola vez."""
    global _resolveurl_mod, _resolveurl_tried
    if _resolveurl_tried:
        return _resolveurl_mod
    _resolveurl_tried = True
    if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
        return None
    try:
        import resolveurl
        _resolveurl_mod = resolveurl
    except Exception as e:
        xbmc.log(f"[url_player] No se pudo cargar ResolveURL: {e}", xbmc.LOGWARNING)
    return _resolveurl_mod


def _resolveurl_resolve(url):
    """Resuelve url con ResolveURL si reconoce el dominio. None si no es soportado,
    falla, o delega en otro addon. valid_url() es regex local (sin red)."""
    mod = _get_resolveurl()
    if not mod:
        return None
    try:
        hmf = mod.HostedMediaFile(url)
        if not hmf.valid_url():
            return None
        xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con ResolveURL...", xbmcgui.NOTIFICATION_INFO, 2000)
        stream = hmf.resolve()                       # 283 resolvers de terceros, calidad variable
    except Exception as e:
        xbmc.log(f"[url_player] ResolveURL error: {e}", xbmc.LOGWARNING)
        return None
    if not (isinstance(stream, str) and stream):
        return None
    # ResolveURL aporta valor con hosters (devuelven un stream http directo). Algunos
    # resolvers (youtube, vimeo...) devuelven plugin://otro.addon; esa delegación la
    # maneja mejor el yt-dlp propio, así que la ignoramos y caemos al siguiente método.
    if stream.startswith('plugin://'):
        return None
    return stream


def _scrape_hosters(html):
    """Detecta en el HTML enlaces a hosters soportados por ResolveURL y los devuelve
    en el formato del escáner. [] si ResolveURL no está o no hay HTML."""
    mod = _get_resolveurl()
    if not mod or not html:
        return []
    try:
        # El regex propio de ResolveURL solo mira href=; los hosters embebidos van
        # casi siempre en <iframe src=...>. Capturamos href y src (valid_url filtra el resto).
        links = mod.scrape_supported(html, regex=r'''(?:href|src)\s*=\s*['"]([^'"]+)''')
    except Exception as e:
        xbmc.log(f"[url_player] scrape_supported error: {e}", xbmc.LOGWARNING)
        return []
    out = []
    for link in links:
        host = urllib.parse.urlparse(link).hostname or 'enlace'
        out.append({'title': f'Hoster: {host}', 'url': link, 'filesize': None, 'ext': ''})
    return out


def _resolve_and_play(raw_url):
    url_type, value = detect_url_type(raw_url)

    # Resolver Debrid: solo intercepta magnets y páginas/hosters desconocidos.
    # Los tipos con resolver propio (dailymotion, youtube...) no pasan por aquí.
    if url_type in ('torrent', 'web_page') and _debrid_active():
        provider = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
        stream = _debrid_cache_get(provider, value)
        if not stream:
            try:
                stream = _get_debrid().resolve(value)
            except Exception as e:
                xbmc.log(f"[AtresDaily/Debrid] {e}", xbmc.LOGWARNING)
                stream = None
            if stream:
                _debrid_cache_put(provider, value, stream)
        if stream:
            _play_resolved_stream(stream)
            return

    # En las dos cadenas de abajo, AddonIsEnabled y no HasAddon. Desde Kodi 19 HasAddon también
    # es cierto con el addon desactivado, y uno desactivado (hay quien apaga Elementum por su
    # servicio) se quedaría con el enlace aunque el siguiente de la lista pudiera abrirlo.
    if url_type == 'torrent':
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.elementum)"):
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo torrent en Elementum...", xbmcgui.NOTIFICATION_INFO, 2000)
            elem_url = "plugin://plugin.video.elementum/play?" + urllib.parse.urlencode({'uri': value})
            xbmc.executebuiltin(f'PlayMedia("{elem_url}")')
            return
        if not xbmc.getCondVisibility("System.AddonIsEnabled(script.module.horus)"):
            accion = "Activar" if xbmc.getCondVisibility("System.HasAddon(script.module.horus)") else "Instalar"
            if not xbmcgui.Dialog().yesno("AtresDaily",
                    "Para reproducir torrents necesitas Elementum, o EKHorus, que los abre con el "
                    f"motor AceStream.\n\n¿{accion} EKHorus ahora?",
                    nolabel="Cerrar", yeslabel=f"{accion} EKHorus"):
                return
            import espakodi_installer
            if not espakodi_installer.instalar_si_falta("script.module.horus"):
                return
        # EKHorus (id script.module.horus) abre magnets y .torrent con el motor AceStream;
        # del magnet saca él mismo el infohash.
        xbmcgui.Dialog().notification("AtresDaily", "Abriendo torrent en EKHorus...", xbmcgui.NOTIFICATION_INFO, 2000)
        ek_url = "plugin://script.module.horus/?" + urllib.parse.urlencode({'action': 'play', 'url': value})
        xbmc.executebuiltin(f'PlayMedia("{ek_url}")')
        return

    if url_type == 'acestream':
        ace_hash = value
        has_sn = xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.streamninja)")
        has_horus = xbmc.getCondVisibility("System.AddonIsEnabled(script.module.horus)")
        if has_sn:
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://plugin.video.streamninja/?action=acestream&id={ace_hash}"
            # Con PlayMedia Kodi espera la respuesta del plugin y deja la rueda de espera encima
            # del vídeo, porque StreamNinja reproduce él mismo y sigue en marcha mientras se ve.
            xbmc.executebuiltin(f'RunPlugin("{ace_url}")')
        elif has_horus:
            # EKHorus se instala con el id de Horus (script.module.horus).
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en EKHorus...", xbmcgui.NOTIFICATION_INFO, 2000)
            ace_url = f"plugin://script.module.horus/?action=play&id={ace_hash}"
            xbmc.executebuiltin(f'PlayMedia("{ace_url}")')
        elif not _ace_engine_alive():
            xbmcgui.Dialog().ok("AtresDaily",
                "No se detectó el motor AceStream en este equipo (127.0.0.1:6878).\n\n"
                "Arranca el motor AceStream, o instala EKHorus (script.module.horus) "
                "o StreamNinja.\n\n"
                "Los dos necesitan además el motor AceStream instalado en el sistema.")
        else:
            # Motor local escuchando: stream MPEG-TS directo
            target = f"http://127.0.0.1:6878/ace/getstream?id={ace_hash}"
            li = xbmcgui.ListItem(path=target)
            li.setContentLookup(False)
            xbmc.Player().play(target, li)
        return

    if url_type == 'dailymotion':
        xbmcgui.Dialog().notification("AtresDaily",
            f"Dailymotion detectado: {value}", xbmcgui.NOTIFICATION_INFO, 2000)
        _played = False
        _python_missing = False
        _ytdlp_missing = False

        # Método 0: yt-dlp del sistema (mejor compatibilidad de CDN en PC).
        if ytdlp_resolver.is_available():
            _dm_url = f"https://www.dailymotion.com/video/{value}"
            _info = ytdlp_resolver.resolve_full(_dm_url)
            if _info and _info.get('url'):
                _play_resolved_stream(_info['url'], headers=_info.get('headers'),
                                      protocol=_info.get('protocol', ''))
                _played = True

        # Windows paso 1: script inline, sin yt-dlp, ~1-2s.
        if not _played and xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                _proc = subprocess.run(
                    ['python', '-c', _DM_SYSPY_SCRIPT, value],
                    capture_output=True, text=True, timeout=20,
                    creationflags=0x08000000,
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    stream_url = json.loads(_proc.stdout).get('url', '')
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setMimeType('application/x-mpegURL')
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        _played = True
                        xbmc.log(f"[url_player] DM inline OK: {stream_url[:80]}", xbmc.LOGINFO)
                if not _played:
                    xbmc.log(
                        f"[url_player] DM inline rc={_proc.returncode} "
                        f"err={(_proc.stderr or '')[:200]}",
                        xbmc.LOGWARNING,
                    )
            except FileNotFoundError:
                _python_missing = True
                xbmc.log("[url_player] DM: python no encontrado en PATH", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"[url_player] DM inline error: {e}", xbmc.LOGWARNING)

        # Windows paso 2: yt-dlp. Sin Python disponible, yt-dlp tampoco funciona.
        if not _played and not _python_missing and xbmc.getCondVisibility("System.Platform.Windows"):
            try:
                xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                _proc = subprocess.run(
                    ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                     '--format', 'best[ext=mp4]/best', '--no-playlist',
                     f'https://www.dailymotion.com/video/{value}'],
                    capture_output=True, text=True, timeout=30,
                    creationflags=0x08000000,
                )
                if _proc.returncode == 0 and _proc.stdout.strip():
                    stream_url = json.loads(_proc.stdout).get('url', '')
                    if stream_url:
                        li = xbmcgui.ListItem(path=stream_url)
                        li.setProperty('IsPlayable', 'true')
                        li.setContentLookup(False)
                        xbmc.Player().play(stream_url, li)
                        _played = True
                        xbmc.log(f"[url_player] DM yt-dlp OK: {stream_url[:80]}", xbmc.LOGINFO)
                if not _played:
                    _err = (_proc.stderr or '') + (_proc.stdout or '')
                    if 'No module named' in _err and 'yt_dlp' in _err:
                        _ytdlp_missing = True
                    xbmc.log(f"[url_player] DM yt-dlp sin URL rc={_proc.returncode}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"[url_player] DM yt-dlp error: {e}", xbmc.LOGWARNING)

        if xbmc.getCondVisibility("System.Platform.Windows") and (_python_missing or _ytdlp_missing):
            _hint = (
                "Instala Python y yt-dlp para reproducción más fiable en Windows"
                if _python_missing
                else "Instala yt-dlp (pip install yt-dlp) para mayor fiabilidad"
            )
            xbmcgui.Dialog().notification("AtresDaily", _hint, xbmcgui.NOTIFICATION_INFO, 6000)

        # Paso 3 (todas las plataformas): inputstream.adaptive con headers para
        # que los segmentos de vod*.cf.dmcdn.net no devuelvan 403.
        if not _played:
            _result = dm_resolver.resolve(value)
            if _result:
                url_val = _result['url']
                mime_val = _result.get('mime', 'application/x-mpegURL')
                subs_val = _result.get('subs', [])
                headers_dict = _result.get('headers', {})
                is_hls = 'mpegURL' in mime_val
                header_str = '&'.join(
                    f'{k}={urllib.parse.quote(str(v))}' for k, v in headers_dict.items()
                ) if headers_dict else ''
                if not is_hls and header_str:
                    url_val = f"{url_val}|{header_str}"
                li = xbmcgui.ListItem(path=url_val)
                li.setMimeType(mime_val)
                li.setProperty('IsPlayable', 'true')
                li.setContentLookup(False)
                if is_hls and header_str:
                    li.setProperty('inputstream', 'inputstream.adaptive')
                    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                    li.setProperty('inputstream.adaptive.manifest_headers', header_str)
                    li.setProperty('inputstream.adaptive.stream_headers', header_str)
                if subs_val:
                    li.setSubtitles(subs_val)
                xbmc.Player().play(url_val, li)
                _played = True
                xbmc.log("[url_player] DM API directa OK", xbmc.LOGINFO)

        # Paso 4: dm_gujal, que funciona sobre todo en Android y Linux.
        if not _played:
            try:
                import dm_gujal
                _result = dm_gujal.play_dm_extreme(value)
                if _result and _result[0]:
                    final_url, subs, mime = _result
                    li = xbmcgui.ListItem(path=final_url)
                    if mime:
                        li.setMimeType(mime)
                    if subs:
                        li.setSubtitles(subs)
                    li.setProperty('IsPlayable', 'true')
                    xbmc.Player().play(final_url, li)
                    _played = True
            except Exception as e:
                xbmc.log(f"[url_player] DM gujal error: {e}", xbmc.LOGWARNING)

        if not _played:
            xbmcgui.Dialog().ok("AtresDaily", "No se pudo resolver el vídeo de Dailymotion.")

    elif url_type == 'youtube':
        yt_web = f"https://www.youtube.com/watch?v={value}"
        is_android = xbmc.getCondVisibility("System.Platform.Android")

        opts = []
        actions = []
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
            opts.append("Reproducir aquí")
            actions.append('addon')
        if ytdlp_resolver.is_available():
            opts.append("Reproducir con yt-dlp")
            actions.append('ytdlp')
        if is_android:
            opts.append("Abrir en la app YouTube")
            actions.append('yt_app')
        opts.append("Abrir en el navegador")
        actions.append('browser')

        sel = 0 if len(opts) == 1 else xbmcgui.Dialog().select("YouTube", opts)
        if sel < 0:
            return
        act = actions[sel]
        if act == 'ytdlp':
            xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
            info = ytdlp_resolver.resolve_full(yt_web)
            if info and info.get('url'):
                _play_resolved_stream(info['url'], headers=info.get('headers'), protocol=info.get('protocol', ''))
            else:
                xbmcgui.Dialog().ok("AtresDaily", "yt-dlp no pudo resolver el vídeo.")
        elif act == 'addon':
            xbmc.executebuiltin(f'PlayMedia("plugin://plugin.video.youtube/play/?video_id={value}")')
            xbmc.sleep(1500)  # mantener el script vivo para que PlayMedia no se cancele al salir
        elif act == 'yt_app':
            xbmc.executebuiltin(
                'StartAndroidActivity(com.google.android.youtube,'
                f'"android.intent.action.VIEW","","{yt_web}")')
        elif act == 'browser':
            import webbrowser
            webbrowser.open(yt_web)

    elif url_type == 'direct_stream':
        # Reutiliza el reproductor común: ISA para HLS/DASH, headers como properties (no
        # como pipe, que ISA no parsea). strip_generic_headers=False porque aquí los headers
        # los puso el usuario a mano y todos son significativos.
        url, headers = parse_url_with_headers(raw_url)
        _play_resolved_stream(url, headers=headers, strip_generic_headers=False)

    elif url_type == 'atresplayer':
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get('url'):
                _play_resolved_stream(info['url'], headers=info.get('headers'), protocol=info.get('protocol', ''))
                return
        # Si no, el navegador o la app nativa (puede pedir iniciar sesión)
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        if is_android:
            opts = ["Abrir en el navegador", "Abrir en app externa"]
            sel = xbmcgui.Dialog().select("No se pudo reproducir (puede requerir login)", opts)
            if sel < 0:
                return
            xbmc.executebuiltin(
                'StartAndroidActivity("","android.intent.action.VIEW","",'
                f'"{value}")')
        else:
            msg = ("No se pudo reproducir este contenido.\n\n"
                   "Es posible que requiera login o sea premium.\n\n"
                   "¿Abrir en el navegador?")
            if not ytdlp_resolver.is_available():
                msg = ("Se necesita yt-dlp para este contenido.\n\n"
                       "Instala con: pip install yt-dlp\n\n"
                       "¿Abrir en el navegador?")
            if xbmcgui.Dialog().yesno("AtresDaily", msg):
                import webbrowser
                webbrowser.open(value)

    elif url_type == 'web_page':
        # Hosters de streaming (streamtape, dood, mixdrop...) que yt-dlp no maneja bien.
        # ResolveURL solo actúa si reconoce el dominio; si no, sigue con yt-dlp.
        ru_stream = _resolveurl_resolve(value)
        if ru_stream:
            li = xbmcgui.ListItem(path=ru_stream)   # se reproduce tal cual; preserva el pipe |User-Agent=...&Referer=... que el hoster exige
            _low = ru_stream.split('|', 1)[0].lower()
            if '.m3u8' in _low:
                li.setMimeType('application/x-mpegURL')
            elif '.mpd' in _low:
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setProperty('IsPlayable', 'true')
            li.setContentLookup(False)
            xbmc.Player().play(ru_stream, li)
            return

        # yt-dlp soporta cientos de webs de forma nativa
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get('url'):
                _play_resolved_stream(info['url'], headers=info.get('headers'), protocol=info.get('protocol', ''))
                return

        # Si no, SendToKodi
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.sendtokodi)"):
            xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con SendToKodi...", xbmcgui.NOTIFICATION_INFO, 2000)
            stk_url = "plugin://plugin.video.sendtokodi/?" + urllib.parse.urlencode({'url': value})
            xbmc.executebuiltin(f'PlayMedia("{stk_url}")')
            return

        # YouTube addon como último recurso (también usa yt-dlp)
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().notification("AtresDaily", "Intentando resolver...", xbmcgui.NOTIFICATION_INFO, 2000)
            yt_url = "plugin://plugin.video.youtube/uri2addon/?uri=" + urllib.parse.quote(value)
            xbmc.executebuiltin(f'PlayMedia("{yt_url}")')
            return

        # Abrir en navegador / app nativa
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        if is_android:
            opts = ["Abrir en el navegador", "Abrir en app externa"]
            sel = xbmcgui.Dialog().select("No se puede resolver aquí", opts)
            if sel < 0:
                return
            xbmc.executebuiltin(
                'StartAndroidActivity("","android.intent.action.VIEW","",'
                f'"{value}")')
        elif xbmcgui.Dialog().yesno("AtresDaily",
                "No se pudo resolver esta URL.\n\n¿Abrir en el navegador?"):
            import webbrowser
            webbrowser.open(value)


def url_input():
    raw = ui_utils.get_text('Pegar URL (Dailymotion, YouTube, stream...)').strip()
    if not raw:
        return

    # Hash desnudo de AceStream (40 hex): normalizar a acestream://
    if re.fullmatch(r'[0-9a-fA-F]{40}', raw):
        raw = 'acestream://' + raw.lower()

    valid_schemes = ('http://', 'https://', 'rtmp://', 'rtsp://', 'magnet:?', 'acestream://')
    if not raw.startswith(valid_schemes):
        xbmcgui.Dialog().ok("AtresDaily",
            "La URL introducida no parece válida.\n\n"
            "Esquemas soportados: http, https, rtmp, rtsp, magnet, acestream")
        return

    _add_to_history(raw)
    url_type, _ = detect_url_type(raw)
    type_labels = {
        'dailymotion': 'Dailymotion',
        'youtube': 'YouTube',
        'atresplayer': 'Vídeo web',
        'torrent': 'Torrent',
        'acestream': 'AceStream',
        'direct_stream': 'Stream directo',
        'web_page': 'Página web'
    }
    detected = type_labels.get(url_type, 'Desconocido')
    url_display = raw[:50] + '...' if len(raw) > 50 else raw

    opts = [
        f"Reproducir ahora ({detected})",
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador"
    ]
    _DOWNLOADABLE = {'dailymotion', 'youtube', 'direct_stream', 'web_page'}
    if url_type in _DOWNLOADABLE:
        opts.append(f"Descargar ({detected})")

    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard('', 'Nombre para el marcador')
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)
    elif sel == 3:
        _resolve_and_download(raw)


def url_history_menu():
    h = int(sys.argv[1])
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay URLs en el historial[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('info.png')})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial de URLs[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('backup_delete.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='url_history_clear'), listitem=li, isFolder=False)

    for entry in history:
        raw_url = entry.get('url', '')
        label = entry.get('label', raw_url)
        date = entry.get('date', '')

        display = label[:80] + '...' if len(label) > 80 else label
        thumb = entry.get('thumb', '')
        li = xbmcgui.ListItem(label=f"{display}")
        li.setArt({'icon': thumb or ui_utils.media_icon('url.png'), 'thumb': thumb or ''})
        li.setInfo('video', {'plot': f"URL: {raw_url}\n\nFecha: {date}"})

        cm = [
            ("Guardar como marcador", f"RunPlugin({_u(action='url_bookmark_save_from_history', url=raw_url)})"),
            ("Eliminar del historial", f"RunPlugin({_u(action='url_history_remove', url=raw_url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=raw_url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()

    if not bookmarks:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay marcadores guardados[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('info.png')})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get('url', '')
        name = bm.get('name', url)
        date = bm.get('date', '')

        thumb = bm.get('thumb', '')
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': thumb or ui_utils.media_icon('url_bookmarks.png'), 'thumb': thumb or ''})
        li.setInfo('video', {'plot': f"URL: {url}\n\nGuardado: {date}"})

        cm = [
            ("Renombrar", f"RunPlugin({_u(action='url_bookmark_rename', url=url)})"),
            ("Eliminar marcador", f"RunPlugin({_u(action='url_bookmark_delete', url=url)})")
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action='url_play', url=url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard('', 'Nombre para el marcador')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification("AtresDaily", "Marcador guardado", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification("AtresDaily", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO)


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ''
    for b in bookmarks:
        if b.get('url') == url:
            current_name = b.get('name', '')
            break

    kb = xbmc.Keyboard(current_name, 'Nuevo nombre')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification("AtresDaily", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial. El registro es inmediato
    (la miniatura/título se obtienen en segundo plano dentro de _add_to_history)."""
    if not raw_url:
        return
    _add_to_history(raw_url)
    _resolve_and_play(raw_url)


def play_without_history(raw_url):
    """Como play_url_action pero sin anotarla en el historial de URLs, porque los canales de las
    listas de canales no son URLs que el usuario haya escrito. AceStream sigue la cadena
    de siempre (StreamNinja, EKHorus/Horus o el motor local)."""
    if raw_url:
        _resolve_and_play(raw_url)


def url_player_ensure_streamninja():
    import ui_utils
    ui_utils.streamninja_open_or_install()


# --- Escaneo de webs y Telegram ---

def scan_videos_dialog():
    """Escanea una web o un canal público de Telegram y permite reproducir."""
    import telegram_scanner
    kb = xbmc.Keyboard('', 'URL de web, o canal de Telegram (@canal, t.me/canal)')
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return

    # Canales de Telegram: flujo propio (acepta @canal, t.me/canal o nombre desnudo)
    if telegram_scanner.is_telegram(url):
        _scan_telegram_flow(url)
        return

    if not url.startswith(('http://', 'https://')):
        xbmcgui.Dialog().ok("AtresDaily",
            "Introduce una URL (http:// o https://) o un canal de Telegram (@canal, t.me/canal).")
        return

    pdp = xbmcgui.DialogProgress()
    pdp.create("Escaneando vídeos", f"Analizando {url[:60]}...")
    try:
        videos = _scan_with_best_engine(url)
    except Exception as exc:
        xbmc.log(f"[AtresDaily] Error escaneando {url[:60]}: {exc}", xbmc.LOGWARNING)
        videos = []
    finally:
        pdp.close()

    if not videos:
        xbmcgui.Dialog().ok("AtresDaily",
            "No se encontraron vídeos en esta página.\n\n"
            "Prueba con otra URL o pega directamente la URL del vídeo.")
        return

    import html_scanner
    labels = []
    for v in videos:
        parts = [v.get('title') or v.get('url', '')[:60]]
        dur = v.get('duration')
        if dur:
            parts.append(html_scanner.format_duration(dur))
        size = v.get('filesize')
        if size:
            parts.append(html_scanner.format_size(size))
        ext = v.get('ext', '')
        if ext:
            parts.append(ext.upper())
        labels.append(" - ".join(parts))

    sel = xbmcgui.Dialog().select(f"Vídeos encontrados ({len(videos)})", labels)
    if sel < 0:
        return
    chosen = videos[sel]
    chosen_url = chosen.get('url', '')
    if chosen_url:
        _add_to_history(chosen_url, label=chosen.get('title'))
        _resolve_and_play(chosen_url)


def _scan_with_best_engine(url):
    """yt-dlp (PC, más completo) o html_scanner para los vídeos; además
    ResolveURL detecta hosters de streaming embebidos (streamtape, dood...) que
    ninguno de los dos reconoce."""
    import html_scanner
    results = []
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)   # devuelve [] si falla, nunca lanza
    mod = _get_resolveurl()
    # El HTML solo hace falta para html_scanner o para buscar hosters. Si yt-dlp ya
    # resolvió y ResolveURL no está, no se descarga.
    html = html_scanner._download_html(url, html_scanner._DOWNLOAD_TIMEOUT) if (not results or mod) else ''
    if not results:
        results = html_scanner.scan_page(url, html_content=html)
    if mod and html:
        seen = {r.get('url') for r in results}
        for h in _scrape_hosters(html):
            if h['url'] not in seen:
                seen.add(h['url'])
                results.append(h)
    return results


def _scan_telegram_flow(channel):
    """Escanea un canal público de Telegram con paginación incremental.
    Empieza por las últimas entradas y permite cargar más antiguas a demanda.
    El label de cada enlace es el texto del mensaje (contexto, no solo la URL)."""
    import telegram_scanner
    import html_scanner

    if telegram_scanner.is_private_invite(channel):
        xbmcgui.Dialog().ok("AtresDaily",
            "Es un enlace de invitación a un canal o grupo PRIVADO de Telegram.\n\n"
            "Solo se pueden escanear canales públicos (t.me/nombre).")
        return

    videos = []
    seen = set()
    cursor = None
    first = True

    while True:
        pdp = xbmcgui.DialogProgress()
        pdp.create("Escaneando Telegram",
                   "Leyendo las últimas entradas..." if first else "Cargando más antiguas...")
        try:
            batch, cursor = telegram_scanner.scan_channel_paged(channel, before_id=cursor)
        except Exception as exc:
            xbmc.log(f"[AtresDaily] Error escaneando Telegram {channel[:40]}: {exc}", xbmc.LOGWARNING)
            batch, cursor = [], None
        finally:
            pdp.close()

        added = 0
        for v in batch:
            u = v.get('url', '')
            if u and u not in seen:
                seen.add(u)
                videos.append(v)
                added += 1

        if not videos:
            # Cubre canal inexistente/vacío y también fallo de red.
            xbmcgui.Dialog().ok("AtresDaily",
                "No se pudieron obtener enlaces de vídeo del canal.\n\n"
                "Verifica que el nombre es correcto y el canal es público "
                "(t.me/nombre), que comparte vídeos y que tienes conexión.")
            return

        if not first and added == 0:
            xbmcgui.Dialog().notification("Telegram",
                "Sin enlaces nuevos en las entradas anteriores",
                xbmcgui.NOTIFICATION_INFO, 2500)
        first = False

        options = []
        for v in videos:
            parts = [v.get('title') or v.get('url', '')[:60]]
            dur = v.get('duration')
            if dur:
                parts.append(html_scanner.format_duration(dur))
            size = v.get('filesize')
            if size:
                parts.append(html_scanner.format_size(size))
            ext = v.get('ext', '')
            if ext:
                parts.append(ext.upper())
            options.append(" - ".join(parts))

        more_idx = -1
        if cursor:
            more_idx = len(options)
            options.append("[COLOR cyan]⬇ Cargar más antiguos[/COLOR]")

        sel = xbmcgui.Dialog().select(f"Telegram: {len(videos)} enlaces", options)
        if sel < 0:
            return
        if sel == more_idx:
            continue  # paginar hacia atrás y reabrir la lista acumulada
        chosen = videos[sel]
        chosen_url = chosen.get('url', '')
        if chosen_url:
            _add_to_history(chosen_url, label=chosen.get('title'))
            _resolve_and_play(chosen_url)
        return


# --- Biblioteca de la nube Debrid ---

def debrid_library_menu():
    h = int(sys.argv[1])
    resolver = _get_debrid()
    if resolver is None:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        items = resolver.list_library()
    except Exception as e:
        xbmc.log(f"[AtresDaily/Debrid] biblioteca: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Debrid", "No se pudo cargar tu nube", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h)
        return

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]Tu nube está vacía[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('info.png')})
        xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for it in items:
        size_gb = (it.get('size', 0) or 0) / 1e9
        ready = it.get('ready')
        label = f"{it.get('filename', '?')}  [COLOR grey]({size_gb:.2f} GB)[/COLOR]"
        if not ready:
            label = f"[COLOR grey]{it.get('filename', '?')} ({it.get('status', 'procesando')})[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': ui_utils.media_icon('archivo_video.png')})
        item_id = it.get('id')
        if ready:
            li.setProperty('IsPlayable', 'false')
            li.addContextMenuItems(ui_utils.menu_contextual([
                ("Ver archivos", f"Container.Update({_u(action='debrid_library_files', id=item_id)})"),
                ("Descargar a disco", f"RunPlugin({_u(action='debrid_download', id=item_id, title=it.get('filename', ''))})"),
                ("Borrar de la nube", f"RunPlugin({_u(action='debrid_library_delete', id=item_id)})"),
            ]))
            url = _u(action='debrid_library_play', id=item_id)
        else:
            url = ''
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def debrid_library_files(item_id):
    h = int(sys.argv[1])
    resolver = _get_debrid()
    if resolver is None or not item_id:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        files = resolver.library_files(item_id)
    except Exception as e:
        xbmc.log(f"[AtresDaily/Debrid] archivos: {e}", xbmc.LOGWARNING)
        files = []
    for idx, f in enumerate(files):
        size_gb = (f.get('size', 0) or 0) / 1e9
        li = xbmcgui.ListItem(label=f"{f.get('name', '?')}  [COLOR grey]({size_gb:.2f} GB)[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('archivo_video.png')})
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='debrid_library_play', id=item_id, file=idx),
            listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def debrid_library_play(item_id, file_index=None):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        if file_index is None:
            stream = resolver.resolve_library_item(item_id)
        else:
            stream = resolver.resolve_library_file(item_id, int(file_index))
    except Exception as e:
        xbmc.log(f"[AtresDaily/Debrid] reproducir nube: {e}", xbmc.LOGWARNING)
        stream = None
    if stream:
        _play_resolved_stream(stream)
    else:
        xbmcgui.Dialog().notification("Debrid", "No se pudo reproducir", xbmcgui.NOTIFICATION_WARNING, 3000)


def debrid_library_delete(item_id):
    if not item_id:
        return
    if not xbmcgui.Dialog().yesno("Debrid", "¿Borrar este elemento de tu nube?"):
        return
    resolver = _get_debrid()
    if resolver is None:
        return
    try:
        resolver.delete_library_item(item_id)
    except Exception as e:
        xbmc.log(f"[AtresDaily/Debrid] borrar nube: {e}", xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def debrid_download(item_id, title=""):
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        stream = resolver.resolve_library_item(item_id)
    except Exception as e:
        xbmc.log(f"[AtresDaily/Debrid] descargar nube: {e}", xbmc.LOGWARNING)
        stream = None
    if not stream:
        xbmcgui.Dialog().notification("Debrid", "No se pudo resolver para descargar", xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    title = title or "video"
    ext = os.path.splitext(urllib.parse.urlparse(stream).path)[1].lower()
    if ext not in _STREAM_EXTENSIONS:
        ext = ".mp4"
    dest = _get_download_dest(title, ext)
    if not dest:
        return
    _download_direct_url(stream, dest, title)


# --- yt-dlp embebido, que se instala al primer uso ---

def _get_ytdlp_pkg_path():
    pkg_path = os.path.join(_get_profile(), "packages")
    if not os.path.exists(pkg_path):
        os.makedirs(pkg_path)
    return pkg_path


def _ensure_ytdlp():
    """Descarga el wheel py3-none-any de yt-dlp desde PyPI si no está ya extraído."""
    import requests
    pkg_path = _get_ytdlp_pkg_path()
    ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
    if os.path.isdir(ytdlp_dir):
        return True
    try:
        pypi_r = requests.get("https://pypi.org/pypi/yt-dlp/json", timeout=15)
        if pypi_r.status_code != 200:
            return False
        whl_url = None
        for u in pypi_r.json().get("urls", []):
            if u["filename"].endswith(".whl") and "py3-none-any" in u["filename"]:
                whl_url = u["url"]
                break
        if not whl_url:
            return False
        whl_r = requests.get(whl_url, timeout=120)
        if whl_r.status_code != 200:
            return False
        whl_data = io.BytesIO(whl_r.content)
        with zipfile.ZipFile(whl_data) as zf:
            for member in zf.namelist():
                if member.startswith("yt_dlp/"):
                    zf.extract(member, pkg_path)
        return os.path.isdir(ytdlp_dir)
    except (requests.RequestException, ValueError, OSError, zipfile.BadZipFile) as e:
        xbmc.log(f"[AtresDaily/url_player] Error descargando yt-dlp: {e}", xbmc.LOGWARNING)
    return False


def _find_system_python():
    """Comando del primer Python >= 3.10 en PATH, o None."""
    no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    for py in ["python", "python3", "py"]:
        try:
            r = subprocess.run(
                [py, "-c", "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}'); assert v >= (3,10)"],
                capture_output=True, text=True, timeout=5, creationflags=no_win)
            if r.returncode == 0:
                return py
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            continue
    return None


# --- Descargas a disco ---

def _get_download_dest(title, ext=".mp4"):
    """Pide carpeta destino y devuelve la ruta final, '' si el usuario cancela."""
    saved_path = ''
    try:
        cfg = ui_utils.load_json('settings.json')
        if isinstance(cfg, dict):
            saved_path = cfg.get('download_path', '')
    except Exception:
        saved_path = ''

    dest_dir = xbmcgui.Dialog().browse(3, "Selecciona dónde guardar", "video",
                                       "", False, False, saved_path)
    if not dest_dir:
        return ''
    safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
    if not safe_title:
        safe_title = f"atresdaily_download_{int(time.time())}"
    if len(safe_title) > 120:
        safe_title = safe_title[:120].rstrip()
    return os.path.join(dest_dir, f"{safe_title}{ext}")


def _download_direct_url(url, dest, title, headers=None):
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando", f"Conectando: {title}")
    tmp = dest + ".tmp"
    try:
        req_headers = headers or {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/120.0.0.0 Safari/537.36',
        }
        r = requests.get(url, headers=req_headers, stream=True, timeout=30)
        if r.status_code >= 400:
            raise RuntimeError(f"El servidor respondió con código {r.status_code}")
        total = int(r.headers.get('content-length', 0))
        done = 0
        with open(tmp, 'wb') as f:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if dp.iscanceled():
                    break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    pct = int(done * 100 / total)
                    dp.update(pct, f"{done / (1024 * 1024):.1f} MB / {total / (1024 * 1024):.1f} MB")
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            xbmcgui.Dialog().ok("AtresDaily", f"Descarga completada:\n{dest}")
        elif os.path.exists(tmp):
            os.remove(tmp)
    except (OSError, RuntimeError) as exc:
        try:
            dp.close()
        except RuntimeError:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log(f"[AtresDaily/url_player] Error descarga directa: {exc}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("AtresDaily", f"Error en la descarga:\n{str(exc)[:200]}")


def _download_hls_stream(playlist_url, dest, title, headers=None):
    """Concatena los .ts de un m3u8 a disco. Acepta headers arbitrarios."""
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    req_headers = headers or {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                      'AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/120.0.0.0 Safari/537.36',
    }
    clean_url = playlist_url.split("|")[0] if "|" in playlist_url else playlist_url
    tmp = dest + ".tmp"
    try:
        params = "?" + clean_url.split("?")[1] if "?" in clean_url else ""
        m3u8_text = requests.get(clean_url, headers=req_headers, timeout=15).text
        segments = [ln for ln in m3u8_text.splitlines() if ln and not ln.startswith("#")]
        if not segments:
            dp.close()
            xbmcgui.Dialog().ok("AtresDaily", "La lista de reproducción está vacía.")
            return
        with open(tmp, 'wb') as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled():
                    break
                if seg_name.startswith("http"):
                    seg_url = seg_name
                else:
                    seg_url = urllib.parse.urljoin(clean_url, seg_name)
                    if params and "?" not in seg_url:
                        seg_url += params
                success = False
                for _attempt in range(3):
                    try:
                        seg_data = requests.get(seg_url, headers=req_headers, timeout=12).content
                        f_out.write(seg_data)
                        success = True
                        break
                    except (requests.RequestException, OSError):
                        continue
                if not success:
                    raise RuntimeError(f"Fallo en segmento {idx + 1}/{len(segments)}")
                pct = int((idx + 1) * 100 / len(segments))
                dp.update(pct, f"Segmento {idx + 1}/{len(segments)} - {title}")
        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            xbmcgui.Dialog().ok("AtresDaily", f"Descarga HLS completada:\n{dest}")
        elif os.path.exists(tmp):
            os.remove(tmp)
    except Exception as exc:
        try:
            dp.close()
        except RuntimeError:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        xbmc.log(f"[AtresDaily/url_player] Error HLS download: {exc}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("AtresDaily", f"Error en descarga HLS:\n{str(exc)[:200]}")


def _download_via_ytdlp(url, dest, title):
    """Descarga vía yt-dlp en un subproceso (Python del sistema). Solo escritorio."""
    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok("AtresDaily",
            "Las descargas con yt-dlp no están disponibles en Android.\n\n"
            "Usa un PC con Python 3.10+ instalado.")
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Descarga con yt-dlp", "Preparando...")
    try:
        dp.update(2, "Buscando Python del sistema...")
        py_cmd = _find_system_python()
        if not py_cmd:
            dp.close()
            xbmcgui.Dialog().ok("AtresDaily",
                "Se necesita Python 3.10+ instalado.\n\n"
                "Descárgalo de python.org marcando 'Add to PATH'.\n\n"
                "Después reinicia Kodi.")
            return

        pkg_path = _get_ytdlp_pkg_path()
        if not os.path.isdir(os.path.join(pkg_path, "yt_dlp")):
            dp.update(5, "Descargando yt-dlp (~3 MB)...")
            if not _ensure_ytdlp():
                dp.close()
                xbmcgui.Dialog().ok("AtresDaily",
                    "Error al descargar yt-dlp.\nComprueba tu conexión a internet.")
                return

        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        progress_file = os.path.join(pkg_path, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)
        helper_path = os.path.join(pkg_path, "_dl_helper.py")
        script = (
            "import sys, os, json\n"
            "sys.path.insert(0, {pkg!r})\n"
            "import yt_dlp\n"
            "progress_file = {pf!r}\n"
            "def hook(d):\n"
            "    info = {{'status': d.get('status', ''), 'percent': 0, 'text': ''}}\n"
            "    if d['status'] == 'downloading':\n"
            "        total = d.get('total_bytes') or d.get('total_bytes_estimate') or 0\n"
            "        done = d.get('downloaded_bytes', 0)\n"
            "        speed = d.get('speed') or 0\n"
            "        if total > 0:\n"
            "            info['percent'] = int(done * 100 / total)\n"
            "            sp = speed / (1024*1024) if speed else 0\n"
            "            info['text'] = f\"{{done/(1024*1024):.1f}}MB / {{total/(1024*1024):.1f}}MB ({{sp:.1f}} MB/s)\"\n"
            "        elif done > 0:\n"
            "            info['percent'] = 50\n"
            "            info['text'] = f\"Descargando: {{done/(1024*1024):.1f}}MB\"\n"
            "    elif d['status'] == 'finished':\n"
            "        info['percent'] = 95\n"
            "        info['text'] = 'Finalizando...'\n"
            "    with open(progress_file, 'w') as f:\n"
            "        json.dump(info, f)\n"
            "opts = {{'format': 'best[ext=mp4]/best', 'outtmpl': {dest!r}, 'quiet': True,\n"
            "        'no_warnings': True, 'progress_hooks': [hook], 'noprogress': True}}\n"
            "try:\n"
            "    yt_dlp.YoutubeDL(opts).download([{url!r}])\n"
            "    with open(progress_file, 'w') as f:\n"
            "        json.dump({{'status': 'done', 'percent': 100, 'text': 'Completado'}}, f)\n"
            "except Exception as e:\n"
            "    with open(progress_file, 'w') as f:\n"
            "        json.dump({{'status': 'error', 'percent': 0, 'text': str(e)[:300]}}, f)\n"
        ).format(pkg=pkg_path, pf=progress_file, dest=dest, url=url)
        with open(helper_path, 'w', encoding='utf-8') as f:
            f.write(script)

        dp.update(10, "Iniciando descarga...")
        no_win = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
        proc = subprocess.Popen([py_cmd, helper_path],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                creationflags=no_win)
        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, 'r') as f:
                        info = json.loads(f.read())
                    dp.update(info.get('percent', 0), info.get('text', 'Descargando...'))
                except Exception:
                    pass
            time.sleep(0.5)
        dp.close()

        for tmp in (helper_path, progress_file):
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass

        if cancelled:
            for ext in ("", ".part"):
                p = dest + ext
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            return

        if proc.returncode == 0 and os.path.exists(dest):
            xbmcgui.Dialog().ok("AtresDaily", f"Descarga completada:\n{dest}")
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode('utf-8', errors='replace')[:200]
            except Exception:
                pass
            xbmcgui.Dialog().ok("AtresDaily", f"Error en la descarga:\n{stderr or 'Desconocido'}")
    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log(f"[AtresDaily/url_player] Error yt-dlp download: {exc}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("AtresDaily", f"Error al preparar la descarga:\n{str(exc)[:200]}")


def _resolve_and_download(raw_url):
    url_type, value = detect_url_type(raw_url)

    if url_type in ('dailymotion', 'youtube', 'web_page'):
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok("AtresDaily",
                "La descarga de este contenido requiere yt-dlp.\n\n"
                "Solo está disponible en PC (Windows/Linux/Mac) con Python 3.10+.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == 'direct_stream':
        url, headers = parse_url_with_headers(raw_url)
        label = _auto_label(raw_url) or "stream"
        clean_path = urllib.parse.urlparse(url).path.lower()
        if clean_path.endswith(".m3u8"):
            dest = _get_download_dest(label, ext=".ts")
            if not dest:
                return
            if not xbmcgui.Dialog().yesno("Descarga HLS",
                    "Este stream se descargará por segmentos.\n"
                    "El proceso puede ser lento. ¿Continuar?"):
                return
            _download_hls_stream(url, dest, label, headers=headers or None)
        else:
            ext = os.path.splitext(clean_path)[1] or ".mp4"
            dest = _get_download_dest(label, ext=ext)
            if not dest:
                return
            _download_direct_url(url, dest, label, headers=headers or None)

    else:
        xbmcgui.Dialog().ok("AtresDaily",
            "Este tipo de contenido no se puede descargar.\n\n"
            "Tipos descargables: Dailymotion, YouTube, streams directos y páginas web.")
