# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en BitChute vía su API REST pública (la web es una SPA; no hay HTML
# scrapeable). Dos llamadas:
#   1) /search/videos devuelve metadatos (sin URL de stream).
#   2) Al reproducir, /video/media entrega el MP4 directo.
# La API ignora la query cuando no hay coincidencias y devuelve el catálogo entero,
# así que se aplica un filtro de relevancia local sobre los resultados.
import hashlib
import html
import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_API_SEARCH = "https://api.bitchute.com/api/beta/search/videos"
_API_MEDIA  = "https://api.bitchute.com/api/beta/video/media"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Referer": "https://www.bitchute.com/",
}

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.atresdaily/search_cache/")
_CACHE_TTL = 3600  # segundos

_TAG_RX = re.compile(r"<[^>]+>")

# Palabras comunes (es/en) que no aportan relevancia: se excluyen al filtrar para que
# no dejen pasar resultados irrelevantes cuando la API devuelve el catálogo entero.
_STOPWORDS = {
    "los", "las", "una", "unos", "unas", "con", "por", "para", "que", "del",
    "como", "este", "esta", "esto", "esos", "esas", "sus", "mas", "muy", "sin",
    "son", "the", "and", "for", "you", "that", "this", "with", "from", "what",
}


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    # tmp único por proceso + os.replace atómico (igual que peertube_search).
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _post_json(url, payload, timeout=15):
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=_HEADERS, method="POST")
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _norm(s):
    """minúsculas sin acentos, para comparar de forma laxa."""
    s = (s or "").lower()
    return "".join(c for c in unicodedata.normalize("NFKD", s)
                   if not unicodedata.combining(c))


def _strip_html(s):
    return _TAG_RX.sub(" ", s or "").strip()


def _parse_dur(s):
    """'mm:ss' o 'hh:mm:ss' -> segundos. 0 si no se puede parsear."""
    if not s:
        return 0
    try:
        secs = 0
        for part in str(s).strip().split(":"):
            secs = secs * 60 + int(part)
        return secs
    except ValueError:
        return 0


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _filter_relevant(query, results):
    """La API devuelve el catálogo entero cuando la query no casa con nada; nos quedamos
    solo con los resultados cuyo título/canal/descripción contienen algún token de la query.
    Con queries muy cortas (sin tokens > 2) no se puede filtrar con fiabilidad: se deja pasar."""
    tokens = [t for t in _norm(query).split() if len(t) > 2 and t not in _STOPWORDS]
    if not tokens:
        return results
    out = []
    for r in results:
        texto = _norm(f"{r['title']} {r['channel']} {r['description']}")
        if any(t in texto for t in tokens):
            out.append(r)
    return out


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "bitchute_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached

    payload = {"query": query, "sensitivity_id": "normal", "sort": "new", "offset": 0}
    data = _post_json(_API_SEARCH, payload)
    items = data.get("videos") if isinstance(data, dict) else None
    results = []
    for v in (items or []):
        vid = v.get("video_id")
        if not vid:
            continue
        ch = v.get("channel")
        channel = ch.get("channel_name", "") if isinstance(ch, dict) else ""
        results.append({
            "video_id":    vid,
            "title":       html.unescape(v.get("video_name", "") or ""),
            "channel":     html.unescape(channel),
            "thumb":       v.get("thumbnail_url", ""),
            "duration":    _parse_dur(v.get("duration", "")),
            "description": html.unescape(_strip_html(v.get("description", ""))),
        })
    results = _filter_relevant(query, results)
    _cache_set(key, results)
    return results


def resolve_stream(video_id):
    if not video_id:
        return ""
    try:
        data = _post_json(_API_MEDIA, {"video_id": video_id})
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return ""   # vídeo inexistente/eliminado
        raise
    return data.get("media_url", "") if isinstance(data, dict) else ""


def play_item(handle, video_id):
    """Resuelve y reproduce un vídeo de BitChute. Llamado por default.py action=bitchute_play."""
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Resolviendo stream de BitChute...")
    try:
        stream_url = resolve_stream(video_id)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error resolviendo BitChute: {e}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("AtresDaily", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("AtresDaily", "No se pudo obtener la URL de reproducción de BitChute.")
        return

    xbmc.log(f"[AtresDaily] BitChute stream: {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if stream_url.lower().split("?")[0].endswith(".m3u8"):  # casi todo es MP4
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(handle, True, li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", f"Buscando en BitChute: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error buscando en BitChute: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error al buscar en BitChute:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("AtresDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'bitchute_play', 'video_id': r['video_id']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:300])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
