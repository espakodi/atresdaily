# -*- coding: utf-8 -*-
# Necesaria en Kodi 19-21 (Python 3.8/3.9): bpo-38755 parte las secuencias UTF-8 en
# líneas largas al leer el .py, y este fichero tiene una de 5590 bytes con tildes.
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import os
import json
import time
import traceback
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import core_settings
import requests
import ui_utils

from plugin_utils import _u, _handle

# Utilidades

def _get_thumb_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, f"trakt_thumbs_{list_id}.json")

def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

def _get_top_movies_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, "top_movies_thumbs.json")

def _load_top_movies_cache():
    path = _get_top_movies_cache_path()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception: pass
    return {}

_MSG_NO_KEY = (
    "No hay ninguna Client ID de Trakt configurada.\n"
    "Ponla en Opciones / Importar → Configurar API Key."
)

_MSG_TOPZILLA = (
    "La versión completa de Trakt (tu cuenta, watchlist, listas personales y "
    "sincronización) está en TopZilla."
)

_MSG_FORBIDDEN = (
    "Trakt ha rechazado la petición (403).\n"
    "Casi siempre significa que la Client ID configurada ya no es válida: revisa que la copiaste "
    "entera, que la app sigue existiendo en developer.trakt.tv y que no ha sido "
    "borrada por 30 días sin uso.\n"
    "En listas concretas también ocurre si el perfil del dueño de la lista es privado.\n\n"
    + _MSG_TOPZILLA
)


_PAGINA = 250          # máximo que acepta Trakt; por defecto pagina de 100 en 100
_LISTA_TTL_S = 86400
_TMDBHELPER_ID = "plugin.video.themoviedb.helper"


def _tmdbhelper_list_url(list_id, user):
    """URL para abrir la colección en TMDb Helper, o None si no está instalado.

    TMDb Helper lleva su propia clave de Trakt, así que sirve de salida cuando la
    nuestra falla. Su ruta pide el slug de la lista, pero Trakt acepta ahí el id
    numérico, así que no hay que guardar slugs aparte.
    """
    if not user or not xbmc.getCondVisibility(f"System.AddonIsEnabled({_TMDBHELPER_ID})"):
        return None
    params = urllib.parse.urlencode({
        'info': 'trakt_userlist', 'list_slug': list_id, 'user_slug': user})
    return f"plugin://{_TMDBHELPER_ID}/?{params}"


def _get_items_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, f"trakt_items_{list_id}.json")


def _clear_items_cache(list_id):
    try:
        path = _get_items_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
    except OSError as e:
        xbmc.log(f"[AtresDaily-TM] no se pudo borrar caché de {list_id}: {e}", xbmc.LOGWARNING)


def _fetch_list_items(list_id, key):
    """Todas las páginas de una lista, con caché de un día. Devuelve (items, error).

    Se pide sin extended=full, que multiplica por cinco lo que manda Trakt por ítem;
    lo único que se pierde (overview, tagline) lo sobrescribe metadata_enricher con
    TMDB en español."""
    path = _get_items_cache_path(list_id)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            guardado = json.load(f)
        if time.time() - guardado['ts'] < _LISTA_TTL_S:
            return guardado['items'], None
    except (OSError, ValueError, KeyError, TypeError):
        pass

    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
    url = f'https://api.trakt.tv/lists/{list_id}/items'
    items = []
    pagina = 1
    while True:
        try:
            r = requests.get(url, params={'limit': _PAGINA, 'page': pagina}, headers=headers, timeout=20)
        except requests.RequestException as e:
            xbmc.log(f"[AtresDaily-TM] lista {list_id} pág {pagina}: {e}", xbmc.LOGWARNING)
            return None, "No se pudo conectar con Trakt"

        err = _trakt_error_msg(r)
        if err:
            return None, err
        try:
            lote = r.json()
        except ValueError:
            return None, "Respuesta no válida"
        if not isinstance(lote, list):
            return None, "Respuesta no válida"

        items.extend(lote)
        try:
            total_paginas = int(r.headers.get('X-Pagination-Page-Count', 1))
        except (TypeError, ValueError):
            total_paginas = 1
        if not lote or pagina >= total_paginas:
            break
        pagina += 1

    try:
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'ts': int(time.time()), 'items': items}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log(f"[AtresDaily-TM] no se pudo guardar caché de {list_id}: {e}", xbmc.LOGWARNING)
    return items, None


def _trakt_error_msg(r):
    """None si la respuesta vale; si no, el texto que se muestra al usuario."""
    if r.status_code == 200:
        return None
    if r.status_code == 403:
        return _MSG_FORBIDDEN
    # Trakt responde 204 (no 404) cuando la colección ya no existe.
    if r.status_code in (204, 404):
        return "Esa colección ya no existe o dejó de ser pública."
    if r.status_code == 401:
        return "Esta colección requiere autorización de usuario (OAuth), que el addon no soporta."
    return f"Trakt respondió con código {r.status_code}. Inténtalo más tarde.\n\n{_MSG_TOPZILLA}"

# Diálogo de búsqueda en varias plataformas

def _check_estuary_palantir_fix():
    """True si el skin Estuary Palantir no necesita el arreglo (no está activo o ya
    está parcheado)."""
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        return True
    
    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')
    
    if not os.path.exists(includes_xml):
        return True  # sin el archivo no se puede comprobar
    
    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        
        patch_marker = '<!-- ATRESDAILY_PATCH_VIDEOS -->'
        espadaily_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'
        
        if patch_marker in content or espadaily_marker in content:
            return True
        
        return False
    except Exception:
        return True

def search_dialog(query):
    """
    Muestra un diálogo para elegir dónde buscar: Dailymotion, Elementum,
    Palantir o el addon externo de Dailymotion (Gujal).
    Todas las opciones muestran un teclado con el texto pre-rellenado
    para que el usuario pueda editarlo antes de buscar.
    """
    if not query: return

    options = [
        "[COLOR gold]Editar búsqueda / Reintentar...[/COLOR]",
        "Buscar en webs de torrent (Elementum)"
    ]
    actions = ["retry", "elementum"]
    # Solo si está instalado.
    try:
        if core_settings.get_palantir_addon_id():
            options.append("[COLOR orange]Buscar en Palantir[/COLOR]")
            actions.append("palantir")
    except Exception: pass

    # Solo si está instalado.
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.balandro)"):
            options.append("[COLOR chartreuse]Buscar en Balandro[/COLOR]")
            actions.append("balandro")
    except Exception: pass

    # Solo si está instalado.
    try:
        if core_settings.is_jacktook_installed():
            options.append("[COLOR yellow]Buscar en Jacktook[/COLOR]")
            actions.append("jacktook")
    except Exception: pass

    # Solo si está instalado.
    try:
        if core_settings.get_alfa_addon_id():
            options.append("[COLOR cyan]Buscar en Alfa[/COLOR]")
            actions.append("alfa")
    except Exception: pass

    # YouTube
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            options.append("[COLOR red]Buscar en YouTube[/COLOR]")
            actions.append("youtube")
    except Exception: pass

    # Atajos personalizados del usuario
    try:
        import search_shortcuts_manager as ssm
        for s in ssm.load_active_shortcuts():
            if s.get('type') == 'builtin':
                continue
            options.append(s.get('name', '?'))
            actions.append(('custom', s))
    except Exception:
        pass

    sel = xbmcgui.Dialog().select(f"Buscar: {query}", options)
    if sel < 0: return

    choice = actions[sel]

    if choice == "retry":
        nq = ui_utils.get_text('Editar búsqueda', query or '')
        if nq:
            search_dialog(nq)

    elif choice == "elementum":
        nq = ui_utils.get_text('Buscar en webs de torrent', query or '')
        if nq:
            xbmc.executebuiltin(
                f"RunPlugin({_u(action='elementum_search', q=nq)})")

    elif choice == "palantir":
        if not _check_estuary_palantir_fix():
            if xbmcgui.Dialog().yesno("AtresDaily",
                "Tienes la skin [B]Estuary Palantir[/B] instalada pero SIN el fix de compatibilidad.\n\n"
                "Sin el fix, puede que veas una pantalla negra al mostrar resultados de Palantir.\n\n"
                "¿Quieres instalar el fix ahora? (Después se buscará automáticamente)"):
                xbmc.executebuiltin(f"RunPlugin({_u(action='toggle_estuary_palantir_fix')})")
                xbmc.sleep(2000)

        xbmc.executebuiltin(
            f"RunPlugin({_u(action='palantir_search_prompt', q=query)})")

    elif choice == "balandro":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_balandro_from_results', q=query)})")

    elif choice == "jacktook":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_jacktook_from_results', q=query)})")

    elif choice == "alfa":
        xbmc.executebuiltin(
            f"RunPlugin({_u(action='search_alfa_from_results', q=query)})")

    elif choice == "youtube":
        nq = ui_utils.get_text('Buscar en YouTube', query or '').strip()
        if nq:
            url = _u(action='yt_html_search', q=nq)
            xbmc.executebuiltin(f'Container.Update({url})')

    elif isinstance(choice, tuple) and choice[0] == 'custom':
        s = choice[1]
        cmd = s.get('command', '')
        addon_id = s.get('addon_id')
        if cmd and (not addon_id or ui_utils.addon_listo(addon_id, s.get('name') or addon_id)):
            xbmc.executebuiltin(cmd.replace('{query}', urllib.parse.quote_plus(query)))

def _meta_flag_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'trakt_meta_downloaded.flag')


def _meta_items_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'trakt_meta_items.json')


def _has_trakt_meta():
    return os.path.exists(_meta_flag_path())




def menu_trakt_root():
    # Asegurar listas por defecto
    core_settings.seed_default_trakt_lists()
    icon_dir = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    if not core_settings.get_trakt_api_key():
        li = xbmcgui.ListItem(label="[COLOR orange]Trakt: falta configurar la Client ID[/COLOR]")
        li.setArt({'icon': os.path.join(icon_dir, 'aviso.png')})
        li.setInfo('video', {'plot': _MSG_NO_KEY})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Actualizar nombres y datos[/B][/COLOR]")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_actualizar_v2.png')})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_refresh_defaults"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar[/COLOR]")
    li.setArt({'icon': os.path.join(icon_dir, 'opciones.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Mejores Películas")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_pelis_top.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="mejores_peliculas"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="FilmAffinity")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_filmaffinity.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="filmaffinity_root"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="SensaCine")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_sensacine.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_root"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Cinemeta - Top Películas")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_cinemeta.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cinemeta_top"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Rankings de TMDB")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_trakt.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="tmdb_lists_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_peliculas.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)
    
    # Listas importadas
    lists = core_settings.get_trakt_lists()
    for l in lists:
        list_id = l.get('id')
        list_name = l.get('name', f'Lista {list_id}')
        if not list_id: continue
        count = l.get('item_count', 0)
        label = f"{list_name} [COLOR gray]({count} ítems)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': os.path.join(icon_dir, 'cat_trakt.png')})
        li.setInfo('video', {'plot': f"ID: {list_id}\nUsuario: {l.get('user', '?')}\nTotal: {count} elementos."})
        
        cm = [("Eliminar de mi colección", f"RunPlugin({_u(action='trakt_delete_list', list_id=list_id)})")]
        destino = _tmdbhelper_list_url(list_id, l.get('user'))
        if destino:
            cm.append(("Abrir en TMDb Helper", f"Container.Update({destino})"))
        li.addContextMenuItems(ui_utils.menu_contextual(cm))
        
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=list_id), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label=f"{ui_utils.punto('topzilla')}[COLOR gold]¿Quieres Trakt completo? Está en TopZilla[/COLOR]")
    li.setArt({'icon': os.path.join(icon_dir, 'cat_trakt.png')})
    li.setInfo('video', {'plot': "Esto es una muestra de las colecciones de Trakt.\n\n"
                                 + _MSG_TOPZILLA
                                 + "\n\nPulsa para abrirlo; si no lo tienes, te ofrece instalarlo."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="topzilla_launch"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())


def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().ok("AtresDaily", _MSG_NO_KEY)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar", xbmcgui.NOTIFICATION_INFO)
        return
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': api_key}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", "Actualizando listas de Trakt...")
    total = len(lists)
    ok = 0
    first_err = None
    cancelado = False
    try:
        for i, l in enumerate(lists):
            if pDialog.iscanceled():
                cancelado = True
                break
            pDialog.update(int((i / total) * 100), f"({i+1}/{total}) {l.get('name', l.get('id', '?'))}")
            # "Actualizar" tiene que traer datos frescos, no los de la caché de ayer.
            _clear_items_cache(l['id'])
            try:
                r = requests.get(f"https://api.trakt.tv/lists/{l['id']}", headers=headers, timeout=5)
                err = _trakt_error_msg(r)
                if err:
                    first_err = first_err or err
                    continue
                data = r.json()
                l['name'] = data.get('name', l.get('name', ''))
                l['user'] = data.get('user', {}).get('username', l.get('user', 'official')) if isinstance(data.get('user'), dict) else l.get('user', 'official')
                l['item_count'] = data.get('item_count', l.get('item_count', 0))
                ok += 1
            except (requests.RequestException, ValueError) as e:
                xbmc.log(f"[AtresDaily-TM] refresh {l['id']}: {e}", xbmc.LOGWARNING)
    finally:
        pDialog.close()
    if not ok:
        if not cancelado:
            xbmcgui.Dialog().ok("AtresDaily", first_err or "No se pudo actualizar ninguna lista.")
        return
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    msg = "Listas actualizadas correctamente" if ok == total else f"Listas actualizadas: {ok}/{total}"
    xbmcgui.Dialog().notification("AtresDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _media_icon(name):
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', name)


def menu_options():
    li = xbmcgui.ListItem(label="[COLOR yellow]Guía: Cómo obtener tu API Key (Paso a Paso)[/COLOR]")
    li.setArt({'icon': _media_icon('info.png')})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)

    # Client ID de Trakt
    user_key = core_settings.get_trakt_settings().get("api_key", "")
    if user_key:
        key_label = "Configurar API Key [COLOR green]PROPIA ACTIVA[/COLOR]"
        key_plot = f"Tienes tu propia Client ID configurada.\nPulsa para cambiarla o quitarla.\nClave activa: {user_key[:12]}..."
    else:
        key_label = "Configurar API Key [COLOR orange]NO CONFIGURADA[/COLOR]"
        key_plot = "El addon trae su propia clave y funciona sin configurar nada.\nSi prefieres usar la tuya, pulsa para introducir tu Client ID de Trakt.tv."

    li = xbmcgui.ListItem(label=key_label)
    li.setArt({'icon': _media_icon('adv_trakt.png')})
    li.setInfo('video', {'plot': key_plot})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)

    # Importar una lista por su id
    key = core_settings.get_trakt_api_key()
    if key:
        li = xbmcgui.ListItem(label="Importar Colección por ID")
        li.setArt({'icon': _media_icon('backup_restore.png')})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la colección pública de Trakt (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Importar colecciones desde EspaTV")
    li.setArt({'icon': _media_icon('cat_trakt.png')})
    li.setInfo('video', {'plot': "Copia las colecciones que tengas guardadas en EspaTV a AtresDaily.\nSolo añade las que no tengas ya."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import_espatv"), listitem=li, isFolder=False)

    # Metadatos de TMDB en español
    if _has_trakt_meta():
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos TMDB de Trakt[/COLOR]")
        li.setArt({'icon': _media_icon('backup_delete.png')})
        li.setInfo('video', {'plot': "Elimina los metadatos TMDB guardados para todas las listas de Trakt."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_all_meta"), listitem=li, isFolder=False)
    elif key:
        li = xbmcgui.ListItem(label="Metadatos TMDB en español (sinopsis, director, actores)")
        li.setArt({'icon': _media_icon('descargas.png')})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, director y reparto de TMDB para todas las listas de Trakt.\nSustituye los textos en inglés de Trakt por los datos completos en español."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_cache_all_meta"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())


def help_guide():
    lines = [
        "PASO 1: Cuenta de Trakt",
        "Regístrate gratis en [B]trakt.tv[/B] si no tienes cuenta.",
        "",
        "PASO 2: Cuenta de GitHub",
        "Trakt exige vincular una cuenta de GitHub verificada para crear apps.",
        "Si no tienes, créala en [B]github.com[/B].",
        "",
        "PASO 3: Portal de desarrolladores",
        "Entra en [B]developer.trakt.tv[/B], pulsa [B]My Apps[/B] y luego [B]Connect GitHub[/B].",
        "Solo hace falta una vez.",
        "",
        "PASO 4: Crea la app",
        "Pulsa [B]Create app[/B]. Nombre: el que quieras (ej: 'MiKodi').",
        "Redirect URI: [B]urn:ietf:wg:oauth:2.0:oob[/B]. Guarda.",
        "",
        "PASO 5: Copia el Client ID",
        "En la página de la app verás el campo [B]Client ID[/B]. Cópialo entero.",
        "",
        "PASO 6: Pégalo en el addon",
        "Vuelve aquí, elige [B]Configurar API Key[/B] y pégalo.",
        "",
        "AVISO: Trakt borra las apps que pasan 30 días seguidos sin uso.",
        "Si dejas de usar las colecciones un mes, tendrás que crear la app otra vez.",
    ]
    xbmcgui.Dialog().textviewer("Cómo obtener tu API Key de Trakt.tv", "\n".join(lines))


def set_api_key():
    user_key = core_settings.get_trakt_settings().get("api_key", "")
    options = ["Introducir / cambiar mi API Key"]
    if user_key:
        options.append("Quitar mi API Key personal")
    options.append("Cancelar")

    idx = xbmcgui.Dialog().select("Configurar API Key de Trakt", options)
    if idx < 0 or options[idx] == "Cancelar":
        return

    if options[idx] == "Quitar mi API Key personal":
        if xbmcgui.Dialog().yesno("Quitar API Key personal", "Se eliminará tu Client ID personal y el addon volverá a usar la suya.\n¿Confirmas?"):
            core_settings.set_trakt_api_key("")
            xbmcgui.Dialog().notification("AtresDaily", "API Key personal eliminada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        return

    # Introducir nueva clave
    new_key = ui_utils.get_text("Introduce tu Client ID de Trakt.tv", user_key or '').strip()
    if not new_key:
        xbmcgui.Dialog().notification("AtresDaily", "No se introdujo ninguna clave", xbmcgui.NOTIFICATION_WARNING)
        return

    # Validar contra la API de Trakt
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", "Validando API Key...")
    try:
        headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': new_key}
        # Endpoint público y sin dueño: un 403 aquí solo puede ser la clave.
        r = requests.get('https://api.trakt.tv/movies/popular?limit=1', headers=headers, timeout=10)
        pDialog.close()
        if r.status_code == 200:
            core_settings.set_trakt_api_key(new_key)
            xbmcgui.Dialog().notification("AtresDaily", "API Key guardada correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        elif r.status_code == 403:
            xbmcgui.Dialog().ok("Client ID no reconocida", "Trakt no reconoce esta Client ID.\nRevisa que la copiaste entera, que la app existe en developer.trakt.tv y que no ha sido borrada por 30 días sin uso.")
        else:
            xbmcgui.Dialog().ok("AtresDaily", f"Trakt respondió con código {r.status_code}. Inténtalo más tarde.")
    except requests.RequestException as e:
        pDialog.close()
        xbmcgui.Dialog().ok("Error de red", f"No se pudo conectar con Trakt.tv:\n{e}")


def import_list():
    kb = xbmc.Keyboard("", "ID de la colección de Trakt (número)")
    kb.doModal()
    if not kb.isConfirmed():
        return
    list_id = kb.getText().strip()
    if not list_id.isdigit():
        xbmcgui.Dialog().notification("AtresDaily", "El ID debe ser un número", xbmcgui.NOTIFICATION_WARNING)
        return

    existing = {l['id'] for l in core_settings.get_trakt_lists()}
    if list_id in existing:
        xbmcgui.Dialog().notification("AtresDaily", "Esa colección ya está importada", xbmcgui.NOTIFICATION_INFO)
        return

    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("AtresDaily", _MSG_NO_KEY)
        return
    headers = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': key}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", f"Consultando lista {list_id}...")
    try:
        r = requests.get(f'https://api.trakt.tv/lists/{list_id}', headers=headers, timeout=10)
        pDialog.close()
        err = _trakt_error_msg(r)
        if err:
            xbmcgui.Dialog().ok("AtresDaily", err)
        else:
            data = r.json()
            name = data.get('name', f'Lista #{list_id}')
            user = data.get('user', {}).get('username', 'desconocido') if isinstance(data.get('user'), dict) else 'desconocido'
            count = data.get('item_count', 0)
            core_settings.add_trakt_list(list_id, name, user, count)
            xbmcgui.Dialog().notification("AtresDaily", f"Importada: {name}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except (requests.RequestException, ValueError) as e:
        pDialog.close()
        xbmcgui.Dialog().ok("Error de red", f"No se pudo conectar con Trakt.tv:\n{e}")


def import_from_espatv():
    import xbmcvfs as _vfs
    espatv_profile = _vfs.translatePath('special://userdata/addon_data/plugin.video.espatv/')
    espatv_file = os.path.join(espatv_profile, 'trakt_settings.json')
    if not os.path.exists(espatv_file):
        xbmcgui.Dialog().ok("EspaTV no encontrado", "No se encontró el archivo de colecciones de EspaTV.\nAsegúrate de que EspaTV está instalado y tiene colecciones guardadas.")
        return
    try:
        with open(espatv_file, 'r', encoding='utf-8') as f:
            espatv_data = json.load(f)
    except Exception as e:
        xbmcgui.Dialog().ok("Error al leer EspaTV", f"No se pudo leer el archivo de EspaTV:\n{e}")
        return

    source_lists = espatv_data.get('lists', [])
    if not source_lists:
        xbmcgui.Dialog().notification("AtresDaily", "EspaTV no tiene colecciones guardadas", xbmcgui.NOTIFICATION_INFO)
        return

    existing_ids = {l['id'] for l in core_settings.get_trakt_lists()}
    new_lists = [l for l in source_lists if l.get('id') and l['id'] not in existing_ids]
    if not new_lists:
        xbmcgui.Dialog().notification("AtresDaily", "Todas las colecciones de EspaTV ya están importadas", xbmcgui.NOTIFICATION_INFO)
        return

    for lst in new_lists:
        core_settings.add_trakt_list(
            lst['id'],
            lst.get('name', f"Lista #{lst['id']}"),
            lst.get('user', 'espatv'),
            lst.get('item_count', 0),
        )

    xbmcgui.Dialog().notification(
        "AtresDaily",
        f"Importadas {len(new_lists)} colecciones de EspaTV",
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def _collect_all_trakt_items(key, pDialog=None):
    """Devuelve (items, errores). Un error por cada lista que no se pudo leer."""
    lists = core_settings.get_trakt_lists()
    all_items = []
    errors = []
    seen = set()
    total_lists = len(lists)
    for i, lst in enumerate(lists):
        if pDialog and pDialog.iscanceled():
            break
        if pDialog:
            pDialog.update(
                int((i / max(total_lists, 1)) * 100),
                "Lista ({0}/{1}): {2}".format(i + 1, total_lists, lst.get('name', lst['id']))
            )
        try:
            items, err = _fetch_list_items(lst['id'], key)
            if err:
                xbmc.log("[AtresDaily-TM] list {0}: {1}".format(lst['id'], err[:60]), xbmc.LOGWARNING)
                errors.append(err)
                continue
            for item in items:
                if not isinstance(item, dict):
                    continue
                t = item.get('type')
                if t not in ('movie', 'show'):
                    continue
                data = item.get(t)
                if not data:
                    continue
                tmdb_id = data.get('ids', {}).get('tmdb')
                title = data.get('title')
                year = data.get('year')
                media_type = 'show' if t == 'show' else 'movie'
                dedup_key = (tmdb_id or title, year, media_type)
                if dedup_key in seen:
                    continue
                seen.add(dedup_key)
                all_items.append({'tmdb_id': tmdb_id, 'title': title, 'year': year, 'media_type': media_type})
        except Exception as e:
            xbmc.log("[AtresDaily-TM] collect list {0}: {1}".format(lst.get('id'), e), xbmc.LOGWARNING)
    if pDialog and not pDialog.iscanceled():
        pDialog.update(100)
    return all_items, errors


def cache_all_meta():
    import metadata_enricher as me

    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("AtresDaily", _MSG_NO_KEY)
        return

    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().ok("Trakt", "No hay listas configuradas en Trakt.")
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", "Recopilando elementos de las listas de Trakt...")
    all_items = []
    errors = []
    try:
        all_items, errors = _collect_all_trakt_items(key, pDialog)
    except Exception as e:
        pDialog.close()
        xbmc.log("[AtresDaily-TM] collect error: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "No se pudo recopilar los elementos", xbmcgui.NOTIFICATION_ERROR)
        return

    if pDialog.iscanceled():
        pDialog.close()
        return

    if not all_items:
        pDialog.close()
        xbmcgui.Dialog().ok("AtresDaily", errors[0] if errors else "No se encontraron elementos en las listas.")
        return

    pDialog.update(0, "Descargando metadatos TMDB en español...")
    was_cancelled = False
    try:
        count = me.batch_fetch_with_progress(all_items, pDialog)
        was_cancelled = pDialog.iscanceled()
    finally:
        pDialog.close()

    if was_cancelled:
        xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada", xbmcgui.NOTIFICATION_WARNING)
        return

    try:
        items_path = _meta_items_path()
        tmp = items_path + '.tmp'
        os.makedirs(os.path.dirname(items_path), exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(all_items, fh, ensure_ascii=False)
        os.replace(tmp, items_path)
        open(_meta_flag_path(), 'w').close()
    except Exception as e:
        xbmc.log("[AtresDaily-TM] meta flag save error: {0}".format(e), xbmc.LOGWARNING)

    xbmcgui.Dialog().notification(
        "AtresDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(all_items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_all_meta():
    import metadata_enricher as me

    items_path = _meta_items_path()
    flag_path = _meta_flag_path()

    saved_items = []
    if os.path.exists(items_path):
        try:
            with open(items_path, 'r', encoding='utf-8') as fh:
                saved_items = json.load(fh)
        except Exception:
            pass

    deleted_count = 0
    if saved_items:
        me.delete_items(saved_items)
        deleted_count = len(saved_items)
    else:
        key = core_settings.get_trakt_api_key()
        if key:
            items, _ = _collect_all_trakt_items(key)
            if items:
                me.delete_items(items)
                deleted_count = len(items)

    for path in (items_path, flag_path):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    if deleted_count:
        xbmcgui.Dialog().notification(
            "AtresDaily",
            "Metadatos TMDB de Trakt eliminados ({0})".format(deleted_count),
            xbmcgui.NOTIFICATION_INFO,
        )
    else:
        xbmcgui.Dialog().notification(
            "AtresDaily",
            "No habia metadatos TMDB que borrar",
            xbmcgui.NOTIFICATION_INFO,
        )
    xbmc.executebuiltin("Container.Refresh")


def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().ok("AtresDaily", _MSG_NO_KEY)
            xbmcplugin.endOfDirectory(_handle())
            return

        items, err = _fetch_list_items(list_id, key)
        if err:
            user = next((l.get('user') for l in core_settings.get_trakt_lists()
                         if str(l.get('id')) == str(list_id)), '')
            destino = _tmdbhelper_list_url(list_id, user)
            if destino:
                abrir = xbmcgui.Dialog().yesno(
                    "AtresDaily", f"{err}\n\n¿Abrir esta colección en TMDb Helper?",
                    nolabel="Cerrar", yeslabel="Abrir")
            else:
                abrir = False
                xbmcgui.Dialog().ok("AtresDaily", err)
            xbmcplugin.endOfDirectory(_handle())
            if abrir:
                xbmc.executebuiltin(f"Container.Update({destino})")
            return

        import metadata_enricher as me

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        cache = _load_thumb_cache(list_id)
        has_cache = len(cache) > 0

        if not has_cache:
            icon_dir = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
            covers_label = "[COLOR cyan]Carátulas (temporales activas)[/COLOR]" if show_covers else "Carátulas"
            li = xbmcgui.ListItem(label=covers_label)
            li.setArt({'icon': os.path.join(icon_dir, 'cat_caratulas.png')})
            li.setInfo('video', {'plot': "Opciones para mostrar o guardar las carátulas de esta lista."})
            xbmcplugin.addDirectoryItem(
                handle=_handle(),
                url=_u(action="trakt_covers_menu", list_id=list_id, show_covers="1" if show_covers else "0"),
                listitem=li, isFolder=False,
            )
        else:
            li = xbmcgui.ListItem(label="[COLOR red][B]Borrar carátulas guardadas (Volver a carga rápida)[/B][/COLOR]")
            li.setArt({'icon': _media_icon('backup_delete.png')})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la lista vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_clear_cache", list_id=list_id), listitem=li, isFolder=False)

        enrich_targets = []
        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            if t not in ('movie', 'show'): continue
            data = item.get(t)
            if not data: continue
            enrich_targets.append({
                'tmdb_id': data.get('ids', {}).get('tmdb'),
                'title': data.get('title'),
                'year': data.get('year'),
                'media_type': 'show' if t == 'show' else 'movie'
            })

        # Con la paginación una lista puede traer más de mil ítems, así que la
        # descarga va con diálogo cancelable en vez de bloquear Kodi en silencio.
        if show_covers and enrich_targets:
            pd = xbmcgui.DialogProgress()
            pd.create("AtresDaily", "Descargando carátulas...")
            try:
                me.batch_fetch_with_progress(enrich_targets, pd)
            finally:
                pd.close()

        # Una vez por lista y no por ítem, porque si Palantir no está cada llamada lista la
        # carpeta de addons, y las listas paginadas pasan de mil ítems.
        hay_palantir = bool(core_settings.get_palantir_addon_id())
        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            if t not in ('movie', 'show'): continue
            data = item.get(t)
            if not data: continue

            title = data.get('title')
            year = data.get('year')
            overview = data.get('overview', '')
            tagline = data.get('tagline', '')
            
            tmdb_id = data.get('ids', {}).get('tmdb')
            media_type = 'show' if t == 'show' else 'movie'
            item_key = f"{title}_{year}"
            label = f"{title} ({year})" if year else title
            li = xbmcgui.ListItem(label=label)

            meta = me.enrich(tmdb_id=tmdb_id, title=title, year=year, media_type=media_type, use_cache_only=True)
            if meta:
                me.apply_to_listitem(li, meta, addon_fanart=af)
                thumb = meta.get('poster') or ai
            else:
                thumb = ai
                if has_cache and item_key in cache:
                    thumb = cache[item_key]
                li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
                video_info = {
                    'title': title,
                    'year': year,
                    'plot': f"[B]{tagline}[/B]\n\n{overview}" if tagline else overview,
                    'mediatype': 'movie' if t == 'movie' else 'tvshow'
                }
                li.setInfo('video', video_info)
            
            cm = []
            if hay_palantir:
                cm.append(("Buscar en Palantir", f"RunPlugin({_u(action='palantir_search_prompt', q=title)})"))

            cm.append(("Buscar en webs de torrent (Elementum)", f"RunPlugin({_u(action='elementum_search', q=title)})"))

            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_fav', title=title, url=title, f_thumb=thumb, f_action='trakt_search_dialog', extra=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            
            li.addContextMenuItems(cm)
            li.setProperty('IsPlayable', 'false')
            play_url = _u(action='trakt_search_dialog', q=title)
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=True)
            
        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmc.log(f"[AtresDaily-Trakt] error en view_list:\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error Trakt", f"Ocurrió un error al ver la lista:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(_handle())
        except Exception:
            pass


def covers_menu(list_id, show_covers):
    if not list_id:
        return
    showing = show_covers == "1"
    temp_label = "Ocultar carátulas temporales" if showing else "Ver solo esta vez (sin guardar)"
    options = [
        "Descargar y guardar permanentemente",
        temp_label,
    ]
    idx = xbmcgui.Dialog().select("Carátulas", options)
    if idx == 0:
        cache_covers(list_id)
    elif idx == 1:
        new_show = "0" if showing else "1"
        xbmc.executebuiltin("Container.Update({0})".format(
            _u(action='trakt_view_list', list_id=list_id, show_covers=new_show)
        ))


def cache_covers(list_id):
    try:
        if not xbmcgui.Dialog().yesno("AtresDaily", 
            "[B]AVISO DE CARGA:[/B]\n\n"
            "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
            "Se descargarán en paralelo y se guardarán en la base de datos local.\n\n"
            "¿Quieres continuar con la descarga?"):
            return

        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().ok("AtresDaily", _MSG_NO_KEY)
            return
        items, err = _fetch_list_items(list_id, key)
        if err:
            xbmcgui.Dialog().ok("AtresDaily", err)
            return

        import metadata_enricher as me

        enrich_targets = []
        for item in items:
            if not isinstance(item, dict): continue
            t = item.get('type')
            if t not in ('movie', 'show'): continue
            data = item.get(t)
            if not data: continue
            enrich_targets.append({
                'tmdb_id': data.get('ids', {}).get('tmdb'),
                'title': data.get('title'),
                'year': data.get('year'),
                'media_type': 'show' if t == 'show' else 'movie'
            })

        if not enrich_targets:
            xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
            return

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("AtresDaily", "Descargando carátulas y fanart...")
        was_cancelled = False
        try:
            me.batch_fetch_with_progress(enrich_targets, pDialog, max_workers=10)
            was_cancelled = pDialog.iscanceled()
        finally:
            pDialog.close()

        if was_cancelled:
            return

        cache = {}
        for target in enrich_targets:
            item_key = f"{target['title']}_{target['year']}"
            meta = me.enrich(tmdb_id=target['tmdb_id'], title=target['title'], year=target['year'], media_type=target['media_type'], use_cache_only=True)
            if meta and meta.get('poster'):
                cache[item_key] = meta.get('poster')

        if cache:
            path = _get_thumb_cache_path(list_id)
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            os.replace(tmp, path)
            xbmcgui.Dialog().notification("AtresDaily", "Carátulas y fanart guardados correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification("AtresDaily", "No se encontraron carátulas", xbmcgui.NOTIFICATION_WARNING)
    except Exception as e:
        xbmcgui.Dialog().ok("Error Cache", f"Error al guardar carátulas:\n{str(e)}")


def clear_cache(list_id):
    try:
        path = _get_thumb_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("AtresDaily", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)


def delete_list(list_id):
    try:
        if xbmcgui.Dialog().yesno("Eliminar Colección", "¿Seguro que quieres borrar esta colección?"):
            core_settings.remove_trakt_list(list_id)
            _clear_items_cache(list_id)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

# Películas top (historia y populares)

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

def _get_movie_plot(m):
    plots = {
        "Avatar": "En un exuberante planeta llamado Pandora viven los Na'vi, seres que parecen primitivos pero que están muy evolucionados.",
        "Vengadores: Endgame": "Los Vengadores restantes deben unirse una vez más para deshacer las acciones de Thanos y restaurar el orden en el universo.",
        "Avatar: El sentido del agua": "Jake Sully y Ney'tiri han formado una familia y hacen todo lo posible por permanecer juntos explorando las regiones de Pandora.",
        "Titanic": "Un joven artista y una chica de clase alta se enamoran a bordo del lujoso e infortunado transatlántico RMS Titanic.",
        "Star Wars: El despertar de la fuerza": "Tres décadas después de la derrota del Imperio, surge una nueva amenaza que busca controlar la galaxia.",
        "Vengadores: Infinity War": "Los Vengadores y sus aliados deben estar dispuestos a sacrificarlo todo para derrotar al poderoso Thanos antes de que destruya el universo.",
        "Spider-Man: No Way Home": "Con la identidad de Spider-Man revelada, Peter pide ayuda al Doctor Strange, desatando el caos del multiverso.",
        "Jurassic World": "Un nuevo parque de dinosaurios abre sus puertas, pero la fuga de un espécimen genéticamente modificado desata el pánico.",
        "El rey león": "El joven león Simba debe reclamar su legítimo lugar como rey de la sabana tras la trágica muerte de su padre Mufasa.",
        "Los Vengadores": "El director de SHIELD, Nick Fury, une a un grupo de superhéroes para salvar al mundo de Loki y su ejército extraterrestre.",
        "Fast & Furious 7": "Dominic Toretto y su equipo deben enfrentarse a Deckard Shaw, quien busca venganza por su hermano hospitalizado.",
        "Top Gun: Maverick": "Tras más de treinta años de servicio, Maverick sigue superando los límites como un valiente piloto de pruebas.",
        "Frozen II": "Elsa, Anna, Kristoff, Olaf y Sven viajan al bosque encantado para descubrir el origen de los poderes de Elsa.",
        "Barbie": "Barbie y Ken se lo pasan en grande en el mundo de Barbie Land, pero una crisis existencial los lleva al mundo real.",
        "Vengadores: La era de Ultrón": "Tony Stark crea por error a Ultrón, una inteligencia artificial decidida a extinguir a la humanidad.",
        "Super Mario Bros.: La película": "Un fontanero llamado Mario viaja por un laberinto subterráneo con su hermano Luigi para salvar un reino dinámico.",
        "Black Panther": "T'Challa regresa a Wakanda para asumir el trono tras la muerte de su padre, enfrentándose a un viejo enemigo.",
        "Harry Potter y las Reliquias de la Muerte - Parte 2": "Harry, Ron y Hermione buscan los últimos Horrocruxes para destruir a Lord Voldemort en la batalla final de Hogwarts.",
        "Star Wars: Los últimos Jedi": "Rey busca la ayuda del legendario maestro Jedi Luke Skywalker mientras la Resistencia lucha por sobrevivir.",
        "Jurassic World: El reino caído": "Owen y Claire regresan a la isla Nublar para salvar a los dinosaurios restantes de una erupción volcánica inminente.",
        "Frozen": "La optimista Anna y el montañés Kristoff buscan a Elsa para deshacer el hechizo de un invierno eterno.",
        "La bella y la bestia": "Una joven inteligente es hecha prisionera por una bestia en su castillo, descubriendo el buen corazón que oculta.",
        "Los Increíbles 2": "Helen es reclutada para liderar una campaña que traiga de vuelta a los superhéroes, mientras Bob se queda en casa cuidando de los niños.",
        "El destino de los furiosos": "Una misteriosa mujer seduce a Dom para adentrarlo en el mundo del crimen y traicionar a su propia familia.",
        "Iron Man 3": "Tony Stark se enfrenta a un enemigo implacable, el Mandarín, mientras lidia con el estrés postraumático.",
        "Minions": "Los divertidos Minions buscan a un nuevo amo supervillano a quien servir, terminando al servicio de Scarlet Overkill.",
        "Capitán América: Civil War": "La presión política crea una fractura entre el Capitán América y Iron Man, dividiendo a los Vengadores.",
        "Aquaman": "Arthur Curry debe reclamar su destino como rey del reino submarino de la Atlántida para evitar una guerra con la superficie.",
        "El Señor de los Anillos: El retorno del Rey": "Frodo y Sam se acercan al Monte del Destino para destruir el Anillo Único mientras Aragorn lidera la batalla final.",
        "Spider-Man: Lejos de casa": "Peter Parker realiza un viaje escolar a Europa, donde es reclutado para combatir a unas misteriosas criaturas elementales.",
        "Capitana Marvel": "Carol Danvers se convierte en una de las heroínas más poderosas del universo cuando la Tierra queda atrapada en una guerra galáctica.",
        "Transformers: El lado oscuro de la luna": "Los Autobots descubren una nave espacial oculta en la Luna y compiten contra los Decepticons por sus secretos.",
        "Skyfall": "La lealtad de James Bond hacia M es puesta a prueba cuando el pasado de ella vuelve para atormentarla.",
        "Transformers: La era de la extinción": "Un mecánico y su hija descubren a Optimus Prime, atrayendo la atención de cazadores de recompensas y del gobierno.",
        "El caballero oscuro: La leyenda renace": "Ocho años después del Joker, Batman regresa para salvar a Gotham del brutal terrorista Bane.",
        "Joker": "Arthur Fleck, un payaso frustrado de Gotham, desciende lentamente a la locura y se convierte en el icónico villano.",
        "Star Wars: El ascenso de Skywalker": "Los miembros supervivientes de la Resistencia se enfrentan a la Primera Orden una vez más en la conclusión de la saga.",
        "Toy Story 4": "Woody, Buzz y el resto de juguetes se embarcan en un viaje por carretera junto a Forky, un nuevo y peculiar juguete hecho a mano.",
        "Toy Story 3": "Con Andy preparándose para ir a la universidad, Woody, Buzz y los demás juguetes terminan por error en una guardería.",
        "Piratas del Caribe: El cofre del hombre muerto": "Jack Sparrow descubre que tiene una deuda de sangre con el legendario Davy Jones, capitán del Holandés Errante.",
        "El rey león (1994)": "La clásica e inolvidable historia animada de Simba, el cachorro de león que debe madurar para reclamar el trono.",
        "Buscando a Dory": "La olvidadiza pez cirujano azul Dory emprende un viaje para reunirse con sus padres perdidos.",
        "Star Wars: La amenaza fantasma": "Dos caballeros Jedi descubren a un niño con un potencial extraordinario en la Fuerza en el planeta Tatooine.",
        "Alicia en el país de las maravillas": "Alicia, ahora de 19 años, regresa al mágico mundo subterráneo de su infancia para derrotar a la Reina de Corazones.",
        "Zootrópolis": "En una ciudad de animales antropomórficos, una coneja policía y un zorro estafador se unen para resolver un misterio.",
        "Harry Potter y la piedra filosofal": "En su primer año en Hogwarts, Harry Potter descubre que es un mago famoso y desentraña el misterio de la piedra filosofal.",
        "Gru, mi villano favorito 3": "Gru descubre que tiene un hermano gemelo rico y carismático llamado Dru, y se ve tentado a volver al crimen.",
        "Buscando a Nemo": "Un pez payaso sobreprotector cruza el océano para rescatar a su hijo único atrapado en la pecera de un dentista.",
        "Harry Potter y la Orden del Fénix": "Harry forma un grupo secreto de estudiantes, el Ejército de Dumbledore, para prepararse ante el regreso de Voldemort.",
        "Harry Potter y el misterio del príncipe": "Harry descubre un antiguo libro anotado por el 'Príncipe Mestizo' mientras se prepara para la guerra inminente.",
        "El Señor de los Anillos: Las dos torres": "Frodo y Sam continúan su viaje hacia Mordor guiados por Gollum, mientras Aragorn y sus aliados defienden el abismo de Helm.",
        "Shrek 2": "Shrek y Fiona viajan al Reino de Muy Muy Lejano para conocer a los padres de ella, desatando una divertida crisis real.",
        "Bohemian Rhapsody": "Una celebración del grupo Queen, su música y su extraordinario cantante Freddie Mercury.",
        "El Señor de los Anillos: La comunidad del anillo": "Un modesto hobbit hereda un anillo mágico y emprende una peligrosa misión para destruirlo en el Monte del Destino.",
        "Harry Potter y las Reliquias de la Muerte - Parte 1": "Harry, Ron y Hermione huyen de los Mortífagos para localizar y destruir los Horrocruxes de Voldemort.",
        "El Hobbit: Un viaje inesperado": "El hobbit Bilbo Bolsón es reclutado por el mago Gandalf y trece enanos para recuperar un tesoro robado por el dragón Smaug.",
        "El caballero oscuro": "Batman se enfrenta al caos desatado en Gotham por un psicópata anarquista conocido como el Joker.",
        "Jumanji: Bienvenidos a la jungla": "Cuatro adolescentes son absorbidos por un videojuego mágico, asumiendo la forma de avatares adultos con habilidades únicas.",
        "Harry Potter y el cáliz de fuego": "Harry es seleccionado misteriosamente para competir en el peligroso Torneo de los Tres Magos en Hogwarts.",
        "Spider-Man 3": "Peter Parker se enfrenta a nuevos villanos y a un misterioso simbionte alienígena que saca a relucir su lado más oscuro.",
        "Transformers: La venganza de los caídos": "Sam Witwicky vuelve a verse envuelto en la guerra entre Autobots y Decepticons debido a antiguos símbolos en su mente.",
        "Spider-Man: Homecoming": "Peter Parker intenta equilibrar su vida escolar ordinaria con sus nuevas responsabilidades como el trepamuros supervisado por Tony Stark.",
        "Ice Age 3: El origen de los dinosaurios": "Sid el perezoso adopta tres huevos de dinosaurio, lo que lleva al grupo a un asombroso mundo subterráneo lleno de peligros.",
        "Ice Age 4: La formación de los continentes": "Manny, Diego y Sid se embarcan en una gran aventura marina usando un iceberg como barco improvisado.",
        "El libro de la selva": "Mowgli, un cachorro humano criado por lobos, huye de la selva para escapar del temible tigre Shere Khan.",
        "Batman v Superman: El amanecer de la justicia": "Temiendo las acciones descontroladas de Superman, Batman decide enfrentarse al salvador de Metrópolis.",
        "El Hobbit: La desolación de Smaug": "Bilbo Bolsón y los enanos continúan su viaje hacia el este para recuperar la Montaña Solitaria y enfrentarse al dragón.",
        "El Hobbit: La batalla de los cinco ejércitos": "Los enanos, elfos, hombres y orcos se enfrentan en una guerra épica por el control del tesoro de Erebor.",
        "Thor: Ragnarok": "Thor es encarcelado en el otro extremo del universo sin su martillo y debe competir en un duelo de gladiadores contra Hulk.",
        "Guardianes de la Galaxia Vol. 2": "Los Guardianes de la Galaxia deben luchar para mantenerse unidos mientras desentrañan los misterios de la familia de Peter Quill.",
        "Inside Out (Del revés)": "Las emociones de una niña llamada Riley compiten por el control de su mente durante una difícil mudanza familiar.",
        "Venom": "El periodista Eddie Brock se une con un simbionte alienígena hambriento de carne humana, convirtiéndose en el antihéroe Venom.",
        "Thor: Love and Thunder": "Thor emprende un viaje de autodescubrimiento, pero su retiro es interrumpido por un asesino galáctico conocido como Gorr.",
        "Deadpool 2": "El mercenario mutante Wade Wilson forma la X-Force para proteger a un joven mutante del implacable viajero del tiempo Cable.",
        "Deadpool": "Un antiguo mercenario de operaciones especiales con factor de curación acelerado busca venganza contra el hombre que desfiguró su rostro.",
        "Star Wars: La venganza de los Sith": "Anakin Skywalker es seducido por el Lado Oscuro de la Fuerza, traicionando a la Orden Jedi para convertirse en Darth Vader.",
        "Spider-Man": "El estudiante Peter Parker adquiere poderes arácnidos tras ser mordido por una araña genéticamente modificada.",
        "Wonder Woman": "La princesa amazona Diana sale de su isla paradisíaca para intervenir en un conflicto mundial y detener al dios de la guerra.",
        "Independence Day": "La Tierra es invadida por naves alienígenas hostiles, y los humanos sobrevivientes deben unirse para lanzar un contraataque el 4 de julio.",
        "Animales fantásticos y dónde encontrarlos": "El magizóologo Newt Scamander llega a Nueva York con una maleta llena de criaturas mágicas que escapan accidentalmente.",
        "Shrek Tercero": "Shrek emprende un viaje para encontrar al joven Arturo Pendragon y coronarlo como nuevo rey de Muy Muy Lejano.",
        "Coco": "Un niño mexicano con sueños de ser músico viaja accidentalmente al vibrante mundo de los muertos para descubrir la verdad de su familia.",
        "Jumanji: Siguiente nivel": "El equipo regresa al juego, pero las reglas han cambiado y deben rescatar a uno de los suyos en terrenos áridos e inexplorados.",
        "Harry Potter y la cámara secreta": "Harry regresa a su segundo año en Hogwarts y descubre una misteriosa advertencia sobre una antigua cámara oculta.",
        "Star Wars: Una nueva esperanza": "El joven granjero Luke Skywalker se une a una princesa rebelde y un contrabandista para destruir la Estación Espacial del Imperio.",
        "ET El extraterrestre": "Un niño solitario se hace amigo de un simpático extraterrestre varado en la Tierra y trata de ayudarlo a volver a casa.",
        "Misión Imposible: Fallout": "Ethan Hunt y su equipo deben recuperar plutonio robado mientras lidian con las consecuencias de una misión fallida.",
        "2012": "Un escritor de novelas de ciencia ficción lucha por mantener a su familia a salvo en medio de un cataclismo global que amenaza a la Tierra.",
        "Indiana Jones y el reino de la calavera de cristal": "El intrépido arqueólogo Indiana Jones se ve envuelto en un complot soviético para descubrir el secreto de una misteriosa calavera de cristal.",
        "Fast & Furious 6": "Hobbs recluta a Dom y a su equipo en Londres para derribar a una organización de mercenarios conductores altamente calificados.",
        "Piratas del Caribe: En el fin del mundo": "Elizabeth, Will y el capitán Barbossa viajan al fin del mundo para rescatar a Jack Sparrow del casillero de Davy Jones.",
        "El código Da Vinci": "Un asesinato en el Museo del Louvre lleva al simbologista Robert Langdon a descubrir una conspiración religiosa de siglos de antigüedad.",
        "X-Men: Días del futuro pasado": "Lobezno viaja en el tiempo al pasado para cambiar la historia y evitar un futuro apocalíptico para mutantes y humanos.",
        "Madagascar 3: De marcha por Europa": "Los animales del zoo de Nueva York se unen a un circo ambulante europeo para intentar volver a su hogar.",
        "Las crónicas de Narnia: El león, la bruja y el armario": "Cuatro hermanos descubren un armario mágico que los conduce al reino fantástico de Narnia, atrapado bajo un invierno eterno.",
        "Man of Steel": "Un niño alienígena con poderes extraordinarios es enviado a la Tierra, donde debe decidir qué tipo de héroe quiere ser para la humanidad.",
        "Monstruos University": "Una mirada a la divertida etapa universitaria de Mike Wazowski y James P. Sullivan antes de convertirse en los mejores asustadores.",
        "Matrix Reloaded": "Neo, Trinity y Morfeo lideran la rebelión contra el ejército de máquinas, mientras Neo explora su destino como El Elegido.",
        "Up": "Un anciano viudo ata miles de globos a su casa para cumplir la promesa de viajar a las Cataratas del Paraíso junto a un joven boy scout.",
        "Gravity": "Dos astronautas quedan varados en el espacio exterior tras la destrucción de su transbordador y deben luchar por sobrevivir.",
        "Capitán América: El Soldado de Invierno": "Steve Rogers descubre una conspiración dentro de S.H.I.E.L.D. y se enfrenta a un misterioso asesino del pasado.",
        "La saga Crepúsculo: Amanecer - Parte 2": "Bella se adapta a su nueva vida como vampiro mientras los Cullen se reúnen para proteger a su hija de los Voturi.",
        "La saga Crepúsculo: Amanecer - Parte 1": "La boda, luna de miel y el nacimiento de un niño traen consecuencias inesperadas para Bella, Edward y Jacob.",
        "La saga Crepúsculo: Luna nueva": "Edward abandona a Bella para protegerla, llevándola a una profunda depresión donde encuentra consuelo en su amigo Jacob Black.",
        "La saga Crepúsculo: Eclipse": "Bella se ve obligada a elegir entre su amor por Edward y su amistad con Jacob mientras una serie de asesinatos azota Seattle.",
        "Forrest Gump": "La vida de Forrest Gump, un hombre sencillo de Alabama que presencia y participa sin querer en los eventos más importantes de la historia.",
        "El sexto sentido": "Un psicólogo infantil intenta ayudar a un niño asustado que afirma ver a personas muertas que caminan entre los vivos.",
        "Interestelar": "Un grupo de exploradores viaja a través de un agujero de gusano en el espacio para encontrar un nuevo hogar para la humanidad.",
        "Origen": "Un hábil ladrón capaz de infiltrarse en los sueños de los demás recibe la tarea de implantar una idea en la mente de un heredero.",
        "Gladiator": "Un traicionado general romano busca venganza contra el corrupto emperador que asesinó a su familia y lo convirtió en esclavo gladiador.",
        "Salvar al soldado Ryan": "Durante la Segunda Guerra Mundial, un grupo de soldados arriesga sus vidas para encontrar y traer de vuelta sano y salvo al soldado Ryan.",
        "La lista de Schindler": "En Polonia, durante la Segunda Guerra Mundial, el empresario Oskar Schindler salva la vida de más de mil judíos empleados en sus fábricas.",
        "El Padrino": "La influyente y poderosa dinastía del crimen de Don Vito Corleone en Nueva York pasa el control a su reticente hijo menor, Michael.",
        "El Padrino Parte II": "La película explora los inicios del joven Vito Corleone y el ascenso de su hijo Michael como el nuevo Don de la familia.",
        "Cadena perpetua": "Dos hombres encarcelados entablan una profunda amistad a lo largo de los años, encontrando consuelo y redención mutua.",
        "Pulp Fiction": "Las vidas de dos gánsteres, un boxeador, la esposa de un jefe mafioso y una pareja de ladrones se entrelazan de manera violenta e ingeniosa.",
        "El club de la lucha": "Un empleado de oficina deprimido y un carismático fabricante de jabón fundan un club de lucha clandestino.",
        "Matrix": "Un programador descubre que la realidad en la que vive es una simulación creada por máquinas inteligentes para controlar a la humanidad.",
        "Goodfellas (Uno de los nuestros)": "La historia real de Henry Hill y su ascenso y caída dentro de la mafia de Nueva York a lo largo de tres décadas.",
        "Seven": "Dos detectives de homicidios rastrean a un asesino en serie cuyos crímenes están inspirados en los siete pecados capitales.",
        "El silencio de los corderos": "Una joven agente del FBI busca la ayuda del manipulador asesino Hannibal Lecter para atrapar a otro asesino en serie.",
        "La vida es bella": "Un camarero judío italiano usa su imaginación y humor para proteger a su hijo de los horrores de un campo de concentración nazi.",
        "Ciudad de Dios": "En las favelas de Río de Janeiro, dos jóvenes eligen caminos opuestos: uno se convierte en fotógrafo y el otro en un temido narcotraficante.",
        "El viaje de Chihiro": "Una niña de diez años entra por accidente en un mundo dominado por dioses, espíritus y brujas, y lucha por rescatar a sus padres.",
        "Parásitos": "Una familia desempleada se infiltra con astucia en el hogar de una adinerada familia, desencadenando una serie de incidentes caóticos.",
        "Psicosis": "Una secretaria huye con dinero robado y se aloja en un desolado motel regentado por un joven tímido bajo el control de su madre.",
        "Casablanca": "Durante la Segunda Guerra Mundial, un cínico expatriado estadounidense se debate entre el amor de su vida y ayudar a su esposo a escapar.",
        "El bueno, el feo y el malo": "Tres hombres ambiciosos y despiadados compiten durante la Guerra de Secesión estadounidense por encontrar un tesoro oculto en un cementerio.",
        "12 hombres sin piedad": "Un jurado de doce hombres debate sobre la culpabilidad de un adolescente acusado de asesinato, enfrentando sus propios prejuicios.",
        "La milla verde": "Un guardia de prisión de los años 30 descubre que uno de los presos condenados a muerte posee un milagroso don de curación.",
        "El gran dictador": "La genial sátira de Charles Chaplin sobre el fascismo, donde interpreta a un barbero judío y a un despiadado dictador.",
        "Cinema Paradiso": "Un director de cine recuerda su infancia y su profunda amistad con el proyeccionista del cine de su pequeño pueblo siciliano.",
        "Regreso al futuro": "Un adolescente es enviado accidentalmente de vuelta a 1955 en un coche DeLorean convertido en máquina del tiempo por un científico loco.",
        "Terminator 2: El juicio final": "Un ciborg del futuro reprogramado es enviado para proteger al joven John Connor de un terminator de metal líquido más avanzado.",
        "Alien, el octavo pasajero": "La tripulación de una nave de carga comercial se enfrenta a una forma de vida extraterrestre hostil y letal en el espacio.",
        "Apocalypse Now": "Durante la Guerra de Vietnam, un capitán del ejército estadounidense es enviado en una misión secreta para asesinar a un coronel renegado.",
        "Django desencadenado": "Un esclavo liberado se une a un cazarrecompensas alemán para rescatar a su esposa de un brutal terrateniente de Mississippi.",
        "El resplandor": "Un escritor se traslada con su familia a un desolado hotel de montaña para trabajar como cuidador, desatando una espiral de locura.",
        "WALL-E": "En un futuro lejano donde la Tierra está cubierta de basura, un pequeño robot de limpieza emprende un viaje espacial que decidirá el destino de la humanidad.",
        "La princesa Mononoke": "Un joven príncipe viaja para encontrar una cura a su maldición y se ve envuelto en una guerra entre los dioses del bosque y una comunidad minera.",
        "Oldboy": "Un hombre es secuestrado y encarcelado misteriosamente durante quince años, y al ser liberado busca incansablemente venganza.",
        "Amélie": "Una imaginativa camarera de París decide cambiar para mejor la vida de las personas que la rodean mediante pequeños y sutiles gestos.",
        "El laberinto del fauno": "En la España de la posguerra, una niña se refugia de la crueldad de su padrastro militar explorando un antiguo y mágico laberinto subterráneo."
    }
    return plots.get(m, f"Película legendaria: {m}")

def _get_movie_genre(m):
    genres = {
        "Avatar": "Ciencia ficción", "Vengadores: Endgame": "Acción", "Avatar: El sentido del agua": "Ciencia ficción", "Titanic": "Romance", "Star Wars: El despertar de la fuerza": "Ciencia ficción", "Vengadores: Infinity War": "Acción", "Spider-Man: No Way Home": "Acción", "Jurassic World": "Ciencia ficción", "El rey león": "Animación", "Los Vengadores": "Acción", "Fast & Furious 7": "Acción", "Top Gun: Maverick": "Acción", "Frozen II": "Animación", "Barbie": "Comedia", "Vengadores: La era de Ultrón": "Acción", "Super Mario Bros.: La película": "Animación", "Black Panther": "Acción", "Harry Potter y las Reliquias de la Muerte - Parte 2": "Fantasía", "Star Wars: Los últimos Jedi": "Ciencia ficción", "Jurassic World: El reino caído": "Ciencia ficción", "Frozen": "Animación", "La bella y la bestia": "Fantasía", "Los Increíbles 2": "Animación", "El destino de los furiosos": "Acción", "Iron Man 3": "Acción", "Minions": "Animación", "Capitán América: Civil War": "Acción", "Aquaman": "Acción", "El Señor de los Anillos: El retorno del Rey": "Fantasía", "Spider-Man: Lejos de casa": "Acción", "Capitana Marvel": "Acción", "Transformers: El lado oscuro de la luna": "Ciencia ficción", "Skyfall": "Acción", "Transformers: La era de la extinción": "Ciencia ficción", "El caballero oscuro: La leyenda renace": "Acción", "Joker": "Drama", "Star Wars: El ascenso de Skywalker": "Ciencia ficción", "Toy Story 4": "Animación", "Toy Story 3": "Animación", "Piratas del Caribe: El cofre del hombre muerto": "Aventura", "El rey león (1994)": "Animación", "Buscando a Dory": "Animación", "Star Wars: La amenaza fantasma": "Ciencia ficción", "Alicia en el país de las maravillas": "Fantasía", "Zootrópolis": "Animación", "Harry Potter y la piedra filosofal": "Fantasía", "Gru, mi villano favorito 3": "Animación", "Buscando a Nemo": "Animación", "Harry Potter y la Orden del Fénix": "Fantasía", "Harry Potter y el misterio del príncipe": "Fantasía", "El Señor de los Anillos: Las dos torres": "Fantasía", "Shrek 2": "Animación", "Bohemian Rhapsody": "Drama", "El Señor de los Anillos: La comunidad del anillo": "Fantasía", "Harry Potter y las Reliquias de la Muerte - Parte 1": "Fantasía", "El Hobbit: Un viaje inesperado": "Fantasía", "El caballero oscuro": "Acción", "Jumanji: Bienvenidos a la jungla": "Aventura", "Harry Potter y el cáliz de fuego": "Fantasía", "Spider-Man 3": "Acción", "Transformers: La venganza de los caídos": "Ciencia ficción", "Spider-Man: Homecoming": "Acción", "Ice Age 3: El origen de los dinosaurios": "Animación", "Ice Age 4: La formación de los continentes": "Animación", "El libro de la selva": "Aventura", "Batman v Superman: El amanecer de la justicia": "Acción", "El Hobbit: La desolación de Smaug": "Fantasía", "El Hobbit: La batalla de los cinco ejércitos": "Fantasía", "Thor: Ragnarok": "Acción", "Guardianes de la Galaxia Vol. 2": "Acción", "Inside Out (Del revés)": "Animación", "Venom": "Acción", "Thor: Love and Thunder": "Acción", "Deadpool 2": "Acción", "Deadpool": "Acción", "Star Wars: La venganza de los Sith": "Ciencia ficción", "Spider-Man": "Acción", "Wonder Woman": "Acción", "Independence Day": "Ciencia ficción", "Animales fantásticos y dónde encontrarlos": "Fantasía", "Shrek Tercero": "Animación", "Coco": "Animación", "Jumanji: Siguiente nivel": "Aventura", "Harry Potter y la cámara secreta": "Fantasía", "Star Wars: Una nueva esperanza": "Ciencia ficción", "ET El extraterrestre": "Ciencia ficción", "Misión Imposible: Fallout": "Acción", "2012": "Ciencia ficción", "Indiana Jones y el reino de la calavera de cristal": "Aventura", "Fast & Furious 6": "Acción", "Piratas del Caribe: En el fin del mundo": "Aventura", "El código Da Vinci": "Misterio", "X-Men: Días del futuro pasado": "Acción", "Madagascar 3: De marcha por Europa": "Animación", "Las crónicas de Narnia: El león, la bruja y el armario": "Fantasía", "Man of Steel": "Acción", "Monstruos University": "Animación", "Matrix Reloaded": "Ciencia ficción", "Up": "Animación", "Gravity": "Ciencia ficción", "Capitán América: El Soldado de Invierno": "Acción", "La saga Crepúsculo: Amanecer - Parte 2": "Fantasía", "La saga Crepúsculo: Amanecer - Parte 1": "Fantasía", "La saga Crepúsculo: Luna nueva": "Fantasía", "La saga Crepúsculo: Eclipse": "Fantasía", "Forrest Gump": "Drama", "El sexto sentido": "Suspense", "Interestelar": "Ciencia ficción", "Origen": "Ciencia ficción", "Gladiator": "Acción", "Salvar al soldado Ryan": "Bélico", "La lista de Schindler": "Drama", "El Padrino": "Crimen", "El Padrino Parte II": "Crimen", "Cadena perpetua": "Drama", "Pulp Fiction": "Crimen", "El club de la lucha": "Drama", "Matrix": "Ciencia ficción", "Goodfellas (Uno de los nuestros)": "Crimen", "Seven": "Suspense", "El silencio de los corderos": "Suspense", "La vida es bella": "Drama", "Ciudad de Dios": "Crimen", "El viaje de Chihiro": "Animación", "Parásitos": "Drama", "Psicosis": "Terror", "Casablanca": "Drama", "El bueno, el feo y el malo": "Western", "12 hombres sin piedad": "Drama", "La milla verde": "Drama", "El gran dictador": "Comedia", "Cinema Paradiso": "Drama", "Regreso al futuro": "Ciencia ficción", "Terminator 2: El juicio final": "Ciencia ficción", "Alien, el octavo pasajero": "Terror", "Apocalypse Now": "Bélico", "Django desencadenado": "Western", "El resplandor": "Terror", "WALL-E": "Animación", "La princesa Mononoke": "Animación", "Oldboy": "Drama", "Amélie": "Comedia", "El laberinto del fauno": "Fantasía"
    }
    return genres.get(m, "Cine")

def _get_movie_details(m):
    details = {
        "Avatar": (2009, 7.9, "James Cameron"),
        "Vengadores: Endgame": (2019, 8.4, "Anthony Russo, Joe Russo"),
        "Avatar: El sentido del agua": (2022, 7.6, "James Cameron"),
        "Titanic": (1997, 7.9, "James Cameron"),
        "Star Wars: El despertar de la fuerza": (2015, 7.8, "J.J. Abrams"),
        "Vengadores: Infinity War": (2018, 8.4, "Anthony Russo, Joe Russo"),
        "Spider-Man: No Way Home": (2021, 8.2, "Jon Watts"),
        "Jurassic World": (2015, 6.9, "Colin Trevorrow"),
        "El rey león": (2019, 6.9, "Jon Favreau"),
        "Los Vengadores": (2012, 8.0, "Joss Whedon"),
        "Fast & Furious 7": (2015, 7.1, "James Wan"),
        "Top Gun: Maverick": (2022, 8.3, "Joseph Kosinski"),
        "Frozen II": (2019, 6.8, "Chris Buck, Jennifer Lee"),
        "Barbie": (2023, 6.9, "Greta Gerwig"),
        "Vengadores: La era de Ultrón": (2015, 7.3, "Joss Whedon"),
        "Super Mario Bros.: La película": (2023, 7.1, "Aaron Horvath, Michael Jelenic"),
        "Black Panther": (2018, 7.3, "Ryan Coogler"),
        "Harry Potter y las Reliquias de la Muerte - Parte 2": (2011, 8.1, "David Yates"),
        "Star Wars: Los últimos Jedi": (2017, 6.9, "Rian Johnson"),
        "Jurassic World: El reino caído": (2018, 6.1, "J.A. Bayona"),
        "Frozen": (2013, 7.4, "Chris Buck, Jennifer Lee"),
        "La bella y la bestia": (2017, 7.1, "Bill Condon"),
        "Los Increíbles 2": (2018, 7.6, "Brad Bird"),
        "El destino de los furiosos": (2017, 6.6, "F. Gary Gray"),
        "Iron Man 3": (2013, 7.1, "Shane Black"),
        "Minions": (2015, 6.4, "Kyle Balda, Pierre Coffin"),
        "Capitán América: Civil War": (2016, 7.8, "Anthony Russo, Joe Russo"),
        "Aquaman": (2018, 6.8, "James Wan"),
        "El Señor de los Anillos: El retorno del Rey": (2003, 9.0, "Peter Jackson"),
        "Spider-Man: Lejos de casa": (2019, 7.4, "Jon Watts"),
        "Capitana Marvel": (2019, 6.8, "Anna Boden, Ryan Fleck"),
        "Transformers: El lado oscuro de la luna": (2011, 6.2, "Michael Bay"),
        "Skyfall": (2012, 7.8, "Sam Mendes"),
        "Transformers: La era de la extinción": (2014, 5.6, "Michael Bay"),
        "El caballero oscuro: La leyenda renace": (2012, 8.4, "Christopher Nolan"),
        "Joker": (2019, 8.4, "Todd Phillips"),
        "Star Wars: El ascenso de Skywalker": (2019, 6.5, "J.J. Abrams"),
        "Toy Story 4": (2019, 7.7, "Josh Cooley"),
        "Toy Story 3": (2010, 8.3, "Lee Unkrich"),
        "Piratas del Caribe: El cofre del hombre muerto": (2006, 7.3, "Gore Verbinski"),
        "El rey león (1994)": (1994, 8.5, "Roger Allers, Rob Minkoff"),
        "Buscando a Dory": (2016, 7.3, "Andrew Stanton"),
        "Star Wars: La amenaza fantasma": (1999, 6.5, "George Lucas"),
        "Alicia en el país de las maravillas": (2010, 6.4, "Tim Burton"),
        "Zootrópolis": (2016, 8.0, "Byron Howard, Rich Moore"),
        "Harry Potter y la piedra filosofal": (2001, 7.6, "Chris Columbus"),
        "Gru, mi villano favorito 3": (2017, 6.2, "Kyle Balda, Pierre Coffin"),
        "Buscando a Nemo": (2003, 8.2, "Andrew Stanton"),
        "Harry Potter y la Orden del Fénix": (2007, 7.5, "David Yates"),
        "Harry Potter y el misterio del príncipe": (2009, 7.6, "David Yates"),
        "El Señor de los Anillos: Las dos torres": (2002, 8.8, "Peter Jackson"),
        "Shrek 2": (2004, 7.3, "A. Adamson, K. Asbury, C. Vernon"),
        "Bohemian Rhapsody": (2018, 7.9, "Bryan Singer"),
        "El Señor de los Anillos: La comunidad del anillo": (2001, 8.8, "Peter Jackson"),
        "Harry Potter y las Reliquias de la Muerte - Parte 1": (2010, 7.7, "David Yates"),
        "El Hobbit: Un viaje inesperado": (2012, 7.8, "Peter Jackson"),
        "El caballero oscuro": (2008, 9.0, "Christopher Nolan"),
        "Jumanji: Bienvenidos a la jungla": (2017, 6.9, "Jake Kasdan"),
        "Harry Potter y el cáliz de fuego": (2005, 7.7, "Mike Newell"),
        "Spider-Man 3": (2007, 6.3, "Sam Raimi"),
        "Transformers: La venganza de los caídos": (2009, 6.0, "Michael Bay"),
        "Spider-Man: Homecoming": (2017, 7.4, "Jon Watts"),
        "Ice Age 3: El origen de los dinosaurios": (2009, 6.9, "Carlos Saldanha, Mike Thurmeier"),
        "Ice Age 4: La formación de los continentes": (2012, 6.5, "Steve Martino, Mike Thurmeier"),
        "El libro de la selva": (2016, 7.4, "Jon Favreau"),
        "Batman v Superman: El amanecer de la justicia": (2016, 6.4, "Zack Snyder"),
        "El Hobbit: La desolación de Smaug": (2013, 7.8, "Peter Jackson"),
        "El Hobbit: La batalla de los cinco ejércitos": (2014, 7.4, "Peter Jackson"),
        "Thor: Ragnarok": (2017, 7.9, "Taika Waititi"),
        "Guardianes de la Galaxia Vol. 2": (2017, 7.6, "James Gunn"),
        "Inside Out (Del revés)": (2015, 8.1, "Pete Docter"),
        "Venom": (2018, 6.7, "Ruben Fleischer"),
        "Thor: Love and Thunder": (2022, 6.2, "Taika Waititi"),
        "Deadpool 2": (2018, 7.7, "David Leitch"),
        "Deadpool": (2016, 8.0, "Tim Miller"),
        "Star Wars: La venganza de los Sith": (2005, 7.6, "George Lucas"),
        "Spider-Man": (2002, 7.4, "Sam Raimi"),
        "Wonder Woman": (2017, 7.4, "Patty Jenkins"),
        "Independence Day": (1996, 7.0, "Roland Emmerich"),
        "Animales fantásticos y dónde encontrarlos": (2016, 7.3, "David Yates"),
        "Shrek Tercero": (2007, 6.1, "Chris Miller, Raman Hui"),
        "Coco": (2017, 8.4, "Lee Unkrich"),
        "Jumanji: Siguiente nivel": (2019, 6.7, "Jake Kasdan"),
        "Harry Potter y la cámara secreta": (2002, 7.4, "Chris Columbus"),
        "Star Wars: Una nueva esperanza": (1977, 8.6, "George Lucas"),
        "ET El extraterrestre": (1982, 7.9, "Steven Spielberg"),
        "Misión Imposible: Fallout": (2018, 7.7, "Christopher McQuarrie"),
        "2012": (2009, 5.8, "Roland Emmerich"),
        "Indiana Jones y el reino de la calavera de cristal": (2008, 6.2, "Steven Spielberg"),
        "Fast & Furious 6": (2013, 7.0, "Justin Lin"),
        "Piratas del Caribe: En el fin del mundo": (2007, 7.1, "Gore Verbinski"),
        "El código Da Vinci": (2006, 6.6, "Ron Howard"),
        "X-Men: Días del futuro pasado": (2014, 7.9, "Bryan Singer"),
        "Madagascar 3: De marcha por Europa": (2012, 6.8, "E. Darnell, T. McGrath, C. Vernon"),
        "Las crónicas de Narnia: El león, la bruja y el armario": (2005, 6.9, "Andrew Adamson"),
        "Man of Steel": (2013, 7.1, "Zack Snyder"),
        "Monstruos University": (2013, 7.2, "Dan Scanlon"),
        "Matrix Reloaded": (2003, 7.2, "Lana Wachowski, Lilly Wachowski"),
        "Up": (2009, 8.3, "Pete Docter"),
        "Gravity": (2013, 7.7, "Alfonso Cuarón"),
        "Capitán América: El Soldado de Invierno": (2014, 7.8, "Anthony Russo, Joe Russo"),
        "La saga Crepúsculo: Amanecer - Parte 2": (2012, 5.5, "Bill Condon"),
        "La saga Crepúsculo: Amanecer - Parte 1": (2011, 4.9, "Bill Condon"),
        "La saga Crepúsculo: Luna nueva": (2009, 4.8, "Chris Weitz"),
        "La saga Crepúsculo: Eclipse": (2010, 5.1, "David Slade"),
        "Forrest Gump": (1994, 8.8, "Robert Zemeckis"),
        "El sexto sentido": (1999, 8.2, "M. Night Shyamalan"),
        "Interestelar": (2014, 8.7, "Christopher Nolan"),
        "Origen": (2010, 8.8, "Christopher Nolan"),
        "Gladiator": (2000, 8.5, "Ridley Scott"),
        "Salvar al soldado Ryan": (1998, 8.6, "Steven Spielberg"),
        "La lista de Schindler": (1993, 9.0, "Steven Spielberg"),
        "El Padrino": (1972, 9.2, "Francis Ford Coppola"),
        "El Padrino Parte II": (1974, 9.0, "Francis Ford Coppola"),
        "Cadena perpetua": (1994, 9.3, "Frank Darabont"),
        "Pulp Fiction": (1994, 8.9, "Quentin Tarantino"),
        "El club de la lucha": (1999, 8.8, "David Fincher"),
        "Matrix": (1999, 8.7, "Lana Wachowski, Lilly Wachowski"),
        "Goodfellas (Uno de los nuestros)": (1990, 8.7, "Martin Scorsese"),
        "Seven": (1995, 8.6, "David Fincher"),
        "El silencio de los corderos": (1991, 8.6, "Jonathan Demme"),
        "La vida es bella": (1997, 8.6, "Roberto Benigni"),
        "Ciudad de Dios": (2002, 8.6, "F. Meirelles, K. Lund"),
        "El viaje de Chihiro": (2001, 8.6, "Hayao Miyazaki"),
        "Parásitos": (2019, 8.5, "Bong Joon Ho"),
        "Psicosis": (1960, 8.5, "Alfred Hitchcock"),
        "Casablanca": (1942, 8.5, "Michael Curtiz"),
        "El bueno, el feo y el malo": (1966, 8.8, "Sergio Leone"),
        "12 hombres sin piedad": (1957, 9.0, "Sidney Lumet"),
        "La milla verde": (1999, 8.6, "Frank Darabont"),
        "El gran dictador": (1940, 8.4, "Charles Chaplin"),
        "Cinema Paradiso": (1988, 8.5, "Giuseppe Tornatore"),
        "Regreso al futuro": (1985, 8.5, "Robert Zemeckis"),
        "Terminator 2: El juicio final": (1991, 8.6, "James Cameron"),
        "Alien, el octavo pasajero": (1979, 8.5, "Ridley Scott"),
        "Apocalypse Now": (1979, 8.4, "Francis Ford Coppola"),
        "Django desencadenado": (2012, 8.4, "Quentin Tarantino"),
        "El resplandor": (1980, 8.4, "Stanley Kubrick"),
        "WALL-E": (2008, 8.4, "Andrew Stanton"),
        "La princesa Mononoke": (1997, 8.4, "Hayao Miyazaki"),
        "Oldboy": (2003, 8.4, "Park Chan-wook"),
        "Amélie": (2001, 8.3, "Jean-Pierre Jeunet"),
        "El laberinto del fauno": (2006, 8.2, "Guillermo del Toro")
    }
    return details.get(m, (2000, 7.0, "Desconocido"))

def top_movies(page):

    try:
        try: page = int(page)
        except Exception: page = 1
        per_page = 50
        movies = _get_movies_list()
        total = len(movies)
        start = (page - 1) * per_page
        end = start + per_page
        page_items = movies[start:end]

        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        # Caché de imágenes
        cache = _load_top_movies_cache()
        has_cache = len(cache) > 0

        # Botones de las carátulas
        if not has_cache:
            li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar y GUARDAR carátulas permanentemente[/B][/COLOR]")
            icon_path = os.path.join(addon.getAddonInfo('path'), 'resources', 'media', 'descargas.png')
            li.setArt({'icon': icon_path})
            li.setInfo('video', {'plot': "Esta opción buscará las fotos de TODA la colección (130+ pelis) y las guardará.\n\n[COLOR red][B]Aviso:[/B][/COLOR] Tardará un poco cada vez que entres, pero se verá de cine."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="cache_top_movies_covers"), listitem=li, isFolder=False)
        else:
            li = xbmcgui.ListItem(label="[COLOR red]Borrar carátulas guardadas (Volver a carga rápida)[/COLOR]")
            li.setArt({'icon': _media_icon('backup_delete.png')})
            li.setInfo('video', {'plot': "Elimina las fotos guardadas para que la colección vuelva a cargar al instante."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="clear_top_movies_cache"), listitem=li, isFolder=False)

        import metadata_enricher as me

        for m in page_items:
            li = xbmcgui.ListItem(label=m)
            
            _details = _get_movie_details(m)
            year = _details[0]
            
            meta = me.enrich(title=m, year=year, media_type='movie', use_cache_only=True)
            if meta:
                me.apply_to_listitem(li, meta, addon_fanart=af)
                thumb = meta.get('poster') or ai
            else:
                thumb = ai
                if has_cache and m in cache:
                    thumb = cache[m]

                li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': af})
                _genre = _get_movie_genre(m)
                _plot = (
                    f"[COLOR gold][B]Género:[/B][/COLOR] [COLOR deepskyblue]{_genre}[/COLOR]  |  "
                    f"[COLOR gold][B]Año:[/B][/COLOR] [COLOR deepskyblue]{_details[0]}[/COLOR]  |  "
                    f"[COLOR gold][B]Nota IMDb:[/B][/COLOR] [COLOR deepskyblue]★ {_details[1]}[/COLOR]\n"
                    f"[COLOR gold][B]Director:[/B][/COLOR] [COLOR deepskyblue]{_details[2]}[/COLOR]\n\n"
                    f"{_get_movie_plot(m)}"
                )
                li.setInfo('video', {
                    'title': m,
                    'plot': _plot,
                    'genre': _genre,
                    'year': year,
                    'rating': float(_details[1]),
                    'director': _details[2]
                })
            
            # Menú contextual
            cm = []
            params_json = json.dumps({'q': m})
            fav_url = _u(action='add_fav', title=m, url=m, f_thumb=thumb, f_action='trakt_search_dialog', extra=params_json)
            cm.append(("Añadir a Mis Favoritos", f"RunPlugin({fav_url})"))
            li.addContextMenuItems(cm)
            
            # Clic principal, diálogo multi-búsqueda
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_search_dialog", q=m), listitem=li, isFolder=True)
        
        if end < total:
            li = xbmcgui.ListItem(label=f"[COLOR limegreen]Siguiente página ({page + 1})[/COLOR]")
            li.setArt({'icon': _media_icon('siguiente.png')})
            xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(_handle())
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar películas top:\n{str(e)}")
        try: xbmcplugin.endOfDirectory(_handle())
        except Exception: pass

def cache_top_movies_covers():
    try:
        if not xbmcgui.Dialog().yesno("AtresDaily", 
            "¿Quieres descargar las carátulas de las 130+ películas top?\n\n"
            "Esto hará que la sección se vea mucho mejor pero [COLOR yellow]tardará un poco más en cargar[/COLOR]."):
            return

        movies = _get_movies_list()
        
        import metadata_enricher as me
        
        enrich_targets = []
        for m in movies:
            _details = _get_movie_details(m)
            enrich_targets.append({
                'title': m,
                'year': _details[0],
                'media_type': 'movie'
            })
            
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("AtresDaily", "Descargando carátulas Top...")
        was_cancelled = False
        try:
            me.batch_fetch_with_progress(enrich_targets, pDialog, max_workers=10)
            was_cancelled = pDialog.iscanceled()
        finally:
            pDialog.close()

        if was_cancelled:
            return

        cache = {}
        for target in enrich_targets:
            m = target['title']
            year = target['year']
            meta = me.enrich(title=m, year=year, media_type='movie', use_cache_only=True)
            if meta and meta.get('poster'):
                cache[m] = meta.get('poster')

        if cache:
            path = _get_top_movies_cache_path()
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(cache, f)
            os.replace(tmp, path)
            xbmcgui.Dialog().notification("AtresDaily", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification("AtresDaily", "No se encontraron carátulas", xbmcgui.NOTIFICATION_WARNING)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al guardar carátulas top:\n{str(e)}")

def clear_top_movies_cache():
    try:
        path = _get_top_movies_cache_path()
        if os.path.exists(path):
            os.remove(path)
            xbmcgui.Dialog().notification("AtresDaily", "Cache eliminada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
