# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import os
import json
import time
import xbmcaddon
import xbmcvfs

# Rutas
_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_WATCH_FILE = os.path.join(_PROFILE_PATH, 'watch_history.json')


def atomic_write_json(path, data, ensure_ascii=True, indent=None):
    """Escribe JSON de forma atómica (tmp único + os.replace). Nunca lanza; devuelve bool.
    Un corte a mitad o dos escrituras solapadas no pueden dejar el archivo corrupto."""
    import threading
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=ensure_ascii, indent=indent)
        os.replace(tmp, path)
        return True
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        return False


# Modo Debug
def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_debug_active(state):
    atomic_write_json(_DEBUG_FILE, {'active': state})


# Modo Congelado (Estático)
def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

# Prioridad de búsqueda (Coincidencia vs Duración)
_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')

def is_prioritize_match_active():
    if not os.path.exists(_PRIORITY_FILE): return False
    try:
        with open(_PRIORITY_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_prioritize_match(state):
    atomic_write_json(_PRIORITY_FILE, {'active': state})


# Filtro de contenidos recientes
def is_recent_active():
    if not os.path.exists(_RECENT_FILE): return False
    try:
        with open(_RECENT_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_recent_active(state):
    atomic_write_json(_RECENT_FILE, {'active': state})


# Gestión de Favoritos
def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
    except Exception: return []
    # Solo entradas válidas. Una importada sin 'url' tumbaría todas las operaciones con KeyError.
    return [f for f in data if isinstance(f, dict) and f.get('url')] if isinstance(data, list) else []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()
    if any(f['url'] == url for f in favs): return False
    favs.append({
        "title": title, "url": url, "icon": icon, 
        "platform": platform, "action": action, "params": params or {}
    })
    atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
    return True

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    atomic_write_json(_FAV_FILE, new_favs, ensure_ascii=False)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        atomic_write_json(_FAV_FILE, favs, ensure_ascii=False)
        return True
        
    return False


# Historial de Reproducción
def get_watch_history():
    if not os.path.exists(_WATCH_FILE): return []
    try:
        with open(_WATCH_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
    except Exception: return []
    return [h for h in data if isinstance(h, dict)] if isinstance(data, list) else []

def add_to_watch_history(vid, title, thumb="", duration=0):
    """Inserta al inicio; si ya existe, mueve en vez de duplicar. Límite: 100."""
    history = get_watch_history()
    # Eliminar entrada existente (para moverla al principio)
    history = [h for h in history if h.get('vid') != vid]
    history.insert(0, {
        "vid": vid, "title": title, "thumb": thumb,
        "duration": duration, "watched_at": int(time.time())
    })
    history = history[:100]
    atomic_write_json(_WATCH_FILE, history, ensure_ascii=False)

def clear_watch_history():
    atomic_write_json(_WATCH_FILE, [])
    return True

def get_watched_ids():
    """Set de IDs vistos (lookup O(1) al marcar items del listing)."""
    return {h.get('vid') for h in get_watch_history() if h.get('vid')}

def remove_watch_entry(vid):
    history = get_watch_history()
    new_history = [h for h in history if h.get('vid') != vid]
    if len(new_history) != len(history):
        atomic_write_json(_WATCH_FILE, new_history, ensure_ascii=False)
        return True
    return False


# Filtro de duración mínima
def get_min_duration():
    if not os.path.exists(_DURATION_FILE): return 0
    try:
        with open(_DURATION_FILE, 'r', encoding='utf-8') as f: return json.load(f).get('minutes', 0)
    except Exception: return 0

def set_min_duration(minutes):
    atomic_write_json(_DURATION_FILE, {'minutes': minutes})

# Modo de búsqueda avanzada
def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return False
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r', encoding='utf-8') as o: return json.load(o).get('active', False)
    except Exception: return False

def set_advanced_search_active(state):
    atomic_write_json(_ADVANCED_SEARCH_FILE, {'active': state})


# Integración con Trakt
_TRAKT_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'trakt_settings.json')
_TRAKT_CLIENT_ID = "bS4meB1pF9rQhl_dGFF2z0llxa-0sIRiMEgh3gUSQUA"
_ESPADAILY_TMDB_API_KEY = "273ffd2f428df3e0ef479eeb8d632541"

def get_trakt_settings():
    if not os.path.exists(_TRAKT_SETTINGS_FILE): return {"api_key": "", "lists": []}
    try:
        with open(_TRAKT_SETTINGS_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {"api_key": "", "lists": []}

def save_trakt_settings(data):
    # atomic_write_json usa un tmp único, así que dos guardados a la vez no se pisan. Si
    # falla se lanza la excepción, para que no se pierda en silencio.
    if not atomic_write_json(_TRAKT_SETTINGS_FILE, data, ensure_ascii=False):
        raise OSError(f"No se pudo guardar {_TRAKT_SETTINGS_FILE}")

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "") or _TRAKT_CLIENT_ID

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "4834057", "9429302", "851495", "1558961",
    "6544049", "3785062", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416"
]

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)

def seed_default_trakt_lists(api_key=''):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: f"Lista Trakt #{lid}" for lid in new_ids}
    if api_key:
        try:
            import requests
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
            def fetch_name(lid):
                try:
                    r = requests.get(f'https://api.trakt.tv/lists/{lid}', headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except Exception:
                    pass
                return lid, names[lid]
            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except Exception:
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)

# Detección de addons externos integrados en la UI
def get_palantir_addon_id():
    """Busca cualquier variante de Palantir instalada (plugin.video.palantir*)."""
    import xbmc
    common_ids = ['plugin.video.palantir', 'plugin.video.palantir2', 'plugin.video.palantir3', 'plugin.video.palantir4']
    for pid in common_ids:
        if xbmc.getCondVisibility(f"System.HasAddon({pid})"):
            return pid
    try:
        addons_dir = xbmcvfs.translatePath('special://home/addons/')
        if os.path.exists(addons_dir):
            for d in os.listdir(addons_dir):
                if d.startswith('plugin.video.palantir') and 'visor' not in d:
                    if xbmc.getCondVisibility(f"System.HasAddon({d})"):
                        return d
    except Exception:
        pass
    return None

def is_jacktook_installed():
    import xbmc
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(plugin.video.jacktook)"))
    except Exception:
        return False

def get_alfa_addon_id():
    import xbmc
    try:
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.alfa)"):
            return 'plugin.video.alfa'
    except Exception:
        pass
    return None

_INTEGRATION_FIRST_USE_FILE = os.path.join(_PROFILE_PATH, 'integration_first_use.json')

def is_integration_first_use_shown(addon_name):
    if not os.path.exists(_INTEGRATION_FIRST_USE_FILE):
        return False
    try:
        with open(_INTEGRATION_FIRST_USE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f).get(addon_name, False)
    except Exception:
        return False

def mark_integration_first_use_shown(addon_name):
    data = {}
    if os.path.exists(_INTEGRATION_FIRST_USE_FILE):
        try:
            with open(_INTEGRATION_FIRST_USE_FILE, 'r', encoding='utf-8') as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    data = loaded
        except Exception:
            pass
    data[addon_name] = True
    atomic_write_json(_INTEGRATION_FIRST_USE_FILE, data)


_WELCOME_FILE = os.path.join(_PROFILE_PATH, 'welcome_state.json')

def welcome_last_version():
    if not os.path.exists(_WELCOME_FILE):
        return ''
    try:
        with open(_WELCOME_FILE, 'r', encoding='utf-8') as f:
            return json.load(f).get('version', '')
    except Exception:
        return ''

def set_welcome_shown(version):
    atomic_write_json(_WELCOME_FILE, {'version': version})

