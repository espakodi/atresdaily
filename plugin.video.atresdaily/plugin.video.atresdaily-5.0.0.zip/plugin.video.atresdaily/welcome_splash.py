# -*- coding: utf-8 -*-
# AtresDaily: Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: consulta el archivo LICENSE para más detalles.

"""
Ventana de bienvenida que aparece al abrir el addon tras instalar o actualizar.
Muestra versión, mensaje de bienvenida, enlaces a las webs y un botón Cerrar.
Solo el botón Cerrar (o Atrás/Esc) cierra; los enlaces abren el navegador y la
ventana permanece abierta.

Ligera, con ~12 controles estáticos y sin hilos ni animaciones, para no
cargar dispositivos modestos (Firestick).
"""
import os

import xbmc
import xbmcaddon
import xbmcgui

import core_settings

_ADDON = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo("path")
_MEDIA = os.path.join(_ADDON_PATH, "resources", "media")
_TEX = os.path.join(_MEDIA, "white.png")
_TRANSP = os.path.join(_MEDIA, "transparent.png")
_FOCUS = os.path.join(_MEDIA, "focus.png")

W, H = 1280, 720          # rejilla fija de las WindowDialog no-XML (escala a la pantalla real)
LEFT = 150

_ACCENT = "FFFF8500"      # Naranja AtresDaily
_GOLD = "FFFFD700"

_WEB_ESPATV = "https://espatv.github.io"
_WEB_LOIOLO = "https://loiolo.io"

# Línea corta, porque ControlLabel no hace wrap.
_WELCOME_BODY = "Gracias por instalar AtresDaily, tu explorador del catálogo de A3Player para Kodi."


def _resolve_fanart():
    # Siempre el fanart/icono propio del addon
    local_fanart = os.path.join(_ADDON_PATH, "fanart.jpg")
    if os.path.exists(local_fanart):
        return local_fanart
    return _ADDON.getAddonInfo("fanart") or _ADDON.getAddonInfo("icon")



class _WelcomeDialog(xbmcgui.WindowDialog):
    """Bienvenida modal. Cierra solo con Cerrar/Atrás; los enlaces no cierran."""

    def __init__(self, version):
        super().__init__()
        self.version = version
        self.url_map = {}
        self.close_btn_id = -1
        self.buttons = []
        self._build()

    def _image(self, x, y, w, h, color=None, texture=None, aspect=None):
        kw = {}
        if color is not None:
            kw["colorDiffuse"] = color
        if aspect is not None:
            kw["aspectRatio"] = aspect
        self._pending.append(xbmcgui.ControlImage(x, y, w, h, texture or _TEX, **kw))

    def _label(self, x, y, w, h, text, font="font13", color="FFFFFFFF", align=0):
        self._pending.append(
            xbmcgui.ControlLabel(x, y, w, h, text, font=font, textColor=color, alignment=align)
        )

    def _button(self, x, y, w, h, text, font="font13", align=0x04):
        btn = xbmcgui.ControlButton(
            x, y, w, h, text,
            font=font, textColor="FFEDEDED", focusedColor=_ACCENT, alignment=align,
            noFocusTexture=_TRANSP, focusTexture=_FOCUS,
        )
        self._pending.append(btn)
        self.buttons.append(btn)
        return btn

    def _build(self):
        self._pending = []

        # Base negra opaca de fondo
        self._image(0, 0, W, H, color="FF000000")
        self._image(0, 0, W, H, texture=_resolve_fanart(), aspect=0)
        self._image(0, 0, W, H, color="A6000000")

        text_w = W - LEFT - 120

        # Barra de acento + título + badge de versión
        self._image(LEFT - 30, 150, 6, 96, color=_ACCENT)
        self._label(LEFT, 142, text_w, 64, "[B]Bienvenido a AtresDaily[/B]", font="font45")
        self._label(LEFT, 214, text_w, 34, f"[B][COLOR {_ACCENT}]VERSIÓN {self.version}[/COLOR][/B]",
                    font="font14")

        y = 296
        for line in _WELCOME_BODY.split("\n"):
            self._label(LEFT, y, text_w, 32, f"[COLOR FFEAEAEA]{line}[/COLOR]")
            y += 34

        y += 24
        self._label(LEFT, y, text_w, 34,
                    f"[B][COLOR {_GOLD}]Antes de empezar, échale un vistazo a los Ajustes del addon.[/COLOR][/B]",
                    font="font14")

        # Enlaces (abren el navegador y no cierran)
        y += 56
        web = self._button(LEFT, y, 880, 40, f"[B][COLOR {_ACCENT}]»[/COLOR]  Web[/B]    espatv.github.io")
        y += 44
        loiolo = self._button(LEFT, y, 880, 40, f"[B][COLOR {_ACCENT}]»[/COLOR]  loiolo.io[/B]    Fuente de addons EspaKodi e información")

        # Botón Cerrar abajo a la derecha, con fondo para que parezca botón
        bw, bh = 230, 50
        bx, by = W - 120 - bw, H - 92
        self._image(bx, by, bw, bh, color="33FFFFFF")
        close = self._button(bx, by, bw, bh, "[B]Cerrar[/B]", font="font14", align=0x02 | 0x04)

        self.addControls(self._pending)

        self.close_btn_id = close.getId()
        self.url_map[web.getId()] = _WEB_ESPATV
        self.url_map[loiolo.getId()] = _WEB_LOIOLO

        # Navegación circular en las 4 direcciones
        n = len(self.buttons)
        for i, b in enumerate(self.buttons):
            prev = self.buttons[(i - 1) % n]
            nxt = self.buttons[(i + 1) % n]
            b.controlUp(prev)
            b.controlLeft(prev)
            b.controlDown(nxt)
            b.controlRight(nxt)
        self.setFocus(close)

    def _open_url(self, url):
        try:
            if xbmc.getCondVisibility("System.Platform.Android"):
                xbmc.executebuiltin(
                    f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")'
                )
            else:
                import webbrowser
                webbrowser.open(url)
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo enlace...",
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            xbmcgui.Dialog().ok("Enlace AtresDaily",
                                "No se pudo abrir automáticamente. Abre esta URL:\n\n" + url)

    def _handle_click(self, control_id):
        if control_id == self.close_btn_id:
            self.close()
            return
        url = self.url_map.get(control_id)
        if url:
            self._open_url(url)

    def onAction(self, action):
        aid = action.getId()
        if aid in (10, 92, 110):
            self.close()
        elif aid in (7, 100, 101):
            self._handle_click(self.getFocusId())

    def onClick(self, controlId):
        self._handle_click(controlId)


_DEV_ALWAYS_SHOW = False  # Poner en True para desarrollo / pruebas. Cambiar a False para producción.

def show_if_needed():
    """Muestra la bienvenida una vez por versión. Nunca rompe el arranque."""
    current = _ADDON.getAddonInfo("version")
    if not _DEV_ALWAYS_SHOW and core_settings.welcome_last_version() == current:
        return
    try:
        dlg = _WelcomeDialog(current)
        dlg.doModal()
        del dlg
        # Se marca como visto solo al cerrar el diálogo
        if not _DEV_ALWAYS_SHOW:
            core_settings.set_welcome_shown(current)
    except Exception as e:
        # Marcar también en caso de error para evitar bucles de fallos
        core_settings.set_welcome_shown(current)
        xbmc.log(f"[AtresDaily] welcome_splash doModal: {e}", xbmc.LOGERROR)

