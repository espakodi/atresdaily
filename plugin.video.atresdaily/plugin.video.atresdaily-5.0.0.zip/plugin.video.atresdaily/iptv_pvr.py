# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Las listas de canales en la sección TV de Kodi, a través de PVR IPTV Simple.

Es una M3U propia que IPTV Simple lee desde una instancia propia, al
lado de las que el usuario ya tenga (la de EspaTV, la de EKHorus...). Ninguna de esas se
escribe nunca; la nuestra se reconoce por la ruta de su M3U.

Los AceStream van a EKHorus (plugin://script.module.horus/...), que sabe atender una
llamada desde la sección TV; sin EKHorus, a AtresDaily, que los resuelve contra el motor
local. Los canales gratuitos que llegan por un redirector (Samsung TV Plus y otros) también van a
AtresDaily, que antes de abrirlos mira si llevan DRM. Las páginas de plataformas no van, porque
solo las sabe abrir el addon.
"""
import contextlib
import json
import os
import re
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

import iptv_lists
import iptv_parse as P
import iptv_store

IPTVSIMPLE = 'pvr.iptvsimple'
CARPETA_PVR = 'special://profile/addon_data/pvr.iptvsimple/'
# Lo que se le dice a IPTV Simple. Resuelve la ruta él solo, así que vale sea cual sea el perfil.
RUTA_M3U = 'special://profile/addon_data/plugin.video.atresdaily/pvr/atresdaily_tv.m3u'
NOMBRE_INSTANCIA = 'AtresDaily'
# Una instancia sin nombre, la única a la que IPTV Simple pasa la lista única de Kodi 19
# (SettingsMigration::MigrateSettings).
INSTANCIA_VACIA = '<settings version="2">\n</settings>\n'
_RE_INSTANCIA = re.compile(r'instance-settings-(\d+)\.xml\Z')

# IPTV Simple para en menos de un segundo y vuelve a cargar en 7 a 9 s.
PARADA_MAX = 15
CARGA_MAX = 60
QUIETO = 3
_INSTALAR_MAX = 180
# IPTV Simple vuelve a leer la M3U cada hora, así que los cambios de las listas llegan solos.
_REFRESCO_MIN = 60

_PESTILLO = 'atresdaily.pvr'
_PESTILLO_CADUCA_S = 180
_HEADING = 'AtresDaily'
_LOG = '[AtresDaily/IPTV]'
_CORTA = ('Hay un canal de la sección TV en marcha, y cargar los canales lo corta.\n\n¿Sigo?')


def _log(texto, nivel=xbmc.LOGINFO):
    xbmc.log(f'{_LOG} TV: {texto}', nivel)


def _kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        return 21


# --- Pestillo contra dos exportaciones a la vez (dos pulsaciones, o el servicio y el menú) ---

def _echar_pestillo():
    ventana = xbmcgui.Window(10000)
    marca = ventana.getProperty(_PESTILLO)
    try:
        if marca and time.time() - float(marca) < _PESTILLO_CADUCA_S:
            return False
    except ValueError:
        pass
    ventana.setProperty(_PESTILLO, str(time.time()))
    return True


def _esperar_turno():
    """Espera a que termine otra actualización de la TV (dos pulsaciones seguidas, o el
    servicio al arrancar) y se queda con el pestillo. Saltarse la segunda dejaría la marca de
    la lista y la TV desincronizadas; esperando, manda la última pulsación, porque cada
    actualización relee las listas al empezar."""
    barra = xbmcgui.DialogProgressBG()
    barra.create(_HEADING, 'Terminando la actualización anterior de la TV de Kodi...')
    monitor = xbmc.Monitor()
    limite = time.time() + _PESTILLO_CADUCA_S
    try:
        while time.time() < limite:
            if _echar_pestillo():
                return True
            if monitor.waitForAbort(0.5):
                return False
    finally:
        barra.close()
    xbmcgui.Dialog().notification(_HEADING, 'La TV de Kodi sigue ocupada. Inténtalo en un momento.',
                                  xbmcgui.NOTIFICATION_WARNING, 4000)
    return False


def _refrescar_pestillo():
    xbmcgui.Window(10000).setProperty(_PESTILLO, str(time.time()))


def _quitar_pestillo():
    xbmcgui.Window(10000).clearProperty(_PESTILLO)


# --- IPTV Simple por JSON-RPC ---

def _jsonrpc(metodo, **params):
    peticion = {'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': params}
    try:
        respuesta = json.loads(xbmc.executeJSONRPC(json.dumps(peticion)))
    except ValueError as e:
        _log(f'{metodo}: {e}', xbmc.LOGWARNING)
        return {}
    return respuesta if isinstance(respuesta, dict) else {}


def _instalado():
    """Si IPTV Simple está, encendido o no. System.HasAddon no dice si está encendido y
    System.AddonIsEnabled solo ve los encendidos."""
    return 'addon' in _jsonrpc('Addons.GetAddonDetails', addonid=IPTVSIMPLE,
                               properties=['enabled']).get('result', {})


def _encendido():
    return bool(xbmc.getCondVisibility(f'System.AddonIsEnabled({IPTVSIMPLE})'))


def _habilitar(encendido):
    _jsonrpc('Addons.SetAddonEnabled', addonid=IPTVSIMPLE, enabled=encendido)


def _clientes():
    clientes = _jsonrpc('PVR.GetClients').get('result', {}).get('clients') or []
    return [(c.get('addonid'), c.get('instanceid'), c.get('clientid')) for c in clientes]


def _esperar(condicion, plazo, paso=0.25):
    """True en cuanto condicion() se cumple; False si pasa el plazo o Kodi se está cerrando."""
    monitor = xbmc.Monitor()
    limite = time.time() + plazo
    while not condicion():
        if time.time() > limite or monitor.waitForAbort(paso):
            return False
        _refrescar_pestillo()
    return True


def _instalar_iptvsimple():
    """Pide a Kodi que instale IPTV Simple y vigila cómo va. True si queda instalado.

    Nunca executebuiltin(..., True), porque con espera Kodi retiene el GIL y todo el Python de Kodi se
    congela mientras la pregunta está en pantalla. Si el usuario dice que
    no, la pregunta se cierra y no se abre ningún progreso, y se deja de esperar a los pocos
    segundos en vez de agotar el plazo entero."""
    xbmc.executebuiltin(f'InstallAddon({IPTVSIMPLE})')
    monitor = xbmc.Monitor()
    limite = time.time() + _INSTALAR_MAX
    vista_pregunta = False
    quieto_desde = None
    while time.time() < limite:
        if monitor.waitForAbort(0.25):
            return False
        _refrescar_pestillo()
        if _encendido():
            return True
        pregunta = bool(xbmc.getCondVisibility('Window.IsActive(yesnodialog)'))
        progreso = bool(xbmc.getCondVisibility('Window.IsActive(progressdialog)')
                        or xbmc.getCondVisibility('Window.IsActive(extendedprogressdialog)'))
        vista_pregunta = vista_pregunta or pregunta
        if pregunta or progreso:
            quieto_desde = None
            continue
        quieto_desde = quieto_desde or time.time()
        if time.time() - quieto_desde >= (5 if vista_pregunta else 12):
            break
    return _instalado()


def _parado():
    """IPTV Simple ha parado del todo: apagado, sin clientes y con la TV de Kodi quieta."""
    if _encendido():
        return False
    clientes = _clientes()
    if any(addon == IPTVSIMPLE for addon, _i, _c in clientes):
        return False
    return xbmc.getInfoLabel('PVR.BackendHost') == '' or bool(clientes)


def _recargar():
    """Apaga y enciende IPTV Simple para que vuelva a leer instancias y listas. Apagar y
    encender seguido deja instancias sin cargar, así que hay que esperar a que pare del todo."""
    _habilitar(False)
    _esperar(_parado, PARADA_MAX)
    xbmc.sleep(500)
    _habilitar(True)


def _canales_nuestros(numero):
    cliente = next((c for addon, i, c in _clientes() if addon == IPTVSIMPLE and i == numero), None)
    if cliente is None:
        return None
    canales = _jsonrpc('PVR.GetChannels', channelgroupid='alltv',
                       properties=['clientid']).get('result', {}).get('channels') or []
    return sum(1 for c in canales if c.get('clientid') == cliente)


def _esperar_canales(numero, cuantos):
    """True cuando la TV de Kodi tiene nuestros canales, todos o los que dejen de crecer."""
    visto = {'n': None, 'desde': time.time()}

    def listos():
        n = _canales_nuestros(numero)
        if n is not None and n >= cuantos:
            return True
        if n != visto['n']:
            visto.update(n=n, desde=time.time())
            return False
        return bool(n) and time.time() - visto['desde'] >= QUIETO

    return _esperar(listos, CARGA_MAX, paso=1)


# --- Instancias de IPTV Simple ---

def _carpeta_pvr():
    return xbmcvfs.translatePath(CARPETA_PVR)


def _ajustes_de(ruta):
    """{id: valor} de un fichero de ajustes de Kodi, o None si no se puede leer."""
    try:
        raiz = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError) as e:
        _log(f'no se ha podido leer {ruta}: {e}', xbmc.LOGWARNING)
        return None
    return {s.get('id'): (s.text or '').strip() for s in raiz.iter('setting')}


def _instancias():
    try:
        nombres = os.listdir(_carpeta_pvr())
    except OSError:
        return {}
    return {int(m.group(1)): os.path.join(_carpeta_pvr(), m.group(0))
            for m in map(_RE_INSTANCIA.match, nombres) if m}


def _nuestra(instancias):
    for numero, ruta in sorted(instancias.items()):
        ajustes = _ajustes_de(ruta)
        if ajustes is not None and ajustes.get('m3uPath') == RUTA_M3U:
            return numero
    return None


def numero_instancia():
    """(número, nueva, con una 1 vacía). La nuestra si ya existe; si no, la siguiente a la
    más alta. Sin ninguna, la 1, para que IPTV Simple no cree una vacía que se queje en cada
    arranque; salvo que la lista única de Kodi 19 esté esperando a migrar, que solo va a una
    instancia sin nombre, así que se deja una 1 vacía para ella y la nuestra es la 2."""
    instancias = _instancias()
    propia = _nuestra(instancias)
    if propia is not None:
        return propia, False, False
    if instancias:
        return max(instancias) + 1, True, False
    viejo = os.path.join(_carpeta_pvr(), 'settings.xml')
    ajustes = _ajustes_de(viejo) if os.path.isfile(viejo) else None
    if ajustes and (ajustes.get('m3uPath') or ajustes.get('m3uUrl')):
        return 2, True, True
    return 1, True, False


def _valores(epg):
    valores = {'kodi_addon_instance_name': NOMBRE_INSTANCIA, 'kodi_addon_instance_enabled': 'true',
               'm3uPathType': '0', 'm3uPath': RUTA_M3U, 'm3uRefreshMode': '1',
               'm3uRefreshIntervalMins': str(_REFRESCO_MIN)}
    if epg:
        valores.update(epgPathType='1', epgUrl=epg)
    return valores


def _instancia_xml(valores):
    # Ningún default="true": Kodi tomaría el valor por no tocado y lo ignoraría.
    raiz = ET.Element('settings', version='2')
    for clave, valor in valores.items():
        ET.SubElement(raiz, 'setting', id=clave).text = valor
    return ET.tostring(raiz, encoding='unicode') + '\n'


def _asegurar_instancia(numero, nueva, con_vacia, epg, reactivar):
    """Escribe nuestra instancia si es nueva, o corrige lo que otra app le haya cambiado (las
    versiones antiguas de EspaTV escribían su lista en todas las instancias). Lo demás que el
    usuario ajustara en ella se respeta, y solo se vuelve a encender si lo pide él (reactivar),
    porque el servicio no enciende una instancia que el usuario apagó en Kodi. True si ha
    cambiado algo, False si no, None si no se pudo escribir."""
    ruta = os.path.join(_carpeta_pvr(), f'instance-settings-{numero}.xml')
    valores = _valores(epg)
    if not reactivar and not nueva:
        valores.pop('kodi_addon_instance_enabled')
    if nueva:
        if con_vacia and not _publicar(os.path.join(_carpeta_pvr(), 'instance-settings-1.xml'),
                                       INSTANCIA_VACIA):
            return None
        return True if _publicar(ruta, _instancia_xml(valores)) else None
    try:
        arbol = ET.parse(ruta)
    except (OSError, ET.ParseError) as e:
        _log(f'no se ha podido leer {ruta}: {e}', xbmc.LOGWARNING)
        return None
    raiz = arbol.getroot()
    cambiado = False
    for clave, valor in valores.items():
        nodo = next((s for s in raiz.iter('setting') if s.get('id') == clave), None)
        if nodo is None:
            nodo = ET.SubElement(raiz, 'setting', id=clave)
        if (nodo.text or '').strip() != valor or 'default' in nodo.attrib:
            nodo.text = valor
            nodo.attrib.pop('default', None)
            cambiado = True
    if not cambiado:
        return False
    return True if _publicar(ruta, ET.tostring(raiz, encoding='unicode') + '\n') else None


def _publicar(destino, texto):
    return iptv_store.atomic_write(destino, texto.encode('utf-8'))


def _borrar(numero=None):
    rutas = [xbmcvfs.translatePath(RUTA_M3U), _ruta_estado()]
    if numero is not None:
        rutas.append(os.path.join(_carpeta_pvr(), f'instance-settings-{numero}.xml'))
    for ruta in rutas:
        try:
            os.remove(ruta)
        except FileNotFoundError:
            pass
        except OSError as e:
            _log(f'no se ha podido borrar {ruta}: {e}', xbmc.LOGWARNING)


# --- La lista ---

def _ace_url(tipo, valor, nombre):
    """EKHorus atiende las llamadas desde la sección TV,
    tanto por content_id (tipo 'id') como por infohash; sin él, AtresDaily resuelve contra el
    motor local."""
    if xbmc.getCondVisibility('System.AddonIsEnabled(script.module.horus)'):
        return 'plugin://script.module.horus/?' + urllib.parse.urlencode(
            {'action': 'play', tipo: valor, 'title': nombre})
    url = f'acestream://{valor}' if tipo == 'id' else P.engine_url(valor)
    return iptv_lists._BASE + '?' + urllib.parse.urlencode(
        {'action': 'iptv_play', 'src': 'pvr', 'url': url, 'title': nombre})


def _addon_url(ch):
    return iptv_lists._u(action='iptv_play', src='pvr', url=ch['url'], title=ch.get('name'),
                         ua=ch.get('ua'), ref=ch.get('ref'),
                         extra=json.dumps(ch['props']) if ch.get('props') else '')


def _construir(publicadas):
    """(texto M3U, canales escritos, omitidos, guía). Solo con las copias guardadas y sin
    red, porque lo llama también el servicio."""
    secciones, epg = [], ''
    for lst in publicadas:
        try:
            parsed = iptv_lists.channels(lst, network=False)
        except P.ListError as e:
            _log(f'la lista {lst["id"]} no tiene copia y no va a la TV: {e}', xbmc.LOGWARNING)
            continue
        secciones.append((lst['name'], parsed['channels']))
        epg = epg or lst.get('epg') or ''
    texto, escritos, omitidos = P.build_pvr_m3u(secciones, _ace_url, _addon_url)
    return texto, escritos, omitidos, epg


def _ruta_estado():
    return os.path.join(iptv_lists.STORE.profile, 'pvr', 'estado.json')


def _guardar_estado(estado):
    iptv_store.atomic_write(_ruta_estado(), json.dumps(estado).encode('utf-8'))


def _canales(n):
    return '1 canal' if n == 1 else f'{n} canales'


@contextlib.contextmanager
def _avance(texto, visible):
    barra = None
    if visible:
        barra = xbmcgui.DialogProgressBG()
        barra.create(_HEADING, texto)
    try:
        yield
    finally:
        if barra is not None:
            barra.close()


def sync(interactive=False, reload_tv=False):
    """Pone la sección TV de Kodi al día con las listas marcadas.

    interactive: puede preguntar y avisar (desde un menú). Sin él, lo hace en silencio y
    nunca corta un canal que se esté viendo (el servicio al arrancar).
    reload_tv: recarga IPTV Simple aunque su instancia no haya cambiado (al poner o quitar
    una lista). Si no, basta con reescribir la M3U: IPTV Simple la relee cada hora.
    Devuelve True si la TV ha quedado como se pedía."""
    if not _echar_pestillo() and not (interactive and _esperar_turno()):
        # El servicio no espera, porque la actualización en marcha ya lee las listas de ahora.
        return False
    try:
        return _sync(interactive, reload_tv)
    except Exception as e:
        # Pasa por ficheros, diálogos y otro addon, así que lo que falle se dice y no se pierde.
        _log(f'no se ha podido terminar: {e!r}', xbmc.LOGERROR)
        if interactive:
            iptv_lists.show_message(f'No se ha podido actualizar la TV de Kodi.\n\n{e}')
        return False
    finally:
        _quitar_pestillo()


def _sync(interactive, reload_tv):
    publicadas = [lst for lst in iptv_lists.STORE.lists() if lst.get('pvr')]
    if not publicadas:
        return _quitar(interactive)

    texto, escritos, omitidos, epg = _construir(publicadas)
    if not escritos:
        if interactive:
            iptv_lists.show_message('Las listas marcadas no tienen canales que se puedan '
                                          'llevar a la TV de Kodi (los enlaces a páginas como '
                                          'Dailymotion o YouTube no van).')
        return False

    if _kodi_major() < 20:
        return _en_kodi19(texto, escritos, interactive)

    encendido = _encendido()
    presente = encendido or _instalado()
    if not presente and not interactive:
        return False

    numero, nueva, con_vacia = numero_instancia()
    # La lista antes que la instancia: IPTV Simple nunca debe encontrar la instancia sin ella.
    if not _publicar(xbmcvfs.translatePath(RUTA_M3U), texto):
        if interactive:
            iptv_lists.show_message('No se ha podido escribir la lista de la TV. Mira si '
                                          'queda espacio en el aparato.')
        return False
    cambiada = _asegurar_instancia(numero, nueva, con_vacia, epg, reactivar=interactive)
    if cambiada is None:
        if interactive:
            iptv_lists.show_message('No se han podido escribir los ajustes de IPTV Simple.')
        return False

    if not presente:
        iptv_lists.show_message('Para ver los canales en la sección TV hace falta IPTV '
                                      'Simple, un addon del repositorio oficial de Kodi.\n\nAhora '
                                      'Kodi te preguntará si quieres instalarlo.')
        if not _instalar_iptvsimple():
            _borrar(numero if nueva else None)
            iptv_lists.show_message('IPTV Simple no se ha instalado, así que los canales no '
                                          'se han llevado a la TV de Kodi.\n\nSi la descarga ha '
                                          'fallado, vuelve a intentarlo, porque a veces falla un servidor '
                                          'de Kodi.')
            return False

    if not (reload_tv or cambiada or not presente):
        _guardar_estado({'instancia': numero, 'canales': escritos, 'fecha': int(time.time())})
        return True

    if encendido and xbmc.getCondVisibility('PVR.IsPlayingTV'):
        if not interactive or not xbmcgui.Dialog().yesno(_HEADING, _CORTA):
            # La lista ya está escrita y llega sola en la próxima relectura o al arrancar Kodi.
            return True

    with _avance('Cargando los canales en la sección TV...', interactive):
        if encendido:
            _recargar()
        elif presente:
            _habilitar(True)
        cargados = _esperar_canales(numero, escritos)
        if con_vacia:
            # La lista de Kodi 19 pasa a la instancia vacía en la primera carga, y la nuestra
            # solo carga en la siguiente.
            _recargar()
            cargados = _esperar_canales(numero, escritos)

    _guardar_estado({'instancia': numero, 'canales': escritos, 'fecha': int(time.time())})
    _log(f'{escritos} canales en la instancia {numero} ({omitidos} omitidos)')
    if interactive:
        _terminar(escritos, omitidos, cargados, presente and not encendido)
    return True


def _terminar(escritos, omitidos, cargados, activado):
    # Todo en un párrafo: la pregunta de Sí/No no se puede desplazar y corta a las 4 líneas.
    partes = [f'{_canales(escritos)} en la sección TV.']
    if omitidos:
        partes.append(f'{_canales(omitidos)} no van por ser enlaces a páginas.')
    if not cargados:
        partes.append('Aún están cargando.')
    if activado:
        partes.append('IPTV Simple se ha activado.')
    texto = ' '.join(partes) + '\n¿Abro ahora la sección TV?'
    if xbmcgui.Dialog().yesno(_HEADING, texto, nolabel='Ahora no', yeslabel='Abrirla'):
        xbmc.executebuiltin('ActivateWindow(TVChannels)')


def _en_kodi19(texto, escritos, interactive):
    """Kodi 19 solo admite una lista en IPTV Simple, que puede ser la del usuario, así que se deja la
    nuestra preparada y se le dice dónde está."""
    ruta = xbmcvfs.translatePath(RUTA_M3U)
    if not _publicar(ruta, texto):
        if interactive:
            iptv_lists.show_message('No se ha podido escribir la lista. Mira si queda '
                                          'espacio en el aparato.')
        return False
    if interactive:
        iptv_lists.show_message(f'Preparada una lista con {_canales(escritos)}.\n\nEn Kodi 19 '
                                      'IPTV Simple solo admite una lista y AtresDaily no toca la '
                                      'que tengas. Para usar esta, ponla en los ajustes de IPTV '
                                      f'Simple como lista local:\n{ruta}')
    return True


def _quitar(interactive):
    """Quita nuestros canales de la TV y deja todo lo demás como estaba."""
    instancias = _instancias() if _kodi_major() >= 20 else {}
    numero = _nuestra(instancias)
    if numero is None and not os.path.exists(xbmcvfs.translatePath(RUTA_M3U)):
        return True
    if not interactive:
        # Sin listas marcadas pero con restos, se quitan desde el menú, donde se puede avisar.
        return True
    encendido = _encendido()
    if encendido and xbmc.getCondVisibility('PVR.IsPlayingTV') \
            and not xbmcgui.Dialog().yesno(_HEADING, _CORTA):
        return True
    _borrar(numero)
    if encendido and numero is not None:
        quedan = [n for n in instancias if n != numero]
        if not quedan and xbmcgui.Dialog().yesno(
                _HEADING, 'IPTV Simple se ha quedado sin listas. ¿Lo desactivo?\n\nSi lo dejas '
                          'activado, en cada arranque buscará una lista que no tiene.',
                nolabel='Dejarlo', yeslabel='Desactivarlo'):
            _habilitar(False)
        else:
            with _avance('Quitando los canales de la sección TV...', True):
                _recargar()
    xbmcgui.Dialog().notification(_HEADING, 'Canales quitados de la sección TV',
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    return True


# --- Servicio ---

def service_start(monitor):
    """Al arrancar Kodi, si hay listas en la TV: las pone al día en un hilo (no retrasa el
    resto del arranque) y reescribe la M3U. Devuelve el hilo, o None si no hay nada que hacer."""
    publicadas = [lst for lst in iptv_lists.STORE.lists() if lst.get('pvr')]
    if not publicadas:
        return None
    hilo = threading.Thread(target=_refresco_de_fondo, args=(monitor, publicadas),
                            name='AtresDailyTV')
    hilo.start()
    return hilo


def _refresco_de_fondo(monitor, publicadas):
    try:
        for lst in publicadas:
            if monitor.abortRequested():
                return
            try:
                iptv_lists.channels(lst, network=True, quiet=True)
            except Exception as e:
                # Una fuente caída no debe impedir que el resto llegue a la TV.
                _log(f'no se ha podido actualizar la lista {lst["id"]}: {e}', xbmc.LOGWARNING)
        if not monitor.abortRequested():
            sync(interactive=False, reload_tv=False)
    except Exception as e:
        _log(f'refresco al arrancar: {e!r}', xbmc.LOGERROR)
