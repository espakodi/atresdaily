# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Dónde viven las listas de canales del usuario.

custom_iptv_lists.json guarda solo la descripción de cada lista (nombre, de dónde sale,
cuántos canales tenía). Los canales no se guardan, se leen de la fuente al abrirla, así que
no hay copias que se desincronicen.

- iptv_lists/<id>.txt: la única copia de lo que el usuario pegó o mandó desde el móvil.
  Es un dato suyo, así que entra en la copia de seguridad y el limpiador no lo toca.
- iptv_cache/<id>.txt: la última versión buena de una fuente remota, ya filtrada y en M3U,
  con su .json al lado (fecha y canales). Se puede borrar, porque se vuelve a descargar.

Cualquier proceso de Kodi puede escribir a la vez (el plugin, el servicio, dos pulsaciones
seguidas del menú contextual), así que toda escritura del JSON pasa por mutate(), que
relee dentro de un cerrojo entre procesos.
"""
import hashlib
import json
import os
import re
import threading
import time
import uuid
from contextlib import contextmanager

LISTS_FILE = 'custom_iptv_lists.json'
TEXT_DIR = 'iptv_lists'
CACHE_DIR = 'iptv_cache'
KINDS = ('url', 'file', 'text', 'web', 'telegram', 'xtream', 'engine')

_LOCK_WAIT_S = 5
# Una escritura del JSON dura milisegundos, así que un cerrojo de más de 30 s es de un proceso
# que murió con él puesto.
_LOCK_STALE_S = 30
_REPLACE_TRIES = 5
_ORPHAN_MIN_AGE_S = 3600
_ID_RE = re.compile(r'[0-9a-f]{12}')


class LockBusy(Exception):
    """Otro proceso está escribiendo las listas y no ha terminado a tiempo."""


class StoreError(Exception):
    """No se ha podido escribir en disco."""


def new_id():
    return uuid.uuid4().hex[:12]


def legacy_id(url):
    """Id estable de una lista del formato antiguo, para que dos procesos que migran a la
    vez lleguen al mismo resultado."""
    return hashlib.sha1(f'url:{url}'.encode('utf-8')).hexdigest()[:12]


def atomic_write(path, data):
    """Escribe bytes en path sin dejarlo nunca a medias. False si no se pudo.

    En Windows os.replace falla con PermissionError mientras otro proceso tiene abierto el
    destino (IPTV Simple leyendo la M3U, un antivirus), así que se reintenta un poco."""
    tmp = f'{path}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex[:6]}.tmp'
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(tmp, 'wb') as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        for attempt in range(_REPLACE_TRIES):
            try:
                os.replace(tmp, path)
                return True
            except PermissionError:
                time.sleep(0.1 * (attempt + 1))
        return False
    except OSError:
        return False
    finally:
        if os.path.exists(tmp):
            _remove(tmp)


def _remove(path):
    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False


def _migrate(entry):
    """Entrada antigua {name, url} -> formato actual. None si no sirve."""
    url = str(entry.get('url') or '').strip()
    if not url:
        return None
    m = re.match(r'^https?://t\.me/s/([A-Za-z0-9_]{5,})/?$', url, re.I)
    kind, src = ('telegram', m.group(1)) if m else ('url', url)
    return {'id': legacy_id(url), 'name': str(entry.get('name') or '').strip() or src,
            'kind': kind, 'src': src, 'count': 0, 'updated': 0}


def normalize_lists(data):
    """Listas válidas de un JSON leído de disco o de una copia de seguridad, en el formato
    actual o en el antiguo."""
    if isinstance(data, dict):
        return _normalize(data.get('lists'))
    return _normalize(data)


def _normalize(entries):
    out, seen = [], set()
    for entry in entries if isinstance(entries, list) else ():
        if not isinstance(entry, dict):
            continue
        if 'id' not in entry and 'url' in entry:
            entry = _migrate(entry)
            if entry is None:
                continue
        lid = str(entry.get('id') or '')
        if not _ID_RE.fullmatch(lid) or entry.get('kind') not in KINDS or lid in seen:
            continue
        if not isinstance(entry.get('src'), str) or not isinstance(entry.get('name'), str):
            continue
        seen.add(lid)
        out.append(entry)
    return out


class Store:
    def __init__(self, profile):
        self.profile = profile
        self.path = os.path.join(profile, LISTS_FILE)

    def _read(self):
        """(revisión, listas). Lanza OSError si el archivo existe pero no se puede leer, porque quien
        va a escribir no debe confundir un bloqueo momentáneo con "no hay listas"."""
        try:
            with open(self.path, 'rb') as f:
                raw = f.read()
        except FileNotFoundError:
            return 0, []
        try:
            data = json.loads(raw.decode('utf-8'))
        except (UnicodeDecodeError, ValueError):
            self._quarantine()
            return 0, []
        rev = data.get('rev') if isinstance(data, dict) and isinstance(data.get('rev'), int) else 0
        return rev, normalize_lists(data)

    def load(self):
        """Como _read() pero sin lanzar nunca, porque una lista rota no debe tumbar el menú."""
        try:
            return self._read()
        except OSError:
            return 0, []

    def lists(self):
        return self.load()[1]

    def get(self, lid):
        return next((lst for lst in self.lists() if lst['id'] == lid), None)

    def _quarantine(self):
        """Aparta un JSON que no se puede leer en vez de machacarlo en la siguiente
        escritura, para que lo que hubiera dentro se pueda recuperar a mano."""
        try:
            os.replace(self.path, f'{self.path}.corrupt-{int(time.time())}')
        except OSError:
            pass

    @contextmanager
    def _lock(self, name):
        path = os.path.join(self.profile, name)
        deadline = time.time() + _LOCK_WAIT_S
        while True:
            try:
                os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
                break
            except (FileExistsError, PermissionError):
                # PermissionError: en Windows, un cerrojo que otro proceso está borrando.
                pass
            except OSError as e:
                raise StoreError(str(e)) from e
            if self._is_stale(path) and _remove(path):
                continue
            if time.time() > deadline:
                raise LockBusy()
            time.sleep(0.05)
        try:
            yield
        finally:
            _remove(path)

    @staticmethod
    def _is_stale(path):
        try:
            return time.time() - os.path.getmtime(path) > _LOCK_STALE_S
        except OSError:
            return False

    def mutate(self, fn):
        """Aplica fn(listas) sobre lo que hay en disco en ese momento y lo guarda. Devuelve lo que
        devuelva fn. fn trabaja por id y es idempotente, así que borrar un id que ya no existe no
        hace nada, y subir o bajar se calcula sobre el orden actual."""
        os.makedirs(self.profile, exist_ok=True)
        with self._lock(LISTS_FILE + '.lock'):
            try:
                rev, lists = self._read()
            except OSError as e:
                raise StoreError(f'No se han podido leer las listas: {e}') from e
            result = fn(lists)
            body = json.dumps({'rev': rev + 1, 'lists': lists}, ensure_ascii=False, indent=1)
            if not atomic_write(self.path, body.encode('utf-8')):
                raise StoreError('No se han podido guardar las listas.')
            return result

    @contextmanager
    def lock(self, name):
        """Cerrojo con nombre para otras operaciones de varios pasos (el PVR)."""
        os.makedirs(self.profile, exist_ok=True)
        with self._lock(name):
            yield

    def _file(self, folder, lid, ext):
        return os.path.join(self.profile, folder, f'{lid}.{ext}')

    def save_text(self, lid, text):
        return atomic_write(self._file(TEXT_DIR, lid, 'txt'), text.encode('utf-8'))

    def load_text(self, lid):
        try:
            with open(self._file(TEXT_DIR, lid, 'txt'), 'r', encoding='utf-8') as f:
                return f.read()
        except OSError:
            return None

    def save_cache(self, lid, m3u_text, meta):
        """La copia primero y los datos después, para que quien lea los datos encuentre la copia."""
        if not atomic_write(self._file(CACHE_DIR, lid, 'txt'), m3u_text.encode('utf-8')):
            return False
        body = json.dumps(meta, ensure_ascii=False).encode('utf-8')
        return atomic_write(self._file(CACHE_DIR, lid, 'json'), body)

    def load_cache(self, lid):
        """(texto, datos) de la última copia buena, o (None, {})."""
        try:
            with open(self._file(CACHE_DIR, lid, 'txt'), 'r', encoding='utf-8') as f:
                text = f.read()
        except OSError:
            return None, {}
        try:
            with open(self._file(CACHE_DIR, lid, 'json'), 'r', encoding='utf-8') as f:
                meta = json.load(f)
        except (OSError, ValueError):
            meta = {}
        return text, meta if isinstance(meta, dict) else {}

    def delete_files(self, lid):
        for folder, ext in ((TEXT_DIR, 'txt'), (CACHE_DIR, 'txt'), (CACHE_DIR, 'json')):
            _remove(self._file(folder, lid, ext))

    def cleanup_orphans(self, min_age=_ORPHAN_MIN_AGE_S):
        """Borra las copias en caché sin lista y los .tmp que dejó un corte a medias.

        Solo lo que tenga más de una hora, porque al añadir la copia se escribe antes que la entrada
        del JSON, y no hay que competir con esa ventana. iptv_lists/ no se barre nunca, porque es
        dato del usuario, y si el JSON acabara en cuarentena se perdería todo lo pegado."""
        valid = {lst['id'] for lst in self.lists()}
        now = time.time()
        removed = 0
        for folder in (TEXT_DIR, CACHE_DIR):
            base = os.path.join(self.profile, folder)
            try:
                names = os.listdir(base)
            except OSError:
                continue
            for name in names:
                path = os.path.join(base, name)
                leftover = name.endswith('.tmp')
                if not leftover and (folder == TEXT_DIR or name.split('.', 1)[0] in valid):
                    continue
                try:
                    if now - os.path.getmtime(path) < min_age or os.path.isdir(path):
                        continue
                except OSError:
                    continue
                if _remove(path):
                    removed += 1
        return removed
