# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Modo Fantasía: la AtresDaily de siempre dentro de una ventana llena de efectos.

La ventana no conoce ningún menú. Sus listas cargan la URL del plugin que diga una
propiedad (<content> en fantasia.xml), así que Kodi ejecuta AtresDaily igual que para un
widget y cualquier menú, presente o futuro, sale solo. Python guarda la pila de rutas y
decide qué hacer al pulsar; lo que se mueve lo mueve el motor de skins, y aquí solo se
cambian propiedades de la ventana para dispararlo.

Lo que el plugin manda a "la ventana actual" (Container.Update, Container.Refresh, un
listado cancelado, abrir otro addon) acabaría en la ventana de Vídeos que queda debajo,
porque para Kodi un diálogo nunca es la ventana actual. instalar_puente() lo desvía hacia
aquí.
"""
import json
import os
import re
import sys
import threading
import time
import traceback
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

RAIZ = 'plugin://plugin.video.atresdaily/'
_LOG = '[AtresDaily/Fantasía]'

# Lo que ven las demás llamadas al plugin, cada una en su propio intérprete: el id de la
# ventana abierta, en una propiedad de Home.
_PROPIEDAD = 'atresdaily.fantasia'
# La llamada al plugin que lleva el modo. Mientras un vídeo lo tiene cerrado se puede
# abrir otra vez, y entonces la nueva se queda con el turno.
_TURNO = 'atresdaily.fantasia.turno'
_EMISOR = 'atresdaily.fantasia'
# Parámetro de relleno para forzar una recarga: el proveedor de la lista solo vuelve a
# pedir el directorio si cambia la URL.
_RECARGA = 'fantasia_recarga'
# Si esta llamada al plugin tiene el puente puesto (instalar_puente).
_puente = False

ID_CERRAR = 100
ID_CARRUSEL = 300
# Por debajo de la raíz, dos listas que se turnan por niveles: al volver atrás, la del
# nivel de arriba sigue cargada y sale al momento.
LISTAS = (310, 311)
_CONTENEDORES = (ID_CARRUSEL,) + LISTAS

# Medidas del carrusel en las 1920x1080 del skin, las de tools/generar_fantasia.py.
CASILLA = 250
CENTRO = (740, 1180)
FRANJA = (230, 810)
# Los vecinos giran 25 grados y la perspectiva de Kodi los pinta más hacia fuera que su
# casilla, unos 85 px el icono y 125 el rótulo.
_DESVIO_VECINOS = 105

# Abren otro addon o una pantalla de Kodi, que quedarían debajo del modo sin verse.
_OCULTAS = {
    'loiolink_launch', 'topzilla_launch', 'espatv_install', 'espatv_launch', 'espadaily_launch',
    'loiolog_install', 'loiolog_launch', 'flowfav_launch', 'streamninja_launch',
    'atresdaily_launch', 'slyguy_install', 'url_player_ensure_sn', 'ek_launch',
    'espakodi_addons_menu', 'fantasia',
}
# Directos se ve dentro de una tele antigua. El resto de estilos se decide al cargar,
# mirando lo que trae el listado.
_ACCIONES_TELE = {'live_tv_menu', 'list_live_cats'}
_MUESTRA_ESTILO = 8
# Un listado que tarda más no se recarga por detrás al volver a él, como la ventana de
# Vídeos no vuelve a pedir los lentos (CFileItemList::CACHE_IF_SLOW).
_LENTO_S = 1.0
_TRANSICION_S = 0.7
_LETRA_S = 0.03

_ATRAS = (9, 10, 92)
_ACEPTAR = (7, 100)
_TECLAS = (1, 2, 3, 4, 7)
_ARRIBA_ABAJO = (3, 4)
_CLIC = 100
_RUEDA = {104: -1, 105: 1}
_GESTOS = (501, 504, 505, 599)
_GESTO_INICIO, _GESTO_ARRASTRE = 501, 504

_BUILTIN = re.compile(r'\s*([\w.]+)\s*(?:\((.*)\))?\s*$', re.S)
_NOMBRE = re.compile(r'[\w.\-]+$')
_FORMATO = re.compile(r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE)\]|\[COLOR [^\]]*\]|\[/COLOR\]|\[CR\]',
                      re.I)


def traducir(orden):
    """La orden para la ventana equivalente a ese builtin, o None si puede ir tal cual."""
    encontrado = _BUILTIN.match(orden)
    if encontrado is None:
        return None
    nombre, argumentos = encontrado.group(1).lower(), (encontrado.group(2) or '').strip()
    if nombre == 'container.refresh':
        return {'orden': 'refrescar'}
    if nombre == 'container.update':
        return _actualizar(argumentos)
    if nombre == 'runaddon':
        return _abrir_addon(argumentos)
    if nombre in ('activatewindow', 'replacewindow'):
        return _abrir_ventana(argumentos)
    return None


def _sin_comillas(texto):
    return texto.strip().strip('"')


def _actualizar(argumentos):
    url, _, resto = argumentos.rpartition(',')
    reemplazar = resto.strip().lower() == 'replace'
    if not reemplazar:
        url = argumentos
    url = _sin_comillas(url)
    return {'orden': 'ir', 'url': url, 'reemplazar': reemplazar} if url else None


def _abrir_addon(argumentos):
    ident = _sin_comillas(argumentos.partition(',')[0])
    if not _NOMBRE.match(ident):
        return None
    if RAIZ == f'plugin://{ident}/':
        # AtresDaily se relanza a sí mismo al aceptar o revocar los términos.
        return {'orden': 'ir', 'url': RAIZ, 'reemplazar': True}
    return {'orden': 'addon', 'id': ident}


def _abrir_ventana(argumentos):
    ventana, _, resto = argumentos.partition(',')
    ventana = _sin_comillas(ventana)
    # Un diálogo, como la rueda de espera, sale encima del modo sin problema.
    if not _NOMBRE.match(ventana) or 'dialog' in ventana.lower():
        return None
    ruta, _, ultimo = resto.rpartition(',')
    if ultimo.strip().lower() != 'return':
        ruta = resto
    ruta = _sin_comillas(ruta)
    if ruta.startswith(RAIZ):
        return {'orden': 'ir', 'url': ruta, 'reemplazar': False}
    return {'orden': 'ventana', 'ventana': ventana, 'url': ruta}


def orden_de_fuera(orden):
    """El builtin que abre fuera del modo lo que pide la orden, o None si no es válida.

    Las órdenes llegan por JSONRPC.NotifyAll, que puede mandar cualquiera, así que solo se
    montan builtins de forma fija con nombres y rutas comprobados.
    """
    tipo = orden.get('orden')
    if tipo == 'addon':
        ident = orden.get('id')
        return f'RunAddon({ident})' if isinstance(ident, str) and _NOMBRE.match(ident) else None
    ruta = orden.get('url', '')
    if not isinstance(ruta, str) or '"' in ruta:
        return None
    if tipo == 'ir':
        return f'ActivateWindow(videos,"{ruta}",return)' if ruta else None
    if tipo == 'ventana':
        ventana = orden.get('ventana')
        if not isinstance(ventana, str) or not _NOMBRE.match(ventana):
            return None
        return f'ActivateWindow({ventana},"{ruta}",return)' if ruta else f'ActivateWindow({ventana})'
    return None


def que_hacer(ruta, es_carpeta, reproducible):
    if not ruta:
        return None
    if not ruta.startswith(RAIZ):
        return 'fuera'
    if es_carpeta:
        return 'entrar'
    return 'reproducir' if reproducible else 'ejecutar'


def _clave(url):
    base, _, consulta = url.partition('?')
    pares = urllib.parse.parse_qsl(consulta, keep_blank_values=True)
    return base.rstrip('/'), tuple(sorted(p for p in pares if p[0] != _RECARGA))


def misma_ruta(una, otra):
    """Si dos URLs del plugin piden lo mismo, sin mirar codificación, orden ni relleno.

    Kodi reconstruye la URL que le pasa al plugin, así que compararlas como texto puede
    fallar por un %20 frente a un +.
    """
    return _clave(una) == _clave(otra)


def con_recarga(url, numero):
    return f'{url}{"&" if "?" in url else "?"}{_RECARGA}={numero}'


def accion_de(url):
    return dict(urllib.parse.parse_qsl(url.partition('?')[2])).get('action', '')


def estilo_de(miniaturas):
    """Galería si al menos la mitad de las miniaturas son fotos de verdad y no iconos."""
    fotos = sum(1 for miniatura in miniaturas if miniatura.startswith('http'))
    return 'galeria' if miniaturas and fotos * 2 >= len(miniaturas) else 'cascada'


def limpiar_rotulo(texto):
    """La etiqueta sin las marcas de formato de Kodi ni el punto verde de novedad."""
    return _FORMATO.sub('', texto).replace('●', '').strip()


def casilla_tocada(x):
    """Casillas desde la central del carrusel hasta lo que se ve en esa x del skin.

    Negativo a la izquierda.
    """
    if x < CENTRO[0]:
        return -1 - max(0, int((CENTRO[0] - _DESVIO_VECINOS - x) // CASILLA))
    if x >= CENTRO[1]:
        return 1 + max(0, int((x - CENTRO[1] - _DESVIO_VECINOS) // CASILLA))
    return 0


def menu_contextual(entradas):
    """Las entradas de un menú contextual, listas para el Modo Fantasía.

    Kodi ejecuta el builtin de una entrada sin pasar por Python, así que el puente no lo
    vería y un Container.Update acabaría en la ventana de Vídeos. Con el modo abierto, lo
    que el puente desviaría pasa por una llamada al plugin que lo ejecuta con el puente
    puesto (reenviar). Con el modo cerrado, las entradas quedan como están.
    """
    if not _puente:
        return list(entradas)
    return [(etiqueta, orden if traducir(orden) is None else
             f'RunPlugin({RAIZ}?action=fantasia_orden&orden={urllib.parse.quote(orden, safe="")})')
            for etiqueta, orden in entradas]


def _ventana_abierta():
    """Id de la ventana del modo si sigue abierta, o None."""
    valor = xbmcgui.Window(10000).getProperty(_PROPIEDAD)
    if not valor.isdigit() or not xbmc.getCondVisibility(f'Window.IsVisible({valor})'):
        return None
    return int(valor)


def _avisar(orden):
    peticion = {'jsonrpc': '2.0', 'id': 1, 'method': 'JSONRPC.NotifyAll',
                'params': {'sender': _EMISOR, 'message': 'fantasia', 'data': orden}}
    xbmc.executeJSONRPC(json.dumps(peticion))


def _oculta(url):
    return url.startswith(RAIZ) and accion_de(url) in _OCULTAS


def instalar_puente():
    """Hace que lo que esta llamada al plugin mande a la ventana actual vaya al modo.

    Solo actúa con la ventana abierta. Cada llamada al plugin es un intérprete nuevo, así
    que lo sustituido no sale de aquí. Con el modo cerrado cuesta una propiedad leída.
    """
    global _puente
    if _ventana_abierta() is None:
        return
    ejecutar = xbmc.executebuiltin
    terminar = xbmcplugin.endOfDirectory
    anadir = xbmcplugin.addDirectoryItem
    anadir_varios = xbmcplugin.addDirectoryItems
    origen = sys.argv[0] + (sys.argv[2] if len(sys.argv) > 2 else '')

    def executebuiltin(orden, wait=False):
        traducida = traducir(orden)
        if traducida is None:
            return ejecutar(orden, wait)
        _avisar(traducida)
        return None

    def endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
        terminar(handle, succeeded, updateListing, cacheToDisc)
        # Un interruptor es una carpeta que cambia el ajuste y cancela su listado para que
        # Kodi no entre en ella. Con handle -1 es un RunPlugin, que no lista nada.
        if not succeeded and handle >= 0:
            _avisar({'orden': 'cancelar', 'url': origen})

    def addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
        if _oculta(url):
            return True
        return anadir(handle, url, listitem, isFolder, totalItems)

    def addDirectoryItems(handle, items, totalItems=0):
        return anadir_varios(handle, [item for item in items if not _oculta(item[0])], totalItems)

    _puente = True
    xbmc.executebuiltin = executebuiltin
    xbmcplugin.endOfDirectory = endOfDirectory
    xbmcplugin.addDirectoryItem = addDirectoryItem
    xbmcplugin.addDirectoryItems = addDirectoryItems


def reenviar(orden):
    """Ejecuta la entrada del menú contextual que menu_contextual() pasó por el plugin.

    Con el modo abierto, el puente de esta llamada la lleva a la ventana. Si el modo se ha
    cerrado entretanto, hace lo que la entrada hacía antes. Solo acepta lo que traducir()
    entiende.
    """
    if traducir(orden) is not None:
        xbmc.executebuiltin(orden)


def _sonidos_activos(ajuste):
    if ajuste == 'false':
        return False
    # Si Kodi tiene quitados sus sonidos de navegación (audiooutput.guisoundmode 0),
    # tampoco suenan los nuestros.
    peticion = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                'params': {'setting': 'audiooutput.guisoundmode'}}
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(peticion)))['result']['value'] != 0
    except (ValueError, KeyError, TypeError):
        return True


def _nivel(ajuste):
    return str(int(ajuste) + 1) if ajuste in ('0', '1', '2') else '2'


class _Ventana(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Lo que tiene que durar más que la ventana (se reabre tras un vídeo) lo pone mostrar().
        # Cada nivel de la pila: [url, posición del foco, nombre de la sección, lista].
        self.pila = [[RAIZ, 0, '', ID_CARRUSEL]]
        self.estilos = {}
        self.lentas = set()
        self.primera = False
        self.motivo = 'salir'
        self.destino = None
        self._iniciada = False
        self._cerrada = False
        self._id = 0
        self._navegado_en = 0.0
        self._pulsado_en = 0.0
        self._cancelado_en = 0.0
        self._transicion_en = 0.0
        self._canal_en = 0.0
        self._recargas = 0
        self._esperando = False
        self._activa = None
        # Por lista: la URL puesta en su propiedad y la clave de lo que tiene cargado.
        self._rutas = {}
        self._contenido = {}
        # Arrastre en marcha sobre el carrusel: dónde empezó el dedo (x del skin), lo elegido
        # entonces y cuántos hay; aparte, lo elegido ahora.
        self._arrastre = None
        self._arrastre_elegido = 0
        self._ultimo_rotulo = ''
        self._con_sonido = False
        self._sonidos = ''

    def onInit(self):
        # Kodi puede repetir onInit; sin la guarda se duplicarían hilos y navegación.
        if self._iniciada:
            return
        self._iniciada = True
        try:
            self._id = xbmcgui.getCurrentWindowDialogId()
            xbmcgui.Window(10000).setProperty(_PROPIEDAD, str(self._id))
            self.aplicar_ajustes()
            threading.Thread(target=self._vigilar_apagado, daemon=True).start()
            if self.primera:
                self._sonar('apertura')
            self._mostrar()
        except Exception:
            # Kodi se traga los errores de onInit y la ventana saldría vacía sin rastro.
            xbmc.log(f'{_LOG} fallo al abrir\n{traceback.format_exc()}', xbmc.LOGERROR)

    def aplicar_ajustes(self):
        """Nivel de efectos, contador y sonidos. Se repite si cambian con el modo abierto."""
        addon = xbmcaddon.Addon()
        self.setProperty('nivel', _nivel(addon.getSetting('fantasia_nivel')))
        self.setProperty('fps', '1' if addon.getSetting('fantasia_fps') == 'true' else '')
        self._con_sonido = _sonidos_activos(addon.getSetting('fantasia_sonidos'))
        self._sonidos = os.path.join(addon.getAddonInfo('path'), 'resources', 'sounds')

    def cerrar(self, motivo, destino=None):
        self.motivo, self.destino = motivo, destino
        self._cerrada = True
        self.close()

    def _vigilar_apagado(self):
        # Al apagar, Kodi espera a los scripts antes de cerrar sus diálogos: sin esto
        # doModal no volvería y Kodi mataría el script a los cinco segundos.
        monitor = xbmc.Monitor()
        while not self._cerrada:
            if monitor.waitForAbort(0.5):
                self.cerrar('apagar')
                return

    def _sonar(self, nombre):
        if self._con_sonido:
            xbmc.playSFX(os.path.join(self._sonidos, f'fantasia_{nombre}.wav'))

    def _lista(self):
        """La lista del nivel de arriba: el carrusel en la raíz y, por debajo, una de LISTAS."""
        return self.pila[-1][3]

    def _arriba(self):
        """Si no hay otro diálogo modal encima.

        Con un diálogo modal delante (un select o el teclado que abre el plugin), Kodi
        resuelve Container(id) contra ese diálogo y los InfoLabels de nuestras listas salen
        vacíos. Los avisos y las barras de progreso de fondo no son modales y no cambian
        nada, pero Window.IsTopMost también los cuenta.
        """
        return xbmc.getCondVisibility(f'Window.IsModalDialogTopmost({self._id})')

    def _foco(self):
        try:
            return self.getFocusId()
        except RuntimeError:
            return 0

    def _apuntar_posicion(self):
        """Guarda en la pila dónde está el foco. Si no se puede leer, deja lo que había."""
        actual = xbmc.getInfoLabel(f'Container({self._lista()}).CurrentItem')
        if self._arriba() and actual.isdigit() and int(actual) > 0:
            self.pila[-1][1] = int(actual) - 1

    def _poner_ruta(self, lista, ruta):
        self._rutas[lista] = ruta
        self.setProperty(f'ruta_{lista}', ruta)

    def _con_recarga(self, url):
        self._recargas += 1
        return con_recarga(url, self._recargas)

    def _fin_de_espera(self):
        self._esperando = False
        self.setProperty('esperando', '')

    def _activar(self, lista, rotulo, marca):
        """Pone a la vista la lista y el nombre de su sección. La que había se retira."""
        self._activa = lista
        self.setProperty('activa', str(lista))
        self.setProperty('carga', '')
        threading.Thread(target=self._escribir, args=(rotulo, marca), daemon=True).start()

    def _mostrar(self, recargar=False):
        """Enseña el nivel de arriba de la pila en su lista.

        Si esa lista aún tiene lo que se vio, sale al momento. Si no, carga por detrás,
        invisible y sin poder recibir el foco (fantasia.xml), mientras sigue a la vista la
        de antes: un interruptor, que cancela su listado, no llega a mover nada.
        """
        url, posicion, rotulo, lista = self.pila[-1]
        clave = _clave(url)
        self._navegado_en = marca = time.monotonic()
        if self._contenido.get(lista) == clave:
            # Al volver a un listado rápido se pide otra vez por detrás, sin apagarlo, para
            # que los interruptores y los puntos verdes salgan al día.
            if recargar or (lista != self._activa and clave not in self.lentas):
                self._poner_ruta(lista, self._con_recarga(url))
            self._fin_de_espera()
            self.setProperty(f'listo_{lista}', '1')
            if lista != self._activa:
                self._activar(lista, rotulo, marca)
            else:
                # Lo que cargaba por detrás (un interruptor cancelado, o se volvió antes de
                # que acabara) deja de hacerlo.
                self.setProperty('carga', '')
            hilo = threading.Thread(target=self._enfocar_cuando_pueda, args=(lista, marca), daemon=True)
        else:
            self._contenido.pop(lista, None)
            self.setProperty(f'listo_{lista}', '')
            estilo = ''
            if lista != ID_CARRUSEL:
                estilo = 'tele' if accion_de(url) in _ACCIONES_TELE else self.estilos.get(clave, '')
                if estilo:
                    self.setProperty(f'estilo_{lista}', estilo)
            # Con la misma URL el proveedor no volvería a pedir el listado.
            self._poner_ruta(lista, url if self._rutas.get(lista) != url else self._con_recarga(url))
            self._esperando = True
            self.setProperty('esperando', '1')
            if self._activa in (None, lista):
                # Nada que dejar a la vista: al abrir, o si cambia lo que tiene esta misma lista.
                self._activar(lista, rotulo, marca)
            else:
                self.setProperty('carga', str(lista))
            hilo = threading.Thread(target=self._enfocar, daemon=True,
                                    args=(lista, clave, rotulo, posicion, marca,
                                          lista != ID_CARRUSEL and not estilo))
        hilo.start()

    def _recargar(self):
        """Vuelve a pedir el listado de la lista actual sin apagarla."""
        self._poner_ruta(self._lista(), self._con_recarga(self.pila[-1][0]))

    def _enfocar(self, lista, clave, rotulo, posicion, marca, decidir_estilo):
        """Cuando termina la carga: decide el estilo, pone la lista a la vista y el foco en ella.

        El proveedor ve la URL nueva en el fotograma siguiente, y desde entonces IsUpdating
        dice que sí hasta que tiene el listado. Si no llega a verse, a los 0,5 s se da por
        cargado.
        """
        monitor = xbmc.Monitor()
        inicio = time.monotonic()
        visto = hubo_dialogo = False
        while time.monotonic() - inicio < 60:
            if self._cerrada or marca != self._navegado_en:
                return
            # Con un diálogo del plugin delante, IsUpdating se leería de ese diálogo.
            if not self._arriba():
                hubo_dialogo = True
            elif xbmc.getCondVisibility(f'Container({lista}).IsUpdating'):
                visto = True
            elif visto or time.monotonic() - inicio > 0.5:
                break
            if monitor.waitForAbort(0.04):
                return
        if self._cerrada or marca != self._navegado_en:
            return
        if time.monotonic() - inicio > _LENTO_S:
            self.lentas.add(clave)
        total = xbmc.getInfoLabel(f'Container({lista}).NumItems')
        total = int(total) if total.isdigit() else 0
        if not total and lista != self._activa and lista in LISTAS:
            # Con un listado vacío o fallido (un diálogo cancelado que no cierra el listado),
            # Kodi se queda en la carpeta donde estaba. Aquí igual: sigue a la vista la lista
            # de antes y el nivel sale de la pila.
            self.pila.pop()
            self.setProperty('carga', '')
            self._fin_de_espera()
            if not hubo_dialogo:
                xbmcgui.Dialog().notification(limpiar_rotulo(rotulo) or 'AtresDaily', 'No hay nada que mostrar',
                                              xbmcgui.NOTIFICATION_INFO, 2500)
            return
        # Vacío o fallido no se guarda: la próxima vez se pide de nuevo.
        if total:
            self._contenido[lista] = clave
        if decidir_estilo:
            miniaturas = [xbmc.getInfoLabel(f'Container({lista}).ListItemAbsolute({i}).Art(thumb)')
                          for i in range(min(total, _MUESTRA_ESTILO))]
            estilo = estilo_de(miniaturas)
            if total:
                self.estilos[clave] = estilo
            self.setProperty(f'estilo_{lista}', estilo)
        if total:
            self.getControl(lista).selectItem(min(posicion, total - 1))
        self.setProperty(f'listo_{lista}', '1')
        if lista != self._activa:
            self._activar(lista, rotulo, marca)
        self._fin_de_espera()
        if total:
            self._enfocar_cuando_pueda(lista, marca)

    def _enfocar_cuando_pueda(self, lista, marca):
        # La lista se activa en el fotograma siguiente, y enfocarla antes no surte efecto.
        # Una lista vacía no se puede enfocar: el foco se queda donde estaba.
        monitor = xbmc.Monitor()
        for _ in range(15):
            if self._cerrada or marca != self._navegado_en:
                return
            if xbmc.getCondVisibility(f'Control.IsEnabled({lista}) + Control.IsVisible({lista})'):
                break
            if monitor.waitForAbort(0.02):
                return
        self.setFocusId(lista)

    def _escribir(self, rotulo, marca):
        """El nombre de la sección, letra a letra. Son pocas llamadas y solo al navegar."""
        monitor = xbmc.Monitor()
        for letras in range(len(rotulo) + 1):
            if self._cerrada or marca != self._navegado_en:
                return
            self.setProperty('seccion', rotulo[:letras])
            if monitor.waitForAbort(_LETRA_S):
                return

    def _transicion(self, tipo):
        self.setProperty('transicion', tipo)
        marca = time.monotonic()
        self._transicion_en = marca

        def apagar():
            if not xbmc.Monitor().waitForAbort(_TRANSICION_S) and self._transicion_en == marca:
                self.setProperty('transicion', '')

        threading.Thread(target=apagar, daemon=True).start()

    def _cambio_de_canal(self):
        # En una lista, bajar dentro de la página no mueve el contenedor y Container.OnNext
        # no se entera: la ráfaga de estática de la tele la dispara esta propiedad.
        self._sonar('canal')
        self.setProperty('canal', '1')
        marca = time.monotonic()
        self._canal_en = marca

        def apagar():
            if not xbmc.Monitor().waitForAbort(0.25) and self._canal_en == marca:
                self.setProperty('canal', '')

        threading.Thread(target=apagar, daemon=True).start()

    def _cargando(self):
        return (time.monotonic() - self._navegado_en < 0.3
                or xbmc.getCondVisibility(f'Container({self._lista()}).IsUpdating'))

    def _sentido(self, tipo):
        # transicion dura lo que el salto al hiperespacio; sentido, hasta la próxima
        # navegación, porque la lista nueva puede tardar más en entrar.
        self.setProperty('sentido', tipo)
        self._transicion(tipo)
        self._sonar(tipo)

    def _ir(self, url, rotulo):
        if misma_ruta(url, RAIZ):
            self._a_la_raiz()
            return
        self._apuntar_posicion()
        # Cada nivel se carga en la lista que no usa el de arriba, que así sigue cargado.
        lista = LISTAS[1] if self._lista() == LISTAS[0] else LISTAS[0]
        self.pila.append([url, 0, rotulo, lista])
        self._sentido('entrar')
        self._mostrar()

    def _a_la_raiz(self):
        del self.pila[1:]
        self._sentido('volver')
        self._mostrar()

    def _volver(self):
        if len(self.pila) == 1:
            self._sonar('volver')
            self.cerrar('salir')
            return
        self.pila.pop()
        self._sentido('volver')
        self._mostrar()

    def _salir_a(self, orden):
        destino = orden_de_fuera(orden)
        if destino:
            self.cerrar('fuera', destino)

    def ordenar(self, orden):
        """Lo que llega del puente, desde otra llamada al plugin."""
        tipo = orden.get('orden')
        if tipo == 'ir':
            url = orden.get('url')
            if not isinstance(url, str) or not url:
                return
            if not url.startswith(RAIZ):
                self._salir_a(orden)
            elif orden.get('reemplazar'):
                if misma_ruta(url, RAIZ):
                    self._a_la_raiz()
                else:
                    self.pila[-1][:2] = [url, 0]
                    self._mostrar()
            elif misma_ruta(url, self.pila[-1][0]):
                self._recargar()
            elif self._esperando and len(self.pila) > 1:
                # Llega mientras carga el nivel de arriba: ese listado redirige. Como en Kodi,
                # la carpeta que redirige no queda en el historial, y volver atrás no la
                # ejecuta otra vez.
                self.pila[-1][:2] = [url, 0]
                self._mostrar()
            else:
                self._ir(url, self._ultimo_rotulo or self.pila[-1][2])
        elif tipo == 'refrescar':
            # Kodi descarta un Refresh que llega con el listado cargando, y así un listado
            # que se refresca a sí mismo no entra en bucle. Tras cancelar un interruptor,
            # la vuelta atrás ya ha recargado el menú.
            if not self._cargando() and time.monotonic() - self._cancelado_en >= 2:
                self._recargar()
        elif tipo == 'cancelar':
            url = orden.get('url')
            if isinstance(url, str):
                self._cancelar(url)
        elif tipo in ('addon', 'ventana'):
            self._salir_a(orden)

    def _cancelar(self, url):
        """Quita de la pila el listado que se ha cancelado.

        Un interruptor cancela su propio listado, que es el de arriba. Un listado que
        redirige con Container.Update y luego se cancela queda justo debajo del destino;
        si se dejara, volver atrás lo ejecutaría otra vez y redirigiría de nuevo.
        """
        for nivel in range(len(self.pila) - 1, 0, -1):
            if misma_ruta(url, self.pila[nivel][0]):
                break
        else:
            return
        self._cancelado_en = time.monotonic()
        lista = self.pila[nivel][3]
        del self.pila[nivel]
        if nivel < len(self.pila):
            return
        self._contenido.pop(lista, None)
        # La lista de debajo no llegó a irse; se recarga para que el interruptor salga al día.
        self._mostrar(recargar=True)

    def onAction(self, accion):
        codigo = accion.getId()
        if codigo in _ATRAS:
            self._volver()
            return
        if self._activa == ID_CARRUSEL and self._raton_en_carrusel(accion, codigo):
            return
        foco = self._foco()
        if codigo in _ACEPTAR and foco in _CONTENEDORES:
            self._pulsar(foco)
        elif codigo in _TECLAS and foco not in _CONTENEDORES + (ID_CERRAR,):
            # El puntero quita el foco a la lista al salir de ella, y con la tecla siguiente
            # Kodi se lo da al ancla. Sin esto, tras usar el ratón se perderían dos teclas.
            # La activa es la que está a la vista, aunque cargue otra por detrás.
            lista = self._activa
            if lista and xbmc.getCondVisibility(
                    f'Control.IsEnabled({lista}) + Integer.IsGreater(Container({lista}).NumItems,0)'):
                self.setFocusId(lista)
        elif codigo in _ARRIBA_ABAJO and foco in LISTAS and self.getProperty(f'estilo_{foco}') == 'tele':
            self._cambio_de_canal()

    def onClick(self, control_id):
        if control_id == ID_CERRAR:
            self.cerrar('salir')

    def _raton_en_carrusel(self, accion, codigo):
        """Clic, rueda o arrastre sobre el carrusel. True si queda atendido.

        En un fixedlist, Kodi no elige lo que se toca fuera de la casilla del foco, sino que
        acumula desplazamiento y abre el elemento enfocado (GUIFixedListContainer::
        SelectItemFromPoint). Por eso en fantasia.xml el carrusel solo recibe el ratón en su
        casilla central y una capa encima se queda con los arrastres; los vecinos y los
        arrastres se atienden aquí.
        """
        if codigo in _GESTOS:
            return self._arrastrar(accion, codigo)
        if codigo != _CLIC and codigo not in _RUEDA:
            return False
        x, y = self._en_el_skin(accion)
        if not FRANJA[0] <= y < FRANJA[1]:
            return False
        paso = casilla_tocada(x)
        if codigo in _RUEDA:
            # Sobre la casilla central, la rueda ya la atiende la lista.
            if paso:
                self._mover_carrusel(_RUEDA[codigo])
        elif paso:
            self._mover_carrusel(paso)
        else:
            self._pulsar(ID_CARRUSEL)
        return True

    @staticmethod
    def _en_el_skin(accion):
        # Kodi da el puntero en píxeles de su superficie, que se estira a las 1920x1080 del skin.
        ancho = xbmcgui.getScreenWidth() or 1920
        alto = xbmcgui.getScreenHeight() or 1080
        return accion.getAmount1() * 1920 / ancho, accion.getAmount2() * 1080 / alto

    def _arrastrar(self, accion, codigo):
        """Un arrastre horizontal por el carrusel.

        Lo elegido se corre tantas casillas como recorre el dedo, redondeando, y vuelve si
        el dedo vuelve. Pasado el final, el dedo tiene que regresar hasta él para que el
        carrusel se mueva otra vez.
        """
        x, y = self._en_el_skin(accion)
        if codigo == _GESTO_INICIO:
            posicion = self._posicion_carrusel() if FRANJA[0] <= y < FRANJA[1] else None
            self._arrastre = (x, *posicion) if posicion else None
            if posicion:
                self._arrastre_elegido = posicion[0]
            return posicion is not None
        if self._arrastre is None:
            return False
        if codigo == _GESTO_ARRASTRE:
            inicio, desde, total = self._arrastre
            elegido = max(0, min(total - 1, desde + round((inicio - x) / CASILLA)))
            if elegido != self._arrastre_elegido:
                self._arrastre_elegido = elegido
                self.setFocusId(ID_CARRUSEL)
                self.getControl(ID_CARRUSEL).selectItem(elegido)
        else:
            self._arrastre = None
            # Si empezó fuera de la casilla central, Kodi le quitó el foco al carrusel.
            self.setFocusId(ID_CARRUSEL)
        return True

    @staticmethod
    def _posicion_carrusel():
        """Lo elegido en el carrusel, contando desde 0, y cuántos tiene. None si no se lee."""
        total = xbmc.getInfoLabel(f'Container({ID_CARRUSEL}).NumItems')
        actual = xbmc.getInfoLabel(f'Container({ID_CARRUSEL}).CurrentItem')
        if total.isdigit() and actual.isdigit() and int(total):
            return int(actual) - 1, int(total)
        return None

    def _mover_carrusel(self, paso):
        posicion = self._posicion_carrusel()
        if posicion:
            actual, total = posicion
            self.setFocusId(ID_CARRUSEL)
            self.getControl(ID_CARRUSEL).selectItem(max(0, min(total - 1, actual + paso)))

    def _pulsar(self, lista):
        # Otra pulsación mientras carga lo pulsado repetiría la acción sobre la lista vieja:
        # dos niveles iguales en la pila o el mismo vídeo dos veces.
        ahora = time.monotonic()
        if self._esperando or ahora - self._pulsado_en < 0.5:
            return
        self._pulsado_en = ahora
        # getSelectedItem() devuelve None en las listas que rellena Kodi (Control.cpp solo
        # mira los ítems añadidos desde Python), así que el ítem se lee por InfoLabels.
        base = f'Container({lista}).ListItem'
        ruta = xbmc.getInfoLabel(f'{base}.FolderPath')
        carpeta = xbmc.getCondVisibility(f'{base}.IsFolder')
        reproducible = xbmc.getInfoLabel(f'{base}.Property(IsPlayable)').lower() == 'true'
        rotulo = limpiar_rotulo(xbmc.getInfoLabel(f'{base}.Label'))
        que = que_hacer(ruta, carpeta, reproducible)
        # Se apunta ya: si esto acaba en un vídeo, la ventana se cierra y al volver tiene
        # que abrirse donde estaba.
        self._apuntar_posicion()
        if que == 'entrar':
            self._ir(ruta, rotulo)
        elif que == 'reproducir':
            self._sonar('reproducir')
            xbmc.executebuiltin(f'PlayMedia("{ruta}")')
        elif que == 'ejecutar':
            # Si la acción acaba llevando a otra pantalla (una búsqueda), esa pantalla se
            # llama como lo que se pulsó.
            self._ultimo_rotulo = rotulo
            xbmc.executebuiltin(f'RunPlugin("{ruta}")')
        elif que == 'fuera' and carpeta:
            self._salir_a({'orden': 'ir', 'url': ruta})
        elif que == 'fuera':
            # Un vídeo de otro addon: al empezar, _Vigia cierra la ventana y vuelve después.
            xbmc.executebuiltin(f'PlayMedia("{ruta}")')


class _Vigia(xbmc.Player):
    """Cierra la ventana cuando arranca un vídeo, venga de donde venga.

    Un diálogo abierto taparía el vídeo, y el que lo lanza puede ser otra llamada al
    plugin o el Modo Cine abierto desde dentro.
    """

    def __init__(self):
        super().__init__()
        self.ventana = None

    def onAVStarted(self):
        if self.ventana is not None and self.isPlayingVideo():
            self.ventana.cerrar('video')


class _Escucha(xbmc.Monitor):

    def __init__(self):
        super().__init__()
        self.ventana = None

    def onNotification(self, sender, method, data):
        if self.ventana is None or sender != _EMISOR or not method.endswith('fantasia'):
            return
        try:
            orden = json.loads(data)
        except ValueError:
            xbmc.log(f'{_LOG} orden ilegible: {data!r}', xbmc.LOGWARNING)
            return
        if isinstance(orden, dict):
            self.ventana.ordenar(orden)

    def onSettingsChanged(self):
        if self.ventana is not None:
            self.ventana.aplicar_ajustes()


def _esperar_fin_del_video(monitor, jugador, origen, es_mio):
    """True si hay que volver a abrir la ventana cuando acabe la reproducción.

    Una cola encadena vídeos, así que se da por acabada tras dos segundos sin nada. Si
    entretanto el modo se abre desde otra llamada al plugin, esa lo lleva y aquí se acaba.
    """
    quieto = 0
    while quieto < 4:
        if monitor.waitForAbort(0.5) or not es_mio():
            return False
        quieto = 0 if jugador.isPlayingVideo() else quieto + 1
    # Kodi rechaza abrir una ventana con un diálogo modal delante (Gamesek), y el que
    # quede tarda en irse por su animación.
    for _ in range(20):
        if not xbmc.getCondVisibility('System.HasActiveModalDialog'):
            break
        if monitor.waitForAbort(0.5) or not es_mio():
            return False
    # Si el usuario se ha ido a otra parte durante el vídeo, el modo termina ahí.
    return xbmcgui.getCurrentWindowId() == origen and es_mio()


def mostrar():
    if _ventana_abierta() is not None:
        xbmcgui.Dialog().notification('Modo Fantasía', 'Ya está abierto',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return
    casa = xbmcgui.Window(10000)
    turno = os.urandom(8).hex()
    casa.setProperty(_TURNO, turno)

    def es_mio():
        return casa.getProperty(_TURNO) == turno

    ruta_addon = xbmcaddon.Addon().getAddonInfo('path')
    # La ventana de debajo (Vídeos, o Inicio si se abrió desde un widget): tras un vídeo,
    # el modo solo vuelve si el usuario sigue en ella.
    origen = xbmcgui.getCurrentWindowId()
    pila, estilos, lentas = [[RAIZ, 0, '', ID_CARRUSEL]], {}, set()
    jugador, escucha = _Vigia(), _Escucha()
    primera = True
    try:
        while True:
            ventana = _Ventana('fantasia.xml', ruta_addon, 'Default', '1080i')
            ventana.pila, ventana.estilos, ventana.lentas = pila, estilos, lentas
            ventana.primera, primera = primera, False
            jugador.ventana = escucha.ventana = ventana
            ventana.doModal()
            jugador.ventana = escucha.ventana = None
            # Cerrada la ventana, las llamadas al plugin vuelven a ser normales, también
            # durante el vídeo, cuando otra ventana de Python podría heredar su id.
            if es_mio():
                casa.clearProperty(_PROPIEDAD)
            motivo, destino = ventana.motivo, ventana.destino
            del ventana
            if motivo == 'video' and _esperar_fin_del_video(escucha, jugador, origen, es_mio):
                continue
            if motivo == 'fuera':
                xbmc.executebuiltin(destino)
            break
    finally:
        # Si el modo se ha abierto desde otra llamada, sus propiedades son de esa.
        if es_mio():
            casa.clearProperty(_PROPIEDAD)
            casa.clearProperty(_TURNO)
