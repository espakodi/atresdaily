async function _fetch(path, opts = {}) {
  const r = await fetch(path, opts);
  if (!r.ok) {
    let err;
    try { err = await r.json(); } catch { err = { error: r.statusText }; }
    throw new Error(err.error || r.statusText);
  }
  return r.json();
}

function _qs(obj) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj || {})) {
    if (v !== undefined && v !== null) p.set(k, v);
  }
  const s = p.toString();
  return s ? `?${s}` : '';
}

// Caché en memoria, para volver atrás sin repetir peticiones
const _memCache = new Map();

async function _fetchCached(path, ttl) {
  const now = Date.now();
  const entry = _memCache.get(path);
  if (entry && entry.exp > now) return entry.data;
  const data = await _fetch(path);
  _memCache.set(path, { data, exp: now + ttl * 1000 });
  return data;
}

export const API = {
  home: () => _fetchCached('/api/home', 300),

  // Catálogo y secciones
  list: (params) => _fetchCached('/api/list' + _qs(params), 1800),

  // Temporadas y episodios de un programa
  details: (url, ctx = '') => _fetchCached('/api/details' + _qs({ url, ctx }), 600),

  search: (q) => _fetchCached('/api/search' + _qs({ q }), 300),

  liveChannels: () => _fetchCached('/api/live/channels', 3600),

  epg: (channel, name = '') => _fetch('/api/live/epg' + _qs({ channel, name })),

  resolve: (payload) => _fetch('/api/resolve', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }),

  getFavorites: () => _fetch('/api/favorites'),

  toggleFavorite: (url, title, thumb) => _fetch('/api/favorites', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ op: 'toggle', url, title, thumb }),
  }),

  getHistory: () => _fetch('/api/history'),

  saveProgress: (id, position, duration, title = '', thumb = '') =>
    _fetch('/api/history/progress', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, position, duration, title, thumb }),
    }).catch(() => {}),
};
