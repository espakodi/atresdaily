const CACHE = 'atresdaily-v9';
const SHELL = [
  '/',
  '/css/base.css?v=9',
  '/css/layout.css?v=9',
  '/css/cards.css?v=9',
  '/css/player.css?v=9',
  '/css/animations.css?v=9',
  '/css/mobile.css?v=9',
  '/js/app.js?v=9',
  '/js/api.js',
  '/js/icons.js',
  '/js/ui/home.js',
  '/js/ui/row.js',
  '/js/ui/grid.js',
  '/js/ui/player.js',
  '/js/ui/search.js',
  '/js/ui/live.js',
  '/js/ui/toast.js',
  '/js/vendor/hls.min.js',
  '/manifest.webmanifest',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(SHELL.map(u => new Request(u, { cache: 'reload' })))).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);

  // Excluir de la caché las peticiones de API, proxy y miniaturas dinámicas
  if (url.pathname.startsWith('/api/') ||
      url.pathname.startsWith('/proxy/') ||
      url.pathname.startsWith('/thumb/')) {
    return;
  }

  // Estrategia Stale-While-Revalidate para recursos estáticos
  if (url.pathname.startsWith('/css/') ||
      url.pathname.startsWith('/js/') ||
      url.pathname.startsWith('/img/')) {
    e.respondWith(
      caches.open(CACHE).then(cache =>
        cache.match(e.request).then(cached => {
          const fetchPromise = fetch(e.request).then(r => {
            if (r && r.status === 200) cache.put(e.request, r.clone());
            return r;
          }).catch(() => cached);
          return cached || fetchPromise;
        })
      )
    );
    return;
  }

  // La página se pide primero a la red; sin conexión, sale de la caché
  e.respondWith(
    fetch(e.request).catch(() => caches.match('/'))
  );
});
