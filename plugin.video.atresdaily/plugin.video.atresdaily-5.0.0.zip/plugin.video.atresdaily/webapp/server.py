# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import os
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import proxy
from .api import handle_api

_STATIC_DIR = os.path.join(os.path.dirname(__file__), 'static')
_STATIC_ROOT = os.path.realpath(_STATIC_DIR)

_MIME_MAP = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json',
    '.webmanifest': 'application/manifest+json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
}


class _Handler(BaseHTTPRequestHandler):
    # Segundos sin actividad por conexión. Sin límite, un cliente que deja la conexión
    # abierta retiene su hilo y la invocación de Kodi que aloja el servidor.
    timeout = 60

    def log_message(self, fmt, *args):
        pass  # Desactivar logs verbosos de peticiones HTTP en consola

    # Sin do_OPTIONS ni cabeceras CORS en la API. El frontend es del mismo origen, y con CORS
    # cualquier web podría mandar POST con JSON al servidor.
    def do_GET(self):
        self._dispatch('GET')

    def do_POST(self):
        self._dispatch('POST')

    def _dispatch(self, method):
        path = self.path

        if path.startswith('/proxy/'):
            self._handle_proxy(path)
            return

        if path.startswith('/thumb/'):
            thumb_id = path[7:].split('?')[0]
            proxy.serve_thumb(self, thumb_id)
            return

        if path.startswith('/api/'):
            try:
                handle_api(self, path, method)
            except Exception as e:
                body = json.dumps({'error': str(e)}).encode()
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            return

        self._serve_static(path)

    def _handle_proxy(self, path):
        # Rutas de proxy HLS admitidas: /proxy/<token>/{master.m3u8 | variant | seg | key | sub}
        parts = path.lstrip('/').split('/', 2)
        if len(parts) < 3:
            self.send_error(400)
            return
        _, token, rest = parts
        u_param = None
        if '?' in rest:
            rest, qs = rest.split('?', 1)
            import urllib.parse
            u_param = dict(urllib.parse.parse_qsl(qs)).get('u', '')

        if rest == 'master.m3u8':
            proxy.serve_playlist(self, token, 'master')
        elif rest == 'variant':
            proxy.serve_playlist(self, token, 'variant', u_param)
        elif rest in ('seg', 'key', 'sub'):
            proxy.serve_segment(self, token, u_param)
        else:
            self.send_error(404)

    def _serve_static(self, path):
        # Lo que no es un archivo devuelve index.html, porque la página enruta por su cuenta (SPA)
        clean = path.split('?')[0]
        rel = clean.lstrip('/')
        if not rel:
            rel = 'index.html'

        full = os.path.join(_STATIC_DIR, rel.replace('/', os.sep))
        if not os.path.realpath(full).startswith(_STATIC_ROOT + os.sep):
            self.send_error(403)
            return
        if not os.path.isfile(full):
            full = os.path.join(_STATIC_DIR, 'index.html')

        try:
            with open(full, 'rb') as f:
                data = f.read()
        except OSError:
            self.send_error(404)
            return

        ext = os.path.splitext(full)[1].lower()
        ct = _MIME_MAP.get(ext, mimetypes.guess_type(full)[0] or 'application/octet-stream')

        self.send_response(200)
        self.send_header('Content-Type', ct)
        self.send_header('Content-Length', str(len(data)))
        if ext in ('.js', '.css', '.png', '.jpg', '.ico', '.svg', '.webmanifest'):
            self.send_header('Cache-Control', 'public, max-age=86400')
        else:
            self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(data)


class _Server(ThreadingHTTPServer):
    # En Windows SO_REUSEADDR deja que dos sockets escuchen en el mismo puerto sin error,
    # así que un puerto ocupado no daría OSError y no se probaría el siguiente. En Linux y
    # Android se mantiene, porque allí hace falta para reabrir el puerto con conexiones en TIME_WAIT.
    allow_reuse_address = os.name != 'nt'


def make_server(host='127.0.0.1', port=8092):
    for p in range(port, port + 8):
        try:
            srv = _Server((host, p), _Handler)
            return srv, p
        except OSError:
            continue
    raise RuntimeError('No hay puertos disponibles en el rango 8092-8099')
