# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Adaptador de datos de la WebApp: normalización, puntuación y búsqueda."""

import difflib
import re
import threading
import time

import categorias

try:
    import connectorexperimental as ce
except ImportError:
    ce = None

_BBCODE_RE = re.compile(r'\[/?[A-Za-z][A-Za-z0-9=/ #]*\]')
_PREMIUM_TAGS = ("EXCLUSIVE", "ORIGINAL", "PREVIEW")

# Constantes que consume api.py; sin conector, valores mínimos. Las categorías, con el
# nombre que se enseña.
_HEADERS = ce.HEADERS if ce else {"User-Agent": "Mozilla/5.0"}
_DM_HEADERS = ce.DM_HEADERS if ce else {"User-Agent": "Mozilla/5.0"}
CATS = [(categorias.nombre(n), c) for n, c in ce.CATS] if ce else []


def strip_bbcode(s):
    """Elimina etiquetas BBCode de Kodi como [COLOR blue], [B], [/COLOR], etc."""
    if not s:
        return s
    return _BBCODE_RE.sub('', s).strip()


def _img(url):
    return ce._fix_img(url) if ce else (url or "")


def get_category_items(cat_id, page=0, size=50):
    return ce.get_category_items(cat_id, page, size) if ce else []


def get_catalog_overview():
    return [dict(sec, name=categorias.nombre(sec["name"])) for sec in ce.get_catalog_overview()] if ce else []


def get_details(url):
    return ce.get_details(url) if ce else {}


def get_episodes(url):
    return ce.get_episodes(url) if ce else []


def get_show_page(url):
    """Temporadas, capítulos y página siguiente de un programa, o None si no se pueden sacar."""
    fn = getattr(ce, "show_page", None) if ce else None
    return fn(url) if fn else None


def get_live_channels():
    return ce.get_live_channels() if ce else []


def get_channel_logo(ch_id):
    return ce.get_channel_logo(ch_id) if ce else ""


def resolve_live(ch_id):
    return ce.resolve_live(ch_id) if ce else (None, None)


def resolve_episode(vid):
    return ce.resolve_episode(vid) if ce else (None, None)


def search_dailymotion(q, limit=50):
    return ce.search_dailymotion(q, limit) if ce else []


def get_dm_thumb(vid):
    return ce.get_dm_thumb(vid) if ce else ''


def normalize_catalog_row(row):
    """Convierte un row (programa/serie) a un item normalizado."""
    img = (row.get("image") or {}).get("pathHorizontal") or (row.get("image") or {}).get("pathVertical")
    return {
        "title": row.get("title", "Sin título"),
        "url": (row.get("link") or {}).get("href", ""),
        "thumb": _img(img),
        "plot": row.get("description", ""),
    }


def _etiqueta(row):
    """Lo que dicen del acceso las marcas de un capítulo, lo mismo que en las listas de Kodi."""
    tag = row.get("tagType", "")
    if row.get("open"):
        return "Cuenta gratis" if tag in _PREMIUM_TAGS else "Sin cuenta"
    if tag in _PREMIUM_TAGS or row.get("claim") == "PREMIUM":
        return {"ORIGINAL": "ATP Original", "PREVIEW": "ATP Avance"}.get(tag, "ATP+")
    return "Sin cuenta" if row.get("vertical") else ""


def normalize_episode(row, ctx_title=""):
    """Convierte un episodio a item normalizado."""
    t = row.get("title", "Episodio")
    n = row.get("name", "")
    full_t = f"{n} - {t}" if n else t
    vid = row.get("contentId") or row.get("id")
    if not vid:
        href = (row.get("link") or {}).get("href", "")
        if "/episode/" in href:
            vid = href.split("/episode/")[1].split("/")[0]
    if not vid:
        return None
    img = (row.get("image") or {}).get("pathHorizontal") or (row.get("image") or {}).get("pathVertical")
    du = row.get("duration", 0) or 0
    if du > 10000:
        du = du / 1000
    return {
        "title": full_t,
        "vid": vid,
        "thumb": _img(img),
        "plot": row.get("description") or "",
        "duration": int(du),
        "is_premium": ((row.get("tagType") in _PREMIUM_TAGS or row.get("claim") == "PREMIUM")
                       and not row.get("open")),
        "etiqueta": _etiqueta(row),
    }


def normalize_dm_video(v, score=None):
    """Convierte un vídeo de Dailymotion a item normalizado."""
    du = int(v.get("duration", 0) or 0)
    mins, secs = divmod(du, 60)
    own = v.get("owner.screenname", "Dailymotion")
    cts = v.get("created_time", 0) or 0
    vws = v.get("views_total", 0) or 0
    try:
        f_date = time.strftime("%d/%m/%Y", time.localtime(cts))
    except Exception:
        f_date = "??"
    plot = f"Canal: {own}\nPublicado: {f_date}\nDuración: {mins}m {secs}s\nVistas: {vws}"
    title = v.get("title", "Vídeo")
    if score is not None:
        title = f"{title} ({int(score * 100)}% match)"
    return {
        "title": title,
        "vid": v.get("id", ""),
        "thumb": v.get("thumbnail_720_url") or v.get("thumbnail_480_url") or "",
        "plot": plot,
        "duration": du,
    }


_search_cache = {}
_search_lock = threading.Lock()
_SEARCH_TTL = 300


def search_catalog(q, max_results=15):
    """Fuzzy match con difflib sobre el catálogo que da el conector. Lista de (score, dict)."""
    if not q or ce is None:
        return []
    ql = q.lower().strip()
    cache_key = f"{ql}_{max_results}"
    cached = _search_cache.get(cache_key)
    if cached and (time.time() - cached[1]) < _SEARCH_TTL:
        return cached[0]

    matched = []
    por_enlace = {}
    for cat_name, item in ce.search_catalog_raw(q):
        cat_name = categorias.nombre(cat_name)
        title = item.get("title", "")
        if not title:
            continue
        tl = title.lower()
        score = (0.95 + (len(ql) / max(len(tl), 1)) * 0.05) if ql in tl else difflib.SequenceMatcher(None, ql, tl).ratio()
        if score <= 0.3:
            continue
        link = (item.get("link") or {}).get("href", "")
        if not link:
            continue
        if link in por_enlace:
            # Un mismo programa está en varias secciones: sale una vez, con todas.
            por_enlace[link]["category"] += f", {cat_name}"
            continue
        norm = normalize_catalog_row(item)
        norm["category"] = cat_name
        por_enlace[link] = norm
        matched.append((score, norm))

    matched.sort(key=lambda x: x[0], reverse=True)
    result = matched[:max_results]
    now = time.time()
    with _search_lock:
        # El servidor vive toda la sesión; sin purga, cada búsqueda distinta se quedaría en memoria.
        for k in [k for k, (_r, ts) in _search_cache.items() if now - ts >= _SEARCH_TTL]:
            del _search_cache[k]
        _search_cache[cache_key] = (result, now)
    return result


def score_dm_results(q, videos):
    """Puntúa y ordena resultados de Dailymotion por similitud con q."""
    if not videos:
        return []
    try:
        import core_settings
        prioritize_match = core_settings.is_prioritize_match_active()
    except Exception:
        prioritize_match = False
    scored = []
    ql = q.lower().strip()
    qn = re.findall(r'(\d+)', ql)
    q_words = [w for w in ql.replace('-', ' ').replace('.', ' ').split() if len(w) > 2]

    for v in videos:
        t = v.get("title", "").strip()
        tl = t.lower()
        if not t:
            continue
        s = difflib.SequenceMatcher(None, ql, tl).ratio()
        if q_words:
            if q_words[0] not in tl:
                s -= 0.6
            found_words = sum(1 for w in q_words if w in tl)
            if found_words < len(q_words):
                s -= 0.1 * (len(q_words) - found_words)
        if ql in tl:
            s += 0.5
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            try:
                qn_ints = [int(x) for x in qn]
                tn_ints = [int(x) for x in tn]
                if set(qn_ints).issubset(set(tn_ints)):
                    s += 2.0
                elif qn:
                    s -= 0.5
            except Exception:
                pass
        du = int(v.get("duration", 0) or 0)
        if s > 0.4:
            if not prioritize_match:
                if du > 600:
                    s += 0.3
                elif du > 300:
                    s += 0.1
            if du < 60:
                s -= 0.2
        scored.append((s, v))

    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:25]
