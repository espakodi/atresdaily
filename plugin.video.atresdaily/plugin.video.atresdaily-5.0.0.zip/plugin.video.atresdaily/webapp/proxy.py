# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import re
import threading
import time
import urllib.parse
from . import tokens, session

_m3u8_cache = {}  # url -> (text, ts)
_m3u8_lock = threading.Lock()
_M3U8_VOD_TTL = 60


def _cache_m3u8(key, text):
    """Guarda una lista VOD y purga las caducadas, que solo sirven durante _M3U8_VOD_TTL. Sin
    purga, el dict crecería con cada vídeo mientras dure la sesión de Kodi."""
    now = time.time()
    with _m3u8_lock:
        for k in [k for k, (_t, ts) in _m3u8_cache.items() if now - ts >= _M3U8_VOD_TTL]:
            del _m3u8_cache[k]
        _m3u8_cache[key] = (text, now)


def _parse_kodi_pipe(pipe_url: str):
    """Descompone 'url|header1=val1&header2=val2' en (url, headers)."""
    if '|' not in pipe_url:
        return pipe_url, {}
    real_url, qs = pipe_url.split('|', 1)
    headers = {}
    for k, v in urllib.parse.parse_qsl(qs):
        headers[k] = v
    return real_url.strip(), headers


def resolve_kodi_url(pipe_url: str):
    return _parse_kodi_pipe(pipe_url)


def _absolute(base: str, uri: str) -> str:
    return urllib.parse.urljoin(base, uri)


def _rewrite_uri_attr(line, token, base_url, sub_path):
    def repl(m):
        abs_uri = _absolute(base_url, m.group(1))
        enc = urllib.parse.quote(tokens.encode_url(abs_uri))
        return f'URI="/proxy/{token}/{sub_path}?u={enc}"'
    return re.sub(r'URI="([^"]+)"', repl, line)


_URI_DIRECTIVES = (
    ('#EXT-X-KEY:',               'key'),
    ('#EXT-X-SESSION-KEY:',       'key'),
    ('#EXT-X-MAP:',               'seg'),
    ('#EXT-X-MEDIA:',             'variant'),
    ('#EXT-X-I-FRAME-STREAM-INF:', 'variant'),
)


def _rewrite_m3u8(text, token, base_url):
    # Quita el BOM y los caracteres invisibles del principio; algunos CDN sirven el M3U8
    # con BOM UTF-8, que rompe los parsers estrictos.
    if text.startswith('﻿'):
        text = text[1:]
    text = text.lstrip()

    lines = text.splitlines()
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]

        rewritten = False
        for prefix, sub_path in _URI_DIRECTIVES:
            if line.startswith(prefix) and 'URI=' in line:
                out.append(_rewrite_uri_attr(line, token, base_url, sub_path))
                i += 1
                rewritten = True
                break
        if rewritten:
            continue

        # #EXT-X-STREAM-INF: la siguiente línea no-vacía es la URI del variant
        if line.startswith('#EXT-X-STREAM-INF:'):
            out.append(line)
            i += 1
            while i < len(lines) and not lines[i].strip():
                out.append(lines[i])
                i += 1
            if i < len(lines):
                uri = lines[i].strip()
                abs_uri = _absolute(base_url, uri)
                enc = tokens.encode_url(abs_uri)
                out.append(f'/proxy/{token}/variant?u={urllib.parse.quote(enc)}')
                i += 1
            continue

        if line.strip() and not line.startswith('#'):
            abs_uri = _absolute(base_url, line.strip())
            enc = tokens.encode_url(abs_uri)
            out.append(f'/proxy/{token}/seg?u={urllib.parse.quote(enc)}')
            i += 1
            continue

        out.append(line)
        i += 1

    return '\n'.join(out)


def serve_playlist(handler, token: str, path_type: str, u_param: str = None):
    entry = tokens.get(token)
    if not entry:
        handler.send_error(404, 'Token expirado o desconocido')
        return

    if path_type == 'master':
        real_url = entry['url']
        hdrs = entry['headers']
        base_url = entry['base_url'] or real_url
    else:
        # variant: la URL viene cifrada en el parámetro u
        try:
            real_url = tokens.decode_url(urllib.parse.unquote(u_param))
            hdrs = entry['headers']
            base_url = real_url
        except Exception:
            handler.send_error(400, 'URL inválida')
            return

    # Caché para VOD
    cache_key = real_url
    is_live = False
    cached = _m3u8_cache.get(cache_key)
    if cached:
        text, ts = cached
        age = time.time() - ts
        is_live = '#EXT-X-ENDLIST' not in text and 'EXT-X-PLAYLIST-TYPE:VOD' not in text
        if not is_live and age < _M3U8_VOD_TTL:
            _send_m3u8(handler, _rewrite_m3u8(text, token, base_url), live=False)
            return

    try:
        import xbmc
        xbmc.log(f'[AtresProxy] fetch {path_type} url={real_url[:120]}', xbmc.LOGINFO)
        resp = session.fetch(real_url, headers=hdrs, timeout=15)
        xbmc.log(f'[AtresProxy] fetch {path_type} status={resp.status_code}', xbmc.LOGINFO)
        if resp.status_code != 200:
            xbmc.log(f'[AtresProxy] CDN error {resp.status_code} body={resp.text[:200]}', xbmc.LOGWARNING)
            handler.send_error(502, f'CDN returned {resp.status_code}')
            return
        text = resp.text
    except Exception as e:
        import xbmc
        xbmc.log(f'[AtresProxy] fetch exception: {e}', xbmc.LOGERROR)
        handler.send_error(502, str(e))
        return

    is_live = '#EXT-X-ENDLIST' not in text and 'EXT-X-PLAYLIST-TYPE:VOD' not in text
    if not is_live:
        _cache_m3u8(cache_key, text)

    rewritten = _rewrite_m3u8(text, token, base_url)
    _send_m3u8(handler, rewritten, live=is_live)


def _send_m3u8(handler, text: str, live: bool):
    body = text.encode('utf-8')
    handler.send_response(200)
    handler.send_header('Content-Type', 'application/vnd.apple.mpegurl')
    handler.send_header('Content-Length', str(len(body)))
    if live:
        handler.send_header('Cache-Control', 'no-store, no-cache')
    else:
        handler.send_header('Cache-Control', 'public, max-age=60')
    handler.send_header('Access-Control-Allow-Origin', '*')
    try:
        handler.end_headers()
        handler.wfile.write(body)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
        return


def serve_segment(handler, token: str, u_param: str):
    """Proxifica un segmento TS / fragmento fMP4 / clave AES."""
    entry = tokens.get(token)
    if not entry:
        handler.send_error(404, 'Token expirado')
        return
    try:
        real_url = tokens.decode_url(urllib.parse.unquote(u_param))
        hdrs = dict(entry['headers'])
        range_hdr = handler.headers.get('Range')
        if range_hdr:
            hdrs['Range'] = range_hdr
    except Exception:
        handler.send_error(400, 'URL inválida')
        return

    try:
        resp = session.fetch(real_url, headers=hdrs, stream=True, timeout=20)
    except Exception as e:
        try: handler.send_error(502, str(e))
        except Exception: pass
        return

    status = resp.status_code
    if status not in (200, 206):
        try: handler.send_error(502, f'CDN {status}')
        except Exception: pass
        return

    try:
        handler.send_response(status)
        for h in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
            v = resp.headers.get(h)
            if v:
                handler.send_header(h, v)
        handler.send_header('Access-Control-Allow-Origin', '*')
        handler.send_header('Cache-Control', 'public, max-age=300')
        handler.end_headers()
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
        return

    # Si el cliente cierra la conexión a mitad del stream, salir sin propagar.
    try:
        for chunk in resp.iter_content(65536):
            handler.wfile.write(chunk)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
        return
    except Exception:
        return


def serve_thumb(handler, thumb_id: str):
    """Proxifica un thumbnail para ocultar el dominio del CDN."""
    real_url = tokens.get_thumb(thumb_id)
    if not real_url:
        handler.send_error(404, 'Thumb no encontrado')
        return
    try:
        resp = session.fetch(real_url, stream=True, timeout=10)
    except Exception as e:
        try: handler.send_error(502, str(e))
        except Exception: pass
        return
    if resp.status_code != 200:
        try: handler.send_error(502, '')
        except Exception: pass
        return
    try:
        handler.send_response(200)
        ct = resp.headers.get('Content-Type', 'image/jpeg')
        handler.send_header('Content-Type', ct)
        cl = resp.headers.get('Content-Length')
        if cl:
            handler.send_header('Content-Length', cl)
        handler.send_header('Cache-Control', 'public, max-age=86400')
        handler.end_headers()
        for chunk in resp.iter_content(32768):
            handler.wfile.write(chunk)
    except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
        return
    except Exception:
        return
