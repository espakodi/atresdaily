# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Endpoints JSON de la WebApp. Usa a2pl.py para HTTP directo y no intercepta
xbmcplugin, que con varios hilos daría carreras con Kodi."""

import json
import threading
import time
import urllib.parse

from . import tokens
from . import a2pl as ap

# Cerrojos para que dos escrituras a la vez de los JSON compartidos no se pisen. Cubren
# la lectura, el cambio y la escritura; las escrituras son esporádicas (favoritos al
# marcar, progreso cada 15 s).
_history_lock = threading.Lock()
_favs_lock = threading.Lock()


# --- Util ---

_MAX_BODY = 64 * 1024


def _read_json_body(handler):
    """Cuerpo JSON de un POST, o None si falta, pasa del límite o no es un objeto.
    Sin límite, un Content-Length enorme haría leer al servidor lo que el cliente quisiera."""
    # Solo con el tipo JSON declarado. Un POST text/plain de otra web abierta en el navegador
    # no necesita permiso CORS, y así podría cambiar los favoritos o el historial.
    if not handler.headers.get('Content-Type', '').startswith('application/json'):
        return None
    try:
        length = int(handler.headers.get('Content-Length', 0))
    except ValueError:
        return None
    if length <= 0 or length > _MAX_BODY:
        return None
    try:
        data = json.loads(handler.rfile.read(length))
    except ValueError:
        return None
    return data if isinstance(data, dict) else None


def _json_response(handler, data, status=200, max_age=0):
    body = json.dumps(data, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    if max_age > 0:
        handler.send_header('Cache-Control', f'private, max-age={max_age}')
    else:
        handler.send_header('Cache-Control', 'no-store')
    handler.end_headers()
    handler.wfile.write(body)


def _proxy_thumb(url):
    if url and url.startswith('http'):
        tid = tokens.create_thumb(url)
        return f'/thumb/{tid}'
    return url or ''


def _real_thumb(thumb):
    """Convierte un thumb '/thumb/xxx' a su URL real (para guardar en disco).
    Si ya es una URL absoluta, la devuelve tal cual. Vacío si no se puede resolver."""
    if not thumb:
        return ''
    if thumb.startswith('http'):
        return thumb
    if thumb.startswith('/thumb/'):
        tid = thumb[len('/thumb/'):].split('?')[0]
        return tokens.get_thumb(tid) or ''
    return ''


def _item_id(*parts):
    """ID opaco estable a partir de partes."""
    raw = '|'.join(str(p) for p in parts)
    return tokens.encode_url(raw)[:20]


def _clean_title(t):
    if not t:
        return ''
    if ' : ' in t:
        parts = t.split(' : ')
        if any(c.lower() in parts[0].lower() for c in ['series', 'programas', 'documentales', 'infantil', 'actualidad']):
            return parts[1].strip()
    return t.strip()


def _backfill_history_thumbs(history):
    """Completa la miniatura y quita el BBCode del título en las entradas incompletas
    de watch_history (las que guardaba el connector de Kodi). Guarda el resultado para
    no repetir las búsquedas en cada carga. Usa _history_lock."""
    needs_save = False
    for entry in history:
        # Limpiar BBCode persistente del título
        title = entry.get('title') or ''
        clean = ap.strip_bbcode(title)
        if clean != title:
            entry['title'] = clean
            needs_save = True
        # Resolver thumb ausente para vídeos de Dailymotion
        if not entry.get('thumb') and entry.get('vid'):
            url = ap.get_dm_thumb(entry['vid'])
            if url:
                entry['thumb'] = url
                needs_save = True
    if needs_save:
        import core_settings
        with _history_lock:
            core_settings.atomic_write_json(core_settings._WATCH_FILE, history[:100], ensure_ascii=False)


# --- Items (formato normalizado para el frontend) ---

def _folder_item(title, kind, params, thumb='', plot=''):
    return {
        'id': _item_id(kind, params),
        'title': title,
        'thumb': _proxy_thumb(thumb),
        'type': 'folder',
        'plot': plot,
        'duration': 0,
        'navigate': {'kind': kind, **params},
    }


def _video_item(title, play, thumb='', plot='', duration=0, **extras):
    item = {
        'id': _item_id(play.get('kind'), play.get('vid') or play.get('ch_id') or play.get('url')),
        'title': title,
        'thumb': _proxy_thumb(thumb),
        'type': 'video',
        'plot': plot,
        'duration': duration,
        'play': play,
    }
    item.update(extras)
    return item


# --- Dispatcher ---

def handle_api(handler, path, method):
    qs = ''
    if '?' in path:
        path, qs = path.split('?', 1)
    params = dict(urllib.parse.parse_qsl(qs))

    if path in ('/api/home', '/api/menu'):
        _handle_home(handler)
    elif path == '/api/list':
        _handle_list(handler, params)
    elif path == '/api/details':
        _handle_details(handler, params)
    elif path == '/api/search':
        _handle_search(handler, params)
    elif path == '/api/live/channels':
        _handle_live_channels(handler)
    elif path == '/api/live/epg':
        _handle_epg(handler, params)
    elif path == '/api/resolve' and method == 'POST':
        _handle_resolve(handler)
    elif path == '/api/favorites':
        if method == 'GET':
            _handle_favs_get(handler)
        elif method == 'POST':
            _handle_favs_post(handler)
    elif path == '/api/history':
        _handle_history(handler)
    elif path == '/api/history/progress' and method == 'POST':
        _handle_progress(handler)
    else:
        _json_response(handler, {'error': 'Not found'}, 404)


# --- /api/home: Hero + filas curadas ---

def _handle_home(handler):
    rows = []

    # Fila 1: Continuar viendo (desde watch_history.json)
    try:
        import core_settings
        history = core_settings.get_watch_history()
        if history:
            _backfill_history_thumbs(history)
            items = []
            for entry in history[:15]:
                vid = entry.get('vid', '')
                if not vid:
                    continue
                clean_title = ap.strip_bbcode(entry.get('title', ''))
                is_atp = len(vid) == 24 and all(c in '0123456789abcdefABCDEF' for c in vid)
                play_kind = 'episode' if is_atp else 'dm'
                items.append(_video_item(
                    title=clean_title,
                    play={'kind': play_kind, 'vid': vid, 'title': clean_title},
                    thumb=entry.get('thumb', ''),
                    duration=int(entry.get('duration', 0) or 0),
                    progress=int(entry.get('progress', 0) or 0),
                ))
            if items:
                rows.append({'id': 'continue', 'title': 'Continuar viendo', 'items': items})
    except Exception:
        pass

    # Fila 2: En directo ahora
    try:
        channels = ap.get_live_channels()
        live_items = []
        for ch in channels[:12]:
            live_items.append(_video_item(
                title=ch['name'],
                play={'kind': 'live', 'ch_id': ch['id'], 'title': ch['name']},
                thumb=ap.get_channel_logo(ch['id']),
                plot=f"Emisión en directo de {ch['name']}",
                is_live=True,
            ))
        if live_items:
            rows.append({'id': 'live', 'title': 'En directo ahora', 'items': live_items})
    except Exception:
        pass

    # Fila 3: Mis favoritos
    try:
        import core_settings
        favs = core_settings.get_favorites()
        if favs:
            fav_items = []
            for f in favs[:20]:
                fav_items.append(_folder_item(
                    title=f.get('title', ''),
                    kind='atresplayer_details',
                    params={'url': f.get('url', ''), 'ctx': _clean_title(f.get('title', ''))},
                    thumb=f.get('icon', '') or f.get('thumbnail', ''),
                ))
            if fav_items:
                rows.append({'id': 'favorites', 'title': 'Mis favoritos', 'items': fav_items})
    except Exception:
        pass

    # Filas 4+: Una por sección del catálogo
    try:
        overview = ap.get_catalog_overview()
        for sec in overview:
            sec_items = []
            for row in sec['items'][:18]:
                norm = ap.normalize_catalog_row(row)
                sec_items.append(_folder_item(
                    title=norm['title'],
                    kind='atresplayer_details',
                    params={'url': norm['url'], 'ctx': _clean_title(norm['title'])},
                    thumb=norm['thumb'],
                    plot=norm['plot'],
                ))
            if sec_items:
                rows.append({'id': f"sec_{sec['id']}", 'title': sec['name'], 'items': sec_items})
    except Exception:
        pass

    # El hero es el primer item con thumbnail de las filas (preferir directo si lo hay)
    hero = None
    for row in rows:
        if row['id'] == 'live' and row['items']:
            hero = row['items'][0]
            break
    if hero is None:
        for row in rows:
            for item in row['items']:
                if item.get('thumb'):
                    hero = item
                    break
            if hero:
                break

    _json_response(handler, {'hero': hero, 'rows': rows}, max_age=300)


# --- /api/list: navegación del catálogo ---

def _handle_list(handler, params):
    kind = params.get('kind', 'catalog_root')

    try:
        if kind == 'catalog_root':
            overview = ap.get_catalog_overview()
            thumb_map = {}
            for sec in overview:
                for row in sec['items']:
                    norm = ap.normalize_catalog_row(row)
                    if norm['thumb']:
                        thumb_map[sec['id']] = norm['thumb']
                        break
            items = []
            for name, cid in ap.CATS:
                items.append(_folder_item(
                    title=name,
                    kind='catalog_section',
                    params={'cat_id': cid, 'page': 0},
                    thumb=thumb_map.get(cid, ''),
                ))
            _json_response(handler, {'title': 'Catálogo', 'items': items}, max_age=1800)

        elif kind == 'catalog_section':
            cat_id = params.get('cat_id', '')
            page = int(params.get('page', 0))
            rows = ap.get_category_items(cat_id, page=page)
            items = []
            for row in rows:
                norm = ap.normalize_catalog_row(row)
                if not norm['url']:
                    continue
                items.append(_folder_item(
                    title=norm['title'],
                    kind='atresplayer_details',
                    params={'url': norm['url'], 'ctx': _clean_title(norm['title'])},
                    thumb=norm['thumb'],
                    plot=norm['plot'],
                ))
            # Paginación si hay 40+
            if len(rows) >= 40:
                items.append(_folder_item(
                    title='Página siguiente >',
                    kind='catalog_section',
                    params={'cat_id': cat_id, 'page': page + 1},
                ))
            cat_name = next((n for n, c in ap.CATS if c == cat_id), 'Sección')
            _json_response(handler, {'title': cat_name, 'items': items}, max_age=1800)

        else:
            _json_response(handler, {'title': '', 'items': []})

    except Exception as e:
        _json_response(handler, {'error': str(e)}, 500)


# --- /api/details: temporadas/episodios de un programa Atresplayer ---

def _handle_details(handler, params):
    url = params.get('url', '')
    ctx = params.get('ctx', '')
    if not url:
        _json_response(handler, {'title': '', 'items': []})
        return

    try:
        pagina = ap.get_show_page(url)
        if pagina is not None:
            if pagina['seasons']:
                items = [_folder_item(title=t, kind='atresplayer_details',
                                      params={'url': link, 'ctx': f'{ctx}|{t}' if ctx else t})
                         for t, link in pagina['seasons']]
                _json_response(handler, {'title': pagina['title'] or 'Temporadas', 'items': items}, max_age=600)
            else:
                _emit_episodes(handler, pagina['episodes'], ctx, pagina['title'] or 'Episodios',
                               siguiente=pagina['next'])
            return

        data = ap.get_details(url)

        # ¿Tiene fila EPISODE? Cargar episodios directamente
        for row in data.get('rows', []):
            if row.get('type') == 'EPISODE' and row.get('href'):
                eps = ap.get_episodes(row['href'])
                _emit_episodes(handler, eps, ctx, data.get('title', 'Episodios'))
                return

        # ¿Tiene temporadas múltiples?
        seasons = data.get('seasons', [])
        if len(seasons) > 1:
            items = []
            for s in seasons:
                t = s.get('title', 'Temporada')
                link = (s.get('link') or {}).get('href', '')
                if link:
                    items.append(_folder_item(
                        title=t,
                        kind='atresplayer_details',
                        params={'url': link, 'ctx': f'{ctx}|{t}' if ctx else t},
                    ))
            _json_response(handler, {'title': data.get('title', 'Temporadas'), 'items': items}, max_age=600)
            return

        # itemRows = episodios directamente
        if 'itemRows' in data:
            _emit_episodes(handler, data['itemRows'], ctx, data.get('title', 'Episodios'))
            return

        _json_response(handler, {'title': data.get('title', ''), 'items': []}, max_age=600)

    except Exception as e:
        _json_response(handler, {'error': str(e)}, 500)


def _emit_episodes(handler, episodes, ctx, title, siguiente=None):
    items = []
    clean_ctx = ' '.join(ctx.replace('|', ' ').split())
    for ep in episodes:
        norm = ap.normalize_episode(ep, ctx)
        if not norm:
            continue
        if norm['is_premium']:
            # Lo premium se muestra como folder con búsqueda externa. En los formatos de un
            # solo episodio, este se llama como el programa y no se repite.
            q = clean_ctx if ctx.split('|')[-1] == norm['title'] else f"{clean_ctx} {norm['title']}"
            items.append(_folder_item(
                title=f"[PREMIUM] {norm['title']}",
                kind='search_dm',
                params={'q': q.strip()},
                thumb=norm['thumb'],
                plot=norm['plot'],
            ))
        else:
            etiqueta = norm['etiqueta']
            items.append(_video_item(
                title=f"[{etiqueta.upper()}] {norm['title']}" if etiqueta else norm['title'],
                play={'kind': 'episode', 'vid': norm['vid'], 'title': norm['title']},
                thumb=norm['thumb'],
                plot=norm['plot'],
                duration=norm['duration'],
            ))
    if siguiente:
        items.append(_folder_item(title='Página siguiente >', kind='atresplayer_details',
                                  params={'url': siguiente, 'ctx': ctx}))
    _json_response(handler, {'title': title, 'items': items}, max_age=600)


# --- /api/search: búsqueda en Dailymotion ---

def _handle_search(handler, params):
    q = params.get('q', '').strip()
    if not q:
        _json_response(handler, {'title': 'Búsqueda', 'items': []})
        return
    cq = ' '.join(_clean_title(q).replace('|', ' ').split()) or q

    try:
        # Búsqueda en paralelo, catálogo Atresplayer + Dailymotion
        atp_results = [None]
        dm_results = [None]

        def _atp_task():
            try:
                atp_results[0] = ap.search_catalog(cq)
            except Exception:
                atp_results[0] = []

        def _dm_task():
            try:
                videos = ap.search_dailymotion(cq)
                dm_results[0] = ap.score_dm_results(cq, videos)
            except Exception:
                dm_results[0] = []

        t1 = threading.Thread(target=_atp_task, daemon=True)
        t2 = threading.Thread(target=_dm_task, daemon=True)
        t1.start(); t2.start()
        t1.join(timeout=12); t2.join(timeout=12)

        items = []

        # Sección 1: Catálogo Atresplayer
        atp = atp_results[0] or []
        for score, prog in atp:
            if not prog.get('url'):
                continue
            pct = int(score * 100)
            items.append(_folder_item(
                title=f"[ATP] {prog['title']} ({prog.get('category', '')}) · {pct}%",
                kind='atresplayer_details',
                params={'url': prog['url'], 'ctx': _clean_title(prog['title'])},
                thumb=prog.get('thumb', ''),
                plot=prog.get('plot', ''),
            ))

        # Sección 2: Dailymotion
        dm = dm_results[0] or []
        for score, v in dm:
            norm = ap.normalize_dm_video(v, score=score)
            if not norm['vid']:
                continue
            items.append(_video_item(
                title=norm['title'],
                play={'kind': 'dm', 'vid': norm['vid'], 'title': norm['title']},
                thumb=norm['thumb'],
                plot=norm['plot'],
                duration=norm['duration'],
            ))

        try:
            import exploration_history
            exploration_history.add_exploration(q)
        except Exception:
            pass

        _json_response(handler, {'title': f'Resultados: {cq}', 'items': items}, max_age=300)
    except Exception as e:
        _json_response(handler, {'error': str(e)}, 500)


# --- /api/live/channels ---

def _handle_live_channels(handler):
    try:
        channels = ap.get_live_channels()
        items = []
        for ch in channels:
            items.append(_video_item(
                title=ch['name'],
                play={'kind': 'live', 'ch_id': ch['id'], 'title': ch['name']},
                thumb=ap.get_channel_logo(ch['id']),
                plot=f"Emisión en directo de {ch['name']}",
                is_live=True,
            ))
        _json_response(handler, {'title': 'Directos', 'items': items}, max_age=3600)
    except Exception as e:
        _json_response(handler, {'error': str(e)}, 500)


# --- /api/live/epg: EPG ---

def _handle_epg(handler, params):
    """No hay endpoint público estructurado en epg_texto. Devolvemos vacío."""
    _json_response(handler, {'channel': params.get('name', ''), 'programs': []})


# --- /api/resolve: resolver stream y crear token opaco ---

def _handle_resolve(handler):
    body = _read_json_body(handler)
    if body is None:
        _json_response(handler, {'error': 'Bad request'}, 400)
        return

    kind = body.get('kind', '')
    title = ap.strip_bbcode(body.get('title', ''))
    # El thumb puede venir como '/thumb/xxx' (del proxy) o vacío. Lo resolvemos
    # a URL real para guardarlo en watch_history con persistencia más allá del TTL.
    thumb_real = _real_thumb(body.get('thumb', ''))

    if kind == 'dm':
        _resolve_dm(handler, body.get('vid', ''), title, thumb_real)
    elif kind == 'live':
        _resolve_live(handler, body.get('ch_id', ''), title)
    elif kind == 'episode':
        _resolve_episode(handler, body.get('vid', ''), title, thumb_real)
    else:
        _json_response(handler, {'error': f'Tipo desconocido: {kind}'}, 400)


def _parse_kodi_pipe(pipe_url):
    if not pipe_url or '|' not in pipe_url:
        return pipe_url, {}
    real, qs = pipe_url.split('|', 1)
    return real.strip(), dict(urllib.parse.parse_qsl(qs))


def _resolve_dm(handler, vid, title, thumb=''):
    import xbmc
    if not vid:
        _json_response(handler, {'error': 'vid requerido'}, 400)
        return

    # Camino preferente con dm_resolver (parsea master HLS, devuelve URL de variante
    # en vod4.cf.dmcdn.net que es accesible sin tropiezos del CDN cdndirector).
    real_url = None
    headers = None
    subs = []
    try:
        import importlib.util as _ilu, os as _os
        _root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
        _spec = _ilu.spec_from_file_location('atresdaily_dm_resolver',
                                              _os.path.join(_root, 'dm_resolver.py'))
        dm_resolver = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(dm_resolver)
        xbmc.log(f'[AtresWebApp] _resolve_dm vid={vid}', xbmc.LOGINFO)
        result = dm_resolver.resolve(vid)
        if result and result.get('url'):
            real_url = result['url']
            headers = dict(result.get('headers') or {})
            subs = result.get('subs') or []
            xbmc.log(f'[AtresWebApp] dm_resolver OK mime={result.get("mime")} url={real_url[:120]}', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[AtresWebApp] dm_resolver exception: {e}', xbmc.LOGWARNING)

    # Si no, dm_gujal, que cubre vídeos en los que falla el parseo del master (cookies
    # dinámicas, etc.).
    if not real_url:
        try:
            import dm_gujal
            final_url, gujal_subs, _mime = dm_gujal.play_dm_extreme(vid, force_hls=True)
            xbmc.log(f'[AtresWebApp] gujal fallback mime={_mime} url={str(final_url)[:120]}', xbmc.LOGINFO)
            if final_url:
                real_url, headers = _parse_kodi_pipe(final_url)
                if not headers:
                    headers = dict(ap._DM_HEADERS)
                subs = gujal_subs or []
        except Exception as e:
            xbmc.log(f'[AtresWebApp] gujal exception: {e}', xbmc.LOGERROR)

    if not real_url:
        _json_response(handler, {'error': 'No se pudo resolver el vídeo'}, 502)
        return

    if not headers:
        headers = dict(ap._DM_HEADERS)
    token = tokens.create(real_url, headers, 'dm', real_url, {'vid': vid, 'title': title})

    sub_list = []
    for s in (subs or []):
        sub_url = s if isinstance(s, str) else (s.get('url') if isinstance(s, dict) else '')
        if not sub_url:
            continue
        lang = s.get('lang', 'es') if isinstance(s, dict) else 'es'
        enc = urllib.parse.quote(tokens.encode_url(sub_url))
        sub_list.append({'lang': lang, 'url': f'/proxy/{token}/sub?u={enc}'})

    # Registrar en watch history con thumb real y título limpio
    try:
        import core_settings
        with _history_lock:
            if not any(h.get('vid') == vid for h in core_settings.get_watch_history()):
                core_settings.add_to_watch_history(vid, title, thumb or '', 0)
    except Exception:
        pass

    _json_response(handler, {
        'token': token,
        'playlist': f'/proxy/{token}/master.m3u8',
        'subtitles': sub_list,
        'title': title,
        'kind': 'dm',
    })


def _resolve_live(handler, ch_id, title):
    if not ch_id:
        _json_response(handler, {'error': 'ch_id requerido'}, 400)
        return
    stream_url, headers = ap.resolve_live(ch_id)
    if not stream_url:
        _json_response(handler, {'error': 'Emisión no disponible (puede requerir desactivar VPN)'}, 502)
        return
    token = tokens.create(stream_url, headers, 'live', stream_url, {'ch_id': ch_id, 'title': title})
    _json_response(handler, {
        'token': token,
        'playlist': f'/proxy/{token}/master.m3u8',
        'subtitles': [],
        'title': title,
        'kind': 'live',
    })


def _resolve_episode(handler, vid, title, thumb=''):
    if not vid:
        _json_response(handler, {'error': 'vid requerido'}, 400)
        return
    stream_url, headers = ap.resolve_episode(vid)
    if not stream_url:
        _json_response(handler, {'error': 'Contenido no disponible (puede ser premium o requerir login)'}, 502)
        return
    token = tokens.create(stream_url, headers, 'episode', stream_url, {'vid': vid, 'title': title})
    try:
        import core_settings
        with _history_lock:
            core_settings.add_to_watch_history(vid, title, thumb or '', 0)
    except Exception:
        pass
    _json_response(handler, {
        'token': token,
        'playlist': f'/proxy/{token}/master.m3u8',
        'subtitles': [],
        'title': title,
        'kind': 'episode',
    })


# --- /api/favorites ---

def _handle_favs_get(handler):
    try:
        import core_settings
        favs = core_settings.get_favorites()
        result = []
        for f in favs:
            result.append({
                'title': f.get('title', ''),
                'action': f.get('action', ''),
                'url': f.get('url', ''),
                'thumb': _proxy_thumb(f.get('icon', '') or f.get('thumbnail', '')),
            })
        _json_response(handler, {'favorites': result})
    except Exception as e:
        _json_response(handler, {'favorites': [], 'error': str(e)})


def _handle_favs_post(handler):
    body = _read_json_body(handler)
    if body is None:
        _json_response(handler, {'error': 'Bad request'}, 400)
        return
    try:
        import core_settings
        op = body.get('op', 'toggle')
        url = body.get('url', '')
        title = body.get('title', '')
        thumb = body.get('thumb', '')

        # Una miniatura del proxy (/thumb/xxx) no sirve guardada, así que se deja vacía.
        if thumb and thumb.startswith('/thumb/'):
            thumb = ''

        # Bajo cerrojo, para no perder favoritos con dos pestañas marcando a la vez.
        with _favs_lock:
            if op == 'add':
                core_settings.add_favorite(title, url, thumb, 'webapp', 'atresplayer_details')
                _json_response(handler, {'status': 'added'})
            elif op == 'remove':
                core_settings.remove_favorite(url)
                _json_response(handler, {'status': 'removed'})
            else:  # toggle
                favs = core_settings.get_favorites()
                if any(f.get('url') == url for f in favs):
                    core_settings.remove_favorite(url)
                    _json_response(handler, {'status': 'removed'})
                else:
                    core_settings.add_favorite(title, url, thumb, 'webapp', 'atresplayer_details')
                    _json_response(handler, {'status': 'added'})
    except Exception as e:
        _json_response(handler, {'error': str(e)}, 500)


# --- /api/history ---

def _handle_history(handler):
    try:
        import core_settings
        history = core_settings.get_watch_history()
        _backfill_history_thumbs(history)
        result = []
        for entry in history[:50]:
            result.append({
                'vid': entry.get('vid', ''),
                'title': ap.strip_bbcode(entry.get('title', '')),
                'thumb': _proxy_thumb(entry.get('thumb', '')),
                'progress': int(entry.get('progress', 0) or 0),
                'duration': int(entry.get('duration', 0) or 0),
                'ts': entry.get('watched_at', 0),
            })
        _json_response(handler, {'history': result})
    except Exception as e:
        _json_response(handler, {'history': [], 'error': str(e)})


def _handle_progress(handler):
    body = _read_json_body(handler)
    if body is None:
        _json_response(handler, {'status': 'error', 'error': 'Bad request'}, 400)
        return
    try:
        vid = body.get('id', '')
        if not vid:
            _json_response(handler, {'status': 'noop'})
            return

        position = int(float(body.get('position', 0) or 0))
        duration = int(float(body.get('duration', 0) or 0))
        title = ap.strip_bbcode(body.get('title', ''))
        # Convertir thumb proxy a URL real para persistencia
        thumb = _real_thumb(body.get('thumb', ''))

        import core_settings

        # Dos pestañas guardando progreso de
        # vídeos distintos en paralelo podrían sobrescribirse mutuamente.
        with _history_lock:
            history = core_settings.get_watch_history()
            found = False
            for entry in history:
                if entry.get('vid') == vid:
                    entry['progress'] = position
                    if duration:
                        entry['duration'] = duration
                    if title:
                        entry['title'] = title
                    if thumb:
                        entry['thumb'] = thumb
                    entry['watched_at'] = int(time.time())
                    found = True
                    break
            if not found:
                history.insert(0, {
                    'vid': vid, 'title': title, 'thumb': thumb,
                    'duration': duration, 'progress': position,
                    'watched_at': int(time.time()),
                })

            # Se guarda cada 15 s durante la reproducción, y escribir in situ dejaría el
            # historial corrupto si Kodi se cierra a mitad.
            core_settings.atomic_write_json(core_settings._WATCH_FILE, history[:100], ensure_ascii=False)

        _json_response(handler, {'status': 'ok'})
    except Exception as e:
        _json_response(handler, {'status': 'error', 'error': str(e)})
