# -*- coding: utf-8 -*-
# AtresDaily - Copyright (C) 2024-2026 RubénSDFA1laberot
# Ventana de lista con panel lateral, portada de EKHorus (lib/list_screen.py y lib/ui_common.py).
#
# Quien la abre pasa una función que devuelve las filas y otra que dice qué hacer al pulsarlas.
# El panel de la derecha sigue a la fila enfocada desde el propio skin, sin Python detrás.

import collections
import contextlib
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

HEADING = "AtresDaily"

ID_CERRAR = 100
ID_BOTON1 = 103
ID_BOTON2 = 104
ID_LISTA = 200
ID_BARRA = 300
ID_TEXTO = 301

_PESTILLO = "atresdaily.lista"
# Solo importa si la ventana anterior ya no existe, porque mientras está abierta no se puede
# volver a pulsar la fila del menú. Se guarda la hora y no un '1' para que un script que Kodi
# mate entre poner y quitar la marca no deje la entrada del menú muerta toda la sesión.
_PESTILLO_VALIDEZ_S = 60

_ATRAS = (9, 10, 92)  # ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_NAV_BACK

# El spinner de Kodi. 'nocancel' porque lo que tapa no se puede interrumpir a medias
_ESPERA = "busydialognocancel"

# Kodi pasa estos gestos a onAction() cuando ningún control los recoge. La lista sí los
# recoge y se desplaza sola, así que aquí solo llega lo de fuera.
GESTO_INICIO = 501
GESTO_ARRASTRE = 504
GESTO_CORTE = 505
GESTO_FIN = 599
# Un <textbox> no atiende gestos ni ratón y solo se mueve con su scrollbar, a páginas. Por eso
# un arrastre pasa páginas en vez de arrastrar el texto.
_PASO = 0.61      # alto del texto respecto a la pantalla
_MINIMO = 0.10    # arrastre más corto que cuenta como pasar página

NARANJA = "FFFF9A1F"
GRIS = "FF8A97A5"
# El texto de las pastillas de color va sobre un relleno saturado, así que es oscuro
TINTA_VERDE = "FF08130C"

# pastilla: (texto, 'on' | 'off' | 'gris'), o None si la fila lleva un valor suelto
Fila = collections.namedtuple(
    "Fila", "clave titulo pista icono valor pastilla plot sep",
    defaults=("", "", "", None, "", False))


def color(texto, tinta):
    return f"[COLOR {tinta}]{texto}[/COLOR]"


def titulo_ventana(pantalla):
    # Como el título de atresdaily_guia.xml
    return (f"[COLOR {NARANJA}][B]Atres[/B][/COLOR][COLOR FF40E0D0]Daily[/COLOR]"
            f"[COLOR {GRIS}]   ·   [/COLOR]{pantalla}")


@contextlib.contextmanager
def ocupado():
    """El spinner de Kodi mientras una pantalla tarda en montarse.

    Hay que cerrarlo antes de abrir una ventana propia, para no tener dos ventanas modales
    peleándose por el foco."""
    xbmc.executebuiltin(f"ActivateWindow({_ESPERA})")
    try:
        yield
    finally:
        xbmc.executebuiltin(f"Dialog.Close({_ESPERA})")


class Deslizador:
    """Convierte el arrastre del dedo en cambios de página de un cuadro de texto.

    Es copia del de iptv_guide.py."""

    def __init__(self, ventana, barra, texto):
        self.ventana = ventana
        self.barra = barra
        self.texto = texto
        self._activo = False
        self._ultimo = 0.0
        self._suma = 0.0
        # Los gestos llegan en píxeles de la superficie de Kodi, que en un móvil no coinciden
        # con los 1080 del skin, así que el umbral se mide en pantallas y no en puntos.
        alto = xbmcgui.getScreenHeight() or 1080
        self._paso = alto * _PASO
        self._minimo = alto * _MINIMO

    def accion(self, action):
        """True si el gesto era para el texto y ya está atendido."""
        gesto = action.getId()

        if gesto == GESTO_INICIO:
            self._activo = True
            self._ultimo = action.getAmount2()
            self._suma = 0.0
            return True

        if not self._activo:
            return False

        if gesto == GESTO_ARRASTRE:
            y = action.getAmount2()
            self._suma += self._ultimo - y
            self._ultimo = y
            while self._suma >= self._paso:
                self._suma -= self._paso
                self._pagina(1)
            while self._suma <= -self._paso:
                self._suma += self._paso
                self._pagina(-1)
            return True

        if gesto in (GESTO_FIN, GESTO_CORTE):
            self._activo = False
            if gesto == GESTO_FIN and abs(self._suma) >= self._minimo:
                self._pagina(1 if self._suma > 0 else -1)
            self._suma = 0.0
            # Kodi deja el foco en el control por defecto tras un gesto; sin esto, quien arrastra
            # y luego coge el mando encuentra el foco en otro sitio.
            self.ventana.setFocusId(self.texto)
            return True

        return False

    def _pagina(self, sentido):
        xbmc.executebuiltin(f"{'PageDown' if sentido > 0 else 'PageUp'}({self.barra})")


class Pantalla(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.titulo = ""
        self.subtitulo = ""
        self.estado = ""
        self.pista = ""
        self.botones = ()        # ((texto, función), ...), dos como mucho
        self.hacer_filas = None  # () -> [Fila]
        self.al_pulsar = None    # (Fila) -> 'cerrar' cierra, 'inicio' repinta arriba
        self._filas = []
        self._dedo = None

    def onInit(self):
        # Kodi puede llamar aquí más de una vez (al recargar el skin); sin esta guarda se
        # duplicarían las filas.
        if self._filas:
            return
        self._dedo = Deslizador(self, ID_BARRA, ID_TEXTO)
        self.setProperty("pl_titulo", self.titulo)
        self.setProperty("pl_sub", self.subtitulo)
        self.setProperty("pl_estado", self.estado)
        self.setProperty("pl_pista", self.pista)
        for n, (etiqueta, _) in enumerate(self.botones[:2]):
            self.setProperty("pl_b1" if n == 0 else "pl_b2", etiqueta)
        self._pintar(0, enfocar=True)

    def repintar(self, seleccion=0):
        self._pintar(seleccion, enfocar=True)

    def _pintar(self, seleccion=None, enfocar=False):
        control = self.getControl(ID_LISTA)
        if seleccion is None:
            seleccion = control.getSelectedPosition()

        self._filas = list(self.hacer_filas())
        items = []
        for fila in self._filas:
            item = xbmcgui.ListItem(label=fila.titulo)
            # El panel lo lee el XML del ítem enfocado. Un hilo que vigile el foco no sirve, porque sus
            # llamadas a xbmcgui congelan el Python de Kodi mientras instala un addon, y un repositorio
            # servido desde Python (el de Elementum) no podría contestar.
            item.setProperty("f_plot", fila.plot)
            if fila.sep:
                item.setProperty("f_tipo", "sep")
            else:
                item.setProperty("f_icono", fila.icono)
                item.setProperty("f_pista", fila.pista)
                if fila.pastilla:
                    item.setProperty("f_pastilla", fila.pastilla[0])
                    item.setProperty("f_estado", fila.pastilla[1])
                elif fila.valor:
                    item.setLabel2(fila.valor)
            items.append(item)

        control.reset()
        control.addItems(items)
        # Si se acaba de borrar la última fila, la posición queda más allá del final y el cursor
        # va a la nueva última en vez de volver arriba, que es adonde lo mandaría Kodi.
        if items:
            control.selectItem(min(max(seleccion, 0), len(items) - 1))
        if enfocar:
            self.setFocusId(ID_LISTA)

    def onAction(self, action):
        if self._dedo is not None and self._dedo.accion(action):
            return
        # Un WindowXMLDialog de Python no se cierra solo con Atrás
        if action.getId() in _ATRAS:
            self.close()

    def onClick(self, controlId):
        if controlId == ID_CERRAR:
            self.close()
            return

        if controlId in (ID_BOTON1, ID_BOTON2):
            n = 0 if controlId == ID_BOTON1 else 1
            if n < len(self.botones) and self.botones[n][1]() == "refrescar":
                self.repintar()
            return

        if controlId != ID_LISTA or not self._filas:
            return

        pos = self.getControl(ID_LISTA).getSelectedPosition()
        if not 0 <= pos < len(self._filas):
            return
        if self._filas[pos].sep:
            # Se importa al pulsar para no cargar los minijuegos con cada ventana
            from minijuegos import sorpresa
            sorpresa.ofrecer()
            self.setFocusId(ID_LISTA)
            return

        resultado = self.al_pulsar(self._filas[pos])
        if resultado == "cerrar":
            self.close()
            return
        # El foco se pone aquí porque, al volver de un diálogo, es del diálogo que se acaba de
        # cerrar y tiene que volver a la fila de la que salió.
        self.repintar(0 if resultado == "inicio" else pos)


def _hay_pestillo():
    marca = xbmcgui.Window(10000).getProperty(_PESTILLO)
    try:
        return bool(marca) and time.time() - float(marca) < _PESTILLO_VALIDEZ_S
    except ValueError:
        return False


def mostrar(titulo, subtitulo, hacer_filas, al_pulsar, botones=(), estado="",
            pista="[B]OK[/B] abre    ·    [B]Derecha[/B] lee    ·    [B]Atrás[/B] cierra"):
    """Abre la ventana. False si no se pudo, para volver a la lista clásica."""
    # Cada pulsación del menú relanza el addon desde cero, y un doble clic abriría dos ventanas
    # iguales, una encima de otra, y cerrar la de arriba parecería no cerrar nada.
    if _hay_pestillo():
        xbmc.log("[AtresDaily] list_screen: ya hay una ventana abierta, no se abre otra", xbmc.LOGINFO)
        return True
    ventana_kodi = xbmcgui.Window(10000)
    ventana_kodi.setProperty(_PESTILLO, str(time.time()))

    ventana = None
    try:
        ventana = Pantalla("atresdaily_lista.xml", xbmcaddon.Addon().getAddonInfo("path"),
                           "Default", "1080i")
        ventana.titulo = titulo
        ventana.subtitulo = subtitulo
        ventana.estado = estado
        ventana.pista = pista
        ventana.botones = tuple(botones)[:2]
        ventana.hacer_filas = hacer_filas
        ventana.al_pulsar = al_pulsar
        ventana.doModal()
        return True
    except Exception as e:  # si la ventana no abre en algún skin, se vuelve a la lista de Kodi
        xbmc.log(f"[AtresDaily] list_screen: {e}", xbmc.LOGERROR)
        return False
    finally:
        # doModal no libera los controles, y en Kodi son texturas en memoria
        del ventana
        ventana_kodi.clearProperty(_PESTILLO)


def clasica_activada():
    """True si el usuario ha pedido las listas de Kodi en vez de las ventanas, por si
    estas fallan en su aparato."""
    return xbmcaddon.Addon().getSetting("espakodi_lista_clasica") == "true"


def _a_la_lista(accion):
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?action={accion}&clasico=1)")


def abrir_o_lista(accion, abrir_ventana):
    """Abre la ventana y, si no abre, lleva a la lista clásica de la misma pantalla."""
    if not abrir_ventana():
        xbmcgui.Dialog().notification(HEADING, "No se pudo abrir la ventana; se abre la lista clásica",
                                      xbmcgui.NOTIFICATION_WARNING, 5000)
        _a_la_lista(accion)


def ventana_o_lista(accion, abrir_ventana, pintar_lista):
    """Punto de entrada de las pantallas que tienen ventana propia y lista clásica."""
    handle = int(sys.argv[1])
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}

    if clasica_activada() or params.get("clasico") == "1":
        if handle >= 0:
            pintar_lista(handle)
        else:
            # La fila se pintó como no-carpeta antes de activar las listas clásicas, y Kodi solo
            # da un directorio donde escribir a las carpetas, así que se pide entrando otra vez.
            _a_la_lista(accion)
        return

    if handle >= 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    abrir_o_lista(accion, abrir_ventana)
