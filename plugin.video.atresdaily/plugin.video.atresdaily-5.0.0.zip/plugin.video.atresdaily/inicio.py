# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Lo que se abre nada más entrar en AtresDaily (Configuración > Al abrir AtresDaily)."""
import os
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

import categorias

RAIZ = 'plugin://plugin.video.atresdaily/'
_VIDEOS = 10025
# La entrada más reciente se queda con el turno, y una espera anterior que siga viva ya no
# abre nada.
_TURNO = 'atresdaily.inicio'
_ESPERA_S = 10
_PASO_S = 0.05

# En el orden de los values de inicio_destino en settings.xml, que guarda la posición.
# (texto, acción, se abre como carpeta). Lo que no es carpeta se lanza como al pulsarlo.
DESTINOS = (
    ('Menú principal', '', True),
    ('Modo Cine', 'experimental_home', False),
    ('Modo Fantasía', 'fantasia', False),
    ('Catálogo', 'catalog_menu', True),
    ('Una categoría del catálogo', 'list_cat', True),
    ('Historial de reproducciones', 'watch_history', True),
    ('Directos', 'live_tv_menu', True),
    ('En Directo A3', 'list_live_cats', True),
    ('TDT Channels España', 'tdt_channels_json', True),
    ('Buscar en internet', 'input_search', False),
    ('Megabuscador', 'busqueda_total', True),
    ('Historial de Búsqueda', 'view_history', True),
    ('Mis Favoritos', 'view_favorites', True),
    ('Mis Descargas', 'view_downloads', True),
)
# Los values de inicio_categoria en settings.xml. Kodi no guarda en ese ajuste un nombre que
# no esté entre ellos, y el conector puede traer categorías antes que el addon.
CATEGORIAS = ('Infantil', 'Vertical', 'Pódcast', 'Noticias', 'Snacks', 'Cine', 'Programas', 'Series',
              'Documentales', 'Premium', 'Telenovelas')


def _posicion(addon):
    try:
        n = int(addon.getSetting('inicio_destino') or 0)
    except ValueError:
        return 0
    return n if 0 <= n < len(DESTINOS) else 0


def _categoria(addon, cats):
    """(nombre que se enseña, id) de la categoría elegida, o None si el catálogo ya no la tiene."""
    nombre = addon.getSetting('inicio_categoria')
    return next(((nombre, cid) for interno, cid in cats.items() if categorias.nombre(interno) == nombre), None)


def destino(addon, cats):
    """(url, carpeta) de lo que se abre al entrar, o None si es el menú principal."""
    _, accion, carpeta = DESTINOS[_posicion(addon)]
    if not accion:
        return None
    if accion == 'list_cat':
        elegida = _categoria(addon, cats)
        if elegida is None:
            return f'{RAIZ}?action=catalog_menu', True
        nombre, cid = elegida
        return f'{RAIZ}?action=list_cat&title={urllib.parse.quote(nombre)}&url={urllib.parse.quote(cid)}', True
    # Como el botón del menú principal. Con el menú avanzado se va a su carpeta, sin pasar
    # por input_search, que solo haría otra llamada al addon para ir allí.
    if accion == 'input_search' and addon.getSetting('advanced_search_active') != 'false':
        return f'{RAIZ}?action=advanced_search_menu', True
    return f'{RAIZ}?action={accion}', carpeta


def texto(addon, cats):
    """Lo elegido, como sale en Configuración."""
    nombre, accion, _ = DESTINOS[_posicion(addon)]
    if accion == 'list_cat':
        elegida = _categoria(addon, cats)
        return f'Catálogo > {elegida[0]}' if elegida else 'Catálogo'
    return nombre


def _es_raiz(ruta):
    """La raíz del addon, con o sin la barra final y con la consulta vacía."""
    base, _, consulta = ruta.partition('?')
    return base.rstrip('/') == RAIZ.rstrip('/') and not consulta


def _elementos():
    try:
        return int(xbmc.getInfoLabel('Container.NumItems') or 0)
    except ValueError:
        return 0


def recien_abierto():
    """Si esta llamada a la raíz es la de entrar en AtresDaily, y no la de volver al menú
    principal desde dentro o la de refrescarlo, que dejan en Vídeos algo de AtresDaily."""
    # Un widget de Inicio también llama a la raíz, y el Modo Fantasía la carga en su carrusel.
    if xbmcgui.getCurrentWindowId() != _VIDEOS or xbmcgui.Window(10000).getProperty('atresdaily.fantasia'):
        return False
    ruta = xbmc.getInfoLabel('Container.FolderPath')
    if _es_raiz(ruta):
        # Desde Inicio o Favoritos, Kodi pone la raíz como carpeta de Vídeos antes de llamar
        # al addon, todavía vacía. Al refrescar el menú, ya tiene sus botones.
        return not _elementos()
    return not ruta.startswith(RAIZ)


def al_entrar(addon, cats):
    """(url, carpeta, turno) de lo que se abre si esta llamada a la raíz es la de entrar, o
    None. Va antes de pintar el menú, porque después la ventana de Vídeos ya lo tiene y no se
    distingue de volver a él. El turno se toma aquí y no al esperar, porque una espera
    anterior que siga viva vería este mismo menú y abriría también."""
    elegido = destino(addon, cats)
    if elegido is None or not recien_abierto():
        return None
    turno = os.urandom(8).hex()
    xbmcgui.Window(10000).setProperty(_TURNO, turno)
    return (*elegido, turno)


def abrir(url, carpeta, turno):
    """Lo abre en cuanto se ve el menú principal, para que Atrás vuelva a él. Un
    Container.Update mandado mientras Kodi aún lo está poniendo se pierde."""
    casa = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()
    try:
        for _ in range(int(_ESPERA_S / _PASO_S)):
            if casa.getProperty(_TURNO) != turno:
                return
            if (xbmcgui.getCurrentWindowId() == _VIDEOS and _es_raiz(xbmc.getInfoLabel('Container.FolderPath'))
                    and _elementos()):
                xbmc.executebuiltin(f'Container.Update({url})' if carpeta else f'RunPlugin({url})')
                return
            if monitor.waitForAbort(_PASO_S):
                return
    finally:
        if casa.getProperty(_TURNO) == turno:
            casa.clearProperty(_TURNO)


def elegir(cats):
    """Botón de Configuración con lo mismo que el ajuste, en una lista."""
    addon = xbmcaddon.Addon()
    n = xbmcgui.Dialog().select('Al abrir AtresDaily', [t for t, _, _ in DESTINOS], preselect=_posicion(addon))
    if n < 0:
        return
    if DESTINOS[n][1] == 'list_cat':
        nombres = [v for v in (categorias.nombre(k) for k in cats) if v in CATEGORIAS]
        if not nombres:
            xbmcgui.Dialog().notification('AtresDaily', 'El catálogo no está disponible ahora',
                                          xbmcgui.NOTIFICATION_WARNING)
            return
        actual = addon.getSetting('inicio_categoria')
        c = xbmcgui.Dialog().select('Categoría del catálogo', nombres,
                                    preselect=nombres.index(actual) if actual in nombres else 0)
        if c < 0:
            return
        addon.setSetting('inicio_categoria', nombres[c])
    addon.setSetting('inicio_destino', str(n))
    xbmc.executebuiltin('Container.Refresh')
