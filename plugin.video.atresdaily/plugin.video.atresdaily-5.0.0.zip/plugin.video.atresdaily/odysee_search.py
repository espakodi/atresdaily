# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
#
# Búsqueda en Odysee (LBRY) sin API key:
#   1) Lighthouse devuelve claim_ids ordenados por relevancia.
#   2) claim_search los hidrata con metadatos (título, miniatura, duración, canal).
#   3) Al reproducir, el enlace del CDN sale del sd_hash del claim (o de la API proxy, igual
#      que yt-dlp, si no lo trae) y se reintenta mientras Odysee no sirva el vídeo.
import hashlib
import http.client
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_LHSE_URL  = "https://lighthouse.odysee.tv/search?s={0}&size={1}&claimType=file&nsfw=false&free_only=true"
_PROXY_CS  = "https://api.na-backend.odysee.com/api/v1/proxy?m=claim_search"
_PROXY_GET = "https://api.na-backend.odysee.com/api/v1/proxy?m=get"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
}

_MIME_EXT = {
    "video/mp4": ".mp4", "video/webm": ".webm", "video/ogg": ".ogv",
    "audio/mpeg": ".mp3", "audio/mp4": ".m4a", "audio/ogg": ".ogg",
    "audio/flac": ".flac", "audio/wav": ".wav",
}
_CDN_STREAM = "https://player.odycdn.com/v6/streams/{claim_id}/{sd6}{ext}"
_CDN_HDRS   = urllib.parse.urlencode({"Referer": "https://odysee.com/",
                                       "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                                                     "Chrome/123.0.0.0 Safari/537.36"})

# Lo que no está en la caché del CDN (CDN77) lo pide al origen de Odysee, que contesta 429 ("Try
# again later") mientras no tiene el vídeo. A veces lo sirve al cabo de un minuto y otras tarda
# horas, así que se reintenta un rato con el aviso en pantalla y después se pregunta si seguir.
_WAIT_STEP = 5        # segundos entre peticiones
_WAIT_ROUND = 60      # segundos de cada tanda de reintentos
_PROBE_TIMEOUT = 5
_MAX_FAILS = 3        # fallos de red seguidos antes de rendirse

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.atresdaily/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except OSError:
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, key + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _get_json(url, timeout=15):
    req = urllib.request.Request(url, headers=_HEADERS)
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _post_json(url, payload, timeout=20):
    body = json.dumps(payload).encode("utf-8")
    headers = dict(_HEADERS, **{"Content-Type": "application/json"})
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    resp = urllib.request.urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode("utf-8", errors="replace"))


def _lighthouse_ids(query, size=30):
    """Devuelve claim_ids ordenados por relevancia (Lighthouse solo da claimId/name)."""
    data = _get_json(_LHSE_URL.format(urllib.parse.quote_plus(query), size))
    arr = data if isinstance(data, list) else data.get("results", [])
    return [it["claimId"] for it in (arr or [])
            if isinstance(it, dict) and it.get("claimId")]


def _claim_search(claim_ids):
    """Completa los claim_ids con sus metadatos en una sola llamada."""
    payload = {
        "jsonrpc": "2.0", "method": "claim_search", "id": 1,
        "params": {"claim_ids": claim_ids, "page": 1,
                   "page_size": len(claim_ids), "no_totals": True},
    }
    data = _post_json(_PROXY_CS, payload)
    return ((data.get("result") or {}).get("items")) or []


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _parse_claim(c):
    """Extrae campos del claim (metadatos anidados bajo value.*)."""
    if not isinstance(c, dict):
        return None
    name = c.get("name", "")
    claim_id = c.get("claim_id", "")
    if not name or not claim_id:
        return None
    val = c.get("value") or {}
    if val.get("stream_type") not in ("video", "audio"):
        return None  # descartar PDFs, imágenes y otros ficheros no reproducibles
    video = val.get("video") or {}
    source = val.get("source") or {}
    sign = c.get("signing_channel") or {}
    channel = (sign.get("value") or {}).get("title") or sign.get("name", "")
    return {
        "name":        name,
        "claim_id":    claim_id,
        "title":       val.get("title") or name,
        "channel":     channel,
        "thumb":       (val.get("thumbnail") or {}).get("url", ""),
        "duration":    video.get("duration", 0),
        "description": val.get("description", ""),
        "sd_hash":     source.get("sd_hash", ""),
        "media_type":  source.get("media_type", ""),
    }


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "odysee_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    ids = _lighthouse_ids(query)
    if not ids:
        return []
    by_id = {}
    for c in _claim_search(ids):
        p = _parse_claim(c)
        if p:
            by_id[p["claim_id"]] = p
    results = [by_id[i] for i in ids if i in by_id]
    _cache_set(key, results)
    return results


def resolve_stream(name, claim_id):
    """Obtiene la streaming_url real via API proxy (mismo método que usa yt-dlp)."""
    uri = f"lbry://{name}#{claim_id}"
    payload = {"jsonrpc": "2.0", "method": "get", "id": 1, "params": {"uri": uri}}
    try:
        data = _post_json(_PROXY_GET, payload)
        url = (data.get("result") or {}).get("streaming_url", "")
        if url:
            return url
    except Exception as e:
        xbmc.log(f"[AtresDaily] Odysee get failed: {e}", xbmc.LOGWARNING)
    return ""


def plugin_url(addon_url, name, claim_id, sd_hash="", media_type=""):
    """URL del plugin que reproduce un resultado de search(). No va directa al CDN porque
    Odysee puede no servir el vídeo al momento, y entonces hay que reintentar (play_item)."""
    params = {"action": "odysee_play", "name": name, "claim_id": claim_id}
    if sd_hash:
        params.update(sd_hash=sd_hash, media_type=media_type)
    return f"{addon_url}?{urllib.parse.urlencode(params)}"


def _probe(url):
    """Estado del vídeo en el CDN: 'ready', 'preparing', 'gone', 'denied' o 'error'."""
    headers = {"User-Agent": _HEADERS["User-Agent"], "Referer": "https://odysee.com/",
               "Range": "bytes=0-1023"}
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers),
                                    timeout=_PROBE_TIMEOUT):
            return "ready"
    except urllib.error.HTTPError as e:
        if e.code == 429:
            return "preparing"
        if e.code in (404, 410):
            return "gone"
        if e.code in (401, 403):
            return "denied"
        return "error"
    except (urllib.error.URLError, http.client.HTTPException, OSError, ValueError):
        return "error"


def _wait_text(state, elapsed):
    if state == "error":
        return f"No se puede conectar con Odysee. Reintentando... ({int(elapsed)} s)"
    return ("Odysee no está sirviendo este vídeo ahora mismo, algo que le pasa con los que se "
            f"ven poco. Se sigue intentando y se abrirá en cuanto llegue. ({int(elapsed)} s)")


def _wait_round(url, monitor, state):
    """Una tanda de espera con el aviso en pantalla. Acaba en 'ready', 'gone', 'denied',
    'error', 'timeout', 'cancelled' o 'abort'."""
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", _wait_text(state, 0))
    start = time.monotonic()
    next_probe = start + _WAIT_STEP
    fails = 1 if state == "error" else 0
    shown = 0
    try:
        while True:
            # Se mira cada 0,2 s para que Cancelar y el cierre de Kodi respondan al momento.
            if dp.iscanceled():
                return "cancelled"
            if monitor.waitForAbort(0.2):
                return "abort"
            elapsed = time.monotonic() - start
            if int(elapsed) != shown:
                shown = int(elapsed)
                dp.update(min(100, int(100 * elapsed / _WAIT_ROUND)), _wait_text(state, elapsed))
            if time.monotonic() < next_probe:
                continue
            state = _probe(url)
            if state in ("ready", "gone", "denied"):
                return state
            fails = fails + 1 if state == "error" else 0
            if fails >= _MAX_FAILS:
                return "error"
            if time.monotonic() - start >= _WAIT_ROUND:
                return "timeout"
            next_probe = time.monotonic() + _WAIT_STEP
    finally:
        dp.close()


def _wait_ready(url):
    """Pide el vídeo al CDN hasta que lo sirve. Acaba en 'ready', 'gone', 'denied', 'error',
    'cancelled' o 'abort'."""
    state = _probe(url)
    if state in ("ready", "gone", "denied"):
        return state
    monitor = xbmc.Monitor()
    while True:
        state = _wait_round(url, monitor, state)
        if state != "timeout":
            return state
        keep_waiting = xbmcgui.Dialog().yesno(
            "AtresDaily", "Odysee sigue sin servir el vídeo. A veces tarda unos minutos y otras "
            "no llega a hacerlo. ¿Seguir intentándolo?", nolabel="Dejarlo",
            yeslabel="Seguir intentándolo")
        if not keep_waiting:
            return "cancelled"
        if monitor.abortRequested():
            return "abort"
        state = "preparing"


_FAIL_MESSAGES = {
    "no_url": "No se pudo obtener la URL de reproducción de Odysee.",
    "gone": "Este vídeo ya no está en Odysee.",
    "denied": "Odysee no deja ver este vídeo ahora mismo.",
    "error": "No se pudo conectar con Odysee. Comprueba la conexión y vuelve a intentarlo.",
}


def play_item(handle, name, claim_id, sd_hash="", media_type=""):
    """Reproduce un vídeo de Odysee (action=odysee_play). Si Odysee no lo sirve al momento,
    reintenta con un aviso que se puede cancelar."""
    if sd_hash:
        url = _CDN_STREAM.format(claim_id=claim_id, sd6=sd_hash[:6],
                                 ext=_MIME_EXT.get(media_type, ""))
    else:
        dp = xbmcgui.DialogProgress()
        dp.create("AtresDaily", "Resolviendo stream de Odysee...")
        try:
            url = resolve_stream(name, claim_id)
        finally:
            dp.close()

    state = _wait_ready(url) if url else "no_url"
    xbmc.log(f"[AtresDaily] Odysee {state}: {url}", xbmc.LOGINFO)
    if state != "ready":
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        if state in _FAIL_MESSAGES:
            xbmcgui.Dialog().ok("AtresDaily", _FAIL_MESSAGES[state])
        return

    # El CDN devuelve 401 sin Referer; se adjunta con la sintaxis de cabeceras de Kodi.
    li = xbmcgui.ListItem(path=f"{url}|{_CDN_HDRS}")
    if media_type in _MIME_EXT:
        li.setMimeType(media_type)
        li.setContentLookup(False)
    # Con handle -1 (RunPlugin) Kodi no espera setResolvedUrl y hay que reproducirlo aquí.
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", f"Buscando en Odysee: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error buscando en Odysee: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error al buscar en Odysee:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("AtresDaily", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = plugin_url(addon_url, r["name"], r["claim_id"],
                              r.get("sd_hash", ""), r.get("media_type", ""))
        title = r["title"]
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):     plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:                  plot_lines.append(f"Duración: {dur}")
        if r.get("description"): plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or title,
                             'title': title, 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)
