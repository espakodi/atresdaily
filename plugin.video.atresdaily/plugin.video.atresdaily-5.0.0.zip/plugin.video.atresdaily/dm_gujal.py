# Código derivado de plugin.video.dailymotion_com (Gujal00), con licencia GPL-3.0
# https://github.com/Gujal00/Kodi-Official
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
# ============================================================================

import re
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcvfs

_UA_MOBILE = 'Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36'

HEADERS_GUJAL = {
    'User-Agent': _UA_MOBILE,
    'Origin': 'https://www.dailymotion.com',
    'Referer': 'https://www.dailymotion.com/'
}

COOKIES_GUJAL = {'lang': 'es_ES', 'ff': 'off'}


def _mime_de(url):
    """MIME según la URL elegida. DM casi nunca publica PROGRESSIVE-URI, así que casi
    siempre sale un manifiesto HLS; anunciarlo como video/mp4 rompe el demuxer."""
    limpia = url.split('|')[0].split('?')[0]
    if limpia.endswith('.m3u8') or 'manifest' in limpia:
        return 'application/x-mpegURL'
    return 'video/mp4'


def play_dm_extreme(vid, max_quality=1080, force_hls=False):
    """Modo extremo, como el addon plugin.video.dailymotion_com: subtítulos,
    verificación HEAD, límite de calidad y tokens sec.

    Devuelve (url, subtítulos, mime), o (None, None, None) si falla."""
    try:
        r = requests.get(
            f"https://www.dailymotion.com/player/metadata/video/{vid}", 
            headers=HEADERS_GUJAL, 
            cookies=COOKIES_GUJAL, 
            timeout=15
        )
        if r.status_code != 200:
            raise Exception("API Error")
        
        content = r.json()
        if content.get('error'):
            raise Exception(content['error'].get('type', 'Unknown Error'))
        
        # Subtítulos
        subs = []
        subs_data = content.get('subtitles', {}).get('data', {})
        if subs_data:
            for lang_key in subs_data.keys():
                urls = subs_data[lang_key].get('urls', [])
                if urls:
                    subs.append(urls[0])
        
        cc = content.get('qualities', {})
        m_url = ''
        
        # Buscar stream HLS en "auto"
        if 'auto' in cc:
            for item in cc['auto']:
                if item.get('type') == 'application/x-mpegURL':
                    m_url = item.get('url')
                    break
        
        if not m_url:
            raise Exception("No HLS stream found")
        
        # El master m3u8
        try:
            # M3U8 con ?sec= token: reescribir con redirect=0 antes de parsear (Gujal)
            extra_cookie = None
            if '.m3u8?sec' in m_url:
                m_url1 = m_url.split('?sec=')
                the_url = f"{m_url1[0]}?redirect=0&sec={urllib.parse.quote(m_url1[1])}"
                rr = requests.get(the_url, cookies=r.cookies.get_dict(), headers=HEADERS_GUJAL, timeout=10)
                if rr.status_code > 200:
                    rr = requests.get(m_url, cookies=r.cookies.get_dict(), headers=HEADERS_GUJAL, timeout=10)
                mbtext = rr.text
                
                if rr.headers.get('set-cookie'):
                    extra_cookie = rr.headers['set-cookie']
            else:
                mbtext = requests.get(m_url, headers=HEADERS_GUJAL, timeout=10).text
            
            xbmc.log(f'[dm_gujal] mbtext len={len(mbtext)} preview={repr(mbtext[:400])}', xbmc.LOGINFO)

            # PROGRESSIVE-URI son URLs MP4 directas; HLS.js necesita URLs de variante M3U8.
            # force_hls=True omite PROGRESSIVE-URI y extrae la URL HLS de la línea siguiente al #EXT-X-STREAM-INF.
            mb = ([] if force_hls else re.findall(r'NAME="([^"]+)",PROGRESSIVE-URI="([^"]+)"', mbtext))
            if not mb:
                # NAME puede ser "720", "720@30", etc.
                lines = mbtext.splitlines()
                for i, line in enumerate(lines):
                    if not line.startswith('#EXT-X-STREAM-INF:'):
                        continue
                    name_m = re.search(r'NAME="([^"]+)"', line)
                    name = name_m.group(1) if name_m else '0'
                    for j in range(i + 1, len(lines)):
                        candidate = lines[j].strip()
                        if candidate and not candidate.startswith('#'):
                            mb.append((name, candidate))
                            break
            
            if mb:
                def sort_key(elem):
                    try:
                        return int(elem[0].split("@")[0])
                    except Exception:
                        return 0
                mb = sorted(mb, key=sort_key, reverse=True)
                
                # primer stream con calidad <= max_quality
                selected_url = None
                for quality, strurl in mb:
                    try:
                        q_val = int(quality.split("@")[0])
                    except Exception:
                        q_val = 0
                    if q_val <= max_quality:
                        selected_url = strurl.split('#cell')[0]
                        break
                
                if not selected_url:
                    selected_url = mb[-1][1].split('#cell')[0]

                xbmc.log(f'[dm_gujal] selected url={selected_url[:100]}', xbmc.LOGINFO)

                # Verificación HEAD
                try:
                    head_r = requests.head(selected_url, headers=HEADERS_GUJAL, cookies=COOKIES_GUJAL, timeout=5)
                    if head_r.status_code != 200:
                        xbmc.log(f"[dm_gujal] HEAD check failed: {head_r.status_code}", xbmc.LOGWARNING)
                except Exception:
                    pass  # Continuar aunque falle HEAD
                
                if extra_cookie:
                    final_url = f"{selected_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}&Cookie={urllib.parse.quote(extra_cookie)}"
                else:
                    final_url = f"{selected_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"

                return final_url, subs, _mime_de(selected_url)
            else:
                # Si no hay calidades parseables, usar el m3u8 master con headers
                final_url = f"{m_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"
                return final_url, subs, "application/x-mpegURL"
                
        except Exception as e:
            xbmc.log(f"[dm_gujal] Extreme m3u8 parse failed: {e}", xbmc.LOGWARNING)
            # Como alternativa, usar m3u8 master directamente
            final_url = f"{m_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"
            return final_url, subs, "application/x-mpegURL"
    
    except Exception as e:
        xbmc.log(f"[dm_gujal] play_dm_extreme error: {e}", xbmc.LOGWARNING)
        return None, None, None


def play_dm_basic(vid):
    """Modo básico: User-Agent de móvil y cookies, sin extras.

    Devuelve (url, mime), o (None, None) si falla."""
    try:
        r = requests.get(
            f"https://www.dailymotion.com/player/metadata/video/{vid}", 
            headers=HEADERS_GUJAL, 
            cookies=COOKIES_GUJAL, 
            timeout=15
        )
        if r.status_code != 200:
            raise Exception("API Error")
        
        content = r.json()
        if content.get('error'):
            raise Exception(content['error'].get('type', 'Unknown Error'))
        
        cc = content.get('qualities', {})
        m_url = ''
        
        if 'auto' in cc:
            for item in cc['auto']:
                if item.get('type') == 'application/x-mpegURL':
                    m_url = item.get('url')
                    break
        
        if not m_url:
            raise Exception("No HLS stream found")
        
        try:
            mbtext = requests.get(m_url, headers=HEADERS_GUJAL, timeout=10).text
            mb = re.findall(r'NAME="([^"]+)",PROGRESSIVE-URI="([^"]+)"', mbtext)
            if not mb:
                mb = re.findall(r'NAME="(\d+)".*\n([^\n]+)', mbtext)
            
            if mb:
                def sort_key(elem):
                    try:
                        return int(elem[0].split("@")[0])
                    except Exception:
                        return 0
                mb = sorted(mb, key=sort_key, reverse=True)
                best_url = mb[0][1].split('#cell')[0]
                final_url = f"{best_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"
                return final_url, _mime_de(best_url)
            else:
                final_url = f"{m_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"
                return final_url, "application/x-mpegURL"
                
        except Exception as e:
            xbmc.log(f"[dm_gujal] Basic m3u8 parse failed: {e}", xbmc.LOGWARNING)
            final_url = f"{m_url}|{urllib.parse.urlencode(HEADERS_GUJAL)}"
            return final_url, "application/x-mpegURL"
    
    except Exception as e:
        xbmc.log(f"[dm_gujal] play_dm_basic error: {e}", xbmc.LOGWARNING)
        return None, None


def download_gujal(url, dest, title, user_agent):
    """Descarga url en dest a un temporal que se renombra al final, para no dejar
    archivos a medias. True si la descarga terminó bien."""
    try:
        vidfile = xbmcvfs.makeLegalFilename(dest)
        if xbmcvfs.exists(vidfile):
            xbmcgui.Dialog().notification('Download:', "El archivo ya existe", xbmcgui.NOTIFICATION_INFO)
            return False

        # Temporal junto al destino; el finally lo borra si algo falla
        tmp_file = vidfile + '.part'

        pDialog = xbmcgui.DialogProgress()
        pDialog.create('AtresDaily (Safe Mode)', f"Descargando: {title}")

        h = {"User-Agent": user_agent, "Referer": "https://www.dailymotion.com/"}

        # timeout de conexión y entre bytes. Sin él, un servidor que no responde colgaría el
        # diálogo sin posibilidad de cancelar.
        with requests.get(url, headers=h, stream=True, timeout=(10, 30)) as dfile:
            # Sin comprobarlo, un 403/404 guardaría la página de error como vídeo.
            if dfile.status_code != 200:
                pDialog.close()
                xbmc.log(f"[dm_gujal] Descarga rechazada: HTTP {dfile.status_code}", xbmc.LOGERROR)
                return False
            totalsize = float(dfile.headers.get('content-length', 0))

            with open(tmp_file, "wb") as handle:
                chunks = 0
                chunk_sz = 1024 * 1024  # trozos de 1 MB
                for chunk in dfile.iter_content(chunk_size=chunk_sz):
                    if chunk:
                        handle.write(chunk)
                        chunks += 1
                        if totalsize > 0:
                            pDialog.update(min(100, int(chunks * chunk_sz / totalsize * 100)))
                        if pDialog.iscanceled():
                            pDialog.close()
                            return False

        pDialog.close()

        # xbmcvfs.rename devuelve False si falla; sin mirarlo se daría la descarga por buena
        # y el finally borraría el único fichero descargado.
        return bool(xbmcvfs.rename(tmp_file, vidfile))
        
    except Exception as e:
        xbmc.log(f"[dm_gujal] Download Error: {e}", xbmc.LOGERROR)
        return False
    finally:
        # Limpiar tmp_file huérfano si existe
        if 'tmp_file' in locals() and tmp_file:
            try:
                if xbmcvfs.exists(tmp_file): xbmcvfs.delete(tmp_file)
            except Exception: pass
