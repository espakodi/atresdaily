# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import re
import html
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests

from plugin_utils import _u, _handle

_session       = requests.Session()
_CARTELERA_URL = "https://www.sensacine.com/peliculas/en-cartelera/cines/"
_ESTRENOS_URL  = "https://www.sensacine.com/peliculas/estrenos/"
_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "es-ES,es;q=0.9",
    "Referer": "https://www.sensacine.com/",
}
_SC_TTL = 6 * 3600       # 6 horas
_SC_MIN_FILMS = 3         # resultado con menos películas se considera fallo


# Caché

def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'atresdaily_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "estrenos": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data.get("cartelera"), dict):
            return empty
        if not isinstance(data.get("estrenos"), dict):
            data["estrenos"] = {}
        return data
    except Exception as e:
        xbmc.log(f"[AtresDaily-SC] cache load error: {e}", xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    try:
        path = _cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as e:
        xbmc.log(f"[AtresDaily-SC] cache save error: {e}", xbmc.LOGWARNING)


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


# Scraping

def _scrape(url):
    """Devuelve lista de {id, title, poster} o None si hay fallo de red."""
    try:
        r = _session.get(url, headers=_HEADERS, timeout=12)
        xbmc.log(f"[AtresDaily-SC] {url} -> {r.status_code}", xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(f"[AtresDaily-SC] resultado sospechoso ({len(films)} films), ignorando", xbmc.LOGWARNING)
            return None
        xbmc.log(f"[AtresDaily-SC] scrapeadas {len(films)} películas", xbmc.LOGINFO)
        return films
    except Exception as e:
        xbmc.log(f"[AtresDaily-SC] scrape error ({url}): {e}", xbmc.LOGERROR)
        return None


def _scrape_cartelera():
    return _scrape(_CARTELERA_URL)


# Entrada pública

def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(f"[AtresDaily-SC] cartelera desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[AtresDaily-SC] SC inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_cartelera():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("AtresDaily", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]")
        icon_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'descargas.png')
        li.setArt({'icon': icon_path})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de las películas en cartelera."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_cartelera_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de cartelera[/COLOR]")
        li.setArt({'icon': os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'backup_delete.png')})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de la cartelera actual."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_cartelera_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())

 
# Estrenos

def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    return _scrape(_ESTRENOS_URL)


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(f"[AtresDaily-SC] estrenos desde caché ({len(films)} títulos)", xbmc.LOGINFO)
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[AtresDaily-SC] estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("AtresDaily", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False

    if not has_meta:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]Descargar metadatos completos (actores, director...)[/B][/COLOR]")
        icon_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'descargas.png')
        li.setArt({'icon': icon_path})
        li.setInfo('video', {'plot': "Descarga sinopsis en español, actores y director de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cache_estrenos_meta"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red]Borrar metadatos de estrenos[/COLOR]")
        li.setArt({'icon': os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'backup_delete.png')})
        li.setInfo('video', {'plot': "Elimina los metadatos guardados de los próximos estrenos."})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_clear_estrenos_meta"), listitem=li, isFolder=False)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("AtresDaily", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "AtresDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("AtresDaily", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("AtresDaily", "No hay estrenos disponibles", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("AtresDaily", "Descargando metadatos estrenos...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "AtresDaily",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("AtresDaily", "Metadatos de estrenos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def show_menu():
    icon_dir = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    
    li = xbmcgui.ListItem(label="En cartelera")
    li.setArt({'icon': os.path.join(icon_dir, 'sc_cartelera.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_cartelera"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Próximos estrenos")
    li.setArt({'icon': os.path.join(icon_dir, 'sc_estrenos.png')})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="sensacine_estrenos"), listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(_handle())
