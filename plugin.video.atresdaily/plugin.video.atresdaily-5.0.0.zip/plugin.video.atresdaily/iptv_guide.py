# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Guía de las listas de canales.

Una ventana con el índice a la izquierda y el texto a la derecha o, si no se puede abrir
en algún skin, los diálogos de siempre de Kodi. Sale sola la primera vez que se pulsa
"Añadir lista de canales" y se puede abrir cuando se quiera desde ese mismo botón, desde
el menú de cada lista y desde "EspaKodi e Información".

La ventana (abrir) la usan también las novedades del addon (novedades.py).
"""
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

import ui_utils

_ADDON = xbmcaddon.Addon()
_PATH = _ADDON.getAddonInfo('path')
_LOG = '[AtresDaily/IPTV]'
_PROPERTY = 'atresdaily.iptv_guide'
_PROPERTY_MAX_AGE_S = 3600

ID_CERRAR = 100
ID_LISTA = 200
ID_BARRA = 300
ID_TEXTO = 301
SONDEO_MS = 200
_ATRAS = (9, 10, 92)  # ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_NAV_BACK

# El textbox de Kodi no se arrastra, así que deslizar el dedo pasa páginas.
GESTO_INICIO = 501
GESTO_ARRASTRE = 504
GESTO_CORTE = 505
GESTO_FIN = 599
_PASO = 0.61
_MINIMO = 0.10

_ORO = 'FFFF9A1F'


def _v(texto):
    """Un valor literal (una dirección, un ajuste, lo que hay que escribir tal cual)."""
    return f'[COLOR {_ORO}]{texto}[/COLOR]'


def _m(texto):
    """El nombre de un botón o de un menú, como sale en pantalla."""
    return f'[I]{texto}[/I]'


def _icono(nombre):
    return f'{_PATH}/resources/media/{nombre}'


GUIA = [
    {'num': '1.', 'titulo': 'Qué son las listas de canales', 'icono': 'info.png',
     'cuerpo': (
         'Con ' + _m('Añadir lista de canales') + ' guardas canales que se ven en directo: '
         'listas IPTV (M3U, M3U8 y las W3U de Wiseplay), enlaces AceStream, canales de Telegram y '
         'webs que publican emisiones, o tu servidor Xtream. Cada lista aparece en '
         + _m('TV en directo') + ', debajo de ' + _m('TDT Channels España (M3U)') + ', y se '
         'abre en carpetas por grupos. También valen las listas de radio en directo.'),
     'entradas': [
         {'titulo': 'Qué se guarda',
          'cuerpo': (
              'De cada lista se guarda su nombre, de dónde sale y cuántos canales tenía. Los '
              'canales se leen de la fuente al abrir la lista, así que siempre ves la versión '
              'al día y los cambios de la fuente te llegan solos.\n\n'
              'Cada lista se puede actualizar, renombrar, subir o bajar en el menú, llevar a la '
              'TV de Kodi o borrar (sección 6).')},
         {'titulo': 'Dónde aparecen',
          'cuerpo': (
              '1.  En ' + _m('TV en directo') + ', cada lista con su número de canales. Una lista '
              'enviada a la TV de Kodi lleva además la marca ' + _v('TV') + '.\n'
              '2.  Debajo, ' + _m('Añadir lista de canales') + ', que abre las formas de añadir '
              'y esta guía.\n'
              '3.  Con dos listas o más aparece ' + _m('Buscar en mis listas') + ', que busca un '
              'canal en todas a la vez.\n'
              '4.  La guía también está en ' + _m('EspaKodi e Información') + ' del menú '
              'principal y en el menú contextual de cada lista.')},
     ]},

    {'num': '2.', 'titulo': 'Formas de añadir una lista', 'icono': 'url_paste.png',
     'cuerpo': (
         'Pulsa ' + _m('Añadir lista de canales') + ' y elige de dónde sale. AtresDaily '
         'reconoce el formato por el contenido, no por la extensión, así que da igual que la dirección '
         'acabe en .m3u, en .txt o en nada.\n\n'
         'Al terminar te pide un nombre para la lista (viene uno propuesto; pulsa OK para '
         'dejarlo) y te dice cuántos canales ha guardado.'),
     'entradas': [
         {'titulo': 'A) Escribir o pegar un enlace',
          'cuerpo': (
              'Sirve para casi todo. Si tienes una dirección copiada en el equipo, el teclado '
              'sale ya relleno con ella.\n\n'
              '·  Una lista en internet: ' + _v('https://ejemplo.com/canales.m3u8') + '\n'
              '·  Una web o un canal de Telegram: ' + _v('@canal') + ', '
              + _v('t.me/canal') + ' o la dirección de la web.\n'
              '·  Un enlace AceStream: ' + _v('acestream://...') + ' o los 40 caracteres del '
              'identificador.\n'
              '·  La dirección que te dio tu proveedor Xtream (' + _v('get.php?username=...')
              + '). AtresDaily lo detecta y te ofrece importar sus canales por categorías.\n\n'
              'Los enlaces de páginas de pegado se leen en crudo solos: Pastebin, paste.ee, '
              'Rentry, un archivo de GitHub o de Gist y un enlace de Dropbox.')},
         {'titulo': 'B) Enviar desde el móvil o el PC',
          'cuerpo': (
              'Para no escribir con el mando.\n\n'
              '1.  Elige ' + _m('Enviar desde el móvil o el PC') + '.\n'
              '2.  Kodi enseña una dirección del tipo ' + _v('http://192.168.1.20:8080') + '.\n'
              '3.  Ábrela en el navegador del móvil o del PC, conectado a la misma red de casa.\n'
              '4.  Pega una dirección o la lista entera, o elige un archivo del móvil (hasta 6 '
              'MB).\n'
              '5.  Pulsa ' + _m('Enviar a Kodi') + ' y sigue en la tele.\n\n'
              'La página se cierra sola al recibir la lista o a los 5 minutos.')},
         {'titulo': 'C) Archivo del dispositivo',
          'cuerpo': (
              'Una lista guardada en el aparato, en una memoria USB o en una carpeta de red que '
              'tengas añadida en Kodi. Valen ' + _v('.m3u') + ', ' + _v('.m3u8') + ', '
              + _v('.txt') + ', ' + _v('.json') + ' y ' + _v('.w3u') + ' (Wiseplay).\n\n'
              'El archivo se vuelve a leer cada vez que abres la lista, así que si lo cambias en '
              'el disco se nota. Si enlaza otras listas, se vuelve a leer cuando lo cambias o '
              'cuando han pasado 6 horas. Si desaparece (la memoria USB quitada, por ejemplo), se '
              'enseña la última copia leída.')},
         {'titulo': 'D) Pegar del portapapeles',
          'cuerpo': (
              'Solo sale en Windows, macOS y Linux, y solo si hay algo copiado. Pega lo que '
              'tengas en el portapapeles del equipo, sea una dirección o la lista entera. Por '
              'privacidad no se enseña lo copiado, solo cuántas líneas tiene.\n\n'
              'En Android Kodi no puede leer el portapapeles, así que usa la opción B.')},
         {'titulo': 'E) Canal de Telegram o web con enlaces',
          'cuerpo': (
              'Para canales públicos de Telegram y webs que publican emisiones (los típicos de '
              'eventos deportivos con enlaces AceStream). AtresDaily lee las tres últimas '
              'páginas del canal y se queda con las emisiones: AceStream, HLS (.m3u8), DASH '
              '(.mpd) y similares. El nombre de cada canal es el texto del mensaje o, en una web, '
              'el que acompaña al enlace. Si el enlace solo dice ' + _v('Enlace') + ' o '
              + _v('Ver') + ', se usa el de su fila de la tabla.\n\n'
              'Al abrir la lista se vuelve a leer si han pasado más de 30 minutos, así que '
              'recoge lo último que se haya publicado.\n\n'
              'Los canales privados (' + _v('t.me/+...') + ', ' + _v('joinchat') + ') no se '
              'pueden leer sin una cuenta. Si Telegram o la web no responden desde tu '
              'conexión, se usa el proxy que tengas activado en ' + _m('Buscar directos en '
              'AceStream') + ', y con una VPN activa también suelen responder.')},
         {'titulo': 'F) Enlaces AceStream',
          'cuerpo': (
              'Pega uno o varios enlaces, separados por espacios, comas o saltos de línea:\n\n'
              + _v('acestream://0123456789abcdef0123456789abcdef01234567') + '\n'
              + _v('0123456789abcdef0123456789abcdef01234567') + '\n\n'
              'Si escribes el nombre delante (' + _v('Mi canal acestream://...') + ') o en la '
              'línea anterior, el canal se llama así. Si varios enlaces llevan el mismo '
              'nombre, salen como ' + _v('opción 2') + ', ' + _v('opción 3') + '...\n\n'
              'Para reproducirlos hace falta lo que explica la sección 5.')},
         {'titulo': 'G) Servidor Xtream Codes',
          'cuerpo': (
              'Con los datos de tu proveedor IPTV.\n\n'
              '1.  Elige ' + _m('Servidor Xtream Codes') + '.\n'
              '2.  Pega la dirección M3U que te dieron, o escribe servidor (' + _v(
                  'http://servidor:8080') + '), usuario y contraseña. La contraseña no se ve '
              'al escribirla.\n'
              '3.  AtresDaily comprueba la cuenta y te avisa si ha caducado, está bloqueada o '
              'los datos no son correctos.\n\n'
              'Los canales se importan por categorías. La fecha de caducidad de la cuenta sale '
              'en ' + _m('Información') + ' (sección 6). Si el servidor tiene apagada su API, se '
              'usa su lista M3U.')},
         {'titulo': 'H) Listas públicas',
          'cuerpo': (
              'Listas abiertas de canales en directo, listas para usar: la TDT española, los '
              'canales gratuitos de Samsung TV Plus, LG Channels, Rakuten TV, Pluto TV y Plex, '
              'emisoras de radio de España y en español y canales de todo el mundo. Elige una y '
              'decide entre ' + _m('Ver ahora')
              + ' (sin guardarla) y ' + _m('Guardar en mis listas') + '. Las que ya tienes '
              'salen marcadas.')},
         {'titulo': 'I) Canales AceStream',
          'cuerpo': (
              'Canales de televisión en directo, los mismos que EKHorus enseña en su apartado '
              'Canales, con buscador y filtros por categoría, país e idioma. Quedan como una '
              'lista más (sección 5).')},
     ]},

    {'num': '3.', 'titulo': 'Formatos que entiende', 'icono': 'adv_anti_errores_iptv.png',
     'cuerpo': (
         '·  M3U y M3U8, con ' + _v('tvg-id') + ', ' + _v('tvg-name') + ', ' + _v('tvg-logo')
         + ', ' + _v('tvg-chno') + ', ' + _v('group-title') + ' y ' + _v('#EXTGRP') + '. Las '
         'comas dentro de un grupo entrecomillado no rompen el nombre.\n'
         '·  Cabeceras por canal: ' + _v('#EXTVLCOPT:http-user-agent') + ', '
         + _v('#EXTVLCOPT:http-referrer') + ' y las que van pegadas a la dirección con '
         + _v('|User-Agent=...&Referer=...') + '.\n'
         '·  ' + _v('#KODIPROP') + ' de InputStream, que es como llegan los canales con DRM '
         '(ClearKey, Widevine).\n'
         '·  La guía de la lista (' + _v('url-tvg') + ' o ' + _v('x-tvg-url') + '), que se '
         'usa para lo que emiten ahora y al llevarla a la TV de Kodi.\n'
         '·  W3U de Wiseplay, con sus grupos y subgrupos, su guía, la radio y las cabeceras de '
         'cada canal (' + _v('referer') + ', ' + _v('userAgent') + ' y ' + _v('headers') + '). '
         'Si enlaza otras listas, se leen también, hasta 20 por lista.\n'
         '·  Listas en JSON. Las de radio de Radio Browser se reparten en carpetas: las más '
         'escuchadas y, después, por género si son de un solo país o por país si mezclan varios.\n'
         '·  Texto: una línea por canal con el nombre y el enlace, o el nombre en una línea y '
         'el enlace en la siguiente.\n'
         '·  Listas comprimidas en gzip y en cualquier codificación (UTF-8, UTF-16, Windows).'),
     'entradas': []},

    {'num': '4.', 'titulo': 'Ver una lista', 'icono': 'directo.png',
     'cuerpo': (
         'Al abrirla, si tiene varios grupos, salen ' + _m('Todos los canales') + ' y una '
         'carpeta por grupo con su número de canales. Los canales sin grupo van a '
         + _m('Sin grupo') + '.'),
     'entradas': [
         {'titulo': 'Buscar',
          'cuerpo': (
              _m('Buscar en esta lista') + ' encuentra un canal por su nombre o su grupo, sin '
              'importar mayúsculas ni tildes. ' + _m('Buscar en mis listas') + ' hace lo mismo '
              'en todas a la vez, con la última copia de cada una.')},
         {'titulo': 'Qué emiten ahora',
          'cuerpo': (
              'Si la lista trae ' + _v('tvg-id') + ', junto a cada canal sale '
              + _v('Ahora: programa (hora-hora)') + ', sacado de la guía de la propia lista. Si '
              'la lista no trae guía, se usa la de ' + _m('EPG (guía de televisión)') + ', que es '
              'de canales españoles. Una guía puede pesar varios MB, así que abrir una lista nunca '
              'la descarga por sorpresa. Si no está al día, arriba sale '
              + _m('Mostrar qué emiten ahora') + ' para bajarla cuando quieras.')},
         {'titulo': 'Reproducir y favoritos',
          'cuerpo': (
              'Pulsa un canal para verlo. Si la lista no dice qué User-Agent usar, se usa el de '
              'un navegador, porque hay servidores que rechazan el de Kodi (el directo de La 1, por '
              'ejemplo). Los HLS respetan el ajuste ' + _m('Motor TDT - InputStream Adaptive')
              + '. Los canales DASH y los que traen DRM usan siempre InputStream Adaptive; si '
              'falta, AtresDaily te ofrece instalarlo.\n\n'
              'Los enlaces a Dailymotion, YouTube o Twitch se abren con los mismos '
              'reproductores que el resto del addon.\n\n'
              'En el menú contextual de un canal, ' + _m('Añadir a Favoritos') + ' lo guarda '
              'con sus cabeceras en los favoritos de AtresDaily.')},
         {'titulo': 'Grabar',
          'cuerpo': (
              'En el menú contextual de un canal o una emisora, ' + _m('Grabar') + ' lo graba '
              'media hora, una, dos o tres horas, o hasta que lo pares (ocho horas como mucho). Si '
              'junto al canal ves lo que se emite ahora, también puedes grabar hasta que acabe el '
              'programa, con cinco minutos más por si se alarga. Lo mismo en ' + _m('TDT Channels '
              'España') + '.\n\n'
              'Se guarda en la carpeta de descargas (la pide la primera vez) y sale en '
              + _m('Mis Descargas') + '. Mientras graba, el canal lleva la marca ' + _v('REC') + ', '
              'arriba a la derecha se ve lo que lleva (se esconde con el vídeo a pantalla completa) y '
              'se para con ' + _m('Parar la grabación') + ', en el mismo menú o en Mis Descargas. '
              'Pasados unos 4 GB sigue en otro archivo, porque las memorias USB en FAT32 no admiten '
              'más.\n\n'
              'No se pueden grabar los canales cifrados (los de Pluto TV y algunos de Samsung, LG o '
              'Plex) ni los que mandan el sonido aparte (los de 3Cat); AtresDaily lo avisa al '
              'empezar. Grabar abre otra conexión aparte de la que usas para verlo, y hay servidores '
              'que solo dejan una.\n\n'
              'Kodi tiene que seguir abierto. Si lo cierras, la grabación se para, y lo grabado '
              'hasta entonces se queda. Mientras graba, Kodi no deja que el aparato se apague o se '
              'suspenda por no usarlo, y en Android la pantalla no se apaga sola, como cuando ves '
              'un vídeo. Si apagas tú la pantalla del móvil o pasas a otra app, Android puede '
              'dormir Kodi, y lo que se emita mientras tanto no se graba.')},
     ]},

    {'num': '5.', 'titulo': 'Canales AceStream', 'icono': 'adv_acestream.png',
     'cuerpo': (
         'Los canales AceStream llevan la marca ' + _v('ACE') + ', salvo en la lista '
         + _m('Canales AceStream') + ', donde lo son todos. AtresDaily no los reproduce por su cuenta, sino que se los pasa al '
         'primero que tengas instalado de estos addons, en este orden.\n\n'
         '1.  StreamNinja.\n'
         '2.  EKHorus (o el Horus original, que usa el mismo id: '
         + _v('script.module.horus') + ').\n'
         '3.  El motor AceStream del propio equipo, si está en marcha en '
         + _v('127.0.0.1:6878') + '.\n\n'
         'Además hace falta el motor AceStream: en Android, la app Ace Stream o AceServe; en un '
         'PC, el motor que EKHorus descarga solo. La guía de EKHorus explica cada caso paso '
         'a paso.\n\n'
         'AceStream es P2P y tu IP es visible para los demás nodos, como en BitTorrent, así '
         'que es mejor tener una VPN activa.'),
     'entradas': [
         {'titulo': 'Canales AceStream',
          'cuerpo': (
              'Unos 1.800 canales de todo el mundo con nombre, logo, categoría, país e idioma, '
              'los mismos que EKHorus enseña en su apartado Canales, sin cuentas ni claves.\n\n'
              '1.  En ' + _m('Añadir lista de canales') + ', elige ' + _m('Canales AceStream')
              + '. Tarda unos segundos.\n'
              '2.  Al abrir la lista salen ' + _m('Todos los canales') + ', ordenados por lo '
              'fiable que es su enlace y con los de tu idioma primero, y las carpetas '
              + _m('Por categoría') + ', ' + _m('Por país') + ' y ' + _m('Por idioma') + '. Las '
              'categorías de adultos no aparecen.\n'
              '3.  Un canal con la marca ' + _v('dudoso') + ' tiene un enlace que puede que no '
              'arranque o que se corte. Si tiene enlaces de repuesto, están en su menú '
              'contextual, en ' + _m('Probar otro enlace') + '.\n\n'
              'La lista se actualiza sola al abrirla si ha pasado un día.')},
         {'titulo': 'Por grupos',
          'cuerpo': (
              'A veces los canales llegan además agrupados de origen. Entonces la lista lleva una '
              'carpeta más, ' + _m('Por grupos') + ', con los canales agrupados así y algunos '
              'que no salen en las otras carpetas.')},
     ]},

    {'num': '6.', 'titulo': 'Gestionar tus listas', 'icono': 'opciones.png',
     'cuerpo': (
         'Todo está en el menú contextual de cada lista (botón Menú del mando, clic derecho o '
         'pulsación larga).'),
     'entradas': [
         {'titulo': 'Actualizar ahora',
          'cuerpo': (
              'Vuelve a leer la fuente en el momento. Si la lista pierde más de la mitad de sus '
              'canales, AtresDaily te pregunta antes de aceptarla, porque suele ser una caída de '
              'la fuente.\n\n'
              'No hace falta usarlo a menudo, porque al abrir una lista se actualiza sola si han '
              'pasado 6 horas (listas de internet y Xtream) o 30 minutos (Telegram y webs). Las '
              'listas pegadas o enviadas no tienen fuente y no se actualizan. Si enlazan otras '
              'listas, esas se leen una sola vez, al añadirlas.')},
         {'titulo': 'Si la fuente falla',
          'cuerpo': (
              'Sin conexión, o si la fuente devuelve una página de error, se enseña la última '
              'copia buena con un aviso de su fecha. Lo mismo si cancelas la actualización al '
              'abrir la lista. Si la fuente devuelve de repente muchos '
              'menos canales que antes (menos de la quinta parte), tampoco se sustituye sola: '
              'sigue la copia anterior hasta que la aceptes con ' + _m('Actualizar ahora') + '.')},
         {'titulo': 'Renombrar, subir, bajar y eliminar',
          'cuerpo': (
              _m('Renombrar') + ' cambia el nombre de la lista. '
              + _m('Subir') + ' y ' + _m('Bajar') + ' la mueven en ' + _m('TV en directo')
              + '. ' + _m('Eliminar') + ' la borra con todo lo guardado de ella y, si estaba en '
              'la TV de Kodi, la quita de allí.')},
         {'titulo': 'Información',
          'cuerpo': (
              'De dónde sale la lista, qué tipo de fuente es, cuántos canales, grupos y '
              'AceStream tiene y cuándo se leyó por última vez. Si enlaza otras listas, cuántas '
              'son y si alguna no se pudo leer. En las de Xtream, además, el '
              'estado de la cuenta, la caducidad y las conexiones permitidas. Las contraseñas '
              'nunca se enseñan.')},
         {'titulo': 'Copias de seguridad',
          'cuerpo': (
              'Las listas entran en la copia de seguridad de AtresDaily (' + _m('Opciones')
              + ', ' + _m('Copia de seguridad') + '), también lo que pegaste o enviaste desde '
              'el móvil. Al restaurar puedes sustituir tus listas o sumarlas a las que ya '
              'tienes.\n\n'
              'Las copias descargadas de cada fuente se pueden borrar desde el limpiador de '
              'almacenamiento del addon sin perder ninguna lista, porque se vuelven a descargar al '
              'abrirlas.')},
     ]},

    {'num': '7.', 'titulo': 'La sección TV de Kodi', 'icono': 'tv.png',
     'cuerpo': (
         'Con ' + _m('Mostrar en la TV de Kodi') + ' (en el menú contextual de la lista) los '
         'canales pasan también a la sección TV de Kodi, con su guía de programación, su '
         'zapping y los widgets del skin. Lo hace a través de IPTV Simple, el addon oficial de '
         'Kodi para listas IPTV.'),
     'entradas': [
         {'titulo': 'Cómo funciona',
          'cuerpo': (
              '1.  La primera vez, si no tienes IPTV Simple, Kodi te pregunta si lo instalas.\n'
              '2.  AtresDaily crea en IPTV Simple una lista propia llamada ' + _v('AtresDaily')
              + '. Las listas que ya tuvieras en IPTV Simple (las de EspaTV o EKHorus, por '
              'ejemplo) no se tocan.\n'
              '3.  Se recarga la TV de Kodi y aparecen los canales, con el nombre de la lista '
              'delante de cada grupo.\n\n'
              'Si estás viendo un canal de la TV cuando hace falta recargarla, AtresDaily te '
              'avisa antes de cortarlo.')},
         {'titulo': 'Qué va y qué no',
          'cuerpo': (
              'Van los directos y los AceStream, también los de ' + _m('Canales AceStream') + '. Los '
              'AceStream se abren con EKHorus si lo tienes, y si no, con el motor AceStream del '
              'equipo. Los enlaces a páginas (Dailymotion, YouTube) no van, porque solo los sabe abrir '
              'el addon.\n\n'
              'Los cambios de la lista llegan a la TV en menos de una hora y cada vez que se '
              'arranca Kodi. Para quitarla, ' + _m('Quitar de la TV de Kodi') + ' en el mismo '
              'menú.')},
         {'titulo': 'En Kodi 19',
          'cuerpo': (
              'Kodi 19 solo admite una lista en IPTV Simple, que puede ser la tuya, así que '
              'AtresDaily no la cambia. Deja preparada su lista y te dice dónde está para que '
              'la pongas tú en los ajustes de IPTV Simple si quieres.')},
     ]},

    {'num': '8.', 'titulo': 'Preguntas frecuentes', 'icono': 'busqueda.png', 'cuerpo': '',
     'entradas': [
         {'titulo': 'Dice que no hay canales en directo',
          'cuerpo': (
              'La lista no trae canales en directo, sus enlaces no se pueden abrir en Kodi o '
              'enlaza otras listas que no se han podido leer. El aviso dice qué ha pasado. Si es '
              'una web, puede que sus emisiones solo aparezcan a la hora del evento. Prueba más '
              'tarde.')},
         {'titulo': 'Error 403, 404 o de conexión',
          'cuerpo': (
              'El servidor rechaza la descarga o la lista ya no existe. Ante un 403, AtresDaily '
              'ya reintenta con el User-Agent de VLC, que algunos proveedores exigen. Algunas '
              'fuentes solo funcionan desde España y otras no responden desde ciertas operadoras, '
              'así que con la VPN activa o sin ella el resultado puede cambiar.')},
         {'titulo': 'El certificado no es válido',
          'cuerpo': (
              'Algunos servidores IPTV tienen el certificado HTTPS caducado o mal puesto. '
              'AtresDaily te pregunta si quieres seguir igualmente. Si aceptas, solo esa lista '
              'se descarga sin comprobar el certificado.')},
         {'titulo': 'Un canal no se reproduce',
          'cuerpo': (
              'Prueba a cambiar ' + _m('Motor TDT - InputStream Adaptive') + ' en las opciones '
              'avanzadas. Muchos canales de listas públicas dejan de funcionar sin aviso, y otros '
              'solo se ven desde España. Si falla uno solo, suele ser la fuente.')},
         {'titulo': 'Canales AceStream: "el motor no contesta"',
          'cuerpo': (
              'Los canales se piden al motor que tengas puesto en EKHorus o, sin EKHorus, al de '
              'este aparato, así que tiene que estar en marcha. En Android abre la app Ace Stream '
              'o AceServe y vuelve a Kodi; en un PC, reproduce cualquier canal con EKHorus para '
              'que lo arranque, y si el motor está en otro aparato, arráncalo allí.\n\n'
              'El aviso dice qué pasa: que el motor no contesta, que es demasiado antiguo para '
              'dar su lista (hace falta uno de la serie 3.2) o que contesta pero no la consigue. '
              'En ese último caso, vuelve a intentarlo dentro de un rato.')},
         {'titulo': 'AceStream no arranca',
          'cuerpo': (
              'Revisa la sección 5: hace falta un addon que lo reproduzca y el motor en marcha. '
              'Si el motor no contesta, AtresDaily te lo dice en vez de quedarse esperando.')},
         {'titulo': '¿Se pierden mis listas al actualizar el addon?',
          'cuerpo': (
              'No. Viven en la carpeta de datos del addon, que las actualizaciones no tocan, y '
              'entran en la copia de seguridad.')},
         {'titulo': 'La lista tarda en abrir',
          'cuerpo': (
              'La primera vez se descarga entera, y una lista Xtream grande puede tener miles '
              'de canales. Una W3U de Wiseplay que enlaza otras listas las descarga también. Las '
              'siguientes veces se abre al momento desde la copia guardada hasta que toca '
              'actualizarla.')},
     ]},

    {'num': '9.', 'titulo': 'Privacidad y seguridad', 'icono': 'info_terminos.png',
     'cuerpo': (
         '·  Todo se guarda en este aparato, en la carpeta de datos de AtresDaily. No se envía '
         'nada a ningún sitio. Solo se descarga cada lista de su propia fuente, y las listas que '
         'enlace.\n'
         '·  Si una lista de internet enlaza otras que están en tu red de casa, esas no se leen.\n'
         '·  La contraseña de Xtream se guarda como en cualquier reproductor IPTV y va en la '
         'copia de seguridad. No se enseña en pantalla ni sale en el registro de Kodi.\n'
         '·  Una lista no puede ejecutar programas ni cambiar ajustes del reproductor. Solo '
         'se aceptan addons de vídeo o audio y las propiedades de InputStream.\n'
         '·  La página para enviar desde el móvil solo existe mientras la tienes abierta en '
         'Kodi.\n\n'
         'AtresDaily no aloja ni distribuye canales. Tú decides qué listas añades y eres '
         'responsable de tener derecho a verlas.'),
     'entradas': []},
]


def _cuenta(n):
    return str(n) if n else ''


def _rotulo(seccion):
    return f"{seccion['num']}  {seccion['titulo']}" if seccion['num'] else seccion['titulo']


def _entera(seccion):
    partes = [seccion['cuerpo']] if seccion['cuerpo'] else []
    partes.extend(f"[B]{e['titulo']}[/B]\n{e['cuerpo']}" for e in seccion['entradas'])
    return '\n\n'.join(partes)


class _Deslizador:
    """Convierte el arrastre del dedo en cambios de página del texto."""

    def __init__(self, ventana, barra, texto):
        self.ventana = ventana
        self.barra = barra
        self.texto = texto
        self._activo = False
        self._ultimo = 0.0
        self._suma = 0.0
        alto = xbmcgui.getScreenHeight() or 1080
        self._paso = alto * _PASO
        self._minimo = alto * _MINIMO

    def accion(self, action):
        gesto = action.getId()
        if gesto == GESTO_INICIO:
            self._activo = True
            self._ultimo = action.getAmount2()
            self._suma = 0.0
            return True
        if not self._activo:
            return False
        if gesto == GESTO_ARRASTRE:
            y = action.getAmount2()
            self._suma += self._ultimo - y
            self._ultimo = y
            while self._suma >= self._paso:
                self._suma -= self._paso
                self._pagina(1)
            while self._suma <= -self._paso:
                self._suma += self._paso
                self._pagina(-1)
            return True
        if gesto in (GESTO_FIN, GESTO_CORTE):
            self._activo = False
            if gesto == GESTO_FIN and abs(self._suma) >= self._minimo:
                self._pagina(1 if self._suma > 0 else -1)
            self._suma = 0.0
            self.ventana.setFocusId(self.texto)
            return True
        return False

    def _pagina(self, sentido):
        xbmc.executebuiltin(f'{"PageDown" if sentido > 0 else "PageUp"}({self.barra})')


class _Lector(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.guia = GUIA
        self.cabecera = 'Guía de las listas de canales'
        self.seccion_entera = False
        self._abiertas = set()
        self._filas = []
        self._cerrando = False
        self._pintado = None
        self._dedo = None

    def onInit(self):
        # Kodi puede llamar aquí más de una vez (al recargar el skin); sin esta guarda se
        # duplicarían las filas y arrancaría un segundo hilo.
        if self._filas:
            return
        self.setProperty('g_cabecera', self.cabecera)
        self._dedo = _Deslizador(self, ID_BARRA, ID_TEXTO)
        self._pintar(0, enfocar=True)
        self._refrescar_panel(forzar=True)
        threading.Thread(target=self._bucle_foco, daemon=True).start()

    def close(self):
        self._cerrando = True
        super().close()

    def _construir_filas(self):
        filas = []
        for s, seccion in enumerate(self.guia):
            filas.append(('seccion', s, -1))
            if s in self._abiertas:
                filas.extend(('entrada', s, e) for e in range(len(seccion['entradas'])))
        return filas

    def _pintar(self, seleccion=None, enfocar=False):
        control = self.getControl(ID_LISTA)
        if seleccion is None:
            seleccion = control.getSelectedPosition()
        self._filas = self._construir_filas()
        items = []
        for tipo, s, e in self._filas:
            seccion = self.guia[s]
            if tipo == 'seccion':
                item = xbmcgui.ListItem(label=_rotulo(seccion))
                item.setProperty('g_tipo', 'seccion')
                item.setProperty('g_icono', _icono(seccion['icono']))
                item.setProperty('g_pista', '' if s in self._abiertas
                                 else _cuenta(len(seccion['entradas'])))
            else:
                item = xbmcgui.ListItem(label=seccion['entradas'][e]['titulo'])
                item.setProperty('g_tipo', 'entrada')
            items.append(item)
        control.reset()
        control.addItems(items)
        if 0 <= seleccion < len(items):
            control.selectItem(seleccion)
        if enfocar:
            self.setFocusId(ID_LISTA)

    def _refrescar_panel(self, forzar=False):
        if self.getFocusId() != ID_LISTA or not self._filas:
            return
        # El hilo puede leer justo mientras el principal rehace la lista, así que se comprueba la
        # posición contra las filas antes de indexar.
        pos = self.getControl(ID_LISTA).getSelectedPosition()
        if not 0 <= pos < len(self._filas) or (pos == self._pintado and not forzar):
            return
        self._pintado = pos
        tipo, s, e = self._filas[pos]
        seccion = self.guia[s]
        if tipo == 'seccion':
            titulo = _rotulo(seccion)
            if self.seccion_entera:
                cuerpo = _entera(seccion)
            else:
                cuerpo = seccion['cuerpo'] or '\n'.join(f"·  {x['titulo']}" for x in seccion['entradas'])
        else:
            titulo = seccion['entradas'][e]['titulo']
            cuerpo = seccion['entradas'][e]['cuerpo']
        self.setProperty('g_titulo', titulo)
        self.setProperty('g_cuerpo', cuerpo)

    def _bucle_foco(self):
        monitor = xbmc.Monitor()
        while not self._cerrando and not monitor.abortRequested():
            try:
                self._refrescar_panel()
            except Exception as e:
                # La ventana puede cerrarse entre la lectura y el pintado.
                xbmc.log(f'{_LOG} guía, bucle de foco: {e}', xbmc.LOGDEBUG)
            if monitor.waitForAbort(SONDEO_MS / 1000):
                break

    def onAction(self, action):
        if self._dedo is not None and self._dedo.accion(action):
            return
        if action.getId() in _ATRAS:
            self.close()

    def onClick(self, controlId):
        if controlId == ID_CERRAR:
            self.close()
            return
        if controlId != ID_LISTA or not self._filas:
            return
        pos = self.getControl(ID_LISTA).getSelectedPosition()
        if not 0 <= pos < len(self._filas):
            return
        tipo, s, _e = self._filas[pos]
        if tipo != 'seccion' or not self.guia[s]['entradas']:
            self._refrescar_panel(forzar=True)
            self.setFocusId(ID_TEXTO)
            return
        self._abiertas.symmetric_difference_update({s})
        self._pintar(pos, enfocar=True)
        self._refrescar_panel(forzar=True)


def _leer_clasico(guia, cabecera):
    """La guía con los diálogos de siempre de Kodi, para cuando la ventana propia no abre."""
    titulos = [_rotulo(s) for s in guia]
    while True:
        elegido = xbmcgui.Dialog().select(cabecera, titulos)
        if elegido < 0:
            return
        xbmcgui.Dialog().textviewer(titulos[elegido], _entera(guia[elegido]))


def _ocupada(ventana, propiedad):
    """True si ya hay una guía abierta (dos pulsaciones seguidas, o desde dos menús)."""
    marca = ventana.getProperty(propiedad)
    try:
        return bool(marca) and time.time() - float(marca) < _PROPERTY_MAX_AGE_S
    except ValueError:
        return False


def show():
    """La guía de las listas de canales. Devuelve True si era la primera vez que se abría,
    es decir, si su botón de EspaKodi e Información llevaba el punto verde."""
    era_nueva = ui_utils.visto('iptv_guide')
    abrir(GUIA, 'Guía de las listas de canales', _PROPERTY)
    return era_nueva


def abrir(guia, cabecera, propiedad, abiertas=(), entera=False):
    """Abre un texto con índice (secciones con el formato de GUIA) en la ventana de la guía.
    propiedad evita abrir dos veces la misma; abiertas son las secciones ya desplegadas; con
    entera, el panel de una sección enseña también el texto de todas sus entradas."""
    ventana_kodi = xbmcgui.Window(10000)
    if _ocupada(ventana_kodi, propiedad):
        return
    ventana_kodi.setProperty(propiedad, str(time.time()))
    lector = None
    fallo = False
    try:
        lector = _Lector('atresdaily_guia.xml', _PATH, 'Default', '1080i')
        lector.guia = guia
        lector.cabecera = cabecera
        lector._abiertas = set(abiertas)
        lector.seccion_entera = entera
        lector.doModal()
    except Exception as e:
        # Si la ventana propia no abre en algún skin, la guía se lee igual, porque quedarse sin
        # ella sería peor que verla con los diálogos normales.
        xbmc.log(f'{_LOG} guía: la ventana no abre, se usan los diálogos: {e}', xbmc.LOGWARNING)
        fallo = True
    finally:
        if lector is not None:
            lector._cerrando = True
        del lector
        ventana_kodi.clearProperty(propiedad)
    if fallo:
        _leer_clasico(guia, cabecera)
