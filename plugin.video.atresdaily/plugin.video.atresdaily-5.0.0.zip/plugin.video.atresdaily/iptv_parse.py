# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Lectura de listas de canales: M3U, W3U/JSON, texto, webs, Telegram y Xtream.

No depende de Kodi, así que se puede probar fuera de él.
"""
import codecs
import gzip
import hashlib
import html as _html
import io
import json
import math
import re
import unicodedata
import urllib.parse
import zlib
from collections import Counter

import html_scanner

KIND_ACE = 'ace'
KIND_HLS = 'hls'
KIND_DASH = 'dash'
KIND_DIRECT = 'direct'
KIND_PLUGIN = 'plugin'
KIND_WEB = 'web'
KIND_TORRENT = 'torrent'
KIND_UNSUPPORTED = 'unsupported'

_GZIP_MAX = 64 * 1024 * 1024
_JSON_MAX_NODES = 200000
_JSON_MAX_DEPTH = 12
W3U_SUBLISTS_MAX = 20
_W3U_DEPTH = 3
_NAME_MAX = 120
_NAME_LINE_MAX = 80
# Una duración de #EXTINF por debajo de esto no dice nada, porque hay listas de directos que
# ponen #EXTINF:1 o #EXTINF:10.
_LIVE_MAX_SECONDS = 300

_HEX40 = re.compile(r'[0-9a-fA-F]{40}')
_MAGNET_HASH_RE = re.compile(r'xt=urn:bt(?:ih:(?:[0-9a-f]{40}|[a-z2-7]{32})|mh:1220[0-9a-f]{64})(?![0-9a-z])',
                             re.I)
_HEX64 = re.compile(r'[0-9a-fA-F]{64}')
_KODI_TAG_RE = re.compile(
    r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR|TABS|COLOR\b[^\]]*)\]', re.I)
_ATTR_RE = re.compile(r'([\w-]+)\s*=\s*"([^"]*)"')
_DUR_RE = re.compile(r'#EXTINF:\s*(-?\d+(?:\.\d+)?)', re.I)
# Coma de más antes de ] o }, fuera de las cadenas.
_TRAILING_COMMA_RE = re.compile(r'("(?:[^"\\]|\\.)*")|,(\s*[\]}])', re.S)
_HEADER_NAME_RE = re.compile(r'[A-Za-z0-9-]+')
_LAN_SUFFIXES = ('.local', '.localhost', '.lan', '.home', '.home.arpa', '.internal', '.localdomain')
# IPs escritas como 127.1, 0x7f.0.0.1 o 0177.0.0.1, que ipaddress no lee y getaddrinfo sí (RFC 3493).
_NUMERIC_HOST_RE = re.compile(r'(?:0x[0-9a-f]*|\d+)(?:\.(?:0x[0-9a-f]*|\d+))*')

_STREAM_SCHEMES = {'rtmp', 'rtmps', 'rtmpe', 'rtmpt', 'rtsp', 'rtsps', 'rtp', 'udp', 'mms',
                   'mmsh', 'srt'}
_LOCAL_HOSTS = {'127.0.0.1', 'localhost', '0.0.0.0', '::1'}
_ACE_LOCAL_PATH_RE = re.compile(r'/(?:ace/)?(?:getstream|manifest(?:\.m3u8)?)$')
_ACE_LOCAL_ID_RE = re.compile(r'/(?:content_id|infohash|pid)/([0-9a-fA-F]{40})(?:/|$)')
_FILE_EXTS = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.m4v', '.m4a', '.mpg', '.mpeg', '.webm',
             '.3gp', '.divx', '.vob')
_STREAM_EXTS = ('.m3u8', '.mpd', '.ts', '.flv', '.aac', '.mp3', '.ogg', '.opus', '.m3u')
_EXT_RE = re.compile(r'[A-Za-z0-9]{1,5}')
_NOT_LIVE_GROUP_RE = re.compile(r'\bvod\b', re.I)
_PAGE_EXTS = ('.html', '.htm', '.aspx', '.jsp', '.shtml')
# Páginas de plataformas que url_player sabe resolver (Dailymotion, YouTube...).
_PLATFORM_HOSTS = ('youtube.com', 'youtu.be', 'dailymotion.com', 'dai.ly', 'twitch.tv',
                   'vimeo.com', 'rumble.com', 'kick.com', 'atresplayer.com')
# Enlaces de charla que aparecen en posts y webs y nunca son un canal.
_JUNK_HOSTS = ('t.me', 'telegram.me', 'telegram.org', 'telegra.ph', 'facebook.com', 'fb.com',
               'instagram.com', 'twitter.com', 'x.com', 'tiktok.com', 'wa.me', 'whatsapp.com',
               'discord.gg', 'discord.com', 'bit.ly', 'tinyurl.com', 'linktr.ee', 'reddit.com',
               'play.google.com', 'apps.apple.com')
# HLS sin .m3u8 en la dirección: el redirector de los canales gratuitos de Samsung TV Plus, Roku
# y otros, y los canales de Plex. Sin el tipo, Kodi 21 no sigue la redirección y resuelve las
# rutas relativas del manifiesto contra jmp2.uk, y el canal no arranca.
_HLS_HOSTS = ('jmp2.uk',)
_HLS_PATHS = (('epg.provider.plex.tv', '/library/parts/'),)

_TEXT_LINK_RE = re.compile(
    r'acestream://[0-9a-fA-F]{40}(?![0-9a-fA-F])'
    r'|(?:https?|rtmps?|rtmpe|rtsp|rtp|udp|mms|srt)://[^\s<>"\']+'
    r'|plugin://[^\s<>"\']+'
    r'|magnet:\?[^\s<>"\']+'
    r'|(?<![0-9A-Za-z])[0-9a-fA-F]{40}(?![0-9A-Za-z])', re.I)
_TRAILING_PUNCT = '.,;:)]}>\'"'
_NAME_SEPARATORS = ' \t-–—|:;,·•>»=*~_'

# Las regex de HTML se paran en el siguiente '<' (o en la siguiente <a>) y no usan '.*?' ni
# '[^>]*' abiertos. Con esos, miles de etiquetas sin cerrar hacen que el tiempo crezca con el
# cuadrado del tamaño.
_HIDDEN_START_RE = re.compile(r'<(script|style|noscript)\b[^<>]*>', re.I)
_JS_JSON_RE = re.compile(r'=\s*(?=[\[{])')
_JS_JSON_TRIES = 50
_ANCHOR_RE = re.compile(r'<(a|button)\b([^<>]*)>((?:[^<]|<(?!/?(?:a|button)\b))*?)</\1\s*>',
                        re.I)
_ATTR_VALUE_RE = re.compile(r'=\s*(?:"([^"]*)"|\'([^\']*)\')')
_BLOCK_RE = re.compile(
    r'<br\s*/?>|</?(?:p|div|li|tr|h\d|pre|blockquote|table|ul|ol|section|article)\b[^<>]*>',
    re.I)
_TAG_RE = re.compile(r'<[^<>]*>')
_TITLE_RE = re.compile(r'<title\b[^<>]*>([^<]*)</title\s*>', re.I)
# Textos de enlace que no dicen qué canal es ("Enlace", "Ver", "Link 2"...). Con ellos el
# nombre está fuera del enlace, en su fila o en la línea de encima.
_GENERIC_WORDS = {'enlace', 'enlaces', 'link', 'links', 'ver', 'aqui', 'click', 'clic', 'pulsa',
                  'pincha', 'abrir', 'play', 'reproducir', 'watch', 'here', 'open', 'acestream',
                  'ace', 'stream', 'opcion', 'option', 'server', 'servidor', 'fuente', 'source',
                  'mirror', 'en', 'copiar', 'copy', 'descargar', 'download', 'magnet', 'torrent'}
_TG_MESSAGE_RE = re.compile(
    r'class=["\'][^"\']*tgme_widget_message_text[^"\']*["\'][^>]*>(.*?)</div>', re.I | re.S)
_TG_POST_ID_RE = re.compile(r'data-post=["\'][^/"\']+/(\d+)["\']')

_URL_KEYS = ('url', 'link', 'stream', 'stream_url', 'streamurl', 'src', 'file', 'uri', 'm3u8')
_HASH_KEYS = ('acestream', 'ace', 'content_id', 'contentid', 'infohash', 'hash', 'id')
_NAME_KEYS = ('name', 'title', 'channel', 'label', 'tvg-name', 'tvg_name', 'nombre', 'canal')
_LOGO_KEYS = ('image', 'logo', 'icon', 'thumbnail', 'tvg-logo', 'tvg_logo', 'poster')
_GROUP_KEYS = ('group', 'group-title', 'group_title', 'category', 'categoria', 'grupo')
_UA_KEYS = ('useragent', 'user-agent', 'user_agent', 'ua')
_REF_KEYS = ('referer', 'referrer')


class ListError(ValueError):
    """Error con un mensaje que se le puede enseñar tal cual al usuario."""


def new_channel(**fields):
    ch = {'name': '', 'url': '', 'logo': '', 'group': '', 'tvg_id': '', 'tvg_name': '',
          'chno': '', 'radio': False, 'ua': '', 'ref': '', 'props': [], 'dur': None}
    ch.update(fields)
    return ch


# --- Texto y nombres ---

def decode(data):
    """bytes de una lista -> str. Acepta gzip, BOM de UTF-8 y UTF-16, UTF-8 y, si todo
    falla, cp1252. Nunca se usa r.text, porque sin charset requests supone ISO-8859-1."""
    if not data:
        return ''
    if data[:2] == b'\x1f\x8b':
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as gz:
                data = gz.read(_GZIP_MAX + 1)
        except (OSError, EOFError, zlib.error) as e:
            raise ListError('El archivo comprimido está dañado.') from e
        if len(data) > _GZIP_MAX:
            raise ListError('La lista es demasiado grande.')
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode('utf-8', 'replace')
    if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        return data.decode('cp1252', 'replace')


def clean_name(text):
    """Nombre apto para un label de Kodi: sin BBCode, sin caracteres de control ni
    emojis (muchos skins los pintan como cuadros) y en una sola línea."""
    text = _KODI_TAG_RE.sub('', _html.unescape(str(text or '')))
    chars = []
    for c in text:
        cat = unicodedata.category(c)
        chars.append(' ' if cat[0] == 'C' or cat == 'So' else c)
    return ' '.join(''.join(chars).split())[:_NAME_MAX].strip()


def fold(text):
    """Texto para comparar sin mayúsculas ni tildes."""
    nk = unicodedata.normalize('NFKD', str(text or ''))
    return ''.join(c for c in nk if not unicodedata.combining(c)).casefold()


def content_hash(text):
    lines = [ln.strip() for ln in str(text or '').splitlines() if ln.strip()]
    return hashlib.sha1('\n'.join(lines).encode('utf-8')).hexdigest()


def safe_props(props):
    """Solo las #KODIPROP de InputStream (que es lo que necesita el DRM). La lista no es de
    fiar y no debe poder fijar cualquier propiedad del reproductor."""
    out = []
    for kp in props or ():
        if '=' not in kp:
            continue
        key, value = kp.split('=', 1)
        key, value = key.strip(), value.strip()
        if key.lower().startswith('inputstream') and value:
            out.append(f'{key}={value}')
    return out


# --- Clasificación de enlaces ---

def _host_matches(host, domains):
    return any(host == d or host.endswith('.' + d) for d in domains)


ENGINE = 'http://127.0.0.1:6878'


def engine_url(infohash):
    """Forma canónica de un canal AceStream que el motor conoce por su infohash (el catálogo
    del motor y la lista de AceServe). Un infohash no es un content_id, y pasárselo a un
    reproductor como acestream:// abriría otra cosa."""
    return f'{ENGINE}/ace/getstream?infohash={infohash.lower()}'


def _local_ace_ref(host, path, query):
    """('id' | 'infohash', valor) de una URL del motor local (getstream, manifest,
    HTTPAceProxy), o None. En un host remoto no se toca, porque es un proxy ajeno que reproduce por
    HTTP."""
    if host not in _LOCAL_HOSTS:
        return None
    m = _ACE_LOCAL_ID_RE.search(path)
    if m:
        kind = 'infohash' if '/infohash/' in path else 'id'
        return kind, m.group(1).lower()
    if _ACE_LOCAL_PATH_RE.search(path):
        qs = urllib.parse.parse_qs(query)
        for key in ('id', 'content_id', 'infohash'):
            value = (qs.get(key) or [''])[0]
            if _HEX40.fullmatch(value):
                return ('infohash' if key == 'infohash' else 'id'), value.lower()
    return None


def ace_ref(url):
    """('id', content_id) o ('infohash', infohash) de un canal AceStream ya normalizado, o
    None si no lo es."""
    u = str(url or '')
    if u.lower().startswith('acestream://'):
        return 'id', u[len('acestream://'):].lower()
    try:
        parts = urllib.parse.urlsplit(u)
        return _local_ace_ref((parts.hostname or '').lower(), parts.path.lower(), parts.query)
    except ValueError:
        return None


def classify(url):
    """(tipo, url normalizada). Los AceStream salen siempre como acestream://<40 hex>."""
    u = str(url or '').strip()
    low = u.lower()
    if not u:
        return KIND_UNSUPPORTED, u
    if low.startswith('acestream://'):
        cid = low[len('acestream://'):].split('?')[0].split('|')[0].strip('/ ')
        if _HEX40.fullmatch(cid):
            return KIND_ACE, 'acestream://' + cid
        return KIND_UNSUPPORTED, u
    if _HEX40.fullmatch(u):
        return KIND_ACE, 'acestream://' + low
    if _HEX64.fullmatch(u):
        return KIND_UNSUPPORTED, u
    if low.startswith('magnet:'):
        # Telegram y muchas webs enseñan el magnet recortado como texto del enlace.
        return (KIND_TORRENT if _MAGNET_HASH_RE.search(u) else KIND_UNSUPPORTED), u
    if low.startswith('plugin://'):
        addon = low[len('plugin://'):].split('/')[0].split('?')[0]
        if addon.startswith(('plugin.video.', 'plugin.audio.')):
            return KIND_PLUGIN, u
        return KIND_UNSUPPORTED, u
    scheme = low.split('://', 1)[0] if '://' in low else ''
    if scheme in _STREAM_SCHEMES:
        return KIND_DIRECT, u
    if scheme not in ('http', 'https'):
        return KIND_UNSUPPORTED, u
    try:
        parts = urllib.parse.urlsplit(u.split('|', 1)[0])
        host = (parts.hostname or '').lower()
    except ValueError:
        return KIND_UNSUPPORTED, u
    if not host:
        return KIND_UNSUPPORTED, u
    path = parts.path.lower()
    ref = _local_ace_ref(host, path, parts.query)
    if ref:
        return KIND_ACE, ('acestream://' + ref[1]) if ref[0] == 'id' else engine_url(ref[1])
    if path.endswith('.torrent'):
        return KIND_TORRENT, u
    if _host_matches(host, _JUNK_HOSTS) or path.endswith(('.w3u', '.json')):
        return KIND_UNSUPPORTED, u
    if _host_matches(host, _PLATFORM_HOSTS) or path.endswith(_PAGE_EXTS):
        return KIND_WEB, u
    if (path.endswith('.m3u8') or _host_matches(host, _HLS_HOSTS)
            or any(host == h and path.startswith(p) for h, p in _HLS_PATHS)):
        return KIND_HLS, u
    if path.endswith('.mpd'):
        return KIND_DASH, u
    return KIND_DIRECT, u


def via_redirector(url):
    """True si url pasa por uno de los redirectores de _HLS_HOSTS, que también llevan a canales
    con DRM."""
    try:
        host = (urllib.parse.urlsplit(str(url or '').split('|', 1)[0]).hostname or '').lower()
    except ValueError:
        return False
    return _host_matches(host, _HLS_HOSTS)


def _url_path(url):
    try:
        return urllib.parse.urlsplit(str(url).split('|', 1)[0]).path.lower()
    except ValueError:
        return ''


def not_live(ch, url=None):
    """True si la entrada no es una emisión en directo."""
    url = url or ch.get('url', '')
    if (ch.get('kind') or classify(url)[0]) == KIND_TORRENT or _url_path(url).endswith(_FILE_EXTS):
        return True
    dur = ch.get('dur')
    if dur is not None and dur > _LIVE_MAX_SECONDS:
        return True
    return bool(_NOT_LIVE_GROUP_RE.search(ch.get('group') or ''))


def _streamy(kind, url):
    """Para webs y Telegram, solo lo que es claramente una emisión y no cualquier enlace."""
    if kind in (KIND_ACE, KIND_HLS, KIND_DASH, KIND_PLUGIN, KIND_TORRENT):
        return True
    if kind != KIND_DIRECT:
        return False
    if not url.lower().startswith(('http://', 'https://')):
        return True
    return _url_path(url).endswith(_STREAM_EXTS)


# --- Formatos ---

def _split_extinf(line):
    """(atributos, nombre). La coma que separa es la primera fuera de comillas, porque un
    group-title="Cine, Estrenos" lleva comas dentro. Si falta una comilla de cierre se
    rescata con la última coma, que es donde suele empezar el nombre."""
    comma, in_quotes = -1, False
    for i, c in enumerate(line):
        if c == '"':
            in_quotes = not in_quotes
        elif c == ',' and not in_quotes:
            comma = i
            break
    if comma < 0 and in_quotes:
        comma = line.rfind(',')
    if comma < 0:
        return line, ''
    return line[:comma], line[comma + 1:].strip()


def _apply_extinf(ch, line):
    meta, name = _split_extinf(line)
    attrs = {k.lower(): v.strip() for k, v in _ATTR_RE.findall(meta)}
    m = _DUR_RE.match(meta)
    if m:
        try:
            ch['dur'] = float(m.group(1))
        except ValueError:
            pass
    ch['tvg_id'] = attrs.get('tvg-id', '')
    ch['tvg_name'] = attrs.get('tvg-name', '')
    ch['logo'] = attrs.get('tvg-logo', '') or attrs.get('logo', '')
    ch['group'] = attrs.get('group-title', '') or ch['group']
    ch['chno'] = attrs.get('tvg-chno', '') or attrs.get('channel-number', '')
    ch['radio'] = attrs.get('radio', '').lower() in ('1', 'true', 'yes')
    ch['name'] = name or ch['tvg_name']
    ch['_inf'] = True


def _apply_vlcopt(ch, option):
    low = option.lower()
    if low.startswith('http-user-agent='):
        ch['ua'] = option.split('=', 1)[1].strip()
    elif low.startswith(('http-referrer=', 'http-referer=')):
        ch['ref'] = option.split('=', 1)[1].strip()


def _first_epg(header):
    for key in ('x-tvg-url', 'url-tvg', 'tvg-url'):
        for candidate in (header.get(key) or '').split(','):
            candidate = candidate.strip()
            if candidate.lower().startswith(('http://', 'https://')):
                return candidate
    return ''


def _parse_m3u(text):
    channels, header, cur = [], {}, None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        head = line[:11].upper()
        if head.startswith('#EXTM3U'):
            header.update({k.lower(): v for k, v in _ATTR_RE.findall(line)})
        elif head.startswith('#EXTINF'):
            # Las #KODIPROP y #EXTVLCOPT pueden ir antes del #EXTINF: si hay un canal a
            # medias sin #EXTINF, se completa ese en vez de empezar otro.
            if cur is None or cur.get('_inf'):
                cur = new_channel()
            _apply_extinf(cur, line)
        elif head.startswith('#EXTGRP:'):
            cur = cur or new_channel()
            if not cur['group']:
                cur['group'] = line[8:].strip()
        elif head.startswith('#KODIPROP:'):
            cur = cur or new_channel()
            cur['props'].append(line[10:].strip())
        elif head.startswith('#EXTVLCOPT:'):
            cur = cur or new_channel()
            _apply_vlcopt(cur, line[11:].strip())
        elif not line.startswith('#'):
            ch = cur or new_channel()
            ch['url'] = line
            channels.append(ch)
            cur = None
    return channels, _first_epg(header)


def _first_str(mapping, keys):
    for key in keys:
        value = mapping.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ''


def _json_url(low):
    """Dirección de un canal en JSON: la de sus claves de url o, si no tiene, un AceStream por su id."""
    url = _first_str(low, _URL_KEYS)
    if url:
        return url
    cid = _first_str(low, _HASH_KEYS)
    return 'acestream://' + cid.lower() if _HEX40.fullmatch(cid) else ''


def _walk_json(node, group, depth, out, budget):
    budget[0] -= 1
    if budget[0] < 0 or depth > _JSON_MAX_DEPTH:
        return
    if isinstance(node, list):
        for item in node:
            _walk_json(item, group, depth + 1, out, budget)
        return
    if not isinstance(node, dict):
        return
    low = {str(k).lower(): v for k, v in node.items()}
    url = _json_url(low)
    if url:
        out.append(new_channel(
            name=_first_str(low, _NAME_KEYS), url=url, logo=_first_str(low, _LOGO_KEYS),
            group=_first_str(low, _GROUP_KEYS) or group, ua=_first_str(low, _UA_KEYS),
            ref=_first_str(low, _REF_KEYS)))
        return
    name = _first_str(low, _NAME_KEYS)
    for value in node.values():
        if isinstance(value, (list, dict)):
            _walk_json(value, name or group, depth + 1, out, budget)


def _loads(text):
    """json.loads que acepta lo que suelen traer las listas escritas a mano: caracteres de control
    dentro de las cadenas, comas de más antes de ] o } y cierres de más al final."""
    try:
        return json.loads(text, strict=False)
    except ValueError:
        text = _TRAILING_COMMA_RE.sub(r'\1\2', text)
    data, end = json.JSONDecoder(strict=False).raw_decode(text)
    # Tras el JSON solo pueden quedar cierres y comas; con otra cosa detrás es un texto que empieza
    # por algo como [1].
    if text[end:].strip(' \t\r\n]},'):
        raise ValueError('Hay algo más detrás del JSON.')
    return data


def _low(node):
    return {str(k).lower(): v for k, v in node.items()}


def _dicts(value):
    return [v for v in value if isinstance(v, dict)] if isinstance(value, list) else []


def _flag(value):
    return str(value).strip().lower() in ('true', '1', 'yes')


def _join_group(parent, group):
    """Ruta de grupos 'A / B'. Si el grupo repite el último de la ruta, no se añade."""
    if not parent or not group or parent == group or parent.endswith(f' / {group}'):
        return parent or group or ''
    return f'{parent} / {group}'


def _w3u_name(value):
    # finalize corta el grupo en el primer ';', que en M3U separa varios grupos.
    return clean_name(value).replace(';', ',')


def _links_list(url):
    """Si un canal de una W3U es en realidad otra lista, porque acaba en .w3u o .json, o lleva #.m3u o
    #.w3u al final de una dirección sin extensión de vídeo (así se marca una lista de Pastebin, por
    ejemplo)."""
    path = _url_path(url)
    return path.endswith(('.w3u', '.json')) or (str(url).lower().endswith(('#.m3u', '#.w3u'))
                                                and not path.endswith(_STREAM_EXTS + _FILE_EXTS))


def _w3u_station(st, url, name, group):
    """Un canal de una W3U. User-Agent y Referer van a sus campos; el resto de headers se pega a
    la dirección con |, que es como los lee Kodi."""
    headers = st.get('headers') if isinstance(st.get('headers'), dict) else {}
    headers = {str(k).strip(): _one_line(v) for k, v in headers.items()
               if isinstance(v, str) and v.strip() and _HEADER_NAME_RE.fullmatch(str(k).strip())}
    named = {k.lower(): v for k, v in headers.items()}
    extra = '&'.join(f'{k}={urllib.parse.quote(v, safe="")}' for k, v in headers.items()
                     if k.lower() not in ('user-agent', 'referer', 'referrer'))
    if extra and url.lower().startswith(('http://', 'https://')):
        url += ('&' if '|' in url else '|') + extra
    return new_channel(
        name=name, url=url, logo=_first_str(st, _LOGO_KEYS), group=group,
        tvg_id=_first_str(st, ('epgid', 'tvg-id', 'tvg_id')), radio=_flag(st.get('audio')),
        ua=_one_line(_first_str(st, _UA_KEYS) or named.get('user-agent', '')),
        ref=_one_line(_first_str(st, _REF_KEYS) or named.get('referer') or named.get('referrer', '')),
        page=any(_flag(st.get(k)) for k in ('ishost', 'host', 'embed')) or bool(_first_str(st, ('hostparser',))))


def _walk_w3u(node, path, depth, out, budget):
    """Canales de un nivel de una W3U y de sus grupos, en el orden de la lista. Un grupo con url, o
    un canal que apunta a otra lista, deja en su sitio un hueco {'_ref': (grupo, url)} que parse_any
    rellena si puede leerla."""
    if depth > _JSON_MAX_DEPTH:
        return
    group = ' / '.join(path)
    for st in _dicts(node.get('stations')):
        budget[0] -= 1
        if budget[0] < 0:
            return
        st = _low(st)
        url, name = _json_url(st), _first_str(st, _NAME_KEYS)
        if not url:
            continue
        if _links_list(url):
            out.append({'_ref': (_join_group(group, _w3u_name(name)), url)})
        else:
            out.append(_w3u_station(st, url, name, group))
    for grp in _dicts(node.get('groups')):
        budget[0] -= 1
        if budget[0] < 0:
            return
        grp = _low(grp)
        name = _w3u_name(_first_str(grp, _NAME_KEYS))
        sub = path + [name] if name else path
        url = _first_str(grp, ('url',))
        if url:
            out.append({'_ref': (' / '.join(sub), url)})
        _walk_w3u(grp, sub, depth + 1, out, budget)


def _parse_w3u(data):
    """(canales, datos) de una W3U de Wiseplay: su nombre y su guía, además de los canales."""
    low = _low(data)
    out = []
    _walk_w3u(low, [], 0, out, [_JSON_MAX_NODES])
    epg = _first_str(low, ('epg',))
    return out, {'title': clean_name(_first_str(low, _NAME_KEYS)),
                 'epg': epg if epg.lower().startswith(('http://', 'https://')) else ''}


# Radio Browser (radio-browser.info). Su JSON trae lo que su M3U no (el país, las etiquetas, el logo
# y las escuchas del último día), y con eso las emisoras se reparten en carpetas, con las más
# escuchadas arriba y después por género si la lista es de un solo país o por país si mezcla varios.
# Las etiquetas las pone quien da de alta la emisora y muchas no traen, así que el nombre también
# cuenta, y lo que no se deja clasificar va a "Otras".
_RB_TOP = 50
_RB_TOP_GROUP = 'Más escuchadas'
_RB_OTHER_GENRE = 'Otras'
_RB_OTHER_COUNTRY = 'Otros países'
# Un país con menos emisoras va a _RB_OTHER_COUNTRY. En las de habla hispana de todo el mundo hay
# muchas sueltas de países que no lo son, mal etiquetadas en origen.
_RB_MIN_COUNTRY = 5
# (carpeta, etiquetas, nombre). A igualdad de puntos gana la que va antes.
_RB_GENRES = tuple((label, re.compile(tags, re.I), re.compile(name, re.I)) for label, tags, name in (
    ('Deportes', r'\bsports?\b|\bdeportes?\b|f[uú]tbol|football|soccer',
     r'\bmarca\b|deport|\bsports?\b|f[uú]tbol|estadio'),
    ('Noticias y tertulias',
     r'\bnews\b|noticias|\btalk\b|hablada|pol[ií]tic|informaci[oó]n|\binformation\b|actualidad|'
     r'magazine|opini[oó]n|tertulia|debate|entrevista|spoken word|public radio',
     r'\bcope\b|\bser\b|onda ?cero|\brne\b|radio nacional|\bes ?radio\b|\brtve\b|canal sur radio|'
     r'catalunya (?:r[aà]dio|informaci)|radio euskadi|radio galega|arag[oó]n radio|onda regional|'
     r'onda madrid|canarias radio|[aà] punt\b|\brac ?1\b|noticias'),
    ('Religiosa',
     r'christian|catholic|cat[oó]lic|religi|gospel|evang[eé]l|cristian|bibl|islam|quran|cor[aá]n|'
     r'iglesia|worship',
     r'radio mar[ií]a|\bmater\b|cristian|evang[eé]l|cat[oó]lic|iglesia|gospel|biblia'),
    ('Música clásica', r'classical|cl[aá]sica\b|\b[oó]pera\b|baroque|barroc|symphon|sinf[oó]n',
     r'cl[aá]sica\b|classical|\b[oó]pera\b|sinf[oó]n'),
    ('Jazz, soul y blues', r'jazz|\bsoul\b|blues|\bfunk|r&b|\brnb\b|swing|motown',
     r'jazz|\bsoul\b|blues|\bfunk'),
    ('Flamenco y copla', r'flamenco|\bcopla|\brumba|sevillanas|canci[oó]n espa[nñ]ola|pasodoble',
     r'flamenco|radiol[eé]|\bcopla|\brumba'),
    ('Latina y urbana',
     r'\blatin|reggaet|\bsalsa\b|\burban|bachata|cumbia|merengue|tropical|ranchera|'
     r'regional mexicana|norte[nñ]|vallenato|mariachi|hip ?hop|\brap\b|\btrap\b',
     r'\blatin|reggaet|\bsalsa\b|\burban|tropical|ranchera|mariachi|hip ?hop'),
    ('Dance y electrónica',
     r'\bdance\b|electr[oó]nic|\belectro\b|\bhouse\b|\bedm\b|techno|trance|\bdisco\b|\bclub|\bdj\b|'
     r'drum and bass|hardstyle|\bdeep\b',
     r'\bdance\b|\bhouse\b|techno|electr[oó]|\bdj\b|\bclub|\bdeep\b|loca ?fm'),
    ('Rock', r'\brock|metal|\bheavy\b|\bindie|alternativ|\bpunk|grunge', r'\brock|metal|\bindie|\bpunk'),
    ('Chill y relax', r'chill|lounge|ambient|relax|new age|downtempo|meditaci|meditation|balearic',
     r'chill|lounge|relax|caf[eé] del mar|ambient|sonica'),
    ('Éxitos de siempre',
     r"\b[6-9]0'?s\b|\b(?:20)?00'?s\b|oldies|classic hits|remember|retro|a[nñ]os [6-9]0|golden|nostalgi",
     r"\b[6-9]0'?s\b|remember|oldies|retro|cl[aá]sicos|a[nñ]os [6-9]0|nostalgi"),
    ('Pop y éxitos',
     r'\bpop\b|\bhits?\b|top ?40|\bchr\b|adult contemporary|[eé]xitos|variety|variada|\bcharts?\b|'
     r'mainstream|rom[aá]ntic|balada|love ?songs',
     r'\bhits?\b|los ?40|cadena 100|\bdial\b|europa fm|\bkiss\b|m[aá]xima|hit ?fm|megastar|flaix|\bpop\b'),
    ('Infantil', r'\bkids?\b|children|infantil|ni[nñ]os', r'\bkids?\b|infantil|ni[nñ]os'),
    ('Cultura', r'cultur|educa|\barts?\b|literat|science|ciencia|histor|universi|\blearn',
     r'cultura|universi|educa'),
    ('Local y comunitaria', r'\blocal\b|community|comunitari|regional|municipal|\blibre\b',
     r'municipal|comunitari|\blocal\b|radio libre'),
))


def _is_radio_browser(data):
    return (isinstance(data, list) and bool(data) and isinstance(data[0], dict)
            and 'stationuuid' in data[0] and ('url' in data[0] or 'url_resolved' in data[0]))


def radio_genre(tags, name):
    """Carpeta de una emisora de Radio Browser. Cada etiqueta (van separadas por comas) que encaja
    con una carpeta le suma un punto, y el nombre, dos."""
    tags = [t.strip() for t in str(tags or '').lower().split(',') if t.strip()]
    best, best_score = _RB_OTHER_GENRE, 0
    for label, tag_re, name_re in _RB_GENRES:
        score = sum(1 for t in tags if tag_re.search(t)) + (2 if name_re.search(name or '') else 0)
        if score > best_score:
            best, best_score = label, score
    return best


def _rb_clicks(station):
    try:
        return int(station.get('clickcount') or 0)
    except (TypeError, ValueError):
        return 0


def _radio_browser(data):
    """Canales de un JSON de Radio Browser, con las carpetas de _RB_GENRES o por país."""
    ranked = sorted((s for s in data if isinstance(s, dict)), key=_rb_clicks, reverse=True)
    by_genre = len({str(s.get('countrycode') or '').upper() for s in ranked} - {''}) <= 1
    other = _RB_OTHER_GENRE if by_genre else _RB_OTHER_COUNTRY
    rows = []
    for s in ranked:
        raw_name = str(s.get('name') or '')
        # Algunos nombres llevan guiones bajos o puntos delante ("__80 EXITOS").
        name = raw_name.strip().lstrip('_.-· ').strip() or raw_name
        if by_genre:
            group = radio_genre(s.get('tags'), name)
        else:
            code = str(s.get('countrycode') or '').strip().lower()
            group = _ENGINE_COUNTRIES.get(code) or clean_name(s.get('country')) or other
        logo = str(s.get('favicon') or '').strip()
        rows.append(new_channel(
            name=name, url=_first_str(_low(s), ('url', 'url_resolved')), group=group, radio=True,
            logo=logo if logo.lower().startswith(('http://', 'https://')) else ''))
    if not by_genre:
        sizes = Counter(ch['group'] for ch in rows)
        for ch in rows:
            if sizes[ch['group']] < _RB_MIN_COUNTRY:
                ch['group'] = other
    # Cada emisora va a una sola carpeta, para que no salga repetida en Todos, en las búsquedas ni en
    # la TV de Kodi. En una lista pequeña no hace falta la de las más escuchadas, y una emisora sin
    # escuchas no entra aunque falten para llenarla.
    if len(rows) > 2 * _RB_TOP:
        for ch, station in zip(rows[:_RB_TOP], ranked):
            if _rb_clicks(station) > 0:
                ch['group'] = _RB_TOP_GROUP
    # Las carpetas salen en el orden de su emisora más escuchada, y la de lo que no se clasifica, al final.
    rank = {_RB_TOP_GROUP: 0, other: 2}
    return sorted(rows, key=lambda ch: rank.get(ch['group'], 1))


def _json_channels(data):
    """(canales, datos) de un JSON ya leído. Una W3U (un objeto con groups o stations) va por su
    lector; cualquier otro JSON, o una W3U en la que no se encuentra nada, por _walk_json."""
    info = {}
    if _is_radio_browser(data):
        return _radio_browser(data), info
    if isinstance(data, dict) and any(str(k).lower() in ('groups', 'stations') for k in data):
        raw, info = _parse_w3u(data)
        if raw:
            return raw, info
        # La url de la raíz es la de la propia lista. _walk_json la tomaría por un canal y no bajaría
        # a los grupos.
        data = {k: v for k, v in data.items() if str(k).lower() not in _URL_KEYS + _HASH_KEYS}
    out = []
    _walk_json(data, '', 0, out, [_JSON_MAX_NODES])
    return out, info


def _parse_json(text):
    """(canales, datos) de una W3U o de un JSON de canales, o None si no es JSON."""
    try:
        data = _loads(text.lstrip('\ufeff \t\r\n'))
    except ValueError:
        return None
    except RecursionError:
        # '[[[[...' con miles de niveles: el decodificador de json no tiene tope propio.
        return [], {}
    return _json_channels(data)


def _strip_trailing(link):
    while link and link[-1] in _TRAILING_PUNCT:
        link = link[:-1]
    return link


def _name_from(text):
    return clean_name(text.strip(_NAME_SEPARATORS)).strip(_NAME_SEPARATORS)


def _parse_text(text):
    """Una línea con enlace es un canal. El nombre sale del resto de la línea
    ('Mi canal acestream://...', 'nombre,url') o de la última línea de texto sin enlace (el
    formato de Telegram y los pastebin). Los nombres repetidos los numera finalize()."""
    out = []
    last_name = ''
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        links = [_strip_trailing(m.group(0)) for m in _TEXT_LINK_RE.finditer(line)]
        if not links:
            last_name = _name_from(line) if len(line) <= _NAME_LINE_MAX else ''
            continue
        name = _name_from(_TEXT_LINK_RE.sub(' ', line)) or last_name
        out.extend(new_channel(name=name, url=link) for link in links)
    return out


def _split_scripts(html):
    """(HTML sin <script>, <style> ni <noscript>, [código de cada <script>]). El cierre se
    busca con find y no con una regex, por lo dicho arriba. Uno sin cerrar llega al final."""
    low = html.lower()
    visible, scripts, pos = [], [], 0
    while True:
        m = _HIDDEN_START_RE.search(html, pos)
        if not m:
            visible.append(html[pos:])
            return ' '.join(visible), scripts
        visible.append(html[pos:m.start()])
        tag = m.group(1).lower()
        end = low.find('</' + tag, m.end())
        if end < 0:
            end = len(html)
        if tag == 'script':
            scripts.append(html[m.end():end])
        close = low.find('>', end)
        pos = len(html) if close < 0 else close + 1


def _tag_links(tag):
    """Enlaces de emisión en los atributos de una etiqueta. Además del href, las webs de
    canales los esconden en onclick="abrir('acestream://...')", data-url o en el texto que
    copia un botón. Un hash suelto solo cuenta si es el valor entero, porque dentro de otro
    valor puede ser la versión de un archivo (estilo.css?v=<40 hex>)."""
    if '://' not in tag and 'magnet:' not in tag.lower() and not _HEX40.search(tag):
        return []
    links = []
    for m in _ATTR_VALUE_RE.finditer(tag):
        value = _html.unescape(m.group(1) if m.group(1) is not None else m.group(2)).strip()
        if _HEX40.fullmatch(value):
            links.append(value)
            continue
        for found in _TEXT_LINK_RE.finditer(value):
            link = _strip_trailing(found.group(0))
            if not _HEX40.fullmatch(link) and _streamy(*classify(link)):
                links.append(link)
    return links


def _generic_label(text):
    return all(w in _GENERIC_WORDS or w.isdigit() for w in re.findall(r'\w+', fold(text)))


def html_to_text(html):
    """Texto visible de un HTML, con los enlaces de cada etiqueta escritos donde está la
    etiqueta para que el parser de texto vea el nombre y el enlace en la misma línea."""
    html = _split_scripts(html)[0]

    def _anchor(m):
        inner = _TAG_RE.sub(' ', m.group(3))
        links = _tag_links(m.group(2))
        if links and _generic_label(_html.unescape(inner)):
            inner = ''
        return f' {inner} {" ".join(links)} '

    def _tag(m):
        return f' {" ".join(_tag_links(m.group(0)))} '

    html = _ANCHOR_RE.sub(_anchor, html)
    html = _BLOCK_RE.sub(lambda m: '\n' + _tag(m), html)
    return _html.unescape(_TAG_RE.sub(_tag, html))


def _script_json(scripts):
    """Canales en JSON dentro de los <script> de una página (un linksData = {...}, por
    ejemplo). Los objetos de JavaScript que no son JSON se saltan."""
    decoder = json.JSONDecoder()
    out, tries = [], 0
    for script in scripts:
        for m in _JS_JSON_RE.finditer(script):
            tries += 1
            if tries > _JS_JSON_TRIES:
                return out
            try:
                data = decoder.raw_decode(script, m.end())[0]
            except (ValueError, RecursionError):
                continue
            out.extend(_json_channels(data)[0])
    return out


def _parse_web(html, base_url):
    """Enlaces del texto visible, del JSON de los scripts y de html_scanner (reproductores,
    iframes...). html_scanner no se usa para los nombres: los suyos salen del nombre del
    archivo ('index') o del código de alrededor del enlace. En su lugar va el título de la
    página, que en una web de un solo canal es justo su nombre."""
    channels = _parse_text(html_to_text(html)) + _script_json(_split_scripts(html)[1])
    m = _TITLE_RE.search(html)
    page = _name_from(_TAG_RE.sub(' ', m.group(1))) if m else ''
    for item in html_scanner.scan_page(base_url or 'http://localhost/', html_content=html,
                                       with_sizes=False):
        # Algunos los devuelve tal cual están en el HTML, con &amp;.
        url = _html.unescape(item.get('url') or '')
        if url:
            channels.append(new_channel(name=page, url=url))
    return channels


def _parse_telegram(html):
    """Cada mensaje por separado, para que el nombre de un post no se pegue al siguiente."""
    channels = []
    for block in _TG_MESSAGE_RE.findall(html):
        channels.extend(_parse_text(html_to_text(block)))
    return channels


def _looks_html(sample):
    low = sample[:4096].lower()
    return any(tag in low for tag in ('<!doctype html', '<html', '<body', '<head', '<div', '<a '))


def _join_url(base, link):
    try:
        return urllib.parse.urljoin(base, link)
    except ValueError:
        return link


def _fallback_name(kind, url):
    if kind == KIND_ACE:
        ref = ace_ref(url)
        return f'AceStream {ref[1][:8]}' if ref else 'AceStream'
    if url.lower().startswith('magnet:'):
        dn = clean_name((urllib.parse.parse_qs(url.partition('?')[2]).get('dn') or [''])[0])
        if dn:
            return dn
    try:
        host = urllib.parse.urlsplit(url.split('|', 1)[0]).hostname or ''
    except ValueError:
        host = ''
    return host or 'Canal'


def finalize(raw, fmt, epg='', base_url=''):
    """Clasifica, filtra y limpia canales ya extraídos (de parse_any o de una API)."""
    strict = fmt in ('web', 'telegram')
    keep_repeats = fmt in ('m3u', 'json')
    channels, index = [], {}
    unsupported = 0
    for ch in raw:
        url = str(ch.get('url') or '').strip()
        if not url:
            continue
        if base_url and '://' not in url and not _HEX40.fullmatch(url):
            url = _join_url(base_url, url)
        kind, norm = classify(url)
        # Una página que Wiseplay abre con su extractor (isHost, embed) no es un stream para Kodi.
        if (kind == KIND_UNSUPPORTED or (strict and not _streamy(kind, norm))
                or (ch.get('page') and kind == KIND_DIRECT)):
            unsupported += 1
            continue
        name = clean_name(ch.get('name')) or clean_name(ch.get('tvg_name'))
        key = (norm, ch.get('group'), name) if keep_repeats else norm
        if key in index:
            known = index[key]
            if name and not known['_named']:
                known['name'], known['_named'] = name, True
            continue
        ch = dict(ch, url=norm, kind=kind, props=safe_props(ch.get('props')),
                  group=clean_name(str(ch.get('group') or '').split(';')[0]),
                  name=name or _fallback_name(kind, norm), _named=bool(name))
        ch.pop('_inf', None)
        ch.pop('page', None)
        index[key] = ch
        channels.append(ch)
    # En texto libre el mismo nombre suele ser el mismo canal por otro enlace. En M3U y JSON
    # el nombre es del proveedor y no se toca, porque la guía lo empareja por él.
    numbered = fmt in ('text', 'web', 'telegram')
    seen = Counter()
    for ch in channels:
        ch.pop('_named', None)
        if numbered:
            key = fold(ch['name'])
            seen[key] += 1
            if seen[key] > 1:
                ch['name'] = f"{ch['name']} · opción {seen[key]}"
    return {'channels': channels, 'epg': epg, 'fmt': fmt, 'unsupported': unsupported}


def _extract(text, base_url='', hint=''):
    """(formato, canales en bruto, guía, datos de la W3U) de un texto, sin filtrar."""
    sample = text[:65536].lstrip('\ufeff \t\r\n')
    if hint == 'telegram' or 'tgme_widget_message' in text[:200000]:
        return 'telegram', _parse_telegram(text), '', {}
    if sample[:7].upper() == '#EXTM3U' or '#EXTINF' in sample.upper():
        raw, epg = _parse_m3u(text)
        return 'm3u', raw, epg, {}
    found = _parse_json(text) if sample[:1] in ('{', '[') else None
    if found is not None:
        return 'json', found[0], found[1].get('epg', ''), found[1]
    if _looks_html(sample):
        return 'web', _parse_web(text, base_url), '', {}
    return 'text', _parse_text(text), '', {}


def _is_lan(host):
    import ipaddress  # solo hace falta al leer listas enlazadas
    # 'localhost.' con el punto final del DNS también llega a este aparato.
    host = host.rstrip('.')
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return '.' not in host or host.endswith(_LAN_SUFFIXES) or bool(_NUMERIC_HOST_RE.fullmatch(host))
    # Con ceros delante (010.0.0.1) hay versiones de Python que la leen en decimal y el sistema en octal.
    return ((ip.version == 4 and str(ip) != host) or ip.is_private or ip.is_loopback or ip.is_link_local
            or ip.is_unspecified)


def is_lan_url(url):
    """Si la dirección puede ser de la red de casa: una IP privada o local, esté escrita como esté, o
    un nombre sin dominio."""
    try:
        return _is_lan((urllib.parse.urlsplit(url).hostname or '').lower())
    except ValueError:
        return False


def _lan_ok(base_url):
    """True si la lista está en la red de casa o es un archivo o un texto. Solo entonces se leen las
    listas enlazadas que estén en esa red."""
    try:
        scheme = urllib.parse.urlsplit(base_url).scheme.lower()
    except ValueError:
        return False
    return scheme not in ('http', 'https') or is_lan_url(base_url)


def _read_sublist(url, state):
    """Canales en bruto de una lista enlazada, con sus direcciones completas, o None si no se puede
    leer o no es una lista (una página de error, por ejemplo)."""
    try:
        parts = urllib.parse.urlsplit(url)
        host = (parts.hostname or '').lower()
    except ValueError:
        return None
    if parts.scheme.lower() not in ('http', 'https') or not host or (_is_lan(host) and not state['lan']):
        return None
    total = min(max(state['known'], state['count']), W3U_SUBLISTS_MAX)
    try:
        text = state['fetch'](url, state['count'], total, state['lan'])
    except ListError:
        return None
    fmt, raw, epg, _info = _extract(text, url)
    if fmt in ('web', 'telegram'):
        return None
    state['epg'] = state['epg'] or epg
    state['known'] += sum(1 for ch in raw if '_ref' in ch)
    for ch in raw:
        link = str(ch.get('url') or '')
        if link and '://' not in link and not _HEX40.fullmatch(link):
            ch['url'] = _join_url(url, link)
    return raw


def _sublist(group, url, state, depth, ancestors):
    """Canales de una lista enlazada con su grupo delante, o [] si no se lee (fallo, ciclo o tope).
    Una lista enlazada desde dos sitios se descarga una vez y sale en los dos."""
    if depth > _W3U_DEPTH or url in ancestors:
        return []
    if url not in state['lists']:
        if state['count'] >= W3U_SUBLISTS_MAX:
            return []
        state['count'] += 1
        state['lists'][url] = _read_sublist(url, state)
        if state['lists'][url] is None:
            state['failed'] += 1
    raw = state['lists'][url]
    if raw is None:
        return []
    placed = [{'_ref': (_join_group(group, ch['_ref'][0]), ch['_ref'][1])} if '_ref' in ch
              else dict(ch, group=_join_group(group, ch.get('group'))) for ch in raw]
    return _resolve(placed, url, state, depth + 1, ancestors | {url})


def _resolve(raw, base_url, state, depth, ancestors):
    """raw con cada hueco de lista enlazada cambiado por sus canales, en el mismo sitio."""
    out = []
    for ch in raw:
        if '_ref' in ch:
            group, link = ch['_ref']
            out.extend(_sublist(group, raw_url(_join_url(base_url, link)), state, depth, ancestors))
        else:
            out.append(ch)
    return out


def parse_any(text, base_url='', hint='', fetch=None):
    """Detecta el formato por el contenido, no por la extensión.

    Devuelve {'channels', 'epg', 'fmt', 'unsupported'}. 'unsupported' cuenta los enlaces que no
    se pueden reproducir
    (esquemas locales, addons que no son de vídeo, charla de redes sociales...). Una W3U con
    nombre añade 'title'.

    Las listas que enlaza una W3U se leen con fetch(url, n, total, lan_ok), que devuelve su texto
    o lanza ListError para saltarla; con lan_ok falso no debe seguir una redirección a la red de
    casa. 'sublists' y 'sublists_failed' cuentan las intentadas y las que fallaron. Si la W3U no
    trae guía, vale la de la primera lista enlazada que la traiga. Sin fetch no se toca la red, y
    'pending_refs' dice cuántas enlaza."""
    text = str(text or '')
    fmt, raw, epg, info = _extract(text, base_url, hint)
    refs = sum(1 for ch in raw if '_ref' in ch) if fmt == 'json' else 0
    state = None
    if refs and fetch is not None:
        state = {'fetch': fetch, 'lists': {}, 'count': 0, 'failed': 0, 'known': refs,
                 'lan': _lan_ok(base_url), 'epg': ''}
        raw = _resolve(raw, base_url, state, 1, frozenset([base_url]))
        epg = epg or state['epg']
    parsed = finalize(raw, fmt, epg, base_url)
    if info.get('title'):
        parsed['title'] = info['title']
    if state is not None:
        parsed.update(sublists=state['count'], sublists_failed=state['failed'])
    elif refs:
        parsed['pending_refs'] = refs
    return parsed


def summary(channels):
    """(grupos distintos, canales AceStream)."""
    groups = {ch['group'] for ch in channels if ch.get('group')}
    return len(groups), sum(1 for ch in channels if ch.get('kind') == KIND_ACE)


# --- Serialización ---

def _attr(value):
    """Valor de atributo en una sola línea y sin comillas dobles, que cortarían el #EXTINF."""
    return ' '.join(str(value or '').replace('"', "'").split())


def _one_line(value):
    return str(value or '').replace('\r', ' ').replace('\n', ' ').strip()


def _extinf(ch, group, always_group):
    attrs = []
    for key, value in (('tvg-id', ch.get('tvg_id')), ('tvg-name', ch.get('tvg_name')),
                       ('tvg-logo', ch.get('logo')), ('tvg-chno', ch.get('chno'))):
        if value:
            attrs.append(f'{key}="{_attr(value)}"')
    if group or always_group:
        attrs.append(f'group-title="{_attr(group)}"')
    if ch.get('radio'):
        attrs.append('radio="true"')
    extra = (' ' + ' '.join(attrs)) if attrs else ''
    # La duración solo cuenta para not_live, así que la de un directo no se copia.
    dur = ch.get('dur')
    secs = int(dur) if dur is not None and dur > _LIVE_MAX_SECONDS else -1
    return f'#EXTINF:{secs}{extra},{_attr(ch.get("name"))}'


def _options(ch):
    lines = []
    if ch.get('ua'):
        lines.append('#EXTVLCOPT:http-user-agent=' + _one_line(ch['ua']))
    if ch.get('ref'):
        lines.append('#EXTVLCOPT:http-referrer=' + _one_line(ch['ref']))
    lines.extend('#KODIPROP:' + _one_line(kp) for kp in ch.get('props') or ())
    return lines


def to_m3u(channels, epg=''):
    """M3U de canales ya filtrados. Es el formato de las copias en caché, y releerlo con
    parse_any devuelve los mismos canales."""
    lines = ['#EXTM3U' + (f' url-tvg="{_attr(epg)}"' if epg else '')]
    for ch in channels:
        lines.append(_extinf(ch, ch.get('group'), False))
        lines.extend(_options(ch))
        lines.append(_one_line(ch['url']))
    return '\n'.join(lines) + '\n'


def build_pvr_m3u(sections, ace_url, addon_url=None):
    """M3U para PVR IPTV Simple a partir de [(nombre de lista, canales)].

    ace_url(tipo, valor, nombre) da la dirección de cada AceStream, que IPTV Simple no sabe
    abrir; tipo es 'id' o 'infohash' (ver ace_ref). addon_url(canal), si se da, sirve por el addon
    los canales de los redirectores (via_redirector), que antes de abrirse miran si llevan DRM,
    porque uno con DRM puede cerrar Kodi. Las páginas de plataformas (KIND_WEB) no
    van, porque solo las resuelve el addon al reproducir y el PVR necesita una dirección que se
    abra sola. Lo que aparta not_live tampoco va, y no cuenta como omitido. group-title va
    siempre, aunque esté vacío, porque sin comillas en la línea IPTV Simple corta el nombre en su
    última coma. Devuelve (texto, canales escritos, canales omitidos)."""
    lines, written, skipped = ['#EXTM3U'], 0, 0
    for list_name, channels in sections:
        for ch in channels:
            if not_live(ch):
                continue
            kind = ch.get('kind') or classify(ch.get('url'))[0]
            ref = ace_ref(ch['url']) if kind == KIND_ACE else None
            if kind == KIND_WEB or (kind == KIND_ACE and not ref):
                skipped += 1
                continue
            # Por el addon, las cabeceras y las propiedades van en su dirección y no en la lista.
            by_addon = not ref and addon_url is not None and via_redirector(ch['url'])
            if ref:
                url = ace_url(ref[0], ref[1], ch.get('name') or '')
            elif by_addon:
                url = addon_url(ch)
            else:
                url = ch['url']
            group = f"{list_name} · {ch['group']}" if ch.get('group') else list_name
            lines.append(_extinf(ch, group, True))
            if not by_addon:
                lines.extend(_options(ch))
            lines.append(_one_line(url))
            written += 1
    return '\n'.join(lines) + '\n', written, skipped


# --- Fuentes ---

def raw_url(url):
    """Enlace de una página de pegado o de un repositorio -> su contenido en crudo."""
    u = str(url or '').strip()
    try:
        parts = urllib.parse.urlsplit(u)
    except ValueError:
        return u
    host = (parts.hostname or '').lower()
    segs = [s for s in parts.path.split('/') if s]
    if host in ('pastebin.com', 'www.pastebin.com') and len(segs) == 1:
        return f'https://pastebin.com/raw/{segs[0]}'
    if host == 'paste.ee' and len(segs) == 2 and segs[0] == 'p':
        return f'https://paste.ee/r/{segs[1]}'
    if host in ('rentry.co', 'rentry.org') and len(segs) == 1:
        return f'https://{host}/{segs[0]}/raw'
    if host == 'github.com' and len(segs) >= 5 and segs[2] == 'blob':
        return 'https://raw.githubusercontent.com/' + '/'.join(segs[:2] + segs[3:])
    if host == 'gist.github.com' and len(segs) == 2:
        return f'https://gist.githubusercontent.com/{segs[0]}/{segs[1]}/raw'
    if host.endswith('dropbox.com') and 'dl=0' in parts.query:
        return urllib.parse.urlunsplit(parts._replace(query=parts.query.replace('dl=0', 'dl=1')))
    return u


def telegram_channel(text):
    """Nombre de un canal público de Telegram (@canal, t.me/canal, t.me/s/canal...) o ''."""
    raw = re.sub(r'^https?://', '', str(text or '').strip(), flags=re.I)
    raw = re.sub(r'^(?:www\.)?(?:t\.me|telegram\.me)/(?:s/)?', '', raw, flags=re.I)
    raw = raw.lstrip('@').split('/')[0].split('?')[0].strip()
    return raw if re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{4,31}', raw) else ''


def telegram_oldest_id(html):
    ids = [int(i) for i in _TG_POST_ID_RE.findall(html)]
    return min(ids) if ids else None


def normalize_server(text):
    """Servidor Xtream tal como lo escribe la gente -> http(s)://host[:puerto][/ruta]."""
    s = str(text or '').strip()
    if s and '://' not in s:
        s = 'http://' + s
    s = s.split('?', 1)[0].rstrip('/')
    for end in ('/player_api.php', '/get.php', '/xmltv.php', '/panel_api.php'):
        if s.lower().endswith(end):
            s = s[:-len(end)]
    return s.rstrip('/')


def parse_xtream_url(url):
    """(servidor, usuario, contraseña) de una URL get.php/player_api.php/xmltv.php, o None."""
    try:
        parts = urllib.parse.urlsplit(str(url or '').strip())
    except ValueError:
        return None
    if parts.scheme.lower() not in ('http', 'https') or not parts.netloc:
        return None
    low = parts.path.lower()
    for end in ('/get.php', '/player_api.php', '/xmltv.php', '/panel_api.php'):
        if low.endswith(end):
            qs = urllib.parse.parse_qs(parts.query)
            user = (qs.get('username') or [''])[0]
            password = (qs.get('password') or [''])[0]
            if user and password:
                prefix = parts.path[:len(parts.path) - len(end)]
                return f'{parts.scheme}://{parts.netloc}{prefix}', user, password
    return None


# Catálogo del motor AceStream (/search) y lista de AceServe (/pl.m3u), con los mismos datos
# que Canales de EKHorus (lib/catalog.py): categoría, país, idioma, estado del enlace y
# enlaces de repuesto.
_ENGINE_CATEGORIES = {
    'sport': 'Deportes', 'tv': 'Televisión', 'movies': 'Cine', 'music': 'Música',
    'news': 'Noticias', 'kids': 'Infantil', 'series': 'Series', 'regional': 'Regional',
    'documentaries': 'Documentales', 'educational': 'Educativos',
    'entertaining': 'Entretenimiento', 'informational': 'Informativos',
    'religion': 'Religión', 'fashion': 'Moda', 'ethnic': 'Étnicos', 'teleshop': 'Teletienda',
    'amateur': 'Aficionados', 'webcam': 'Webcams', 'cyber_games': 'Videojuegos', 'other': 'Otras',
}
_ENGINE_COUNTRIES = {
    'es': 'España', 'int': 'Internacional', 'us': 'Estados Unidos', 'gb': 'Reino Unido',
    'ru': 'Rusia', 'de': 'Alemania', 'pl': 'Polonia', 'tr': 'Turquía', 'fr': 'Francia',
    'it': 'Italia', 'pt': 'Portugal', 'nl': 'Países Bajos', 'be': 'Bélgica', 'ua': 'Ucrania',
    'ro': 'Rumanía', 'gr': 'Grecia', 'ar': 'Argentina', 'mx': 'México', 'cl': 'Chile',
    'co': 'Colombia', 'pe': 'Perú', 'bo': 'Bolivia', 'cr': 'Costa Rica',
    'do': 'República Dominicana', 've': 'Venezuela', 'br': 'Brasil', 'ca': 'Canadá',
    'in': 'India', 'cn': 'China', 'jp': 'Japón', 'il': 'Israel', 'cz': 'Chequia',
    'sk': 'Eslovaquia', 'hu': 'Hungría', 'bg': 'Bulgaria', 'rs': 'Serbia', 'hr': 'Croacia',
    'se': 'Suecia', 'no': 'Noruega', 'dk': 'Dinamarca', 'fi': 'Finlandia', 'at': 'Austria',
    'ch': 'Suiza', 'ie': 'Irlanda', 'kz': 'Kazajistán', 'az': 'Azerbaiyán', 'ge': 'Georgia',
    'am': 'Armenia', 'by': 'Bielorrusia', 'ee': 'Estonia', 'lv': 'Letonia', 'lt': 'Lituania',
    'si': 'Eslovenia', 'uy': 'Uruguay', 'py': 'Paraguay', 'ec': 'Ecuador', 'gt': 'Guatemala',
    'pa': 'Panamá', 'hn': 'Honduras', 'sv': 'El Salvador', 'ni': 'Nicaragua', 'cu': 'Cuba',
    'pr': 'Puerto Rico', 'gq': 'Guinea Ecuatorial', 'ad': 'Andorra', 'au': 'Australia',
    'cw': 'Curazao',
}
_ENGINE_LANGUAGES = {
    'spa': 'Español', 'eng': 'Inglés', 'rus': 'Ruso', 'deu': 'Alemán', 'fra': 'Francés',
    'ita': 'Italiano', 'por': 'Portugués', 'pol': 'Polaco', 'tur': 'Turco', 'cat': 'Catalán',
    'eus': 'Euskera', 'glg': 'Gallego', 'nld': 'Neerlandés', 'ukr': 'Ucraniano',
    'ron': 'Rumano', 'ell': 'Griego', 'ara': 'Árabe', 'hin': 'Hindi', 'zho': 'Chino',
    'jpn': 'Japonés', 'ces': 'Checo', 'slk': 'Eslovaco', 'bul': 'Búlgaro', 'srp': 'Serbio',
    'hrv': 'Croata', 'hun': 'Húngaro', 'swe': 'Sueco', 'nor': 'Noruego', 'dan': 'Danés',
    'fin': 'Finés', 'kor': 'Coreano', 'vie': 'Vietnamita', 'tha': 'Tailandés',
    'ind': 'Indonesio', 'urd': 'Urdu', 'fas': 'Persa', 'heb': 'Hebreo', 'hye': 'Armenio',
    'aze': 'Azerí', 'kaz': 'Kazajo', 'tuk': 'Turcomano', 'uzb': 'Uzbeko', 'kat': 'Georgiano',
    'lav': 'Letón', 'lit': 'Lituano', 'est': 'Estonio', 'slv': 'Esloveno', 'mkd': 'Macedonio',
}
# El catálogo usa a la vez los dos juegos de códigos de idioma (deu y ger, nld y nl) y escribe
# Ucrania y el Reino Unido de varias formas. Sin esto salen filas repetidas.
_ENGINE_LANG_ALIAS = {'ger': 'deu', 'fre': 'fra', 'dut': 'nld', 'nl': 'nld', 'gre': 'ell',
                      'rum': 'ron', 'chi': 'zho', 'cze': 'ces', 'ice': 'isl', 'per': 'fas'}
_ENGINE_COUNTRY_ALIAS = {'ukr': 'ua', 'uk': 'gb', 'en': 'gb'}
# País de cada idioma, el de la tabla de banderas de EKHorus: da la bandera del idioma y pone
# primero, en "Por país", el del idioma de Kodi. Los idiomas que no son de un solo país (árabe,
# catalán, kurdo...) no están, porque darles uno sería decidir por el usuario.
_ENGINE_LANG_COUNTRY = {
    'rus': 'ru', 'deu': 'de', 'pol': 'pl', 'eng': 'gb', 'spa': 'es', 'ita': 'it', 'nld': 'nl',
    'fra': 'fr', 'zho': 'cn', 'cmn': 'cn', 'ces': 'cz', 'ukr': 'ua', 'ell': 'gr', 'por': 'pt',
    'tur': 'tr', 'hin': 'in', 'ind': 'id', 'vie': 'vn', 'tha': 'th', 'urd': 'pk', 'hye': 'am',
    'bul': 'bg', 'fin': 'fi', 'kat': 'ge', 'hun': 'hu', 'jpn': 'jp', 'swe': 'se', 'ron': 'ro',
    'dan': 'dk', 'nor': 'no', 'isl': 'is', 'tam': 'in',
}
_ENGINE_AVAILABLE = 2
# Cada enlace que falla cuesta la espera entera del reproductor, así que más de tres de
# repuesto es una espera que nadie aguanta.
_ENGINE_SPARES = 3
# Una categoría con menos canales es un resto, como la "Chileiptv" que trae el catálogo.
_ENGINE_MIN_CATEGORY = 5
# Clave de los canales que no dicen su categoría, país o idioma. Empieza por guion bajo para
# no chocar con ninguna etiqueta del motor.
ENGINE_NO_DATA = '_sin'
ENGINE_FACETS = (('cats', 'Por categoría'), ('countries', 'Por país'), ('langs', 'Por idioma'),
                 ('pl', 'Por grupos'))
_ENGINE_HASH_RE = re.compile(r'[?&](infohash|id|content_id)=([0-9a-fA-F]{40})(?![0-9a-fA-F])')
# Los logos del catálogo vienen de aquí por http y el servidor responde con un 301 a
# https, así que pedirlos ya en https ahorra ese salto.
_ENGINE_LOGO_HOST = 'http://c1.torrentstream.info/'


def _engine_key(text):
    return re.sub(r'[\s\-]+', '_', str(text or '').strip().lower())


def _engine_adult(label):
    key = _engine_key(label)
    return '18_plus' in key or '18+' in key or key.startswith(('erotic', 'adult', 'porn', 'xxx'))


def _engine_logo(icons):
    for icon in icons if isinstance(icons, list) else ():
        url = icon.get('url') if isinstance(icon, dict) else None
        if not isinstance(url, str):
            continue
        if url.startswith(_ENGINE_LOGO_HOST):
            return 'https://' + url[len('http://'):]
        if url.startswith(('http://', 'https://')):
            return url
    return ''


def _num(value):
    try:
        n = float(value)
    except (TypeError, ValueError):
        return 0.0
    return n if math.isfinite(n) else 0.0


def _keys(value, alias=None):
    """Claves de una lista del motor, sin repetir. El motor manda listas, pero una suelta en texto
    se partiría letra a letra."""
    values = [value] if isinstance(value, str) else value if isinstance(value, list) else []
    out = []
    for v in values:
        key = _engine_key(v)
        key = (alias or {}).get(key, key)
        if key and key not in out:
            out.append(key)
    return out


def engine_group_name(label):
    """Nombre en español de una categoría del catálogo o de un grupo de AceServe. Lo que no está en
    la tabla se queda como viene, porque suelen ser nombres propios ("Emilia Romagna")."""
    return _ENGINE_CATEGORIES.get(_engine_key(label), clean_name(label))


def engine_channels(groups):
    """Canales de /search, uno por grupo, con su enlace más sano (el que el motor da por
    disponible y, entre esos, el de más disponibilidad) y hasta tres de repuesto. Sin las
    categorías de adultos."""
    out = []
    for group in groups if isinstance(groups, list) else ():
        if not isinstance(group, dict):
            continue
        links = sorted((i for i in group.get('items') or []
                        if isinstance(i, dict) and _HEX40.fullmatch(str(i.get('infohash') or ''))
                        and not i.get('disabled')),
                       key=lambda i: (int(_num(i.get('status'))) == _ENGINE_AVAILABLE,
                                      _num(i.get('availability'))),
                       reverse=True)
        if not links:
            continue
        best = links[0]
        cats = _keys(best.get('categories'))
        if any(_engine_adult(c) for c in cats):
            continue
        name = str(group.get('name') or best.get('name') or '').strip()
        if not name:
            continue
        infohash = best['infohash'].lower()
        spares = []
        for other in links[1:]:
            h = other['infohash'].lower()
            if h != infohash and h not in spares:
                spares.append(h)
        ch = new_channel(name=name, url=engine_url(infohash), logo=_engine_logo(group.get('icons')),
                         group=next((_ENGINE_CATEGORIES[c] for c in cats if c in _ENGINE_CATEGORIES), 'Otras'))
        ch.update(cats=cats, countries=_keys(best.get('countries'), _ENGINE_COUNTRY_ALIAS),
                  langs=sorted(_keys(best.get('languages'), _ENGINE_LANG_ALIAS)),
                  status=int(_num(best.get('status'))), avail=_num(best.get('availability')),
                  alts=spares[:_ENGINE_SPARES])
        out.append(ch)
    return out


def engine_playlist(text):
    """[(grupo, nombre, 'infohash' o 'id', valor)] de la lista de AceServe (/pl.m3u), sin adultos.
    Sus direcciones apuntan al motor de ese aparato y no se usan; solo se saca el enlace."""
    out, group, name = [], '', ''
    for raw in str(text or '').splitlines():
        line = raw.strip()
        if line[:7].upper() == '#EXTINF':
            meta, name = _split_extinf(line)
            attrs = {k.lower(): v.strip() for k, v in _ATTR_RE.findall(meta)}
            group = attrs.get('group-title', '')
        elif line and not line.startswith('#'):
            m = _ENGINE_HASH_RE.search(line)
            if m and clean_name(name) and not _engine_adult(group):
                kind = 'infohash' if m.group(1).lower() == 'infohash' else 'id'
                out.append((group or 'Other', clean_name(name), kind, m.group(2).lower()))
            group = name = ''
    return out


def engine_adult_links(groups):
    """Enlaces que el catálogo marca como de adultos, para que no se cuelen por la lista propia
    del motor bajo un grupo que no lo diga."""
    out = set()
    for group in groups if isinstance(groups, list) else ():
        for item in (group.get('items') or []) if isinstance(group, dict) else ():
            if (isinstance(item, dict) and _HEX40.fullmatch(str(item.get('infohash') or ''))
                    and any(_engine_adult(c) for c in _keys(item.get('categories')))):
                out.add(item['infohash'].lower())
    return out


def engine_merge(channels, playlist, exclude=()):
    """Cruza la lista propia del motor con el catálogo. Los canales que ya están se quedan con su
    grupo de esa lista; los que no, van al final sin categoría, país ni idioma, como en EKHorus.
    exclude son enlaces que no deben entrar (los de adultos del catálogo)."""
    known = {}
    for ch in channels:
        ref = ace_ref(ch['url'])
        if ref:
            known[ref[1]] = ch
    extra = []
    for group, name, kind, value in playlist or ():
        if value in exclude:
            continue
        ch = known.get(value)
        if ch is not None:
            ch.setdefault('pl', group)
            continue
        ch = new_channel(name=name, url=engine_url(value) if kind == 'infohash' else 'acestream://' + value,
                         group=engine_group_name(group))
        ch.update(cats=[], countries=[], langs=[], status=_ENGINE_AVAILABLE, avail=0.0, alts=[], pl=group)
        known[value] = ch
        extra.append(ch)
    return list(channels) + extra


def engine_sort(channels, lang=''):
    """Primero lo que funciona y se entiende, como en EKHorus: enlace sano, idioma de Kodi,
    disponibilidad y nombre. Sin el idioma, quien abre el catálogo en español ve primero
    canales en cirílico."""
    lang = _ENGINE_LANG_ALIAS.get(lang, lang)
    return sorted(channels, key=lambda ch: (ch.get('status') != _ENGINE_AVAILABLE,
                                            not (lang and lang in (ch.get('langs') or ())),
                                            -_num(ch.get('avail')), fold(ch.get('name'))))


def engine_label(field, key):
    if key == ENGINE_NO_DATA:
        return 'Sin especificar'
    if field == 'pl':
        return engine_group_name(key)
    table = {'cats': _ENGINE_CATEGORIES, 'countries': _ENGINE_COUNTRIES,
             'langs': _ENGINE_LANGUAGES}.get(field, {})
    return table.get(key) or str(key).replace('_', ' ').upper()


def engine_flag(field, key):
    """Código de la bandera de un país o de un idioma, o '' si no tiene una que no deje dudas."""
    if field == 'countries':
        return key
    if field == 'langs':
        return _ENGINE_LANG_COUNTRY.get(_ENGINE_LANG_ALIAS.get(key, key), '')
    return ''


def engine_icon_key(field, key):
    """Nombre del icono de una categoría o de un grupo de la lista propia del motor, que usa las
    mismas etiquetas que las categorías ("Sport", "TV")."""
    return _engine_key(key) if field == 'pl' else key


def engine_preferred(field, lang):
    """La fila que va la primera: el idioma de Kodi en idiomas y su país en países."""
    lang = _ENGINE_LANG_ALIAS.get(lang, lang)
    if field == 'langs':
        return lang
    if field == 'countries':
        return _ENGINE_LANG_COUNTRY.get(lang, '')
    return ''


def engine_facets(channels, field, preferred=''):
    """[(clave, nombre, canales)] por 'cats', 'countries', 'langs' o 'pl' (los grupos de
    AceServe, solo con sus canales). La preferida va la primera, "Sin especificar" la última y
    el resto de mayor a menor. En categorías, las etiquetas desconocidas de menos de cinco
    canales van a Otras; las conocidas se quedan aunque sean pocas, porque en un motor pequeño
    Deportes o Noticias también tienen pocos."""
    index = {}
    for ch in channels:
        if field == 'pl':
            values = [ch['pl']] if ch.get('pl') else []
            if not values:
                continue
        else:
            values = ch.get(field) or [ENGINE_NO_DATA]
        for value in values:
            index.setdefault(value, []).append(ch)
    if field == 'cats':
        other = index.get('other', [])
        seen = {id(ch) for ch in other}
        for key in [k for k, v in index.items()
                    if len(v) < _ENGINE_MIN_CATEGORY and k not in _ENGINE_CATEGORIES and k != ENGINE_NO_DATA]:
            for ch in index.pop(key):
                if id(ch) not in seen:
                    seen.add(id(ch))
                    other.append(ch)
        if other:
            index['other'] = other
    rows = [(k, engine_label(field, k), v) for k, v in index.items()]
    return sorted(rows, key=lambda r: (r[0] != preferred, r[0] == ENGINE_NO_DATA, -len(r[2]), fold(r[1])))


_ENGINE_FIELDS = (('logo', 'l'), ('cats', 'c'), ('countries', 'p'), ('langs', 'i'),
                  ('status', 's'), ('avail', 'a'), ('alts', 'x'), ('pl', 'pl'))


def engine_dump(channels):
    """Copia del catálogo para la caché, con todo lo que la M3U no sabe guardar."""
    rows = []
    for ch in channels:
        ref = ace_ref(ch['url'])
        if not ref:
            continue
        row = {'n': ch.get('name') or '', 't': ref[0], 'h': ref[1], 'g': ch.get('group') or ''}
        row.update({short: ch[key] for key, short in _ENGINE_FIELDS if ch.get(key)})
        rows.append(row)
    return json.dumps({'v': 1, 'channels': rows}, ensure_ascii=False, separators=(',', ':'))


def engine_load(text):
    """Canales de una copia de engine_dump, o None si el texto no es una de ellas."""
    try:
        doc = json.loads(text)
    except (ValueError, RecursionError):
        return None
    if not isinstance(doc, dict) or doc.get('v') != 1 or not isinstance(doc.get('channels'), list):
        return None
    out = []
    for row in doc['channels']:
        if not isinstance(row, dict) or not _HEX40.fullmatch(str(row.get('h') or '')):
            continue
        h = row['h'].lower()
        ch = new_channel(name=clean_name(row.get('n')) or f'AceStream {h[:8]}',
                         url='acestream://' + h if row.get('t') == 'id' else engine_url(h),
                         logo=str(row.get('l') or ''), group=clean_name(row.get('g')))
        ch.update(kind=KIND_ACE, cats=_keys(row.get('c')), countries=_keys(row.get('p')),
                  langs=_keys(row.get('i')), status=int(_num(row.get('s'))), avail=_num(row.get('a')),
                  alts=[x for x in _keys(row.get('x')) if _HEX40.fullmatch(x)],
                  pl=str(row.get('pl') or ''))
        out.append(ch)
    return out


def _xtream_base(server, user, password, section):
    u = urllib.parse.quote(user, safe='')
    p = urllib.parse.quote(password, safe='')
    return f'{server}/{section}/{u}/{p}'


def _file_ext(value):
    ext = str(value or '').strip().lstrip('.')
    return ext if _EXT_RE.fullmatch(ext) else 'mp4'


def _int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def xtream_channels(server, user, password, streams, categories, fmt, section='live'):
    """Canales de get_live_streams. En las otras secciones cada entrada lleva su extensión."""
    names = {}
    for cat in categories if isinstance(categories, list) else ():
        if isinstance(cat, dict):
            names[str(cat.get('category_id'))] = clean_name(cat.get('category_name'))
    live_ext = 'm3u8' if fmt == 'm3u8' else 'ts'
    base = _xtream_base(server, user, password, section)
    out = []
    for s in streams if isinstance(streams, list) else ():
        if not isinstance(s, dict):
            continue
        sid = _int(s.get('stream_id'))
        if sid is None:
            continue
        ext = live_ext if section == 'live' else _file_ext(s.get('container_extension'))
        out.append(new_channel(
            name=s.get('name') or '', url=f'{base}/{sid}.{ext}',
            logo=s.get('stream_icon') or '', group=names.get(str(s.get('category_id')), ''),
            tvg_id=s.get('epg_channel_id') or '', chno=str(s.get('num') or '')))
    return out


def xtream_categories(rows, kind):
    """[{'k': kind, 'id', 'n'}] de una lista de categorías del servidor."""
    out = []
    for cat in rows if isinstance(rows, list) else ():
        cid = str(cat.get('category_id') or '').strip() if isinstance(cat, dict) else ''
        if cid:
            out.append({'k': kind, 'id': cid, 'n': clean_name(cat.get('category_name')) or cid})
    return out


def xtream_series(rows):
    """[{'id', 'n', 'logo', 'plot'}] de get_series."""
    out = []
    for s in rows if isinstance(rows, list) else ():
        sid = _int(s.get('series_id')) if isinstance(s, dict) else None
        if sid is not None:
            out.append({'id': str(sid), 'n': clean_name(s.get('name')) or str(sid),
                        'logo': str(s.get('cover') or ''), 'plot': str(s.get('plot') or '')})
    return out


def xtream_episodes(server, user, password, info):
    """[(temporada, canales)] de get_series_info, en orden. Hay servidores que mandan 'episodes'
    como lista de temporadas en vez de como diccionario."""
    eps = info.get('episodes') if isinstance(info, dict) else None
    if isinstance(eps, dict):
        groups = eps.items()
    elif isinstance(eps, list):
        groups = [('', g) for g in eps]
    else:
        return []
    base = _xtream_base(server, user, password, 'series')
    seasons = {}
    for key, rows in groups:
        for e in rows if isinstance(rows, list) else ():
            eid = _int(e.get('id')) if isinstance(e, dict) else None
            if eid is None:
                continue
            num = _int(e.get('episode_num'))
            extra = e.get('info') if isinstance(e.get('info'), dict) else {}
            season = _int(key)
            if season is None:
                season = _int(e.get('season')) or 0
            ch = new_channel(name=clean_name(e.get('title')) or f'Capítulo {num or eid}',
                             url=f'{base}/{eid}.{_file_ext(e.get("container_extension"))}',
                             logo=str(extra.get('movie_image') or ''))
            seasons.setdefault(season, []).append((num if num is not None else eid, ch))
    return [(s, [ch for _n, ch in sorted(rows, key=lambda r: r[0])]) for s, rows in sorted(seasons.items())]
