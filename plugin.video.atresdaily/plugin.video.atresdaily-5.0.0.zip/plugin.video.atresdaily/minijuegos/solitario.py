# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/solitario.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random

from minijuegos import base, scores, tactil

PALOS = ('♠', '♥', '♦', '♣')
ROJOS = (1, 2)
FIGURAS = {1: 'A', 11: 'J', 12: 'Q', 13: 'K'}
COLUMNAS = 7
TOTAL_CARTAS = 52
POR_PALO = 13

ANCHO_CARTA, ALTO_CARTA = 150, 192
HUECO = 36
FILA_ARRIBA = 180
FILA_TABLERO = 420
ALTO_TABLERO = 540
PASO_TAPADA, PASO_DESTAPADA = 16, 40
PASO_MINIMO = 12
X0 = (base.ANCHO - (COLUMNAS * (ANCHO_CARTA + HUECO) - HUECO)) // 2

COLUMNA_MAZO, COLUMNA_DESCARTE, COLUMNA_OTRA, COLUMNA_FUNDACIONES = 0, 1, 2, 3
ZONA_ARRIBA, ZONA_TABLERO = 'arriba', 'tablero'
MAZO, DESCARTE, OTRA, FUNDACION, TABLERO = 'mazo', 'descarte', 'otra', 'fundacion', 'tablero'

COLOR_CARTA = 'FFF0F3F6'
COLOR_DORSO = 'FF2E5C8A'
COLOR_HUECO = 'FF1B242E'
COLOR_ROJO = 'FFC8433A'
COLOR_NEGRO = 'FF16202B'
COLOR_ELEGIDA = 'FFE8C34A'
COLOR_CURSOR = 'FF3AC6E8'
GROSOR_CURSOR = 6


def _x(columna):
    return X0 + columna * (ANCHO_CARTA + HUECO)


def _texto(carta):
    valor, palo = carta
    return f'{FIGURAS.get(valor, valor)}{PALOS[palo]}'


def cabe_en_fundacion(carta, fundacion):
    valor, palo = carta
    if not fundacion:
        return valor == 1
    return palo == fundacion[-1][1] and valor == fundacion[-1][0] + 1


def cabe_en_columna(carta, columna):
    if not columna:
        return carta[0] == POR_PALO
    valor, palo = columna[-1]
    return (palo in ROJOS) != (carta[1] in ROJOS) and carta[0] == valor - 1


class VentanaSolitario(base.Ventana):
    def __init__(self):
        super().__init__('Solitario', tactil.DIRECTO)
        self.lab_movimientos = self.etiqueta(X0, 120, 500, 42, '', fuente=base.FUENTE_MEDIA)
        self.lab_estado = self.etiqueta(0, 120, base.ANCHO, 42, '', fuente=base.FUENTE_MEDIA,
                                        alineacion=6)
        record = scores.mejor('solitario')
        self.lab_record = self.etiqueta(base.ANCHO - X0 - 500, 120, 500, 42,
                                        f'Récord: {record} movimientos' if record else '',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        for columna in (COLUMNA_MAZO, COLUMNA_DESCARTE, COLUMNA_OTRA):
            self.imagen(_x(columna), FILA_ARRIBA, ANCHO_CARTA, ALTO_CARTA, COLOR_HUECO)
        self.lab_otra = self.etiqueta(_x(COLUMNA_OTRA) - HUECO // 2,
                                      FILA_ARRIBA + ALTO_CARTA // 2 - 18, ANCHO_CARTA + HUECO,
                                      36, '', fuente=base.FUENTE_PEQUENA,
                                      color=base.COLOR_TEXTO_SUAVE, alineacion=6)
        for numero in range(len(PALOS)):
            self.imagen(_x(COLUMNA_FUNDACIONES + numero), FILA_ARRIBA, ANCHO_CARTA, ALTO_CARTA,
                        COLOR_HUECO)
            self.etiqueta(_x(COLUMNA_FUNDACIONES + numero), FILA_ARRIBA + ALTO_CARTA // 2 - 24,
                          ANCHO_CARTA, 48, PALOS[numero], fuente=base.FUENTE_TITULO,
                          color=base.COLOR_TEXTO_TENUE, alineacion=6)
        for columna in range(COLUMNAS):
            self.imagen(_x(columna), FILA_TABLERO, ANCHO_CARTA, ALTO_CARTA, COLOR_HUECO)
        self.lab_vuelta = self.etiqueta(_x(COLUMNA_MAZO), FILA_ARRIBA + ALTO_CARTA // 2 - 18,
                                        ANCHO_CARTA, 36, '', fuente=base.FUENTE_PEQUENA,
                                        color=base.COLOR_TEXTO_SUAVE, alineacion=6)
        self.cartas_ui = self._crear_cartas()
        self.cursor_partes = [self.imagen(_x(0), FILA_TABLERO, GROSOR_CURSOR, GROSOR_CURSOR,
                                          COLOR_CURSOR) for _ in range(4)]
        self.pie_controles(FILA_TABLERO + ALTO_TABLERO + 6,
                           'Mover: {mover}   ·   '
                           'Coger y soltar: {ok}   ·   '
                           'A su montón: {menu}   ·   '
                           'Salir: {atras}')
        self.crear_overlay()
        self._reiniciar()

    def _crear_cartas(self):
        x, y = _x(COLUMNA_MAZO), FILA_ARRIBA
        return [(self.imagen(x, y, ANCHO_CARTA, ALTO_CARTA, COLOR_CARTA),
                 self.etiqueta(x, y, ANCHO_CARTA - 24, 42, fuente=base.FUENTE_MEDIA,
                               color=COLOR_NEGRO))
                for _ in range(TOTAL_CARTAS)]

    def _reiniciar(self):
        baraja = [(valor, palo) for palo in range(len(PALOS))
                  for valor in range(1, POR_PALO + 1)]
        random.shuffle(baraja)
        self.columnas = [[baraja.pop() for _ in range(numero + 1)] for numero in range(COLUMNAS)]
        self.tapadas = list(range(COLUMNAS))
        self.mazo = baraja
        self.descarte = []
        self.fundaciones = [[] for _ in PALOS]
        self.movimientos = 0
        self.elegido = None
        self.otra_armada = False
        self.zona = ZONA_TABLERO
        self.indice = 0
        self.profundidad = 0
        self.terminado = False
        self.ocultar_overlay()
        self._pintar()

    def _paso(self, columna):
        destapadas = len(self.columnas[columna]) - self.tapadas[columna]
        if destapadas <= 1:
            return PASO_DESTAPADA
        libre = ALTO_TABLERO - ALTO_CARTA - self.tapadas[columna] * PASO_TAPADA
        return max(PASO_MINIMO, min(PASO_DESTAPADA, libre // (destapadas - 1)))

    def _desplazamiento(self, columna, posicion):
        tapadas = self.tapadas[columna]
        return (min(posicion, tapadas) * PASO_TAPADA
                + max(0, posicion - tapadas) * self._paso(columna))

    def _es_elegida(self, origen, indice):
        return self.elegido is not None and self.elegido[:2] == (origen, indice)

    def _pintar_carta(self, indice, x, y, carta, elegida=False):
        imagen, etiqueta = self.cartas_ui[indice]
        imagen.setPosition(self.esc_x(x), self.esc_y(y))
        etiqueta.setPosition(self.esc_x(x + 12), self.esc_y(y + 6))
        if carta is None:
            imagen.setColorDiffuse(COLOR_DORSO)
            etiqueta.setLabel('')
        else:
            imagen.setColorDiffuse(COLOR_ELEGIDA if elegida else COLOR_CARTA)
            etiqueta.setLabel(_texto(carta),
                              textColor=COLOR_ROJO if carta[1] in ROJOS else COLOR_NEGRO)
        imagen.setVisible(True)
        etiqueta.setVisible(True)
        return indice + 1

    def _pintar(self):
        self._ajustar_cursor()
        indice = 0
        if self.mazo:
            indice = self._pintar_carta(indice, _x(COLUMNA_MAZO), FILA_ARRIBA, None)
        self.lab_vuelta.setLabel('' if self.mazo or not self.descarte else 'Otra vuelta')
        if self.descarte:
            indice = self._pintar_carta(indice, _x(COLUMNA_DESCARTE), FILA_ARRIBA,
                                        self.descarte[-1], self._es_elegida(DESCARTE, 0))
        for numero, fundacion in enumerate(self.fundaciones):
            if fundacion:
                indice = self._pintar_carta(indice, _x(COLUMNA_FUNDACIONES + numero), FILA_ARRIBA,
                                            fundacion[-1], self._es_elegida(FUNDACION, numero))
        for columna in range(COLUMNAS):
            desde = self.elegido[2] if self._es_elegida(TABLERO, columna) else None
            for posicion, carta in enumerate(self.columnas[columna]):
                tapada = posicion < self.tapadas[columna]
                indice = self._pintar_carta(
                    indice, _x(columna), FILA_TABLERO + self._desplazamiento(columna, posicion),
                    None if tapada else carta, desde is not None and posicion >= desde)
        for imagen, etiqueta in self.cartas_ui[indice:]:
            imagen.setVisible(False)
            etiqueta.setVisible(False)
        self._colocar_cursor()
        self.lab_otra.setLabel('¿Seguro?' if self.otra_armada else 'Otra mano',
                               textColor=COLOR_ELEGIDA if self.otra_armada
                               else base.COLOR_TEXTO_SUAVE)
        self.lab_movimientos.setLabel(f'Movimientos: {self.movimientos}')
        self.lab_estado.setLabel(f'Colocadas: {sum(len(f) for f in self.fundaciones)}'
                                 f'/{TOTAL_CARTAS}')

    def _colocar_cursor(self):
        if self.zona == ZONA_ARRIBA:
            x, y, alto = _x(self.indice), FILA_ARRIBA, ALTO_CARTA
        else:
            cartas = self.columnas[self.indice]
            arriba = self._desplazamiento(self.indice, self.profundidad)
            hasta = self._desplazamiento(self.indice, max(0, len(cartas) - 1))
            x, y, alto = _x(self.indice), FILA_TABLERO + arriba, hasta - arriba + ALTO_CARTA
        grosor, ancho = GROSOR_CURSOR, ANCHO_CARTA
        lados = ((x - grosor, y - grosor, ancho + 2 * grosor, grosor),
                 (x - grosor, y + alto, ancho + 2 * grosor, grosor),
                 (x - grosor, y, grosor, alto),
                 (x + ancho, y, grosor, alto))
        color = COLOR_ELEGIDA if self.elegido is not None else COLOR_CURSOR
        for control, (lado_x, lado_y, lado_ancho, lado_alto) in zip(self.cursor_partes, lados):
            control.setPosition(self.esc_x(lado_x), self.esc_y(lado_y))
            control.setWidth(self.esc_ancho(lado_ancho))
            control.setHeight(self.esc_alto(lado_alto))
            control.setColorDiffuse(color)

    def _ultima(self, columna):
        cartas = self.columnas[columna]
        return max(self.tapadas[columna], len(cartas) - 1) if cartas else 0

    def _ajustar_cursor(self):
        if self.zona != ZONA_TABLERO:
            return
        cartas = self.columnas[self.indice]
        if not cartas:
            self.profundidad = 0
            return
        self.profundidad = max(self.tapadas[self.indice],
                               min(self.profundidad, len(cartas) - 1))

    def _mover_lado(self, paso):
        self.indice = max(0, min(COLUMNAS - 1, self.indice + paso))
        if self.zona == ZONA_TABLERO:
            self.profundidad = self._ultima(self.indice)

    def _subir(self):
        if self.zona == ZONA_ARRIBA:
            return
        if self.columnas[self.indice] and self.profundidad > self.tapadas[self.indice]:
            self.profundidad -= 1
            return
        self.zona = ZONA_ARRIBA

    def _bajar(self):
        if self.zona == ZONA_ARRIBA:
            self.zona = ZONA_TABLERO
            self.profundidad = self._ultima(self.indice)
            return
        if self.columnas[self.indice]:
            self.profundidad = min(self.profundidad + 1, len(self.columnas[self.indice]) - 1)

    def _robar(self):
        if self.mazo:
            self.descarte.append(self.mazo.pop())
        elif self.descarte:
            self.mazo = list(reversed(self.descarte))
            self.descarte = []
        else:
            return
        self.movimientos += 1
        self.elegido = None

    def _elegir(self):
        if self.zona == ZONA_ARRIBA:
            if self.indice == COLUMNA_DESCARTE and self.descarte:
                self.elegido = (DESCARTE, 0, 0)
            elif (self.indice >= COLUMNA_FUNDACIONES
                  and self.fundaciones[self.indice - COLUMNA_FUNDACIONES]):
                self.elegido = (FUNDACION, self.indice - COLUMNA_FUNDACIONES, 0)
            return
        if self.columnas[self.indice] and self.profundidad >= self.tapadas[self.indice]:
            self.elegido = (TABLERO, self.indice, self.profundidad)

    def _cartas_elegidas(self):
        origen, indice, profundidad = self.elegido
        if origen == DESCARTE:
            return [self.descarte[-1]]
        if origen == FUNDACION:
            return [self.fundaciones[indice][-1]]
        return self.columnas[indice][profundidad:]

    def _quitar_del_origen(self):
        origen, indice, profundidad = self.elegido
        if origen == DESCARTE:
            self.descarte.pop()
        elif origen == FUNDACION:
            self.fundaciones[indice].pop()
        else:
            del self.columnas[indice][profundidad:]

    def _soltar(self):
        cartas = self._cartas_elegidas()
        if self.zona == ZONA_ARRIBA:
            if self.indice < COLUMNA_FUNDACIONES:
                return False
            fundacion = self.fundaciones[self.indice - COLUMNA_FUNDACIONES]
            if len(cartas) > 1 or not cabe_en_fundacion(cartas[0], fundacion):
                return False
            self._quitar_del_origen()
            fundacion.append(cartas[0])
        else:
            if not cabe_en_columna(cartas[0], self.columnas[self.indice]):
                return False
            self._quitar_del_origen()
            self.columnas[self.indice].extend(cartas)
        self.movimientos += 1
        self._destapar()
        self._rematar()
        self._comprobar_victoria()
        return True

    def _rematar(self):
        if self.mazo or self.descarte or any(self.tapadas):
            return
        movida = True
        while movida:
            movida = False
            for cartas in self.columnas:
                if not cartas:
                    continue
                numero = next((n for n, fundacion in enumerate(self.fundaciones)
                               if cabe_en_fundacion(cartas[-1], fundacion)), None)
                if numero is not None:
                    self.fundaciones[numero].append(cartas.pop())
                    self.movimientos += 1
                    movida = True

    def _a_la_fundacion(self):
        if self.zona == ZONA_ARRIBA and self.indice == COLUMNA_DESCARTE and self.descarte:
            carta = self.descarte[-1]
        elif self.zona == ZONA_TABLERO and self.columnas[self.indice]:
            carta = self.columnas[self.indice][-1]
        else:
            return
        numero = next((n for n, f in enumerate(self.fundaciones) if cabe_en_fundacion(carta, f)),
                      None)
        if numero is None:
            return
        if self.zona == ZONA_ARRIBA:
            self.descarte.pop()
        else:
            self.columnas[self.indice].pop()
        self.fundaciones[numero].append(carta)
        self.movimientos += 1
        self.elegido = None
        self._destapar()
        self._rematar()
        self._comprobar_victoria()

    def _destapar(self):
        for numero, cartas in enumerate(self.columnas):
            if not cartas:
                self.tapadas[numero] = 0
            elif self.tapadas[numero] >= len(cartas):
                self.tapadas[numero] = len(cartas) - 1

    def _comprobar_victoria(self):
        if sum(len(fundacion) for fundacion in self.fundaciones) < TOTAL_CARTAS:
            return
        self.terminado = True
        es_record = scores.registrar('solitario', self.movimientos, menor_mejor=True)
        detalle = f'Movimientos: {self.movimientos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.movimientos} movimientos')
        self.mostrar_overlay('¡COMPLETADO!', detalle, base.ayuda_fin_partida())

    def _pila_bajo_el_cursor(self):
        if self.zona == ZONA_TABLERO:
            return (TABLERO, self.indice)
        if self.indice == COLUMNA_MAZO:
            return (MAZO, 0)
        if self.indice == COLUMNA_DESCARTE:
            return (DESCARTE, 0)
        if self.indice == COLUMNA_OTRA:
            return (OTRA, 0)
        return (FUNDACION, self.indice - COLUMNA_FUNDACIONES)

    def _pulsar(self):
        pila = self._pila_bajo_el_cursor()
        if pila[0] == OTRA:
            if self.otra_armada:
                self._reiniciar()
            else:
                self.otra_armada = True
            return
        if self.elegido is None:
            if pila[0] == MAZO:
                self._robar()
            else:
                self._elegir()
            return
        if self.elegido[:2] == pila:
            self.elegido = None
        elif self._soltar():
            self.elegido = None

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if self.terminado or self.confirmar_salida():
                self.close()
            return
        if self.terminado:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion != base.ACEPTAR:
            self.otra_armada = False
        if accion in (base.IZQUIERDA, base.DERECHA):
            self._mover_lado(-1 if accion == base.IZQUIERDA else 1)
        elif accion == base.ARRIBA:
            self._subir()
        elif accion == base.ABAJO:
            self._bajar()
        elif accion == base.ACEPTAR:
            self._pulsar()
        elif accion == base.MENU_CONTEXTUAL:
            self._a_la_fundacion()
        else:
            return
        self._pintar()


def jugar():
    ventana = VentanaSolitario()
    base.ejecutar(ventana)
    del ventana
