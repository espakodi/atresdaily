# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/memoria.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random

from minijuegos import base, scores, tactil

COLUMNAS, FILAS = 6, 4
TOTAL_PAREJAS = COLUMNAS * FILAS // 2
CELDA, HUECO = 165, 15
PASO = CELDA + HUECO

COLOR_TAPADA = 'FF2E3A47'
COLOR_NUMERO = 'FF10151B'
COLORES = (
    'FFE85D4A', 'FF43D675', 'FF4A78E8', 'FFE8C34A', 'FFB06AE0', 'FF3AC6E8',
    'FFE8974A', 'FF54C06E', 'FFA98BF0', 'FF6AA8F0', 'FFD8975A', 'FF52C4BC',
)


class VentanaMemoria(base.Ventana):
    MOVIMIENTOS = {
        base.ARRIBA: (0, -1),
        base.ABAJO: (0, 1),
        base.IZQUIERDA: (-1, 0),
        base.DERECHA: (1, 0),
    }

    def __init__(self):
        super().__init__('Memoria', tactil.DIRECTO)
        ancho_tablero = COLUMNAS * PASO - HUECO
        self.x0 = (base.ANCHO - ancho_tablero) // 2
        self.y0 = 180
        self.lab_intentos = self.etiqueta(self.x0, 126, 450, 42, '', fuente=base.FUENTE_MEDIA)
        self.lab_parejas = self.etiqueta(self.x0, 126, ancho_tablero, 42, '',
                                         fuente=base.FUENTE_MEDIA, alineacion=6)
        record = scores.mejor('memoria')
        self.lab_record = self.etiqueta(self.x0 + ancho_tablero - 600, 126, 600, 42,
                                        f'Récord: {record} intentos' if record else '',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(self.x0 - 9, self.y0 - 9, ancho_tablero + 18,
                    FILAS * PASO - HUECO + 18, base.COLOR_MARCO)
        self.celdas = self.rejilla(COLUMNAS, FILAS, self.x0, self.y0, CELDA, HUECO, COLOR_TAPADA)
        self.numeros = [
            [self.etiqueta(self.x0 + c * PASO, self.y0 + f * PASO, CELDA, CELDA, '',
                           fuente='font37', alineacion=6)
             for c in range(COLUMNAS)]
            for f in range(FILAS)]
        self.pie_controles(self.y0 + FILAS * PASO + 24,
                           'Mover: {mover}   ·   '
                           'Levantar: {ok}   ·   '
                           'Salir: {atras}')
        self.cursor_img = self.imagen(self.x0, self.y0, CELDA, CELDA, '66FFFFFF')
        self.crear_overlay()
        self._reiniciar()

    def _reiniciar(self):
        valores = list(range(1, 13)) * 2
        random.shuffle(valores)
        self.cartas = {}
        for indice, valor in enumerate(valores):
            self.cartas[(indice % COLUMNAS, indice // COLUMNAS)] = valor
        self.levantadas = []
        self.resueltas = set()
        self.intentos = 0
        self.terminado = False
        for f in range(FILAS):
            for c in range(COLUMNAS):
                self.celdas[f][c].setColorDiffuse(COLOR_TAPADA)
                self.numeros[f][c].setLabel('')
        self.cursor = (COLUMNAS // 2, FILAS // 2)
        self._mover_cursor(0, 0)
        self.lab_intentos.setLabel('Intentos: 0')
        self.lab_parejas.setLabel(f'Parejas: 0/{TOTAL_PAREJAS}')
        self.ocultar_overlay()

    def _mover_cursor(self, dc, df):
        self._poner_cursor(self.cursor[0] + dc, self.cursor[1] + df)

    def _poner_cursor(self, c, f):
        c = min(max(c, 0), COLUMNAS - 1)
        f = min(max(f, 0), FILAS - 1)
        self.cursor = (c, f)
        self.cursor_img.setPosition(self.esc_x(self.x0 + c * PASO),
                                    self.esc_y(self.y0 + f * PASO))

    def casilla_en(self, x, y):
        c = int((x - self.x0) // PASO)
        f = int((y - self.y0) // PASO)
        if 0 <= c < COLUMNAS and 0 <= f < FILAS:
            return c, f
        return None

    def _mostrar_carta(self, pos):
        valor = self.cartas[pos]
        self.celdas[pos[1]][pos[0]].setColorDiffuse(COLORES[valor - 1])
        self.numeros[pos[1]][pos[0]].setLabel(str(valor), textColor=COLOR_NUMERO)

    def _bajar_pendientes(self):
        for pos in self.levantadas:
            self.celdas[pos[1]][pos[0]].setColorDiffuse(COLOR_TAPADA)
            self.numeros[pos[1]][pos[0]].setLabel('')
        self.levantadas = []

    def _levantar(self, pos):
        if pos in self.resueltas or pos in self.levantadas:
            return
        if len(self.levantadas) == 2:
            self._bajar_pendientes()
        self.levantadas.append(pos)
        self._mostrar_carta(pos)
        if len(self.levantadas) == 2:
            self.intentos += 1
            self.lab_intentos.setLabel(f'Intentos: {self.intentos}')
            primera, segunda = self.levantadas
            if self.cartas[primera] == self.cartas[segunda]:
                self.resueltas.update(self.levantadas)
                self.levantadas = []
                self.lab_parejas.setLabel(
                    f'Parejas: {len(self.resueltas) // 2}/{TOTAL_PAREJAS}')
                if len(self.resueltas) == COLUMNAS * FILAS:
                    self._ganar()

    def _ganar(self):
        self.terminado = True
        es_record = scores.registrar('memoria', self.intentos, menor_mejor=True)
        detalle = f'Intentos: {self.intentos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.intentos} intentos')
        self.mostrar_overlay('¡COMPLETADO!', detalle, base.ayuda_fin_partida())

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if self.terminado or self.confirmar_salida():
                self.close()
            return
        if self.terminado:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        punto = base.punto_tocado(self, action)
        if punto is not None:
            casilla = self.casilla_en(*punto)
            if casilla is not None:
                self._poner_cursor(*casilla)
                self._levantar(casilla)
            return

        if accion in self.MOVIMIENTOS:
            self._mover_cursor(*self.MOVIMIENTOS[accion])
        elif accion == base.ACEPTAR:
            self._levantar(self.cursor)


def jugar():
    ventana = VentanaMemoria()
    base.ejecutar(ventana)
    del ventana
