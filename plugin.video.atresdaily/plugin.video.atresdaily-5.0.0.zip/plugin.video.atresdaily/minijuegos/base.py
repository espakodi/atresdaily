# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/base.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import gc
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from minijuegos import dificultad

ANCHO, ALTO = 1920, 1080
MEDIA = os.path.join(
    xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')), 'resources', 'media', 'minijuegos')
PIXEL = os.path.join(MEDIA, 'white.png')
CIRCULO = os.path.join(MEDIA, 'circulo.png')
ICONO_AJUSTES = os.path.join(MEDIA, 'menu', 'ek_ajustes.png')

IZQUIERDA, DERECHA, ARRIBA, ABAJO = 1, 2, 3, 4
ACEPTAR = 7
ATRAS = (9, 10, 92)
MENU_CONTEXTUAL = 117
PAUSA = (12, 79, 229)
RATON_MOVER = 107
RATON_CLIC = 100
RATON_DERECHO = 101
RATON_ARRASTRAR = 106
RATON_SOLTAR = 109

TOQUE = 401
TOQUE_LARGO = 411
DESLIZAR = {511: IZQUIERDA, 521: DERECHA, 531: ARRIBA, 541: ABAJO}
GESTO_INICIO = 501
GESTO_MOVER = 504
GESTO_FIN = 599

_PLATAFORMAS_MANDO = ('Android', 'IOS', 'TVOS', 'WebOS')

_BOTONES_TECLADO = {'mover': 'flechas', 'ok': 'Intro', 'menu': 'C',
                    'atras': 'Esc', 'pausa': 'Espacio',
                    'apuntar': 'izquierda y derecha', 'llevar': 'flechas'}
_BOTONES_MANDO = {'mover': 'cruceta o stick', 'ok': 'OK', 'menu': 'Menú',
                  'atras': 'Atrás', 'pausa': 'Menú',
                  'apuntar': 'izquierda y derecha', 'llevar': 'cruceta o stick'}
_BOTONES_DEDOS = {'mover': 'la cruceta', 'ok': 'el botón', 'menu': 'la rueda dentada',
                  'atras': 'Atrás', 'pausa': 'la rueda dentada',
                  'apuntar': 'arrastrar, o la cruceta para afinar',
                  'llevar': 'arrastrar, o la cruceta para afinar'}
_BOTONES_DEDOS_TABLERO = {'mover': 'deslizar', 'ok': 'tocar', 'menu': 'mantener pulsado',
                          'atras': 'Atrás', 'pausa': 'la rueda dentada',
                          'apuntar': 'arrastrar', 'llevar': 'arrastrar'}

COLOR_FONDO = 'FF10151B'
COLOR_VELO = 'CC000000'
COLOR_TEXTO = 'FFE8ECEF'
COLOR_TEXTO_SUAVE = 'FF8A97A5'
COLOR_TEXTO_TENUE = 'FF5D6875'
COLOR_MARCO = 'FF2A3441'

FUENTE_BASE = 'font13'
FUENTE_PEQUENA = 'font12'
FUENTE_MEDIA = 'font27'
FUENTE_TITULO = 'font32_title'
FUENTE_GRANDE = 'font45_title'


def usa_mando():
    return any(xbmc.getCondVisibility(f'System.Platform.{plataforma}')
               for plataforma in _PLATAFORMAS_MANDO)


def botones():
    modo = _tactil().jugando_con_dedos()
    if modo is None:
        return _BOTONES_MANDO if usa_mando() else _BOTONES_TECLADO
    if modo == _tactil().DIRECTO:
        return _BOTONES_DEDOS_TABLERO
    if modo == _tactil().CRUCETA:
        return dict(_BOTONES_DEDOS, ok='fuera de la cruceta')
    return _BOTONES_DEDOS


def boton(accion):
    return botones()[accion]


DIRECCIONES = (IZQUIERDA, DERECHA, ARRIBA, ABAJO)


def quiere_otra_partida(accion):
    return accion == ACEPTAR or accion in DIRECCIONES


def ayuda_fin_partida():
    if _tactil().jugando_con_dedos() == _tactil().CRUCETA:
        return f'toca la pantalla: otra partida   ·   {boton("atras")}: salir'
    return f'{boton("ok")}: otra partida   ·   {boton("atras")}: salir'


def leyenda_dispositivos():
    modo = _tactil().jugando_con_dedos()
    if modo is not None:
        if modo != _tactil().DIRECTO:
            return ('La rueda dentada de arriba pausa y sale del juego; '
                    'las flechas y el mando siguen valiendo')
        return ('Toca donde quieras ir; la rueda dentada de arriba sale del juego; '
                'las flechas y el mando siguen valiendo')
    if usa_mando():
        return ('Mando: OK = A, Menú = X o mantener A, Atrás = B      '
                'Remoto: mantener OK hace de Menú')
    return 'También valen: Retroceso (←) para salir y mantener Intro en vez de C'


class _SinContador:
    def paso(self, duracion, objetivo_ms):
        pass

    def cerrar(self):
        pass


SIN_CONTADOR = _SinContador()

_REGISTRO_MAXIMO = 1024 * 1024
_LINEAS_POR_VACIADO = 20
REGISTRO = 'rendimiento.log'


class Contador:
    def __init__(self, ventana, juego):
        self.etiqueta = ventana.etiqueta(24, 18, 900, 30, '', fuente=FUENTE_PEQUENA,
                                         color=COLOR_TEXTO_TENUE)
        self._juego = juego
        self._registro = None
        self._sin_vaciar = 0
        self._reiniciar_cuenta(time.monotonic())
        self._recogidas = self._cuantas_recogidas()

    def _reiniciar_cuenta(self, ahora):
        self._desde = ahora
        self._pasos = 0
        self._suma = 0.0
        self._peor = 0.0
        self._objetivo = 0

    @staticmethod
    def _cuantas_recogidas():
        return sum(gen['collections'] for gen in gc.get_stats())

    def _abrir_registro(self):
        ruta = _ruta_registro()
        try:
            os.makedirs(os.path.dirname(ruta), exist_ok=True)
            if os.path.exists(ruta) and os.path.getsize(ruta) > _REGISTRO_MAXIMO:
                os.remove(ruta)
            fichero = open(ruta, 'a', encoding='utf-8')
        except OSError as error:
            xbmc.log(f'AtresDaily: no se pudo abrir {ruta}: {error}', xbmc.LOGWARNING)
            return False
        fichero.write(f'\n# {self._juego} · {dificultad.nombre()} · '
                      f'{time.strftime("%Y-%m-%d %H:%M:%S")}\n')
        self._registro = fichero
        return True

    def _apuntar(self, linea):
        if self._registro is None and not self._abrir_registro():
            return
        try:
            self._registro.write(linea + '\n')
            self._sin_vaciar += 1
            if self._sin_vaciar >= _LINEAS_POR_VACIADO:
                self._sin_vaciar = 0
                self._registro.flush()
        except OSError as error:
            xbmc.log(f'AtresDaily: no se pudo apuntar el rendimiento: {error}', xbmc.LOGWARNING)

    def cerrar(self):
        if self._registro is not None:
            self._registro.close()
            self._registro = None

    def paso(self, duracion, objetivo_ms):
        self._pasos += 1
        self._suma += duracion
        self._peor = max(self._peor, duracion)
        self._objetivo = objetivo_ms
        ahora = time.monotonic()
        transcurrido = ahora - self._desde
        if transcurrido < 1:
            return
        pasos = self._pasos / transcurrido
        pedidos = 1000 / self._objetivo
        medio = self._suma / self._pasos * 1000
        peor = self._peor * 1000
        fps = xbmc.getInfoLabel('System.FPS')
        recogidas = self._cuantas_recogidas() - self._recogidas
        self.etiqueta.setLabel(
            f'pasos {pasos:.0f}/{pedidos:.0f}   ·   tick {medio:.1f} ms (peor {peor:.0f})'
            f'   ·   {fps} fps   ·   gc {recogidas}')
        self._apuntar(f'{time.strftime("%H:%M:%S")} {self._juego} pasos={pasos:.1f}/{pedidos:.0f}'
                      f' tick={medio:.2f} peor={peor:.1f} fps={fps} gc={recogidas}')
        self._recogidas += recogidas
        self._reiniciar_cuenta(ahora)


def _contador_encendido():
    return xbmcaddon.Addon().getSetting('juegos_mostrar_rendimiento') == 'true'


def _ruta_registro():
    carpeta = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'minijuegos')
    return os.path.join(carpeta, REGISTRO)


def _borrar_registro():
    try:
        os.remove(_ruta_registro())
    except OSError:
        pass


def _estirado(ancho_coords, alto_coords):
    try:
        ancho_px = int(xbmc.getInfoLabel('System.ScreenWidth'))
        alto_px = int(xbmc.getInfoLabel('System.ScreenHeight'))
    except ValueError:
        return 1.0, 1.0
    if ancho_px <= 0 or alto_px <= 0:
        return 1.0, 1.0
    return ancho_px / ancho_coords, alto_px / alto_coords


def _tactil():
    from minijuegos import tactil
    return tactil


class Ventana(xbmcgui.WindowDialog):
    pausa = False
    usa_disparo_automatico = False
    sonidos_de_kodi = False

    def __init__(self, titulo, tacto=None, ajustes=True, ejes=None):
        super().__init__()
        self.cerrado = False
        self._compas = time.monotonic()
        self._pendientes = []
        self._ancho_real = self.getWidth()
        self._alto_real = self.getHeight()
        estira_x, estira_y = _estirado(self._ancho_real, self._alto_real)
        self._estira_x, self._estira_y = estira_x, estira_y
        pixeles = min(self._ancho_real / ANCHO * estira_x, self._alto_real / ALTO * estira_y)
        self._escala_x = pixeles / estira_x
        self._escala_y = pixeles / estira_y
        self._margen_x = (self._ancho_real - ANCHO * self._escala_x) / 2
        self._margen_y = (self._alto_real - ALTO * self._escala_y) / 2
        self._fondo = self.imagen_completa(COLOR_FONDO)
        self.etiqueta(0, 36, ANCHO, 60, titulo, fuente=FUENTE_TITULO, alineacion=6)
        if _contador_encendido():
            self.rendimiento = Contador(self, titulo)
        else:
            self.rendimiento = SIN_CONTADOR
            _borrar_registro()
        self.volcar()
        self._foco = xbmcgui.ControlButton(0, 0, self._ancho_real, self._alto_real, '',
                                           focusTexture='', noFocusTexture='')
        self.addControl(self._foco)
        self.setFocus(self._foco)
        self.tacto = None
        if tacto is not None and _tactil().modo_ajustado() != 2:
            self.tacto = _tactil().Tacto(self, tacto, ajustes, ejes)
            if _tactil().encendido_de_entrada():
                self.tacto.marcar()

    def esc_ancho(self, medida):
        return max(1, round(medida * self._escala_x))

    def esc_alto(self, medida):
        return max(1, round(medida * self._escala_y))

    def esc_x(self, x):
        return round(self._margen_x + x * self._escala_x)

    def esc_y(self, y):
        return round(self._margen_y + y * self._escala_y)

    def esperar(self, monitor, intervalo_ms):
        objetivo = self._compas + intervalo_ms / 1000
        espera = objetivo - time.monotonic()
        if espera <= 0:
            self._compas = time.monotonic()
            return monitor.abortRequested()
        self._compas = objetivo
        return monitor.waitForAbort(espera)

    def punto_del_raton(self, accion):
        x = (accion.getAmount1() / self._estira_x - self._margen_x) / self._escala_x
        y = (accion.getAmount2() / self._estira_y - self._margen_y) / self._escala_y
        return x, y

    def volcar(self):
        if not self._pendientes:
            return
        self.addControls(self._pendientes)
        self._pendientes = []

    def imagen_completa(self, color):
        control = xbmcgui.ControlImage(0, 0, self._ancho_real, self._alto_real,
                                       PIXEL, colorDiffuse=color)
        self._pendientes.append(control)
        return control

    def imagen(self, x, y, ancho, alto, color, textura=PIXEL):
        control = xbmcgui.ControlImage(self.esc_x(x), self.esc_y(y), self.esc_ancho(ancho),
                                       self.esc_alto(alto), textura, colorDiffuse=color)
        self._pendientes.append(control)
        return control

    def etiqueta(self, x, y, ancho, alto, texto='', fuente=FUENTE_BASE, color=COLOR_TEXTO,
                 alineacion=0):
        control = xbmcgui.ControlLabel(self.esc_x(x), self.esc_y(y), self.esc_ancho(ancho),
                                       self.esc_alto(alto), texto, font=fuente,
                                       textColor=color, alignment=alineacion)
        self._pendientes.append(control)
        return control

    def rejilla(self, columnas, filas, x0, y0, celda, hueco, color, textura=PIXEL):
        lado_x, lado_y = self.esc_ancho(celda), self.esc_alto(celda)
        controles = [
            [xbmcgui.ControlImage(self.esc_x(x0 + c * (celda + hueco)),
                                  self.esc_y(y0 + f * (celda + hueco)),
                                  lado_x, lado_y, textura, colorDiffuse=color)
             for c in range(columnas)]
            for f in range(filas)]
        self._pendientes += [control for fila in controles for control in fila]
        return controles

    def pie_controles(self, y, plantilla):
        self._pie = plantilla
        self._pie_control = self.etiqueta(0, y, ANCHO, 36, plantilla.format(**botones()),
                                          color=COLOR_TEXTO_SUAVE, alineacion=6)
        self._leyenda = self.etiqueta(0, y + 39, ANCHO, 36, leyenda_dispositivos(),
                                      fuente=FUENTE_PEQUENA, color=COLOR_TEXTO_TENUE,
                                      alineacion=6)

    def repintar_pie(self):
        if getattr(self, '_pie', None) is None:
            return
        self._pie_control.setLabel(self._pie.format(**botones()))
        self._leyenda.setLabel(leyenda_dispositivos())

    def crear_aviso(self, texto):
        self._barra_aviso = self.imagen(0, 474, ANCHO, 90, 'EE0F141A')
        self._texto_aviso = self.etiqueta(0, 492, ANCHO, 60, texto,
                                          fuente=FUENTE_MEDIA, alineacion=6)

    def mostrar_aviso(self, visible, texto=None):
        if texto is not None:
            self._texto_aviso.setLabel(texto)
        self._barra_aviso.setVisible(visible)
        self._texto_aviso.setVisible(visible)

    def crear_overlay(self):
        self._velo = self.imagen_completa(COLOR_VELO)
        self._msj_titulo = self.etiqueta(0, 420, ANCHO, 84, '', fuente=FUENTE_GRANDE,
                                         alineacion=6)
        self._msj_detalle = self.etiqueta(0, 528, ANCHO, 51, '', fuente=FUENTE_MEDIA,
                                          alineacion=6)
        self._msj_ayuda = self.etiqueta(0, 603, ANCHO, 42, '', color=COLOR_TEXTO_SUAVE,
                                        alineacion=6)
        self._momento_overlay = 0.0
        self.volcar()
        self.ocultar_overlay()

    def mostrar_overlay(self, titulo, detalle, ayuda):
        self._momento_overlay = time.monotonic()
        self._velo.setVisible(True)
        for control, texto in ((self._msj_titulo, titulo),
                               (self._msj_detalle, detalle),
                               (self._msj_ayuda, ayuda)):
            control.setLabel(texto)
            control.setVisible(True)

    def ocultar_overlay(self):
        for control in (self._velo, self._msj_titulo, self._msj_detalle, self._msj_ayuda):
            control.setVisible(False)

    def overlay_asentado(self):
        return time.monotonic() - self._momento_overlay >= 0.8

    def alternar_pausa(self):
        self.pausa = not self.pausa
        if self.pausa:
            self.mostrar_overlay('PAUSA', '',
                                 f'{boton("pausa")}: reanudar   ·   {boton("atras")}: salir')
        else:
            self.ocultar_overlay()

    def confirmar_salida(self):
        return xbmcgui.Dialog().yesno('AtresDaily', '¿Salir de la partida?')

    def abrir_ajustes(self):
        estaba = self.pausa
        self.pausa = True
        tactil = _tactil()
        con_mandos = self.tacto is not None and self.tacto.modo != tactil.DIRECTO
        dialogo = xbmcgui.Dialog()
        while True:
            opciones, hacer = ['Seguir jugando'], [None]
            if con_mandos:
                opciones.append(f'Sensibilidad de los mandos: {tactil.nombre_sensibilidad()}')
                hacer.append(tactil.elegir_sensibilidad)
                opciones.append(f'Tamaño de los mandos: {tactil.nombre_tamano()}')
                hacer.append(tactil.cambiar_tamano)
            if self.usa_disparo_automatico:
                marca = 'Sí' if tactil.disparo_automatico() else 'No'
                opciones.append(f'Disparo automático: {marca}')
                hacer.append(tactil.alternar_disparo)
            opciones.append('Salir del juego')
            elegido = dialogo.select('AtresDaily', opciones)
            if not 0 < elegido < len(hacer):
                break
            hacer[elegido](self.tacto)
        if elegido == len(opciones) - 1:
            self.cerrado = True
            self.close()
            return
        self.pausa = estaba


_CLICS_SI_NO_SUENA_NADA, _CLICS_SIEMPRE = 1, 2


def _suenan_los_clics():
    peticion = {'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
                'params': {'setting': 'audiooutput.guisoundmode'}}
    try:
        modo = json.loads(xbmc.executeJSONRPC(json.dumps(peticion)))['result']['value']
    except (ValueError, KeyError, TypeError):
        return False
    if modo == _CLICS_SIEMPRE:
        return True
    return modo == _CLICS_SI_NO_SUENA_NADA and not xbmc.Player().isPlaying()


_RECOGIDA_JUGANDO = (20000, 20, 20)


def _apartar_recolector():
    umbrales = gc.get_threshold()
    gc.collect()
    gc.freeze()
    gc.set_threshold(*_RECOGIDA_JUGANDO)
    return umbrales


def _devolver_recolector(umbrales):
    gc.set_threshold(*umbrales)
    gc.unfreeze()


def _cerrar_al_abortar(ventana):
    monitor = xbmc.Monitor()
    while not ventana.cerrado:
        if monitor.waitForAbort(0.2):
            ventana.cerrado = True
            ventana.close()
            return


def accion_tactil(ventana, accion):
    if ventana.tacto is None:
        return None
    traducida = ventana.tacto.traducir(accion)
    if traducida != _tactil().AJUSTES:
        return traducida
    ventana.abrir_ajustes()
    return None


def direccion_sostenida(ventana):
    if ventana.tacto is None:
        return None
    return ventana.tacto.sostenida()


def punto_tocado(ventana, accion):
    if ventana.tacto is None:
        return None
    return ventana.tacto.punto_tocado(accion)


def dispara_solo(ventana):
    tacto = getattr(ventana, 'tacto', None)
    return tacto is not None and tacto.encendido and tacto.disparo_auto


def arrastre(ventana, accion):
    if ventana.tacto is None:
        return None
    return ventana.tacto.arrastre(accion)


def ejecutar(ventana, hilo=None):
    if getattr(ventana, 'tacto', None) is not None and _tactil().encendido_de_entrada():
        ventana.tacto.mostrar()
    callar = not ventana.sonidos_de_kodi and _suenan_los_clics()
    if callar:
        xbmc.enableNavSounds(False)
    umbrales = _apartar_recolector() if hilo is not None else None
    if hilo is not None:
        hilo.start()
    threading.Thread(target=_cerrar_al_abortar, args=(ventana,), daemon=True).start()
    try:
        ventana.doModal()
    finally:
        ventana.rendimiento.cerrar()
        if umbrales is not None:
            _devolver_recolector(umbrales)
        if callar:
            xbmc.enableNavSounds(True)
        ventana.cerrado = True
        _tactil().olvidar()
        if hilo is not None:
            hilo.join(2)
