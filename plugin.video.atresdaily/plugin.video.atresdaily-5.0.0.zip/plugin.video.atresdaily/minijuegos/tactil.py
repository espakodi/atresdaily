# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/tactil.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from minijuegos import base

MANDO = 'mando'
CRUCETA = 'cruceta'
BOTON = 'boton'
DIRECTO = 'directo'

_CON_CRUZ = (MANDO, CRUCETA)
_CON_BOTON = (MANDO, BOTON)

_PLATAFORMAS_TACTILES = ('Android', 'IOS')

_GESTOS = ((base.TOQUE, base.TOQUE_LARGO, base.GESTO_INICIO, base.GESTO_MOVER,
            base.GESTO_FIN) + tuple(base.DESLIZAR))

_CON_PUNTO = (base.RATON_MOVER, base.RATON_CLIC, base.RATON_DERECHO, base.TOQUE,
              base.TOQUE_LARGO, base.GESTO_INICIO, base.GESTO_MOVER)

EJE_HORIZONTAL = (base.IZQUIERDA, base.DERECHA)
EJE_VERTICAL = (base.ARRIBA, base.ABAJO)
AMBOS_EJES = EJE_HORIZONTAL + EJE_VERTICAL

_TAP_COMPLETO = (base.TOQUE, base.TOQUE_LARGO)

CADUCIDAD_S = 0.7

HUECO_ARRASTRE_S = 0.016

RECORRIDO_MINIMO = 120

RETARDO_MS = 320
CADENCIAS_MS = (200, 120, 60)
CADENCIA_POR_DEFECTO = 1
NOMBRES_SENSIBILIDAD = ('Lenta', 'Normal', 'Rápida')

CRUZ_NORMAL, ACCION_NORMAL = (60, 615, 450), (1600, 760, 260)
CRUZ_GRANDE, ACCION_GRANDE = (60, 495, 570), (1530, 690, 330)
HUECO_MANDO = 10
COLOR_MANDO = '2AFFFFFF'
COLOR_MANDO_PULSADO = '803AC6E8'

RUEDA_X, RUEDA_Y, RUEDA_LADO = 1808, 24, 76
RUEDA_ICONO = 44
RUEDA_MARGEN = 10
COLOR_RUEDA = '99FFFFFF'
AJUSTES = 'ajustes'


def modo_ajustado():
    try:
        return int(xbmcaddon.Addon().getSetting('juegos_mandos_tactiles') or 0)
    except ValueError:
        return 0


def mandos_grandes():
    return xbmcaddon.Addon().getSetting('juegos_mandos_grandes') == 'true'


def geometria(grandes):
    if grandes:
        return CRUZ_GRANDE, ACCION_GRANDE
    return CRUZ_NORMAL, ACCION_NORMAL


def nombre_tamano():
    return 'Extragrande' if mandos_grandes() else 'Normal'


def cambiar_tamano(tacto):
    grandes = not mandos_grandes()
    xbmcaddon.Addon().setSetting('juegos_mandos_grandes', 'true' if grandes else 'false')
    if tacto is not None:
        tacto.redimensionar()


def sensibilidad_ajustada():
    try:
        valor = int(xbmcaddon.Addon().getSetting('juegos_sensibilidad_tactil'))
    except ValueError:
        return CADENCIA_POR_DEFECTO
    return valor if 0 <= valor < len(CADENCIAS_MS) else CADENCIA_POR_DEFECTO


def nombre_sensibilidad():
    return NOMBRES_SENSIBILIDAD[sensibilidad_ajustada()]


def elegir_sensibilidad(tacto):
    elegida = xbmcgui.Dialog().select('Sensibilidad de los mandos',
                                      list(NOMBRES_SENSIBILIDAD))
    if elegida < 0:
        return
    xbmcaddon.Addon().setSetting('juegos_sensibilidad_tactil', str(elegida))
    if tacto is not None:
        tacto.releer_ajustes()


def disparo_automatico():
    return xbmcaddon.Addon().getSetting('juegos_disparo_automatico') != 'false'


def alternar_disparo(tacto):
    xbmcaddon.Addon().setSetting('juegos_disparo_automatico',
                                 'false' if disparo_automatico() else 'true')
    if tacto is not None:
        tacto.releer_ajustes()


def es_tactil():
    return any(xbmc.getCondVisibility(f'System.Platform.{plataforma}')
               for plataforma in _PLATAFORMAS_TACTILES)


def encendido_de_entrada():
    modo = modo_ajustado()
    return modo == 1 or (modo == 0 and es_tactil())


_JUGANDO = [None]


def direccion_en(x, y, cruz, ejes=AMBOS_EJES):
    cruz_x, cruz_y, lado = cruz
    radio = lado / 2
    dx, dy = x - (cruz_x + radio), y - (cruz_y + radio)
    if abs(dx) > radio or abs(dy) > radio:
        return None
    if base.ARRIBA not in ejes:
        dy = 0.0
    elif base.IZQUIERDA not in ejes:
        dx = 0.0
    muerto = lado / 10
    if abs(dx) < muerto and abs(dy) < muerto:
        return None
    if abs(dx) >= abs(dy):
        return base.IZQUIERDA if dx < 0 else base.DERECHA
    return base.ARRIBA if dy < 0 else base.ABAJO


def jugando_con_dedos():
    return _JUGANDO[0]


def olvidar():
    _JUGANDO[0] = None


class Tacto:
    def __init__(self, ventana, modo, ajustes=True, ejes=None):
        self.ventana = ventana
        self.modo = modo
        self.ajustes = ajustes
        self.ejes = AMBOS_EJES if ejes is None else ejes
        self.encendido = False
        self.visible = False
        self.arrastrando = False
        self.grandes = mandos_grandes()
        self.cruz, self.accion = geometria(self.grandes)
        self.cadencia_ms = CADENCIAS_MS[sensibilidad_ajustada()]
        self.disparo_auto = disparo_automatico()
        self._desde_gesto = None
        self._hasta_gesto = None
        self._deslizado = False
        self._atendido = 0.0
        self._pulsada = None
        self._desde = 0.0
        self._caduca = 0.0
        self._repetida = 0.0
        self._controles = []
        self._dibujados = []
        self._zonas = {}
        self._pintada = None
        self._lock = threading.Lock()

    def releer_ajustes(self):
        self.cadencia_ms = CADENCIAS_MS[sensibilidad_ajustada()]
        self.disparo_auto = disparo_automatico()

    def marcar(self):
        self.encendido = True
        _JUGANDO[0] = self.modo

    def activar(self):
        if not self.encendido or _JUGANDO[0] != self.modo:
            self.marcar()
            self.ventana.repintar_pie()
        self.mostrar()

    def mostrar(self):
        if self.visible:
            return
        self.visible = True
        self._zonas = self._zonas_mandos()
        for accion, (x, y, ancho, alto) in self._zonas.items():
            control = self.ventana.imagen(x + HUECO_MANDO, y + HUECO_MANDO,
                                          ancho - 2 * HUECO_MANDO, alto - 2 * HUECO_MANDO,
                                          COLOR_MANDO, base.PIXEL)
            self._controles.append((accion, control))
            self._dibujados.append(control)
        if self.ajustes:
            self._zonas[AJUSTES] = (RUEDA_X, RUEDA_Y, RUEDA_LADO, RUEDA_LADO)
            chapa = self.ventana.imagen(RUEDA_X, RUEDA_Y, RUEDA_LADO, RUEDA_LADO,
                                        COLOR_MANDO, base.CIRCULO)
            self._controles.append((AJUSTES, chapa))
            hueco = (RUEDA_LADO - RUEDA_ICONO) // 2
            self._dibujados += [chapa, self.ventana.imagen(
                RUEDA_X + hueco, RUEDA_Y + hueco, RUEDA_ICONO, RUEDA_ICONO, COLOR_RUEDA,
                base.ICONO_AJUSTES)]
        self.ventana.volcar()

    def _zonas_mandos(self):
        zonas = {}
        if self.modo in _CON_CRUZ:
            cruz_x, cruz_y, lado = self.cruz
            medio = lado // 3
            sitios = ((base.IZQUIERDA, cruz_x, cruz_y + medio),
                      (base.DERECHA, cruz_x + 2 * medio, cruz_y + medio),
                      (base.ARRIBA, cruz_x + medio, cruz_y),
                      (base.ABAJO, cruz_x + medio, cruz_y + 2 * medio))
            for flecha, x, y in sitios:
                if flecha in self.ejes:
                    zonas[flecha] = (x, y, medio, medio)
        if self.modo in _CON_BOTON:
            boton_x, boton_y, lado = self.accion
            zonas[base.ACEPTAR] = (boton_x, boton_y, lado, lado)
        return zonas

    def redimensionar(self):
        self.grandes = mandos_grandes()
        self.cruz, self.accion = geometria(self.grandes)
        if not self.visible:
            return
        self._zonas.update(self._zonas_mandos())
        for accion, control in self._controles:
            if accion == AJUSTES:
                continue
            x, y, ancho, alto = self._zonas[accion]
            control.setPosition(self.ventana.esc_x(x + HUECO_MANDO),
                                self.ventana.esc_y(y + HUECO_MANDO))
            control.setWidth(self.ventana.esc_ancho(ancho - 2 * HUECO_MANDO))
            control.setHeight(self.ventana.esc_alto(alto - 2 * HUECO_MANDO))

    def _pintar(self, pulsada):
        if pulsada == self._pintada:
            return
        self._pintada = pulsada
        for accion, control in self._controles:
            control.setColorDiffuse(COLOR_MANDO_PULSADO if accion == pulsada
                                    else COLOR_MANDO)

    def zona(self, x, y):
        if not self.visible:
            return None
        if (self.ajustes
                and RUEDA_X - RUEDA_MARGEN <= x < RUEDA_X + RUEDA_LADO + RUEDA_MARGEN
                and RUEDA_Y - RUEDA_MARGEN <= y < RUEDA_Y + RUEDA_LADO + RUEDA_MARGEN):
            return AJUSTES
        accion_x, accion_y, lado = self.accion
        if (self.modo in _CON_BOTON and accion_x <= x < accion_x + lado
                and accion_y <= y < accion_y + lado):
            return base.ACEPTAR
        return (direccion_en(x, y, self.cruz, self.ejes)
                if self.modo in _CON_CRUZ else None)

    def _posar(self, zona, ahora):
        estrenada = zona != self._pulsada or ahora > self._caduca
        self._pulsada = zona
        self._caduca = ahora + CADUCIDAD_S
        if estrenada:
            self._desde = ahora
            self._repetida = ahora
            self._pintar(zona)
        return estrenada

    def _toca_repetir(self, ahora):
        if self._pulsada is None or ahora > self._caduca:
            return False
        if ahora - self._desde < RETARDO_MS / 1000:
            return False
        if ahora - self._repetida < self.cadencia_ms / 1000:
            return False
        self._repetida = ahora
        return True

    def sostenida(self):
        with self._lock:
            ahora = time.monotonic()
            if self._pulsada is not None and ahora > self._caduca:
                self.soltar()
                return None
            if self._pulsada in AMBOS_EJES and self._toca_repetir(ahora):
                return self._pulsada
            return None

    def soltar(self):
        self._pulsada = None
        self._pintar(None)

    def es_toque(self, codigo):
        if codigo in (base.TOQUE, base.TOQUE_LARGO):
            return True
        return self.encendido and codigo in (base.RATON_CLIC, base.RATON_DERECHO)

    def punto_tocado(self, accion):
        if self.modo != DIRECTO or not self.es_toque(accion.getId()):
            return None
        return self.ventana.punto_del_raton(accion)

    def arrastre(self, accion):
        if not self.encendido:
            return None
        codigo = accion.getId()
        if codigo not in (base.GESTO_INICIO, base.GESTO_MOVER):
            return None
        ahora = time.monotonic()
        punto = self.ventana.punto_del_raton(accion)
        if codigo == base.GESTO_INICIO:
            self.arrastrando = self.zona(*punto) is None
        elif ahora - self._atendido < HUECO_ARRASTRE_S:
            return None
        self._atendido = ahora
        return punto if self.arrastrando else None

    def traducir(self, accion):
        codigo = accion.getId()

        if codigo in base.DESLIZAR:
            self.activar()
            self._deslizado = True
            return base.DESLIZAR[codigo]

        if codigo == base.GESTO_FIN:
            self.activar()
            self.arrastrando = False
            with self._lock:
                self.soltar()
            return self._direccion_del_gesto()

        if not self.encendido and codigo not in _GESTOS:
            return None
        if codigo not in _CON_PUNTO:
            return None

        self.activar()
        punto = self.ventana.punto_del_raton(accion)
        zona = self.zona(*punto)
        ahora = time.monotonic()

        if codigo == base.GESTO_INICIO:
            self._desde_gesto, self._hasta_gesto, self._deslizado = punto, punto, False
        elif codigo == base.GESTO_MOVER:
            self._hasta_gesto = punto

        if codigo in _TAP_COMPLETO:
            with self._lock:
                self.soltar()
            return zona if zona is not None else self._fuera(codigo, punto)

        if codigo == base.RATON_CLIC:
            with self._lock:
                pulsada = self._pulsada
                self.soltar()
            if zona == AJUSTES:
                return AJUSTES if pulsada == AJUSTES else None
            return (None if pulsada is not None or zona is not None
                    else self._fuera(codigo, punto))

        if codigo == base.RATON_DERECHO:
            with self._lock:
                if self._pulsada is not None:
                    self._caduca = ahora + CADUCIDAD_S
                    return None
            return None if zona is not None else self._fuera(codigo, punto)

        with self._lock:
            if zona is None:
                self.soltar()
                return None
            if not self._posar(zona, ahora) and not self._toca_repetir(ahora):
                return None
            return None if zona == AJUSTES else zona

    def _direccion_del_gesto(self):
        desde, self._desde_gesto = self._desde_gesto, None
        if self.modo != DIRECTO or self._deslizado or desde is None:
            return None
        dx, dy = self._hasta_gesto[0] - desde[0], self._hasta_gesto[1] - desde[1]
        if max(abs(dx), abs(dy)) < RECORRIDO_MINIMO:
            return None
        if abs(dx) >= abs(dy):
            return base.IZQUIERDA if dx < 0 else base.DERECHA
        return base.ARRIBA if dy < 0 else base.ABAJO

    def _fuera(self, codigo, punto):
        if self.modo in _CON_CRUZ:
            cruz_x, cruz_y, lado = self.cruz
            if cruz_x <= punto[0] <= cruz_x + lado and cruz_y <= punto[1] <= cruz_y + lado:
                return None
        if codigo not in (base.TOQUE_LARGO, base.RATON_DERECHO):
            return base.ACEPTAR
        return base.MENU_CONTEXTUAL if self.modo == DIRECTO else None
