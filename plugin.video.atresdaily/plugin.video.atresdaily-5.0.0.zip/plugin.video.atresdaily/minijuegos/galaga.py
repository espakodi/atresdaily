# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/galaga.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import math
import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

CAMPO_X0, CAMPO_X1 = 390, 1530
CAMPO_Y0, CAMPO_Y1 = 174, 942

COLUMNAS = 8
ENEMIGO_ANCHO, ENEMIGO_ALTO = 48, 36
PASO_COL, PASO_FILA = 120, 84
FORMACION_X0 = CAMPO_X0 + (CAMPO_X1 - CAMPO_X0 - (COLUMNAS - 1) * PASO_COL - ENEMIGO_ANCHO) // 2
FORMACION_Y0 = 250

FORMACION = (
    ('jefe', 0, (2, 3, 4, 5)),
    ('mariposa', 1, tuple(range(COLUMNAS))),
    ('mariposa', 2, tuple(range(COLUMNAS))),
    ('abeja', 3, tuple(range(COLUMNAS))),
)
PUNTOS_FORMACION = {'jefe': 150, 'mariposa': 80, 'abeja': 50}
PUNTOS_PICANDO = {'jefe': 400, 'mariposa': 160, 'abeja': 100}
COLORES = {'jefe': 'FF43C46A', 'mariposa': 'FFE8503A', 'abeja': 'FF4FA8E8'}

NAVE_ANCHO, NAVE_ALTO = 54, 42
NAVE_CASCO_ANCHO, NAVE_ALAS_ALTO = 18, 18
NAVE_Y = 860
VEL_NAVE = 21
PARADA_S = 0.18

BALA_ANCHO, BALA_ALTO = 6, 30
VEL_BALA = 33
MAX_BALAS = 2
BALA_ENEMIGA_ANCHO, BALA_ENEMIGA_ALTO = 9, 24
VEL_BALA_ENEMIGA = 12
MAX_BALAS_ENEMIGAS = 6

TICK_MS = 33
VIDAS = 3
TICKS_INVULNERABLE = 45
TICKS_EXPLOSION = 6
TICKS_ESPERA_OLEADA = 30
TICKS_AVISO_OLEADA = 45

VAIVEN_MAX, VAIVEN_PASO, VAIVEN_CADA = 30, 3, 3
RADIO_RIZO, PASOS_RIZO = 170, 14
VEL_ENTRADA, VEL_PICADO = 21, 24
MAX_PICADOS = 5
RETARDO_GRUPO, TAMANO_GRUPO = 9, 4
DESVIO_PICADO = 90
NIVEL_TOPE = 8

ESTRELLAS = 36

NIVELES = ((MAX_PICADOS, DESVIO_PICADO, VIDAS),
           (6,           70,            3),
           (8,           50,            2),
           (10,          35,            2))

COLOR_CAMPO = 'FF0C1119'
COLOR_ESTRELLA = 'FF39465A'
COLOR_NAVE = 'FF9CE8F2'
COLOR_BALA = 'FFFFE066'
COLOR_BALA_ENEMIGA = 'FFFF6B6B'
COLOR_EXPLOSION = 'FFFFC04A'


def _dentro_x(x):
    return min(max(x, CAMPO_X0), CAMPO_X1 - ENEMIGO_ANCHO)


def _solapan(ax, ay, aancho, aalto, bx, by, bancho, balto):
    return (ax < bx + bancho and bx < ax + aancho
            and ay < by + balto and by < ay + aalto)


def _puntos_enemigo(tipo, picando):
    return (PUNTOS_PICANDO if picando else PUNTOS_FORMACION)[tipo]


def _hueco(fila, columna):
    return (FORMACION_X0 + columna * PASO_COL, FORMACION_Y0 + fila * PASO_FILA)


def _ruta_entrada(lado):
    x0 = CAMPO_X0 + 20 if lado < 0 else CAMPO_X1 - ENEMIGO_ANCHO - 20
    centro_x = x0 - lado * RADIO_RIZO
    centro_y = CAMPO_Y0 + 300
    inicio = math.pi if lado < 0 else 0.0
    ruta = [(x0, CAMPO_Y0 + 10)]
    for paso in range(1, PASOS_RIZO + 1):
        angulo = inicio + lado * 2 * math.pi * paso / PASOS_RIZO
        ruta.append((centro_x + RADIO_RIZO * math.cos(angulo),
                     centro_y + RADIO_RIZO * math.sin(angulo)))
    return ruta


def _ruta_picado(x, y, objetivo_x):
    lado = 1 if objetivo_x >= x else -1
    caida = CAMPO_Y1 - 40 - y
    return [
        (_dentro_x(x - lado * 110), y + caida * 0.16),
        (_dentro_x((x + objetivo_x) / 2 + lado * 130), y + caida * 0.48),
        (_dentro_x(objetivo_x), y + caida * 0.80),
        (_dentro_x(objetivo_x - lado * 70), CAMPO_Y1 - 40),
    ]


def _avanzar_hacia(x, y, destino, velocidad):
    dx, dy = destino[0] - x, destino[1] - y
    distancia = math.hypot(dx, dy)
    if distancia <= velocidad:
        return destino[0], destino[1], True
    return x + dx / distancia * velocidad, y + dy / distancia * velocidad, False


class VentanaGalaga(base.Ventana):
    usa_disparo_automatico = True

    def __init__(self):
        super().__init__('Galaga', tactil.MANDO, ejes=tactil.EJE_HORIZONTAL)
        self.marcador = self.etiqueta(210, 126, 360, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_vidas = self.etiqueta(600, 126, 300, 42, f'Vidas: {VIDAS}',
                                       fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_nivel = self.etiqueta(1020, 126, 300, 42, 'Oleada: 1',
                                       fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_record = self.etiqueta(1350, 126, 360, 42, f'Récord: {scores.mejor("galaga")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(CAMPO_X0 - 9, CAMPO_Y0 - 9, CAMPO_X1 - CAMPO_X0 + 18,
                    CAMPO_Y1 - CAMPO_Y0 + 18, base.COLOR_MARCO)
        self.imagen(CAMPO_X0, CAMPO_Y0, CAMPO_X1 - CAMPO_X0, CAMPO_Y1 - CAMPO_Y0, COLOR_CAMPO)
        for _ in range(ESTRELLAS):
            self.imagen(random.randint(CAMPO_X0 + 4, CAMPO_X1 - 8),
                        random.randint(CAMPO_Y0 + 4, CAMPO_Y1 - 8), 3, 3, COLOR_ESTRELLA)

        self.enemigos = []
        for tipo, fila, columnas in FORMACION:
            for columna in columnas:
                casa = _hueco(fila, columna)
                control = self.imagen(casa[0], casa[1], ENEMIGO_ANCHO, ENEMIGO_ALTO,
                                      COLORES[tipo])
                control.setVisible(False)
                self.enemigos.append({'control': control, 'tipo': tipo, 'casa': casa,
                                      'x': float(casa[0]), 'y': float(casa[1]),
                                      'estado': 'muerto', 'ruta': (), 'paso': 0,
                                      'retardo': 0, 'explosion': 0,
                                      'color': COLORES[tipo], 'visible': False})

        self.balas = [self._crear_bala(BALA_ANCHO, BALA_ALTO, COLOR_BALA)
                      for _ in range(MAX_BALAS)]
        self.balas_enemigas = [self._crear_bala(BALA_ENEMIGA_ANCHO, BALA_ENEMIGA_ALTO,
                                                COLOR_BALA_ENEMIGA)
                               for _ in range(MAX_BALAS_ENEMIGAS)]
        centro = (CAMPO_X0 + CAMPO_X1 - NAVE_ANCHO) / 2
        self.nave = (
            self.imagen(centro + (NAVE_ANCHO - NAVE_CASCO_ANCHO) // 2, NAVE_Y,
                        NAVE_CASCO_ANCHO, NAVE_ALTO, COLOR_NAVE),
            self.imagen(centro, NAVE_Y + NAVE_ALTO - NAVE_ALAS_ALTO, NAVE_ANCHO,
                        NAVE_ALAS_ALTO, COLOR_NAVE),
        )
        self._casco_py = self.esc_y(NAVE_Y)
        self._alas_py = self.esc_y(NAVE_Y + NAVE_ALTO - NAVE_ALAS_ALTO)
        self.pie_controles(CAMPO_Y1 + 27,
                           'Mover: {llevar}   ·   '
                           'Disparar: {ok}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.lab_oleada = self.etiqueta(0, 615, base.ANCHO, 60, '', fuente=base.FUENTE_GRANDE,
                                        alineacion=6)
        self.lab_oleada.setVisible(False)
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _crear_bala(self, ancho, alto, color):
        control = self.imagen(CAMPO_X0 + 60, CAMPO_Y0 + 60, ancho, alto, color)
        control.setVisible(False)
        return {'control': control, 'x': 0.0, 'y': 0.0, 'activa': False}

    def _reiniciar(self):
        self.max_picados, self.desvio_picado, self.vidas = NIVELES[dificultad.nivel()]
        self.puntos = 0
        self.nivel = 1
        self.paso = 0
        self.vx = 0.0
        self.ultimo_movimiento = 0.0
        self.invulnerable = 0
        self.nave_x = (CAMPO_X0 + CAMPO_X1 - NAVE_ANCHO) / 2
        self.en_marcha = False
        self.marcador.setLabel('Puntos: 0')
        self.lab_vidas.setLabel(f'Vidas: {self.vidas}')
        self._nave_visible = None
        self._ensenar_nave(True)
        self._colocar_nave()
        self._apagar_balas()
        self._nueva_oleada()
        self.pausa = False
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _nueva_oleada(self):
        self.vaiven = 0
        self.vaiven_dir = 1
        self.espera_oleada = TICKS_ESPERA_OLEADA
        self.lab_nivel.setLabel(f'Oleada: {self.nivel}')
        self.lab_oleada.setLabel(f'OLEADA {self.nivel}')
        self.lab_oleada.setVisible(True)
        self.aviso_oleada = TICKS_AVISO_OLEADA
        for indice, enemigo in enumerate(self.enemigos):
            lado = -1 if (indice // TAMANO_GRUPO) % 2 else 1
            enemigo['estado'] = 'entrando'
            enemigo['ruta'] = _ruta_entrada(lado)
            enemigo['paso'] = 0
            enemigo['retardo'] = (indice // TAMANO_GRUPO) * RETARDO_GRUPO + indice % TAMANO_GRUPO
            enemigo['explosion'] = 0
            enemigo['x'], enemigo['y'] = enemigo['ruta'][0]
            self._ensenar(enemigo, False)

    @staticmethod
    def _pintar(enemigo, color):
        if enemigo['color'] != color:
            enemigo['color'] = color
            enemigo['control'].setColorDiffuse(color)

    @staticmethod
    def _ensenar(enemigo, visible):
        if enemigo['visible'] != visible:
            enemigo['visible'] = visible
            enemigo['control'].setVisible(visible)

    def _ensenar_nave(self, visible):
        if self._nave_visible != visible:
            self._nave_visible = visible
            for control in self.nave:
                control.setVisible(visible)

    def _colocar(self, control, x, y):
        control.setPosition(self.esc_x(x), self.esc_y(y))

    def _colocar_nave(self):
        self.nave[0].setPosition(
            self.esc_x(self.nave_x + (NAVE_ANCHO - NAVE_CASCO_ANCHO) // 2), self._casco_py)
        self.nave[1].setPosition(self.esc_x(self.nave_x), self._alas_py)

    def _colocar_enemigo(self, enemigo, x, y):
        enemigo['x'], enemigo['y'] = x, y
        self._colocar(enemigo['control'], x, y)

    def _apagar(self, bala):
        bala['activa'] = False
        bala['control'].setVisible(False)

    def _apagar_balas(self):
        for bala in self.balas + self.balas_enemigas:
            self._apagar(bala)

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Galaga, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def _tick(self):
        sostenida = base.direccion_sostenida(self)
        if sostenida in (base.IZQUIERDA, base.DERECHA):
            self._empujar_nave(sostenida)
        if self.en_marcha and self.vivo and base.dispara_solo(self):
            self._disparar()
        self.paso += 1
        if self.aviso_oleada:
            self.aviso_oleada -= 1
            if not self.aviso_oleada:
                self.lab_oleada.setVisible(False)
        self._mover_nave()
        if self.paso % VAIVEN_CADA == 0:
            self._mover_formacion()
        self._mover_enemigos()
        if not self.vivo:
            return
        self._mover_balas()
        if not self.vivo:
            return
        self._disparo_enemigo()
        self._lanzar_picado()
        if all(enemigo['estado'] == 'muerto' for enemigo in self.enemigos):
            self.espera_oleada -= 1
            if self.espera_oleada <= 0:
                self.nivel += 1
                self._nueva_oleada()

    def _mover_nave(self):
        if self.invulnerable:
            self.invulnerable -= 1
            self._ensenar_nave(not self.invulnerable or (self.invulnerable // 3) % 2 == 0)
        if self.vx and time.monotonic() - self.ultimo_movimiento > PARADA_S:
            self.vx = 0.0
        if not self.vx:
            return
        self._poner_nave(self.nave_x + self.vx)

    def _poner_nave(self, x):
        x = min(max(x, CAMPO_X0), CAMPO_X1 - NAVE_ANCHO)
        if x == self.nave_x:
            return
        self.nave_x = x
        self._colocar_nave()

    def _mover_formacion(self):
        self.vaiven += self.vaiven_dir * VAIVEN_PASO
        if abs(self.vaiven) >= VAIVEN_MAX:
            self.vaiven_dir = -self.vaiven_dir
        for enemigo in self.enemigos:
            if enemigo['estado'] == 'formacion':
                self._colocar_enemigo(enemigo, enemigo['casa'][0] + self.vaiven,
                                      enemigo['casa'][1])

    def _mover_enemigos(self):
        for enemigo in self.enemigos:
            estado = enemigo['estado']
            if estado == 'muerto':
                if enemigo['explosion']:
                    enemigo['explosion'] -= 1
                    if not enemigo['explosion']:
                        self._ensenar(enemigo, False)
                continue
            if enemigo['retardo']:
                enemigo['retardo'] -= 1
                continue
            if not enemigo['visible']:
                self._pintar(enemigo, COLORES[enemigo['tipo']])
                self._colocar(enemigo['control'], enemigo['x'], enemigo['y'])
                self._ensenar(enemigo, True)
            if estado == 'formacion':
                continue
            if estado == 'volviendo':
                destino = (enemigo['casa'][0] + self.vaiven, enemigo['casa'][1])
                velocidad = VEL_ENTRADA
            else:
                destino = enemigo['ruta'][enemigo['paso']]
                velocidad = (VEL_ENTRADA if estado == 'entrando'
                             else VEL_PICADO + min(self.nivel, NIVEL_TOPE))
            x, y, llegado = _avanzar_hacia(enemigo['x'], enemigo['y'], destino, velocidad)
            self._colocar_enemigo(enemigo, x, y)
            if estado == 'picado' and self._choca_con_nave(x, y):
                self._matar(enemigo)
                self._impacto_nave()
                if not self.vivo:
                    return
                continue
            if not llegado:
                continue
            if estado == 'volviendo':
                enemigo['estado'] = 'formacion'
            elif enemigo['paso'] + 1 < len(enemigo['ruta']):
                enemigo['paso'] += 1
            elif estado == 'entrando':
                enemigo['estado'] = 'volviendo'
            else:
                enemigo['estado'] = 'volviendo'
                self._colocar_enemigo(enemigo, x, float(CAMPO_Y0))

    def _choca_con_nave(self, x, y):
        return not self.invulnerable and _solapan(
            x, y, ENEMIGO_ANCHO, ENEMIGO_ALTO,
            self.nave_x, NAVE_Y, NAVE_ANCHO, NAVE_ALTO)

    def _mover_balas(self):
        for bala in self.balas:
            if not bala['activa']:
                continue
            bala['y'] -= VEL_BALA
            if bala['y'] + BALA_ALTO < CAMPO_Y0:
                self._apagar(bala)
                continue
            if self._impacto_enemigo(bala):
                continue
            self._colocar(bala['control'], bala['x'], bala['y'])
        for bala in self.balas_enemigas:
            if not bala['activa']:
                continue
            bala['y'] += VEL_BALA_ENEMIGA + min(self.nivel, NIVEL_TOPE)
            if bala['y'] > CAMPO_Y1:
                self._apagar(bala)
                continue
            self._colocar(bala['control'], bala['x'], bala['y'])
            if not self.invulnerable and _solapan(
                    bala['x'], bala['y'], BALA_ENEMIGA_ANCHO, BALA_ENEMIGA_ALTO,
                    self.nave_x, NAVE_Y, NAVE_ANCHO, NAVE_ALTO):
                self._apagar(bala)
                self._impacto_nave()
                return

    def _impacto_enemigo(self, bala):
        arriba, abajo = bala['y'] - ENEMIGO_ALTO, bala['y'] + BALA_ALTO
        for enemigo in self.enemigos:
            if enemigo['estado'] == 'muerto' or enemigo['retardo']:
                continue
            if not arriba < enemigo['y'] < abajo:
                continue
            if not _solapan(bala['x'], bala['y'], BALA_ANCHO, BALA_ALTO,
                            enemigo['x'], enemigo['y'], ENEMIGO_ANCHO, ENEMIGO_ALTO):
                continue
            self._apagar(bala)
            self._matar(enemigo)
            return True
        return False

    def _matar(self, enemigo):
        self.puntos += _puntos_enemigo(enemigo['tipo'], enemigo['estado'] == 'picado')
        enemigo['estado'] = 'muerto'
        enemigo['explosion'] = TICKS_EXPLOSION
        self._pintar(enemigo, COLOR_EXPLOSION)
        self.marcador.setLabel(f'Puntos: {self.puntos}')

    def _impacto_nave(self):
        self.vidas -= 1
        self.lab_vidas.setLabel(f'Vidas: {self.vidas}')
        self._apagar_balas()
        if self.vidas <= 0:
            self._fin()
            return
        self.nave_x = (CAMPO_X0 + CAMPO_X1 - NAVE_ANCHO) / 2
        self.vx = 0.0
        self._colocar_nave()
        self.invulnerable = TICKS_INVULNERABLE

    def _disparo_enemigo(self):
        if self.paso % max(9, 34 - self.nivel * 3):
            return
        tiradores = [e for e in self.enemigos
                     if e['estado'] in ('picado', 'entrando') and not e['retardo']]
        if not tiradores:
            return
        enemigo = random.choice(tiradores)
        for bala in self.balas_enemigas:
            if bala['activa']:
                continue
            bala['activa'] = True
            bala['x'] = enemigo['x'] + (ENEMIGO_ANCHO - BALA_ENEMIGA_ANCHO) / 2
            bala['y'] = enemigo['y'] + ENEMIGO_ALTO
            bala['control'].setVisible(True)
            self._colocar(bala['control'], bala['x'], bala['y'])
            return

    def _lanzar_picado(self):
        if self.paso % max(20, 95 - self.nivel * 10):
            return
        picando = sum(1 for e in self.enemigos if e['estado'] == 'picado')
        if picando >= min(self.max_picados, 1 + self.nivel):
            return
        candidatos = [e for e in self.enemigos if e['estado'] == 'formacion']
        if not candidatos:
            return
        enemigo = random.choice(candidatos)
        objetivo = self.nave_x + random.uniform(-self.desvio_picado, self.desvio_picado)
        enemigo['estado'] = 'picado'
        enemigo['ruta'] = _ruta_picado(enemigo['x'], enemigo['y'], objetivo)
        enemigo['paso'] = 0

    def _disparar(self):
        for bala in self.balas:
            if bala['activa']:
                continue
            bala['activa'] = True
            bala['x'] = self.nave_x + (NAVE_ANCHO - BALA_ANCHO) / 2
            bala['y'] = float(NAVE_Y - BALA_ALTO)
            bala['control'].setVisible(True)
            self._colocar(bala['control'], bala['x'], bala['y'])
            return

    def _fin(self):
        self.en_marcha = False
        self.lab_oleada.setVisible(False)
        es_record = scores.registrar('galaga', self.puntos)
        detalle = f'Puntos: {self.puntos}   ·   oleada {self.nivel}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        punto = base.arrastre(self, action)
        if punto is not None and not self.pausa:
            with self.lock:
                if not self.vivo:
                    return
                if not self.en_marcha:
                    self.en_marcha = True
                    self.mostrar_aviso(False)
                self.vx = 0.0
                self._poner_nave(punto[0] - NAVE_ANCHO / 2)
            return
        if self.pausa or accion not in (base.IZQUIERDA, base.DERECHA, base.ACEPTAR):
            return
        with self.lock:
            if not self.vivo:
                return
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            if accion == base.ACEPTAR:
                self._disparar()
            else:
                self._empujar_nave(accion)

    def _empujar_nave(self, accion):
        self.vx = -VEL_NAVE if accion == base.IZQUIERDA else VEL_NAVE
        self.ultimo_movimiento = time.monotonic()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaGalaga()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
