# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/pong.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import math
import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

TECHO, SUELO = 186, 966
TICK_MS = 33

ANCHO_PALA, ALTO_PALA = 24, 168
PALA_X = 96
PALA_CPU_X = base.ANCHO - PALA_X - ANCHO_PALA
PASO_PALA = 54
LADO_BOLA = 24

VEL_SAQUE = 18.0
VEL_POR_PUNTO = 1.5
ACELERON = 1.04
VEL_MAXIMA = 120.0
ANGULO_MAXIMO = math.radians(55)
ANGULO_SAQUE = math.radians(20)
ANGULO_MINIMO = math.radians(10)

VEL_CPU_SAQUE = 11.0
VEL_CPU_POR_PUNTO = 1.1
VEL_CPU_MAXIMA = 30.0

FALLOS_MAXIMOS = 3
TICKS_SAQUE = 18

NIVELES = ((VEL_SAQUE, ACELERON, VEL_CPU_SAQUE, VEL_CPU_MAXIMA, FALLOS_MAXIMOS),
           (24.0,      1.06,     13.0,          36.0,           2),
           (30.0,      1.08,     15.0,          42.0,           1),
           (36.0,      1.10,     17.0,          48.0,           1))

COLOR_PISTA = 'FF141A22'
COLOR_PALA = 'FF6FE3A8'
COLOR_PALA_CPU = 'FFE85D4A'
COLOR_BOLA = 'FFE8ECEF'


class VentanaPong(base.Ventana):
    def __init__(self):
        super().__init__('Pong', tactil.CRUCETA, ejes=tactil.EJE_VERTICAL)
        self.marcador = self.etiqueta(120, 126, 600, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_estado = self.etiqueta(0, 126, base.ANCHO, 42, '', fuente=base.FUENTE_MEDIA,
                                        alineacion=6)
        self.lab_record = self.etiqueta(base.ANCHO - 720, 126, 600, 42,
                                        f'Récord: {scores.mejor("pong")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(0, TECHO - 6, base.ANCHO, 6, base.COLOR_MARCO)
        self.imagen(0, TECHO, base.ANCHO, SUELO - TECHO, COLOR_PISTA)
        self.imagen(0, SUELO, base.ANCHO, 6, base.COLOR_MARCO)
        for y in range(TECHO + 18, SUELO - 36, 54):
            self.imagen(base.ANCHO // 2 - 3, y, 6, 30, base.COLOR_MARCO)

        self.control_pala = self.imagen(PALA_X, TECHO, ANCHO_PALA, ALTO_PALA, COLOR_PALA)
        self.control_cpu = self.imagen(PALA_CPU_X, TECHO, ANCHO_PALA, ALTO_PALA, COLOR_PALA_CPU)
        self.control_bola = self.imagen(0, TECHO, LADO_BOLA, LADO_BOLA, COLOR_BOLA)
        self._pala_px = self.esc_x(PALA_X)
        self._cpu_px = self.esc_x(PALA_CPU_X)

        self.pie_controles(SUELO + 27,
                           'Mover: {llevar}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        (self.vel_saque, self.aceleron, self.vel_cpu_saque, self.vel_cpu_tope,
         self.fallos_maximos) = NIVELES[dificultad.nivel()]
        self.en_marcha = False
        self.pausa = False
        self.puntos = 0
        self.fallos = 0
        self.pala_y = (TECHO + SUELO - ALTO_PALA) / 2
        self.cpu_y = self.pala_y
        self.marcador.setLabel('Puntos: 0')
        self._actualizar_estado()
        self._colocar_pala()
        self._colocar_cpu()
        self._sacar(hacia_jugador=True)
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _sacar(self, hacia_jugador):
        self.bola_x = (base.ANCHO - LADO_BOLA) / 2
        self.bola_y = (TECHO + SUELO - LADO_BOLA) / 2
        self.velocidad = min(VEL_MAXIMA, self.vel_saque + self.puntos * VEL_POR_PUNTO)
        angulo = random.uniform(-ANGULO_SAQUE, ANGULO_SAQUE)
        self.vx = (-1 if hacia_jugador else 1) * self.velocidad * math.cos(angulo)
        self.vy = self.velocidad * math.sin(angulo)
        self.espera = TICKS_SAQUE
        self._colocar_bola()

    def _colocar_pala(self):
        self.control_pala.setPosition(self._pala_px, self.esc_y(self.pala_y))

    def _colocar_cpu(self):
        self.control_cpu.setPosition(self._cpu_px, self.esc_y(self.cpu_y))

    def _colocar_bola(self):
        self.control_bola.setPosition(self.esc_x(self.bola_x), self.esc_y(self.bola_y))

    def _actualizar_estado(self):
        self.lab_estado.setLabel(f'Fallos: {self.fallos} de {self.fallos_maximos}')

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Pong, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def _tick(self):
        sostenida = base.direccion_sostenida(self)
        if sostenida is not None:
            self._mover_pala(sostenida)
        if self.espera:
            self.espera -= 1
            return
        self._mover_cpu()
        previo_x, previo_y = self.bola_x, self.bola_y
        self.bola_x += self.vx
        self.bola_y += self.vy
        self._revisar_palas(previo_x, previo_y)
        self._rebotar_en_bordes()
        if self.bola_x + LADO_BOLA < 0:
            self._fallo()
            return
        if self.bola_x > base.ANCHO:
            self._tanto()
            return
        self._colocar_bola()

    def _mover_cpu(self):
        if self.vx < 0 or self.bola_x + LADO_BOLA / 2 < base.ANCHO / 2:
            return
        tope = min(self.vel_cpu_tope, self.vel_cpu_saque + self.puntos * VEL_CPU_POR_PUNTO)
        objetivo = self.bola_y + LADO_BOLA / 2 - ALTO_PALA / 2
        self.cpu_y += max(-tope, min(tope, objetivo - self.cpu_y))
        self.cpu_y = max(TECHO, min(SUELO - ALTO_PALA, self.cpu_y))
        self._colocar_cpu()

    def _rebotar_en_bordes(self):
        if self.bola_y < TECHO:
            self.bola_y = 2 * TECHO - self.bola_y
            self.vy = -self.vy
        elif self.bola_y + LADO_BOLA > SUELO:
            self.bola_y = 2 * (SUELO - LADO_BOLA) - self.bola_y
            self.vy = -self.vy

    def _revisar_palas(self, previo_x, previo_y):
        plano_jugador = PALA_X + ANCHO_PALA
        if self.vx < 0 and previo_x >= plano_jugador > self.bola_x:
            if self._golpea(self.pala_y, previo_x, previo_y, plano_jugador):
                self.bola_x = float(plano_jugador)
                self._devolver(self.pala_y, 1)
            return
        plano_cpu = PALA_CPU_X - LADO_BOLA
        if self.vx > 0 and previo_x <= plano_cpu < self.bola_x:
            if self._golpea(self.cpu_y, previo_x, previo_y, plano_cpu):
                self.bola_x = float(plano_cpu)
                self._devolver(self.cpu_y, -1)

    def _golpea(self, pala_y, previo_x, previo_y, plano):
        recorrido = (plano - previo_x) / (self.bola_x - previo_x)
        y = previo_y + (self.bola_y - previo_y) * recorrido
        y = max(TECHO, min(SUELO - LADO_BOLA, y))
        return pala_y - LADO_BOLA <= y <= pala_y + ALTO_PALA

    def _devolver(self, pala_y, sentido):
        desde_centro = self.bola_y + LADO_BOLA / 2 - (pala_y + ALTO_PALA / 2)
        desvio = max(-1.0, min(1.0, desde_centro / (ALTO_PALA / 2)))
        angulo = desvio * ANGULO_MAXIMO
        if abs(angulo) < ANGULO_MINIMO:
            angulo = math.copysign(ANGULO_MINIMO, desde_centro)
        self.velocidad = min(VEL_MAXIMA, self.velocidad * self.aceleron)
        self.vx = sentido * self.velocidad * math.cos(angulo)
        self.vy = self.velocidad * math.sin(angulo)

    def _tanto(self):
        self.puntos += 1
        self.marcador.setLabel(f'Puntos: {self.puntos}')
        self._sacar(hacia_jugador=False)

    def _fallo(self):
        self.fallos += 1
        self._actualizar_estado()
        if self.fallos >= self.fallos_maximos:
            self._fin()
            return
        self._sacar(hacia_jugador=True)

    def _fin(self):
        self.en_marcha = False
        es_record = scores.registrar('pong', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        punto = base.arrastre(self, action)
        if punto is not None:
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            with self.lock:
                if self.vivo:
                    self._poner_pala(punto[1] - ALTO_PALA / 2)
            return
        if accion not in (base.ARRIBA, base.ABAJO, base.ACEPTAR):
            return
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)
        with self.lock:
            if not self.vivo:
                return
            self._mover_pala(accion)

    def _mover_pala(self, accion):
        if accion == base.ARRIBA:
            self._poner_pala(self.pala_y - PASO_PALA)
        elif accion == base.ABAJO:
            self._poner_pala(self.pala_y + PASO_PALA)

    def _poner_pala(self, y):
        y = min(max(y, TECHO), SUELO - ALTO_PALA)
        if y == self.pala_y:
            return
        self.pala_y = y
        self._colocar_pala()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaPong()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
