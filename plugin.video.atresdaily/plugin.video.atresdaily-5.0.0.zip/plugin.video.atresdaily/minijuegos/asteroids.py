# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/asteroids.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import math
import os
import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

BOLA = os.path.join(base.MEDIA, 'bola.png')
MEDIA_NAVE = os.path.join(base.MEDIA, 'nave')

TECHO, SUELO = 165, 960
CAMPO_ALTO = SUELO - TECHO
TICK_MS = 33

ORIENTACIONES = 16
EMPUJE = 1.6
ROZAMIENTO = .985
FRENO = .82
VEL_MAX = 20.0

MORRO = 30
CAJA_NAVE = 33
ENVOLTURA_NAVE = 78
LADO_NAVE = 96
TICKS_LLAMA = 6

BALA_LADO = 9
BALAS_MAX = 4
VEL_BALA = 30.0
BALA_TICKS = 36

LADOS = {3: 96, 2: 57, 1: 33}
PUNTOS = {3: 20, 2: 50, 1: 100}
VELOCIDADES = {3: (3.0, 5.5), 2: (4.5, 7.5), 1: (6.0, 10.0)}
FACTOR_CRIA = 1.15
GRANDES_MAX = 6
ROCAS_MAX = 4 * GRANDES_MAX

VIDAS = 3
DISTANCIA_SEGURA = 240

NIVELES = ((0,           1.00,      VIDAS),
           (1,           1.25,      3),
           (2,           1.50,      2),
           (3,           1.80,      2))
TICKS_ESPERA = 30
TICKS_INVULNERABLE = 60
TICKS_PARPADEO = 5

COLOR_ESPACIO = 'FF0B1017'
COLOR_BALA = 'FFE8C34A'
COLOR_ROCA = 'FF8A97A5'
SIN_TENIR = 'FFFFFFFF'


def _rotar(punto, pasos):
    angulo = pasos * 2 * math.pi / ORIENTACIONES
    seno, coseno = math.sin(angulo), math.cos(angulo)
    x, y = punto
    return x * coseno - y * seno, x * seno + y * coseno


DIRECCIONES = tuple(_rotar((0, -1), paso) for paso in range(ORIENTACIONES))


def _texturas(paso):
    return (os.path.join(MEDIA_NAVE, f'{paso}.png'),
            os.path.join(MEDIA_NAVE, f'{paso}-llama.png'))


def _envolver(x, y, lado):
    mitad = lado / 2
    if x < -mitad:
        x += base.ANCHO + lado
    elif x > base.ANCHO + mitad:
        x -= base.ANCHO + lado
    if y < TECHO - mitad:
        y += CAMPO_ALTO + lado
    elif y > SUELO + mitad:
        y -= CAMPO_ALTO + lado
    return x, y


def _chocan(x1, y1, lado1, x2, y2, lado2):
    dx, dy = x1 - x2, y1 - y2
    alcance = (lado1 + lado2) / 2
    return dx * dx + dy * dy < alcance * alcance


class VentanaAsteroids(base.Ventana):
    def __init__(self):
        super().__init__('Asteroids', tactil.MANDO)
        self.marcador = self.etiqueta(120, 126, 420, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_vidas = self.etiqueta(600, 126, 330, 42, '', fuente=base.FUENTE_MEDIA,
                                       alineacion=6)
        self.lab_oleada = self.etiqueta(990, 126, 330, 42, '', fuente=base.FUENTE_MEDIA,
                                        alineacion=6)
        self.lab_record = self.etiqueta(1380, 126, 420, 42,
                                        f'Récord: {scores.mejor("asteroids")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(0, TECHO - 6, base.ANCHO, 6, base.COLOR_MARCO)
        self.imagen(0, TECHO, base.ANCHO, CAMPO_ALTO, COLOR_ESPACIO)
        self.imagen(0, SUELO, base.ANCHO, 6, base.COLOR_MARCO)

        centro_x, centro_y = base.ANCHO / 2, (TECHO + SUELO) / 2
        self.libres_rocas = [self._crear_punto(centro_x, centro_y, LADOS[3], COLOR_ROCA)
                             for _ in range(ROCAS_MAX)]
        self.libres_balas = [self._crear_punto(centro_x, centro_y, BALA_LADO, COLOR_BALA)
                             for _ in range(BALAS_MAX)]
        for control in self.libres_rocas + self.libres_balas:
            control.setVisible(False)

        self.naves = [tuple(self.imagen(centro_x - LADO_NAVE / 2, centro_y - LADO_NAVE / 2,
                                        LADO_NAVE, LADO_NAVE, SIN_TENIR, textura)
                            for textura in _texturas(paso))
                      for paso in range(ORIENTACIONES)]
        for pareja in self.naves:
            for control in pareja:
                control.setVisible(False)
        self._nave_a_la_vista = False
        self._nave_puesta = None
        self._nave_sitio = None

        self.pie_controles(SUELO + 27,
                           'Girar y empujar: {mover}'
                           '   ·   Disparar: {ok}'
                           '   ·   Frenar: abajo'
                           '   ·   Pausa: {pausa}'
                           '   ·   Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self.asteroides = []
        self.balas = []
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _crear_punto(self, x, y, lado, color):
        return self.imagen(x - lado / 2, y - lado / 2, lado, lado, color, BOLA)

    def _reiniciar(self):
        self.rocas_de_mas, self.vel_rocas, self.vidas = NIVELES[dificultad.nivel()]
        self.en_marcha = False
        self.pausa = False
        self.puntos = 0
        self.oleada = 0
        self.espera = 0
        self.invulnerable = 0
        self.llama = 0
        for roca in list(self.asteroides):
            self._retirar_roca(roca)
        for bala in list(self.balas):
            self._retirar_bala(bala)
        self.x, self.y = base.ANCHO / 2, (TECHO + SUELO) / 2
        self.vx = self.vy = 0.0
        self.orientacion = 0
        self.marcador.setLabel('Puntos: 0')
        self.lab_vidas.setLabel(f'Vidas: {self.vidas}')
        self._nueva_oleada()
        self._mostrar_nave(True)
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _tomar_control(self, libres, x, y, lado):
        control = libres.pop()
        control.setWidth(self.esc_ancho(lado))
        control.setHeight(self.esc_alto(lado))
        control.setPosition(self.esc_x(x - lado / 2), self.esc_y(y - lado / 2))
        control.setVisible(True)
        return control

    def _crear_roca(self, clase, x, y, vx, vy):
        self.asteroides.append({
            'clase': clase, 'x': x, 'y': y, 'vx': vx, 'vy': vy,
            'control': self._tomar_control(self.libres_rocas, x, y, LADOS[clase]),
        })

    def _retirar_roca(self, roca):
        roca['control'].setVisible(False)
        self.libres_rocas.append(roca['control'])
        self.asteroides.remove(roca)

    def _retirar_bala(self, bala):
        bala['control'].setVisible(False)
        self.libres_balas.append(bala['control'])
        self.balas.remove(bala)

    def _sitio_libre(self, lado):
        for _ in range(20):
            x = random.uniform(lado, base.ANCHO - lado)
            y = random.uniform(TECHO + lado, SUELO - lado)
            if abs(x - self.x) > DISTANCIA_SEGURA or abs(y - self.y) > DISTANCIA_SEGURA:
                break
        return x, y

    def _nueva_oleada(self):
        self.oleada += 1
        self.lab_oleada.setLabel(f'Oleada: {self.oleada}')
        for _ in range(min(GRANDES_MAX, 2 + self.oleada + self.rocas_de_mas)):
            x, y = self._sitio_libre(LADOS[3])
            dx, dy = DIRECCIONES[random.randrange(ORIENTACIONES)]
            velocidad = random.uniform(*VELOCIDADES[3]) * self.vel_rocas
            self._crear_roca(3, x, y, dx * velocidad, dy * velocidad)

    def _partir(self, roca):
        self.puntos += PUNTOS[roca['clase']]
        self.marcador.setLabel(f'Puntos: {self.puntos}')
        clase = roca['clase'] - 1
        x, y, vx, vy = roca['x'], roca['y'], roca['vx'], roca['vy']
        self._retirar_roca(roca)
        if not clase:
            return
        for giro in (-2, 2):
            cria_vx, cria_vy = _rotar((vx, vy), giro)
            self._crear_roca(clase, x, y, cria_vx * FACTOR_CRIA, cria_vy * FACTOR_CRIA)

    def _roca_tocada(self, bala):
        for roca in self.asteroides:
            if _chocan(bala['x'], bala['y'], BALA_LADO,
                       roca['x'], roca['y'], LADOS[roca['clase']]):
                return roca
        return None

    def _mover_balas(self):
        for bala in list(self.balas):
            bala['ticks'] -= 1
            bala['x'], bala['y'] = _envolver(bala['x'] + bala['vx'],
                                             bala['y'] + bala['vy'], BALA_LADO)
            roca = self._roca_tocada(bala)
            if roca is not None:
                self._retirar_bala(bala)
                self._partir(roca)
            elif bala['ticks'] <= 0:
                self._retirar_bala(bala)
            else:
                bala['control'].setPosition(self.esc_x(bala['x'] - BALA_LADO / 2),
                                            self.esc_y(bala['y'] - BALA_LADO / 2))

    def _mover_asteroides(self):
        for roca in self.asteroides:
            lado = LADOS[roca['clase']]
            roca['x'], roca['y'] = _envolver(roca['x'] + roca['vx'], roca['y'] + roca['vy'], lado)
            roca['control'].setPosition(self.esc_x(roca['x'] - lado / 2),
                                        self.esc_y(roca['y'] - lado / 2))

    def _mover_nave(self):
        self.vx *= ROZAMIENTO
        self.vy *= ROZAMIENTO
        self.x, self.y = _envolver(self.x + self.vx, self.y + self.vy, ENVOLTURA_NAVE)
        if self.llama:
            self.llama -= 1
        self._pintar_nave()

    def _pintar_nave(self):
        if not self._nave_a_la_vista:
            return
        control = self.naves[self.orientacion][bool(self.llama)]
        sitio = (self.esc_x(self.x - LADO_NAVE / 2), self.esc_y(self.y - LADO_NAVE / 2))
        cambia_dibujo = control is not self._nave_puesta
        if not cambia_dibujo and sitio == self._nave_sitio:
            return
        control.setPosition(*sitio)
        self._nave_sitio = sitio
        if cambia_dibujo:
            control.setVisible(True)
            if self._nave_puesta is not None:
                self._nave_puesta.setVisible(False)
            self._nave_puesta = control

    def _mostrar_nave(self, visible):
        if visible:
            self._nave_a_la_vista = True
            self._pintar_nave()
        elif self._nave_a_la_vista:
            self._nave_a_la_vista = False
            self._nave_puesta.setVisible(False)
            self._nave_puesta = None

    def _nave_golpeada(self):
        return any(_chocan(self.x, self.y, CAJA_NAVE,
                           roca['x'], roca['y'], LADOS[roca['clase']])
                   for roca in self.asteroides)

    def _perder_vida(self):
        self.vidas -= 1
        self.lab_vidas.setLabel(f'Vidas: {self.vidas}')
        self.llama = 0
        self._mostrar_nave(False)
        if self.vidas:
            self.espera = TICKS_ESPERA
            return
        self._fin()

    def _reaparecer(self):
        x, y = base.ANCHO / 2, (TECHO + SUELO) / 2
        if any(_chocan(x, y, DISTANCIA_SEGURA, roca['x'], roca['y'], LADOS[roca['clase']])
               for roca in self.asteroides):
            return False
        self.x, self.y = x, y
        self.vx = self.vy = 0.0
        self.orientacion = 0
        self.invulnerable = TICKS_INVULNERABLE
        self._mostrar_nave(True)
        return True

    def _tick(self):
        sostenida = base.direccion_sostenida(self)
        if sostenida is not None and self.vivo and not self.espera:
            if sostenida == base.IZQUIERDA:
                self._girar(-1)
            elif sostenida == base.DERECHA:
                self._girar(1)
            elif sostenida == base.ARRIBA:
                self._empujar()
            elif sostenida == base.ABAJO:
                self.vx *= FRENO
                self.vy *= FRENO
        self._mover_balas()
        self._mover_asteroides()
        if not self.asteroides:
            self._nueva_oleada()
        if self.espera:
            self.espera -= 1
            if not self.espera and not self._reaparecer():
                self.espera = 1
            return
        self._mover_nave()
        if self.invulnerable:
            self.invulnerable -= 1
            self._mostrar_nave(self.invulnerable // TICKS_PARPADEO % 2 == 0)
        elif self._nave_golpeada():
            self._perder_vida()

    def _fin(self):
        self.en_marcha = False
        es_record = scores.registrar('asteroids', self.puntos)
        detalle = f'Puntos: {self.puntos}   ·   Oleada: {self.oleada}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Asteroids, fallo en el bucle\n{traceback.format_exc()}',
                     xbmc.LOGERROR)
            self.close()

    def _girar(self, sentido):
        self.orientacion = (self.orientacion + sentido) % ORIENTACIONES
        self._pintar_nave()

    def _apuntar_a(self, x, y):
        if abs(x - self.x) < 1 and abs(y - self.y) < 1:
            return
        vuelta = math.atan2(x - self.x, self.y - y) / (2 * math.pi)
        orientacion = round(vuelta * ORIENTACIONES) % ORIENTACIONES
        if orientacion == self.orientacion:
            return
        self.orientacion = orientacion
        self._pintar_nave()

    def _empujar(self):
        dx, dy = DIRECCIONES[self.orientacion]
        self.vx += dx * EMPUJE
        self.vy += dy * EMPUJE
        velocidad = math.hypot(self.vx, self.vy)
        if velocidad > VEL_MAX:
            self.vx *= VEL_MAX / velocidad
            self.vy *= VEL_MAX / velocidad
        self.llama = TICKS_LLAMA
        self._pintar_nave()

    def _disparar(self):
        if not self.libres_balas:
            return
        dx, dy = DIRECCIONES[self.orientacion]
        x, y = self.x + dx * MORRO, self.y + dy * MORRO
        self.balas.append({
            'x': x, 'y': y, 'ticks': BALA_TICKS,
            'vx': dx * VEL_BALA + self.vx, 'vy': dy * VEL_BALA + self.vy,
            'control': self._tomar_control(self.libres_balas, x, y, BALA_LADO),
        })

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        punto = base.arrastre(self, action)
        if punto is not None and self.en_marcha:
            with self.lock:
                if self.vivo and not self.espera:
                    self._apuntar_a(*punto)
            return
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)
            return
        with self.lock:
            if not self.vivo or self.espera:
                return
            if accion == base.IZQUIERDA:
                self._girar(-1)
            elif accion == base.DERECHA:
                self._girar(1)
            elif accion == base.ARRIBA:
                self._empujar()
            elif accion == base.ABAJO:
                self.vx *= FRENO
                self.vy *= FRENO
            elif accion == base.ACEPTAR:
                self._disparar()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaAsteroids()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
