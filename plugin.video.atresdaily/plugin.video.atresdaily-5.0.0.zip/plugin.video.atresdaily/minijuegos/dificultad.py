# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/dificultad.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import xbmcaddon

NIVELES = ('Normal', 'Difícil', 'Experto', 'Demencial')
SUFIJOS = ('', '@dificil', '@experto', '@demencial')

CON_NIVELES = frozenset({'snake', 'tetris', 'flappy', 'pong', 'invaders', 'burbujas',
                         'frogger', 'galaga', 'asteroids', 'pacman', 'buscaminas'})


def nivel():
    try:
        elegido = int(xbmcaddon.Addon().getSetting('juegos_dificultad'))
    except ValueError:
        return 0
    return elegido if 0 <= elegido < len(NIVELES) else 0


def nombre():
    return NIVELES[nivel()]


def sufijo(juego):
    return SUFIJOS[nivel()] if juego in CON_NIVELES else ''
