# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/buscaminas.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

COLUMNAS, FILAS = 13, 8
MINAS = 18
CELDA, HUECO = 75, 6
PASO = CELDA + HUECO

NIVELES = (MINAS, 26, 34, 42)

COLOR_TAPADA = 'FF3E4A5A'
COLOR_DESTAPADA = 'FF222A34'
COLOR_BANDERA = 'FFE0A83C'
COLOR_MINA = 'FFD0453A'
COLOR_NUMEROS = {
    1: 'FF6AA8F0', 2: 'FF54C06E', 3: 'FFE86A5A', 4: 'FFA98BF0',
    5: 'FFD8975A', 6: 'FF52C4BC', 7: 'FFE0E4E8', 8: 'FF9AA4AE',
}


class VentanaBuscaminas(base.Ventana):
    MOVIMIENTOS = {
        base.ARRIBA: (0, -1),
        base.ABAJO: (0, 1),
        base.IZQUIERDA: (-1, 0),
        base.DERECHA: (1, 0),
    }

    def __init__(self):
        super().__init__('Buscaminas', tactil.DIRECTO)
        ancho_tablero = COLUMNAS * PASO - HUECO
        self.x0 = (base.ANCHO - ancho_tablero) // 2
        self.y0 = 195
        self.lab_minas = self.etiqueta(self.x0, 138, 450, 42, '', fuente=base.FUENTE_MEDIA)
        self.lab_tiempo = self.etiqueta(self.x0 + ancho_tablero - 450, 138, 450, 42, '',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(self.x0 - 9, self.y0 - 9, ancho_tablero + 18,
                    FILAS * PASO - HUECO + 18, base.COLOR_MARCO)
        self.celdas = self.rejilla(COLUMNAS, FILAS, self.x0, self.y0, CELDA, HUECO, COLOR_TAPADA)
        self.numeros = [
            [self.etiqueta(self.x0 + c * PASO, self.y0 + f * PASO, CELDA, CELDA, '',
                           fuente=base.FUENTE_MEDIA, alineacion=6)
             for c in range(COLUMNAS)]
            for f in range(FILAS)]
        self.pie_controles(self.y0 + FILAS * PASO + 24,
                           'Mover: {mover}   ·   '
                           'Destapar: {ok}   ·   '
                           'Bandera: {menu}   ·   '
                           'Salir: {atras}')
        self.cursor_img = self.imagen(self.x0, self.y0, CELDA, CELDA, '66FFFFFF')
        self.crear_overlay()

        self._reiniciar()
        self.hilo = threading.Thread(target=self._reloj, daemon=True)

    def _reiniciar(self):
        self.cuantas_minas = NIVELES[dificultad.nivel()]
        for f in range(FILAS):
            for c in range(COLUMNAS):
                self.celdas[f][c].setColorDiffuse(COLOR_TAPADA)
                self.numeros[f][c].setLabel('')
        self.minas = set()
        self.banderas = set()
        self.descubiertas = set()
        self.terminado = False
        self.inicio = None
        self.cursor = (COLUMNAS // 2, FILAS // 2)
        self._mover_cursor(0, 0)
        self.lab_minas.setLabel(f'Minas: {self.cuantas_minas}')
        self._ultimo_tiempo = 'Tiempo: 0s'
        self.lab_tiempo.setLabel(self._ultimo_tiempo)
        self.ocultar_overlay()

    def _mover_cursor(self, dc, df):
        self._poner_cursor(self.cursor[0] + dc, self.cursor[1] + df)

    def _poner_cursor(self, c, f):
        c = min(max(c, 0), COLUMNAS - 1)
        f = min(max(f, 0), FILAS - 1)
        self.cursor = (c, f)
        self.cursor_img.setPosition(self.esc_x(self.x0 + c * PASO),
                                    self.esc_y(self.y0 + f * PASO))

    def casilla_en(self, x, y):
        c = int((x - self.x0) // PASO)
        f = int((y - self.y0) // PASO)
        if 0 <= c < COLUMNAS and 0 <= f < FILAS:
            return c, f
        return None

    def _reloj(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if monitor.waitForAbort(0.5):
                    return
                if self.terminado:
                    continue
                inicio = self.inicio
                texto = f'Tiempo: {int(time.monotonic() - inicio)}s' if inicio else 'Tiempo: 0s'
                if texto != self._ultimo_tiempo:
                    self._ultimo_tiempo = texto
                    self.lab_tiempo.setLabel(texto)
        except Exception:
            xbmc.log(f'AtresDaily Buscaminas, fallo en el reloj\n{traceback.format_exc()}',
                     xbmc.LOGERROR)

    def _vecinas(self, pos):
        c0, f0 = pos
        return [(c, f)
                for c in range(max(0, c0 - 1), min(COLUMNAS, c0 + 2))
                for f in range(max(0, f0 - 1), min(FILAS, f0 + 2))
                if (c, f) != pos]

    def _generar_minas(self, segura):
        prohibidas = set(self._vecinas(segura)) | {segura}
        candidatas = [(c, f) for c in range(COLUMNAS) for f in range(FILAS)
                      if (c, f) not in prohibidas]
        self.minas = set(random.sample(candidatas, self.cuantas_minas))
        self.inicio = time.monotonic()

    def _destapar(self, pos):
        if pos in self.banderas or pos in self.descubiertas:
            return
        if not self.minas:
            self._generar_minas(pos)
        if pos in self.minas:
            self._perder()
            return
        pendientes = [pos]
        while pendientes:
            celda = pendientes.pop()
            if celda in self.descubiertas:
                continue
            self.descubiertas.add(celda)
            cerca = sum(1 for v in self._vecinas(celda) if v in self.minas)
            self.celdas[celda[1]][celda[0]].setColorDiffuse(COLOR_DESTAPADA)
            if cerca:
                self.numeros[celda[1]][celda[0]].setLabel(str(cerca),
                                                          textColor=COLOR_NUMEROS[cerca])
            else:
                pendientes.extend(v for v in self._vecinas(celda)
                                  if v not in self.descubiertas and v not in self.banderas)
        if len(self.descubiertas) == COLUMNAS * FILAS - self.cuantas_minas:
            self._ganar()

    def _alternar_bandera(self, pos):
        if pos in self.descubiertas:
            return
        if pos in self.banderas:
            self.banderas.discard(pos)
            self.celdas[pos[1]][pos[0]].setColorDiffuse(COLOR_TAPADA)
        else:
            self.banderas.add(pos)
            self.celdas[pos[1]][pos[0]].setColorDiffuse(COLOR_BANDERA)
        self.lab_minas.setLabel(f'Minas: {self.cuantas_minas - len(self.banderas)}')

    def _perder(self):
        self.terminado = True
        for c, f in self.minas:
            self.celdas[f][c].setColorDiffuse(COLOR_MINA)
            self.numeros[f][c].setLabel('*')
        self.mostrar_overlay('BOOM', 'Has pisado una mina', base.ayuda_fin_partida())

    def _ganar(self):
        self.terminado = True
        for c, f in self.minas:
            self.celdas[f][c].setColorDiffuse(COLOR_BANDERA)
        self.lab_minas.setLabel('Minas: 0')
        segundos = max(1, int(time.monotonic() - self.inicio))
        es_record = scores.registrar('buscaminas', segundos, menor_mejor=True)
        detalle = f'Tiempo: {segundos}s'
        if es_record:
            detalle += '   ·   ¡mejor tiempo!'
        self.mostrar_overlay('¡GANADO!', detalle, base.ayuda_fin_partida())

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if self.terminado or self.confirmar_salida():
                self._salir()
            return
        if self.terminado:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        punto = base.punto_tocado(self, action)
        if punto is not None:
            casilla = self.casilla_en(*punto)
            if casilla is not None:
                self._poner_cursor(*casilla)
                if accion == base.MENU_CONTEXTUAL:
                    self._alternar_bandera(casilla)
                else:
                    self._destapar(casilla)
            return

        if accion in self.MOVIMIENTOS:
            self._mover_cursor(*self.MOVIMIENTOS[accion])
        elif accion == base.ACEPTAR:
            self._destapar(self.cursor)
        elif accion == base.MENU_CONTEXTUAL:
            self._alternar_bandera(self.cursor)

    def abrir_ajustes(self):
        desde = time.monotonic()
        super().abrir_ajustes()
        if self.inicio:
            self.inicio += time.monotonic() - desde

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaBuscaminas()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
