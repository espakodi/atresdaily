# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Easter egg de los separadores. Al pulsar uno se ofrece un minijuego al azar."""
import random
import time

import xbmcaddon
import xbmcgui

from minijuegos import lista

# Un doble clic lanza el plugin dos veces, y las dos llamadas usarían el mismo cuadro de sí/no
# de Kodi. Se guarda la hora y no un '1' para que un script que Kodi mate entre poner y quitar
# la marca no deje los separadores sin juego toda la sesión.
_PESTILLO = 'atresdaily.minijuego'
_PESTILLO_VALIDEZ_S = 60
_ANTERIOR = 'atresdaily.minijuego_anterior'


def _pestillo_puesto(ventana_kodi):
    # Con el reloj atrasado desde que se puso, la edad sale negativa y la marca no vale
    marca = ventana_kodi.getProperty(_PESTILLO)
    try:
        return bool(marca) and 0 <= time.time() - float(marca) < _PESTILLO_VALIDEZ_S
    except ValueError:
        return False


def _texto(juego):
    texto = ('Esto es un separador, pero aquí tienes un easter egg.\n\n'
             f'Te ha tocado {juego.nombre}.')
    conseguido = lista.marca(juego)
    return f'{texto} Tu {conseguido}.' if conseguido else texto


def ofrecer():
    if xbmcaddon.Addon().getSetting('juegos_separadores') == 'false':
        return
    ventana_kodi = xbmcgui.Window(10000)
    if _pestillo_puesto(ventana_kodi):
        return
    ventana_kodi.setProperty(_PESTILLO, str(time.time()))
    try:
        anterior = ventana_kodi.getProperty(_ANTERIOR)
        juego = random.choice([j for j in lista.JUEGOS if j.id != anterior] or lista.JUEGOS)
        ventana_kodi.setProperty(_ANTERIOR, juego.id)
        # Sin defaultbutton, que no existe en Kodi 19. El foco empieza en "Ahora no", y así un
        # OK de más no abre una partida.
        if xbmcgui.Dialog().yesno(lista.TITULO, _texto(juego), nolabel='Ahora no',
                                  yeslabel='Jugar'):
            lista.abrir(juego.id)
    finally:
        ventana_kodi.clearProperty(_PESTILLO)
