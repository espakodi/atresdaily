# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/scores.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

from minijuegos import dificultad

_PERFIL = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'minijuegos')
_FICHERO = os.path.join(_PERFIL, 'records.json')


def clave(juego):
    return juego + dificultad.sufijo(juego)


def _leer():
    try:
        with open(_FICHERO, encoding='utf-8') as fichero:
            datos = json.load(fichero)
    except (OSError, ValueError):
        return {}
    return datos if isinstance(datos, dict) else {}


def mejor(juego):
    return _leer().get(clave(juego), 0)


def todos():
    return _leer()


def marcas(juego):
    datos = _leer()
    return {c: v for c, v in datos.items() if c == juego or c.startswith(juego + '@')}


def _guardar(datos):
    temporal = _FICHERO + '.tmp'
    try:
        os.makedirs(_PERFIL, exist_ok=True)
        with open(temporal, 'w', encoding='utf-8') as fichero:
            json.dump(datos, fichero)
        _renombrar(temporal, _FICHERO)
    except OSError as error:
        xbmc.log(f'AtresDaily: no se pudo guardar records.json: {error}', xbmc.LOGWARNING)
        return False
    return True


def _renombrar(temporal, destino, intentos=4):
    for intento in range(intentos):
        try:
            os.replace(temporal, destino)
            return
        except OSError:
            if intento == intentos - 1:
                raise
            time.sleep(0.05 * (intento + 1))


def registrar(juego, puntos, menor_mejor=False):
    if puntos <= 0 and not menor_mejor:
        return False
    datos = _leer()
    donde = clave(juego)
    actual = datos.get(donde)
    if actual is not None:
        if menor_mejor and puntos >= actual:
            return False
        if not menor_mejor and puntos <= actual:
            return False
    datos[donde] = puntos
    return _guardar(datos)


def borrar(juego=None):
    datos = _leer()
    if juego is None:
        cuantos = len(datos)
        return cuantos if datos and _guardar({}) else 0
    suyos = [c for c in datos if c == juego or c.startswith(juego + '@')]
    if not suyos:
        return 0
    for c in suyos:
        del datos[c]
    return len(suyos) if _guardar(datos) else 0
