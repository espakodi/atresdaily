# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/frogger.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import math
import os
import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

MEDIA_CARRILES = os.path.join(base.MEDIA, 'carriles')

COLUMNAS, FILAS = 15, 11
ANCHO_CELDA, ALTO_FILA = 128, 72
X0, Y0 = 0, 180
ANCHO_JUEGO = COLUMNAS * ANCHO_CELDA
ALTO_JUEGO = FILAS * ALTO_FILA
DERECHA_JUEGO = X0 + ANCHO_JUEGO

MARGEN = 9
ALTO_FICHA = ALTO_FILA - 2 * MARGEN
ANCHO_RANA = 72

FILA_SALIDA = FILAS - 1
FILA_MEDIANA = 5
FILAS_RIO = (1, 2, 3, 4)
COLUMNAS_META = (1, 4, 7, 10, 13)
COLUMNA_INICIAL = 7

TICK_MS = 33
SEGUNDOS = 30
VIDAS = 3
FACTOR_MAXIMO = 2.0

NIVELES = ((SEGUNDOS, 1.00,     VIDAS),
           (24,       1.25,     3),
           (19,       1.50,     2),
           (15,       1.75,     2))

COLOR_META = 'FF14332B'
COLOR_BAHIA = 'FF0C161D'
COLOR_AGUA = 'FF16324A'
COLOR_HIERBA = 'FF1E3B26'
COLOR_ASFALTO = 'FF1B1F26'
COLOR_RANA = 'FF6BE07E'
COLOR_TRONCO = 'FF8A5A34'
COLOR_TORTUGA = 'FF4AA8B0'
COLOR_COCHE = 'FFE85D4A'
COLOR_DEPORTIVO = 'FFD9A0E8'
COLOR_CAMION = 'FFE8C34A'

CARRILES = (
    (1, 1, 8.0, 420, 240, COLOR_TRONCO),
    (2, -1, 5.0, 300, 180, COLOR_TORTUGA),
    (3, 1, 6.0, 240, 210, COLOR_TRONCO),
    (4, -1, 4.0, 360, 240, COLOR_TORTUGA),
    (6, -1, 11.0, 300, 540, COLOR_CAMION),
    (7, 1, 9.0, 150, 570, COLOR_DEPORTIVO),
    (8, -1, 7.0, 132, 348, COLOR_COCHE),
    (9, 1, 5.0, 168, 432, COLOR_COCHE),
)

def _origen(periodo, largo):
    return X0 - largo - periodo


def ancho_tira(periodo, largo):
    falta = DERECHA_JUEGO - _origen(periodo, largo)
    return -(-falta // periodo) * periodo


def _solapa(ax, aancho, bx, bancho):
    return ax < bx + bancho and bx < ax + aancho


def _color_fila(fila):
    if fila == 0:
        return COLOR_META
    if fila in FILAS_RIO:
        return COLOR_AGUA
    if fila in (FILA_MEDIANA, FILA_SALIDA):
        return COLOR_HIERBA
    return COLOR_ASFALTO


class VentanaFrogger(base.Ventana):
    MOVIMIENTOS = {
        base.ARRIBA: (0, -1),
        base.ABAJO: (0, 1),
        base.IZQUIERDA: (-1, 0),
        base.DERECHA: (1, 0),
    }

    def __init__(self):
        super().__init__('Frogger', tactil.CRUCETA)
        self.bloqueo = threading.Lock()
        self.marcador = self.etiqueta(60, 126, 460, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_vidas = self.etiqueta(540, 126, 300, 42, f'Vidas: {VIDAS}',
                                       fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_nivel = self.etiqueta(840, 126, 240, 42, 'Nivel: 1',
                                       fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_tiempo = self.etiqueta(1080, 126, 300, 42, f'Tiempo: {SEGUNDOS}s',
                                        fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_record = self.etiqueta(1400, 126, 460, 42,
                                        f'Récord: {scores.mejor("frogger")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(X0, Y0 - 6, ANCHO_JUEGO, 6, base.COLOR_MARCO)
        self.imagen(X0, Y0 + ALTO_JUEGO, ANCHO_JUEGO, 6, base.COLOR_MARCO)
        for fila in range(FILAS):
            self.imagen(X0, Y0 + fila * ALTO_FILA, ANCHO_JUEGO, ALTO_FILA, _color_fila(fila))
        self.bahias = [self.imagen(X0 + columna * ANCHO_CELDA, Y0 + MARGEN,
                                   ANCHO_CELDA, ALTO_FICHA, COLOR_BAHIA)
                       for columna in COLUMNAS_META]
        self.carriles = {}
        for fila, sentido, velocidad, largo, hueco, color in CARRILES:
            y = Y0 + fila * ALTO_FILA + MARGEN
            periodo = largo + hueco
            ancho = ancho_tira(periodo, largo)
            self.carriles[fila] = {
                'sentido': sentido, 'velocidad': velocidad, 'largo': largo,
                'periodo': periodo, 'y': y, 'py': self.esc_y(y),
                'origen': _origen(periodo, largo), 'desfase': 0.0,
                'x': [0.0] * (ancho // periodo),
                'control': self.imagen(X0, y, ancho, ALTO_FICHA, color,
                                       textura=os.path.join(MEDIA_CARRILES, f'{fila}.png')),
            }
        for lado in (-ANCHO_JUEGO, DERECHA_JUEGO):
            self.imagen(lado, Y0 - 6, ANCHO_JUEGO, ALTO_JUEGO + 12, base.COLOR_FONDO)
        self.rana = self.imagen(X0, Y0, ANCHO_RANA, ALTO_FICHA, COLOR_RANA)
        self.pie_controles(Y0 + ALTO_JUEGO + 12,
                           'Saltar: {mover}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("mover")} para saltar')
        self.crear_overlay()

        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        self.segundos, self.factor_inicial, self.vidas = NIVELES[dificultad.nivel()]
        self.puntos = 0
        self.nivel = 1
        self.factor = self.factor_inicial
        self.metas = [False] * len(COLUMNAS_META)
        for bahia in self.bahias:
            bahia.setColorDiffuse(COLOR_BAHIA)
        self.marcador.setLabel('Puntos: 0')
        self.lab_vidas.setLabel(f'Vidas: {self.vidas}')
        self.lab_nivel.setLabel('Nivel: 1')
        for carril in self.carriles.values():
            self._colocar_carril(carril)
        self._nueva_rana()
        self.pausa = False
        self.ocultar_overlay()
        self.vivo = True

    def _colocar_carril(self, carril, desfase=None):
        if desfase is None:
            desfase = random.uniform(0, carril['periodo'])
        carril['desfase'] = desfase % carril['periodo']
        izquierda = carril['origen'] + carril['desfase']
        for indice in range(len(carril['x'])):
            carril['x'][indice] = izquierda + indice * carril['periodo']
        carril['control'].setPosition(self.esc_x(izquierda), carril['py'])

    def _nueva_rana(self, motivo=''):
        self.en_marcha = False
        self.fila = FILA_SALIDA
        self.fila_mejor = FILA_SALIDA
        self.x = float(X0 + COLUMNA_INICIAL * ANCHO_CELDA + (ANCHO_CELDA - ANCHO_RANA) / 2)
        self.tiempo = float(self.segundos)
        self._ultimo_segundo = self.segundos
        self.lab_tiempo.setLabel(f'Tiempo: {self.segundos}s')
        self._colocar_rana()
        seguir = f'Pulsa {base.boton("mover")} para saltar'
        self.mostrar_aviso(True, f'{motivo}   ·   {seguir}' if motivo else seguir)

    def _colocar_rana(self):
        self.rana.setPosition(self.esc_x(self.x),
                              self.esc_y(Y0 + self.fila * ALTO_FILA + MARGEN))

    def _sumar(self, puntos):
        self.puntos += puntos
        self.marcador.setLabel(f'Puntos: {self.puntos}')

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Frogger, fallo en el bucle\n{traceback.format_exc()}',
                     xbmc.LOGERROR)
            self.close()

    def _tick(self):
        with self.bloqueo:
            self._mover_obstaculos()
            carril = self.carriles.get(self.fila)
            if carril is not None:
                if self.fila in FILAS_RIO:
                    if not self._arrastrar(carril):
                        self._morir('¡A remojo!')
                        return
                elif any(_solapa(self.x, ANCHO_RANA, x, carril['largo'])
                         for x in carril['x']):
                    self._morir('¡Atropellada!')
                    return
            self.tiempo -= TICK_MS / 1000
            if self.tiempo <= 0:
                self._morir('Se acabó el tiempo')
                return
            segundos = math.ceil(self.tiempo)
            if segundos != self._ultimo_segundo:
                self._ultimo_segundo = segundos
                self.lab_tiempo.setLabel(f'Tiempo: {segundos}s')

    def _mover_obstaculos(self):
        for carril in self.carriles.values():
            self._colocar_carril(
                carril,
                carril['desfase'] + carril['sentido'] * carril['velocidad'] * self.factor)

    def _arrastrar(self, carril):
        centro = self.x + ANCHO_RANA / 2
        if not any(x <= centro <= x + carril['largo'] for x in carril['x']):
            return False
        self.x += carril['sentido'] * carril['velocidad'] * self.factor
        if self.x < X0 or self.x + ANCHO_RANA > DERECHA_JUEGO:
            return False
        self._colocar_rana()
        return True

    def _saltar(self, dc, df):
        with self.bloqueo:
            if dc:
                self.x = min(max(self.x + dc * ANCHO_CELDA, X0), DERECHA_JUEGO - ANCHO_RANA)
            fila = self.fila + df
            if not 0 <= fila <= FILA_SALIDA:
                self._colocar_rana()
                return
            self.fila = fila
            if fila < self.fila_mejor:
                self.fila_mejor = fila
                self._sumar(10)
            if fila == 0:
                self._entrar_en_meta()
                return
            self._colocar_rana()

    def _entrar_en_meta(self):
        centro = self.x + ANCHO_RANA / 2
        for indice, columna in enumerate(COLUMNAS_META):
            izquierda = X0 + columna * ANCHO_CELDA
            if not izquierda <= centro <= izquierda + ANCHO_CELDA:
                continue
            if self.metas[indice]:
                break
            self.metas[indice] = True
            self.bahias[indice].setColorDiffuse(COLOR_RANA)
            self._sumar(50 + int(self.tiempo) * 2)
            if all(self.metas):
                self._subir_nivel()
            else:
                self._nueva_rana('¡Bahía conquistada!')
            return
        self._morir('Ahí no hay hueco')

    def _subir_nivel(self):
        self._sumar(500)
        self.nivel += 1
        self.factor = min(FACTOR_MAXIMO * self.factor_inicial,
                          self.factor_inicial + (self.nivel - 1) * 0.15)
        self.lab_nivel.setLabel(f'Nivel: {self.nivel}')
        for indice in range(len(self.metas)):
            self.metas[indice] = False
            self.bahias[indice].setColorDiffuse(COLOR_BAHIA)
        self._nueva_rana(f'¡Nivel {self.nivel}!')

    def _morir(self, motivo):
        self.vidas -= 1
        self.lab_vidas.setLabel(f'Vidas: {max(0, self.vidas)}')
        if self.vidas <= 0:
            self._fin()
            return
        self._nueva_rana(motivo)

    def _fin(self):
        self.en_marcha = False
        es_record = scores.registrar('frogger', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        salto = self.MOVIMIENTOS.get(accion)
        if salto:
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            self._saltar(*salto)

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaFrogger()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
