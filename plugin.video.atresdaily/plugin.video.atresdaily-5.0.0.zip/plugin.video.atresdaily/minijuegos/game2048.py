# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/game2048.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random

import xbmcgui

from minijuegos import base, scores, tactil

TAM = 4
CELDA, HUECO = 180, 21
PASO = CELDA + HUECO

BRUJULA_X, BRUJULA_Y, BRUJULA_ANCHO = 104, 486, 360
FUENTE_FLECHA = 'font60'
FLECHAS = {base.IZQUIERDA: '←', base.DERECHA: '→',
           base.ARRIBA: '↑', base.ABAJO: '↓'}

COLOR_MARCO = 'FFBBADA0'
COLOR_VACIA = 'FFCDC1B4'
COLOR_TEXTO_OSCURO = 'FF776E65'
COLOR_TEXTO_CLARO = 'FFF9F6F2'
COLOR_SUPER = 'FF3C3A32'
COLORES = {
    2: 'FFEEE4DA', 4: 'FFEDE0C8', 8: 'FFF2B179', 16: 'FFF59563',
    32: 'FFF67C5F', 64: 'FFF65E3B', 128: 'FFEDCF72', 256: 'FFEDCC61',
    512: 'FFEDC850', 1024: 'FFEDC53F', 2048: 'FFEDC22E',
}


def _compactar(fila):
    valores = [v for v in fila if v]
    resultado, puntos, i = [], 0, 0
    while i < len(valores):
        if i + 1 < len(valores) and valores[i] == valores[i + 1]:
            resultado.append(valores[i] * 2)
            puntos += valores[i] * 2
            i += 2
        else:
            resultado.append(valores[i])
            i += 1
    resultado += [0] * (TAM - len(resultado))
    return resultado, puntos


class Ventana2048(base.Ventana):
    def __init__(self):
        super().__init__('2048', tactil.DIRECTO)
        lado = TAM * PASO - HUECO
        x0 = (base.ANCHO - lado) // 2
        y0 = 180
        self.marcador = self.etiqueta(x0 - 150, 126, lado + 300, 42, '',
                                      fuente=base.FUENTE_MEDIA, alineacion=6)
        self.imagen(x0 - 15, y0 - 15, lado + 30, lado + 30, COLOR_MARCO)
        self.fichas = self.rejilla(TAM, TAM, x0, y0, CELDA, HUECO, COLOR_VACIA)
        self.numeros = [
            [self.etiqueta(x0 + c * PASO, y0 + f * PASO, CELDA, CELDA, '',
                           fuente='font37', color=COLOR_TEXTO_OSCURO, alineacion=6)
             for c in range(TAM)]
            for f in range(TAM)]
        self.brujula = self.etiqueta(BRUJULA_X, BRUJULA_Y, BRUJULA_ANCHO, 120, '',
                                     fuente=FUENTE_FLECHA, alineacion=6)
        self.brujula_pie = self.etiqueta(BRUJULA_X, BRUJULA_Y + 114, BRUJULA_ANCHO, 36,
                                         'último gesto', fuente=base.FUENTE_PEQUENA,
                                         color=base.COLOR_TEXTO_TENUE, alineacion=6)
        self._mostrar_brujula(tactil.jugando_con_dedos() is not None)
        self.pie_controles(y0 + lado + 27,
                           'Mover fichas: {mover}   ·   '
                           'Salir: {atras}')
        self.crear_overlay()
        self._reiniciar()

    def _reiniciar(self):
        self.matriz = [[0] * TAM for _ in range(TAM)]
        self.puntos = 0
        self.record = scores.mejor('2048')
        self.terminado = False
        self.logrado_2048 = False
        self._aparecer_ficha()
        self._aparecer_ficha()
        self._repintar()
        self.ocultar_overlay()

    def _aparecer_ficha(self):
        libres = [(c, f) for c in range(TAM) for f in range(TAM) if not self.matriz[f][c]]
        c, f = random.choice(libres)
        self.matriz[f][c] = 4 if random.random() < 0.1 else 2

    @staticmethod
    def _color(valor):
        if not valor:
            return COLOR_VACIA
        return COLORES.get(valor, COLOR_SUPER)

    def _repintar(self):
        for f in range(TAM):
            for c in range(TAM):
                valor = self.matriz[f][c]
                self.fichas[f][c].setColorDiffuse(self._color(valor))
                if valor:
                    color = COLOR_TEXTO_OSCURO if valor <= 4 else COLOR_TEXTO_CLARO
                    self.numeros[f][c].setLabel(str(valor), textColor=color)
                else:
                    self.numeros[f][c].setLabel('')
        self.record = max(self.record, self.puntos)
        self.marcador.setLabel(f'Puntos: {self.puntos}   ·   Récord: {self.record}')

    def _extraer(self, direccion):
        m = self.matriz
        if direccion == base.IZQUIERDA:
            return [list(f) for f in m]
        if direccion == base.DERECHA:
            return [list(reversed(f)) for f in m]
        if direccion == base.ARRIBA:
            return [[m[f][c] for f in range(TAM)] for c in range(TAM)]
        return [[m[f][c] for f in reversed(range(TAM))] for c in range(TAM)]

    def _colocar(self, direccion, filas):
        if direccion == base.IZQUIERDA:
            self.matriz = [list(f) for f in filas]
        elif direccion == base.DERECHA:
            self.matriz = [list(reversed(f)) for f in filas]
        elif direccion == base.ARRIBA:
            self.matriz = [[filas[c][f] for c in range(TAM)] for f in range(TAM)]
        else:
            self.matriz = [[filas[c][TAM - 1 - f] for c in range(TAM)] for f in range(TAM)]

    def _mover(self, direccion):
        filas = self._extraer(direccion)
        nuevas, ganancia = [], 0
        for fila in filas:
            fila_nueva, puntos = _compactar(fila)
            nuevas.append(fila_nueva)
            ganancia += puntos
        if nuevas == filas:
            return
        self._colocar(direccion, nuevas)
        self.puntos += ganancia
        self._aparecer_ficha()
        self._repintar()
        if not self.logrado_2048 and any(2048 in fila for fila in self.matriz):
            self.logrado_2048 = True
            xbmcgui.Dialog().notification('AtresDaily', '¡2048 conseguido! La partida continúa.',
                                          xbmcgui.NOTIFICATION_INFO, 4000, False)
        if not self._hay_movimientos():
            self._terminar()

    def _hay_movimientos(self):
        for f in range(TAM):
            for c in range(TAM):
                if not self.matriz[f][c]:
                    return True
                if c + 1 < TAM and self.matriz[f][c] == self.matriz[f][c + 1]:
                    return True
                if f + 1 < TAM and self.matriz[f][c] == self.matriz[f + 1][c]:
                    return True
        return False

    def _terminar(self):
        self.terminado = True
        es_record = scores.registrar('2048', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
        self.mostrar_overlay('SIN MOVIMIENTOS', detalle, base.ayuda_fin_partida())

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if self.terminado or self.confirmar_salida():
                self.close()
            return
        if self.terminado:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion in FLECHAS:
            self.brujula.setLabel(FLECHAS[accion])
            self._mostrar_brujula(tactil.jugando_con_dedos() is not None)
            self._mover(accion)

    def _mostrar_brujula(self, visible):
        self.brujula.setVisible(visible)
        self.brujula_pie.setVisible(visible)


def jugar():
    ventana = Ventana2048()
    base.ejecutar(ventana)
    del ventana
