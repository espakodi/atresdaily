# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/pacman.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

LABERINTO = (
    '#############################',
    '#...........................#',
    '#.####.#####.#.#.#####.####.#',
    '#o####.#####.#.#.#####.####o#',
    '#.####.#####.#.#.#####.####.#',
    '#...........................#',
    '#.####.##.#########.##.####.#',
    '#......##.#########.##......#',
    '######.................######',
    '######.#######-#######.######',
    ' ......#####     #####...... ',
    '######.###############.######',
    '######........ ........######',
    '#......##.#########.##......#',
    '#.####.##.#########.##.####.#',
    '#...........................#',
    '#.####.#####.#.#.#####.####.#',
    '#o####.#####.#.#.#####.####o#',
    '#.####.#####.#.#.#####.####.#',
    '#...........................#',
    '#############################',
)
COLUMNAS, FILAS = len(LABERINTO[0]), len(LABERINTO)

CELDA = 38
X0 = (base.ANCHO - COLUMNAS * CELDA) // 2
Y0 = 172
LADO_FICHA = 30
LADO_PASTILLA = 8
LADO_COCO = 18

TICK_MS = 33
VEL_PAC = 0.25
VEL_FANTASMA = 0.19
VEL_ASUSTADO = 0.125
VIDAS = 3
ENCIERRO_TICKS = 3000 // TICK_MS
PARPADEO_TICKS = 1000 // TICK_MS
FASES = (7, 20, 7, 20, 5)

NIVELES = ((VEL_FANTASMA,  VEL_ASUSTADO, VIDAS),
           (0.22,          0.140,        3),
           (0.25,          0.160,        2),
           (0.26,          0.185,        2))

INICIO_PAC = (14, 12)
SALIDA = (14, 8)

DIRECCIONES = ((0, -1), (-1, 0), (0, 1), (1, 0))
DIRECCIONES_ACCION = {
    base.ARRIBA: (0, -1),
    base.IZQUIERDA: (-1, 0),
    base.ABAJO: (0, 1),
    base.DERECHA: (1, 0),
}

COLOR_MURO = 'FF2E4BC4'
COLOR_PASILLO = 'FF0C1119'
COLOR_PUERTA = 'FFE89ACB'
COLOR_PASTILLA = 'FFE8DCC0'
COLOR_COCO = 'FFF2C14A'
COLOR_PAC = 'FFF2D24A'
COLOR_ASUSTADO = 'FF3A5BD6'
COLOR_PARPADEO = 'FFE8ECEF'

FANTASMAS = (
    {'color': 'FFE85D4A', 'esquina': (COLUMNAS - 2, 1), 'casa': (13, 10), 'espera': 0},
    {'color': 'FFE89ACB', 'esquina': (1, 1), 'casa': (12, 10), 'espera': 45},
    {'color': 'FF3AC6E8', 'esquina': (COLUMNAS - 2, FILAS - 2), 'casa': (15, 10), 'espera': 105},
    {'color': 'FFE8974A', 'esquina': (1, FILAS - 2), 'casa': (16, 10), 'espera': 165},
)


def transitable(casilla):
    columna, fila = casilla
    return 0 <= fila < FILAS and LABERINTO[fila][columna] not in '#-'


def vecina(casilla, direccion):
    return ((casilla[0] + direccion[0]) % COLUMNAS, casilla[1] + direccion[1])


def _distancia(casilla, objetivo):
    return (casilla[0] - objetivo[0]) ** 2 + (casilla[1] - objetivo[1]) ** 2


class VentanaPacMan(base.Ventana):
    def __init__(self):
        super().__init__('Pac-Man', tactil.CRUCETA)
        ancho, alto = COLUMNAS * CELDA, FILAS * CELDA
        self.lab_puntos = self.etiqueta(X0, 118, 400, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_estado = self.etiqueta(X0 + (ancho - 400) // 2, 118, 400, 42, '',
                                        fuente=base.FUENTE_MEDIA, alineacion=6)
        self.lab_record = self.etiqueta(X0 + ancho - 400, 118, 400, 42,
                                        f'Récord: {scores.mejor("pacman")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(X0 - 6, Y0 - 6, ancho + 12, alto + 12, base.COLOR_MARCO)
        self.imagen(X0, Y0, ancho, alto, COLOR_PASILLO)
        self._pintar_muros()
        self.pastillas = self._crear_pastillas()
        self.fantasmas = [dict(datos, control=self.imagen(0, 0, LADO_FICHA, LADO_FICHA,
                                                          datos['color']), pintado=datos['color'],
                               indice=indice)
                          for indice, datos in enumerate(FANTASMAS)]
        self.pac = {'control': self.imagen(0, 0, LADO_FICHA, LADO_FICHA, COLOR_PAC)}
        self.pie_controles(Y0 + alto + 12,
                           'Mover: {mover}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso('Pulsa una dirección para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _pintar_muros(self):
        for fila, texto in enumerate(LABERINTO):
            inicio = None
            for columna in range(COLUMNAS + 1):
                if columna < COLUMNAS and texto[columna] == '#':
                    if inicio is None:
                        inicio = columna
                    continue
                if inicio is not None:
                    self.imagen(X0 + inicio * CELDA, Y0 + fila * CELDA,
                                (columna - inicio) * CELDA, CELDA, COLOR_MURO)
                    inicio = None
                if columna < COLUMNAS and texto[columna] == '-':
                    self.imagen(X0 + columna * CELDA, Y0 + fila * CELDA + CELDA // 2 - 3,
                                CELDA, 6, COLOR_PUERTA)

    def _crear_pastillas(self):
        pastillas = {}
        for fila, texto in enumerate(LABERINTO):
            for columna, caracter in enumerate(texto):
                if caracter not in '.o':
                    continue
                es_coco = caracter == 'o'
                lado = LADO_COCO if es_coco else LADO_PASTILLA
                margen = (CELDA - lado) // 2
                pastillas[(columna, fila)] = self.imagen(
                    X0 + columna * CELDA + margen, Y0 + fila * CELDA + margen, lado, lado,
                    COLOR_COCO if es_coco else COLOR_PASTILLA)
        return pastillas

    def _reiniciar(self):
        fantasmas, self.vel_asustado, self.vidas = NIVELES[dificultad.nivel()]
        self.puntos = 0
        self.nivel = 1
        self.vel_pac = VEL_PAC
        self.vel_fantasma = fantasmas
        self.vel_fantasma_inicial = fantasmas
        self.lab_puntos.setLabel('Puntos: 0')
        self.quedan = set(self.pastillas)
        for control in self.pastillas.values():
            control.setVisible(True)
        self._recolocar()
        self.ocultar_overlay()
        self.vivo = True

    def _recolocar(self):
        self.en_marcha = False
        self.pausa = False
        self.ticks = 0
        self.asustados = 0
        self.cadena = 0
        self.pac.update({'casilla': INICIO_PAC, 'avance': 0.0, 'paso': (0, 0),
                         'direccion': (-1, 0), 'pendiente': (-1, 0)})
        for fantasma in self.fantasmas:
            fantasma.update({'casilla': fantasma['casa'], 'avance': 0.0, 'paso': (0, 0),
                             'encierro': fantasma['espera']})
            if not fantasma['encierro']:
                self._soltar(fantasma)
        self._actualizar_estado()
        self._pintar_entidades()
        self.mostrar_aviso(True)

    def _soltar(self, fantasma):
        fantasma.update({'casilla': SALIDA, 'avance': 0.0, 'paso': (0, 0), 'encierro': 0})

    def _actualizar_estado(self):
        self.lab_estado.setLabel(f'Vidas: {self.vidas}   ·   Nivel: {self.nivel}')

    def _posicion(self, entidad):
        columna, fila = entidad['casilla']
        paso = entidad['paso']
        return (columna + paso[0] * entidad['avance'], fila + paso[1] * entidad['avance'])

    def _avanzar(self, entidad, velocidad):
        if entidad['paso'] == (0, 0):
            return True
        entidad['avance'] += velocidad
        if entidad['avance'] < 1.0:
            return False
        entidad['avance'] -= 1.0
        entidad['casilla'] = vecina(entidad['casilla'], entidad['paso'])
        return True

    def _al_llegar_pac(self):
        casilla = self.pac['casilla']
        self._comer(casilla)
        if not self.en_marcha:
            return
        for direccion in (self.pac['pendiente'], self.pac['direccion']):
            if transitable(vecina(casilla, direccion)):
                self.pac['direccion'] = direccion
                self.pac['paso'] = direccion
                return
        self.pac['paso'] = (0, 0)
        self.pac['avance'] = 0.0

    def _decidir_fantasma(self, fantasma):
        casilla = fantasma['casilla']
        atras = (-fantasma['paso'][0], -fantasma['paso'][1])
        salidas = [d for d in DIRECCIONES if d != atras and transitable(vecina(casilla, d))]
        if not salidas:
            salidas = [d for d in DIRECCIONES if transitable(vecina(casilla, d))]
        if not salidas:
            fantasma['paso'] = (0, 0)
            return
        if self.asustados:
            fantasma['paso'] = random.choice(salidas)
            return
        objetivo = self._objetivo(fantasma)
        fantasma['paso'] = min(salidas, key=lambda d: _distancia(vecina(casilla, d), objetivo))

    def _objetivo(self, fantasma):
        if self._es_dispersion():
            return fantasma['esquina']
        pac = self.pac['casilla']
        avance_x, avance_y = self.pac['direccion']
        if fantasma['indice'] == 0:
            return pac
        if fantasma['indice'] == 1:
            return (pac[0] + avance_x * 4, pac[1] + avance_y * 4)
        if fantasma['indice'] == 2:
            pivote = (pac[0] + avance_x * 2, pac[1] + avance_y * 2)
            rojo = self.fantasmas[0]['casilla']
            return (pivote[0] * 2 - rojo[0], pivote[1] * 2 - rojo[1])
        propia = fantasma['casilla']
        if abs(propia[0] - pac[0]) + abs(propia[1] - pac[1]) > 8:
            return pac
        return fantasma['esquina']

    def _es_dispersion(self):
        restante = self.ticks
        for indice, segundos in enumerate(FASES):
            restante -= segundos * 1000 // TICK_MS
            if restante < 0:
                return indice % 2 == 0
        return False

    def _comer(self, casilla):
        if casilla not in self.quedan:
            return
        self.quedan.discard(casilla)
        self.pastillas[casilla].setVisible(False)
        if LABERINTO[casilla[1]][casilla[0]] == 'o':
            self.puntos += 50
            self.asustados = max(2, 8 - self.nivel) * 1000 // TICK_MS
            self.cadena = 0
        else:
            self.puntos += 10
        self.lab_puntos.setLabel(f'Puntos: {self.puntos}')
        if not self.quedan:
            self._siguiente_nivel()

    def _siguiente_nivel(self):
        self.nivel += 1
        self.vel_pac = min(0.32, VEL_PAC + 0.015 * (self.nivel - 1))
        self.vel_fantasma = min(0.28, self.vel_fantasma_inicial + 0.015 * (self.nivel - 1))
        self.quedan = set(self.pastillas)
        for control in self.pastillas.values():
            control.setVisible(True)
        self._recolocar()

    def _tocado(self, fantasma):
        pac_x, pac_y = self._posicion(self.pac)
        otro_x, otro_y = self._posicion(fantasma)
        separacion = abs(pac_x - otro_x)
        return min(separacion, COLUMNAS - separacion) < 0.6 and abs(pac_y - otro_y) < 0.6

    def _revisar_choques(self):
        for fantasma in self.fantasmas:
            if fantasma['encierro'] or not self._tocado(fantasma):
                continue
            if not self.asustados:
                self._perder_vida()
                return
            self.cadena = min(self.cadena + 1, 4)
            self.puntos += 100 * 2 ** self.cadena
            self.lab_puntos.setLabel(f'Puntos: {self.puntos}')
            fantasma.update({'casilla': fantasma['casa'], 'avance': 0.0, 'paso': (0, 0),
                             'encierro': ENCIERRO_TICKS})

    def _perder_vida(self):
        self.vidas -= 1
        if self.vidas <= 0:
            self._fin()
            return
        self._recolocar()

    def _fin(self):
        self.en_marcha = False
        self._actualizar_estado()
        es_record = scores.registrar('pacman', self.puntos)
        detalle = f'Puntos: {self.puntos}   ·   Nivel: {self.nivel}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def _pintar_entidades(self):
        self._situar(self.pac)
        for fantasma in self.fantasmas:
            self._situar(fantasma)
            color = self._color_fantasma(fantasma)
            if color != fantasma['pintado']:
                fantasma['control'].setColorDiffuse(color)
                fantasma['pintado'] = color

    def _situar(self, entidad):
        columna, fila = self._posicion(entidad)
        margen = (CELDA - LADO_FICHA) // 2
        entidad['control'].setPosition(self.esc_x(X0 + columna * CELDA + margen),
                                       self.esc_y(Y0 + fila * CELDA + margen))

    def _color_fantasma(self, fantasma):
        if not self.asustados or fantasma['encierro']:
            return fantasma['color']
        if self.asustados < PARPADEO_TICKS and (self.asustados // 5) % 2:
            return COLOR_PARPADEO
        return COLOR_ASUSTADO

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Pac-Man, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def _tick(self):
        self.ticks += 1
        if self.asustados:
            self.asustados -= 1
        if self._avanzar(self.pac, self.vel_pac):
            self._al_llegar_pac()
            if not self.en_marcha:
                return
        for fantasma in self.fantasmas:
            if fantasma['encierro']:
                fantasma['encierro'] -= 1
                if not fantasma['encierro']:
                    self._soltar(fantasma)
                continue
            velocidad = self.vel_asustado if self.asustados else self.vel_fantasma
            if self._avanzar(fantasma, velocidad):
                self._decidir_fantasma(fantasma)
        self._pintar_entidades()
        self._revisar_choques()

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        direccion = DIRECCIONES_ACCION.get(accion)
        if direccion is None:
            return
        self.pac['pendiente'] = direccion
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaPacMan()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
