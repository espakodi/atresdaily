# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Los ajustes de los minijuegos como botones, dentro de Configuración.

Son ajustes nativos de Kodi, así que este menú y la pestaña Minijuegos de los ajustes del addon
leen y cambian lo mismo.
"""
import xbmc
import xbmcaddon
import xbmcgui

import ui_utils
from minijuegos import lista

_PIE = 'Lo mismo está en la pestaña Minijuegos de los ajustes del addon.'
_NUNCA = '2'
# Los que solo cuentan con los mandos en pantalla: con "Nunca" no se enseñan
_DE_LOS_MANDOS = ('juegos_sensibilidad_tactil', 'juegos_mandos_grandes',
                  'juegos_disparo_automatico')

# (ajuste nativo, rótulo, opciones o None si es sí/no, explicación)
_AJUSTES = (
    ('juegos_separadores', 'Minijuego al pulsar un separador', None,
     'Los separadores de los menús esconden un easter egg. Al pulsar uno se ofrece uno de los '
     'catorce minijuegos al azar. Apágalo si los pulsas sin querer.'),
    ('juegos_dificultad', 'Dificultad', ('Normal', 'Difícil', 'Experto', 'Demencial'),
     'Solo Normal deja los juegos exactamente como han sido siempre. Los niveles duros aceleran, '
     'dan menos vidas o dejan menos hueco, cada juego a su manera; 2048, Memoria y Solitario no '
     'cambian. Cada nivel guarda su propio récord, así que una marca de Experto no compite con '
     'una de Normal.'),
    ('juegos_mandos_tactiles', 'Mandos en pantalla', ('Automático', 'Siempre', 'Nunca'),
     'Dibuja una cruceta y un botón de acción sobre el juego para poder jugar con los dedos. En '
     'automático salen en móviles y tabletas; en un ordenador con pantalla táctil salen la '
     'primera vez que deslizas el dedo.'),
    ('juegos_sensibilidad_tactil', 'Sensibilidad de los mandos', ('Lenta', 'Normal', 'Rápida'),
     'A qué velocidad se repite una flecha mantenida en los mandos en pantalla. No cambia el '
     'teclado ni el mando, que repiten por su cuenta.'),
    ('juegos_mandos_grandes', 'Mandos extragrandes', None,
     'Agranda la cruceta y el botón de acción, para pantallas pequeñas o si te cuesta acertar. '
     'Crecen hacia el centro y se quedan anclados en su esquina. También se cambia desde la '
     'rueda dentada sin salir de la partida.'),
    ('juegos_disparo_automatico', 'Las naves disparan solas con los dedos', None,
     'En Invaders y Galaga. Kodi no dice dónde está el segundo dedo, así que pulsar la cruceta y '
     'el botón a la vez no se puede detectar, y sin esto habría que elegir entre moverse o '
     'disparar. Con teclado y mando no cambia nada.'),
    ('juegos_mostrar_rendimiento', 'Contador de rendimiento', None,
     'Enseña cuatro números arriba a la izquierda mientras juegas: los pasos por segundo que da '
     'el juego y los que pedía, lo que tarda un paso, los fotogramas por segundo de Kodi y '
     'cuántas veces ha recogido basura Python. También se apuntan en rendimiento.log, en la '
     'carpeta minijuegos de los datos del addon, y ese fichero se borra en la primera partida '
     'con el contador apagado.'),
)


def _indice(valor, opciones):
    try:
        indice = int(valor)
    except ValueError:
        return 0
    return indice if 0 <= indice < len(opciones) else 0


def menu():
    ui_utils.visto('minijuegos')
    addon = xbmcaddon.Addon()
    icono = ui_utils.media_icon('adv_minijuegos.png')
    sin_mandos = addon.getSetting('juegos_mandos_tactiles') == _NUNCA
    for clave, rotulo, opciones, explicacion in _AJUSTES:
        if clave in _DE_LOS_MANDOS:
            if sin_mandos:
                continue
            rotulo = f'   {rotulo}'
        valor = addon.getSetting(clave)
        if opciones:
            estado = f'[COLOR green]{opciones[_indice(valor, opciones)]}[/COLOR]'
            pulsar = 'Pulsa para elegir.'
        else:
            estado = '[COLOR green]SÍ[/COLOR]' if valor == 'true' else '[COLOR gray]NO[/COLOR]'
            pulsar = 'Pulsa para cambiar.'
        ui_utils.add_item(action='minijuegos_ajuste', url=clave, title=f'{rotulo}: {estado}',
                          thumbnail=icono, folder=False,
                          plot=f'{explicacion}\n\n{_PIE}\n\n[I]{pulsar}[/I]')
    ui_utils.add_item(action='minijuegos_borrar_record', title='Borrar un récord',
                      thumbnail=icono, folder=False,
                      plot='Abre la lista de juegos con marca guardada, para borrar el que elijas '
                           f'o todos.\n\n{_PIE}')
    ui_utils.close_item_list()


def cambiar(clave):
    ajuste = next((a for a in _AJUSTES if a[0] == clave), None)
    if ajuste is None:
        return
    _clave, rotulo, opciones, _explicacion = ajuste
    addon = xbmcaddon.Addon()
    if opciones:
        elegido = xbmcgui.Dialog().select(rotulo, list(opciones),
                                          preselect=_indice(addon.getSetting(clave), opciones))
        if elegido < 0:
            return
        addon.setSetting(clave, str(elegido))
        nuevo = opciones[elegido]
    else:
        activo = addon.getSetting(clave) != 'true'
        addon.setSetting(clave, 'true' if activo else 'false')
        nuevo = 'SÍ' if activo else 'NO'
    xbmcgui.Dialog().notification(lista.TITULO, f'{rotulo}: {nuevo}')
    xbmc.executebuiltin('Container.Refresh')
