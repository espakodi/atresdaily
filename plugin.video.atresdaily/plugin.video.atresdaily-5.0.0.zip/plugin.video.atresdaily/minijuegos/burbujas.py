# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/burbujas.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import math
import os
import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

BOLA = os.path.join(base.MEDIA, 'bola.png')

COLUMNAS = 12
CELDA = 60
PASO_F = 52
FILAS = 14
FILA_LIMITE = 12
FILAS_INICIALES = 6
X0, Y0 = 600, 156
ANCHO_TABLERO = COLUMNAS * CELDA
Y_LIMITE = Y0 + FILA_LIMITE * PASO_F + CELDA // 2
CANON_X, CANON_Y = 960, 918

TICK_MS = 24
SUBPASO = 9
PASOS_TICK = 4
PASOS_GUIA = 6
PUNTOS_GUIA = 14
LADO_GUIA = 16
PASO_ANGULO = 2
ANGULO_MAX = 78
RADIO_CHOQUE = CELDA * 0.88
TIROS_POR_BAJADA = 8
BONUS_TABLERO = 500

NIVELES = ((TIROS_POR_BAJADA, FILAS_INICIALES),
           (6,                7),
           (4,                8),
           (3,                9))
FOGONAZO_MS = 170
GRAVEDAD_CAIDA = 12.0

COLORES = ('FFE85D4A', 'FF3AC6E8', 'FF43D675', 'FFE8C34A', 'FFB06AE0')
COLOR_ARENA = 'FF141B24'
COLOR_LIMITE = 'FF7A3540'
COLOR_FOGONAZO = 'FFFFFFFF'
COLOR_VACIO = '00000000'


def _ancho_fila(f, paridad):
    return COLUMNAS - ((f + paridad) % 2)


def _centro(c, f, paridad):
    x = X0 + ((f + paridad) % 2) * CELDA / 2 + c * CELDA + CELDA / 2
    return x, Y0 + f * PASO_F + CELDA / 2


def _vecinas(c, f, paridad):
    desfase = (f + paridad) % 2
    alrededor = ((c - 1, f), (c + 1, f),
                 (c - 1 + desfase, f - 1), (c + desfase, f - 1),
                 (c - 1 + desfase, f + 1), (c + desfase, f + 1))
    return [(nc, nf) for nc, nf in alrededor
            if 0 <= nf < FILAS and 0 <= nc < _ancho_fila(nf, paridad)]


def _avanzar(x, y, vx, vy, paso):
    x += vx * paso
    y += vy * paso
    izquierda, derecha = X0 + CELDA / 2, X0 + ANCHO_TABLERO - CELDA / 2
    if x < izquierda:
        x, vx = 2 * izquierda - x, -vx
    elif x > derecha:
        x, vx = 2 * derecha - x, -vx
    return x, y, vx


class VentanaBurbujas(base.Ventana):
    def __init__(self):
        super().__init__('Burbujas', tactil.MANDO, ejes=tactil.EJE_HORIZONTAL)
        self.imagen(X0 - 9, Y0 - 9, ANCHO_TABLERO + 18, 810, COLOR_ARENA)
        self.celdas = [
            self.rejilla(COLUMNAS, 1, X0 + (f % 2) * (CELDA // 2), Y0 + f * PASO_F,
                         CELDA, 0, COLOR_VACIO, BOLA)[0]
            for f in range(FILAS)]
        self.pintado = [[None] * COLUMNAS for _ in range(FILAS)]
        self.imagen(X0, Y_LIMITE, ANCHO_TABLERO, 3, COLOR_LIMITE)

        panel_x = 120
        self.lab_puntos = self.etiqueta(panel_x, 300, 420, 45, '', fuente=base.FUENTE_MEDIA)
        self.lab_bajada = self.etiqueta(panel_x, 366, 420, 45, '', fuente=base.FUENTE_MEDIA)
        self.lab_record = self.etiqueta(panel_x, 432, 420, 45,
                                        f'Récord: {scores.mejor("burbujas")}',
                                        fuente=base.FUENTE_MEDIA, color=base.COLOR_TEXTO_SUAVE)
        self.etiqueta(1380, 300, 420, 45, 'Siguiente', fuente=base.FUENTE_MEDIA)
        self.vista_siguiente = self.imagen(1380, 366, CELDA, CELDA, COLOR_VACIO, BOLA)

        self.guia = [self.imagen(CANON_X, CANON_Y, LADO_GUIA, LADO_GUIA,
                                 base.COLOR_TEXTO_TENUE, BOLA)
                     for _ in range(PUNTOS_GUIA)]
        self.bola = self.imagen(CANON_X - CELDA / 2, CANON_Y - CELDA / 2,
                                CELDA, CELDA, COLOR_VACIO, BOLA)
        self.pie_controles(972,
                           'Apuntar: {apuntar}'
                           '   ·   Disparar: {ok}'
                           '   ·   Pausa: {pausa}'
                           '   ·   Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        self.tiros_por_bajada, self.filas_iniciales = NIVELES[dificultad.nivel()]
        self.en_marcha = False
        self.pausa = False
        self.apuntando = False
        self.volando = False
        self.reventando = ()
        self.momento_fogonazo = 0.0
        self.cayendo = ()
        self.caida_y, self.caida_vy = 0.0, 0.0
        self.paridad = 0
        self.puntos = 0
        self.tiros = 0
        self.angulo = 0.0
        self.px, self.py = float(CANON_X), float(CANON_Y)
        self.vx, self.vy = 0.0, -1.0
        self.bolas = [[None] * COLUMNAS for _ in range(FILAS)]
        self._llenar_tablero()
        self._recolocar_celdas()
        self.color_siguiente = self._sortear_color()
        self._cargar_bola()
        self._repintar()
        self._actualizar_panel()
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _llenar_tablero(self):
        for f in range(self.filas_iniciales):
            for c in range(_ancho_fila(f, self.paridad)):
                self.bolas[f][c] = random.choice(COLORES)

    def _sortear_color(self):
        presentes = sorted({color for fila in self.bolas for color in fila if color})
        return random.choice(presentes or COLORES)

    def _cargar_bola(self):
        self.color_actual = self.color_siguiente
        self.color_siguiente = self._sortear_color()
        self.bola.setPosition(self.esc_x(CANON_X - CELDA / 2), self.esc_y(CANON_Y - CELDA / 2))
        self.bola.setColorDiffuse(self.color_actual)
        self.vista_siguiente.setColorDiffuse(self.color_siguiente)
        for punto in self.guia:
            punto.setColorDiffuse(f'99{self.color_actual[2:]}')
        self._dibujar_guia()

    def _recolocar_celdas(self):
        for f in range(FILAS):
            desfase = ((f + self.paridad) % 2) * CELDA / 2
            for c in range(COLUMNAS):
                self.celdas[f][c].setPosition(self.esc_x(X0 + desfase + c * CELDA),
                                              self.esc_y(Y0 + f * PASO_F))

    def _repintar(self):
        for f in range(FILAS):
            ancho = _ancho_fila(f, self.paridad)
            for c in range(COLUMNAS):
                color = (self.bolas[f][c] if c < ancho else None) or COLOR_VACIO
                anterior = self.pintado[f][c]
                if color == anterior:
                    continue
                self.pintado[f][c] = color
                celda = self.celdas[f][c]
                if color == COLOR_VACIO:
                    celda.setVisible(False)
                    continue
                celda.setColorDiffuse(color)
                if anterior == COLOR_VACIO:
                    celda.setVisible(True)

    def _actualizar_panel(self):
        self.lab_puntos.setLabel(f'Puntos: {self.puntos}')
        restantes = self.tiros_por_bajada - self.tiros % self.tiros_por_bajada
        plural = 'tiro' if restantes == 1 else 'tiros'
        self.lab_bajada.setLabel(f'Baja en: {restantes} {plural}')

    def _dibujar_guia(self):
        radianes = math.radians(self.angulo)
        x, y = float(CANON_X), float(CANON_Y)
        vx, vy = math.sin(radianes), -math.cos(radianes)
        chocado = False
        for punto in self.guia:
            for _ in range(PASOS_GUIA):
                x, y, vx = _avanzar(x, y, vx, vy, SUBPASO)
            chocado = chocado or self._choca(x, y)
            punto.setVisible(not chocado)
            if not chocado:
                punto.setPosition(self.esc_x(x - LADO_GUIA / 2), self.esc_y(y - LADO_GUIA / 2))

    def _girar(self, grados):
        self._apuntar(self.angulo + grados)

    def _apuntar(self, grados):
        self.angulo = min(max(grados, -ANGULO_MAX), ANGULO_MAX)
        self._dibujar_guia()

    def _apuntar_a(self, x, y):
        if y >= CANON_Y:
            return
        self._apuntar(math.degrees(math.atan2(x - CANON_X, CANON_Y - y)))

    def _disparar(self):
        radianes = math.radians(self.angulo)
        self.px, self.py = float(CANON_X), float(CANON_Y)
        self.vx, self.vy = math.sin(radianes), -math.cos(radianes)
        self.volando = True
        for punto in self.guia:
            punto.setVisible(False)

    def _choca(self, px, py):
        if py - CELDA / 2 <= Y0:
            return True
        fila = int((py - Y0) / PASO_F)
        for f in range(max(0, fila - 1), min(FILAS, fila + 2)):
            for c in range(_ancho_fila(f, self.paridad)):
                if self.bolas[f][c] is None:
                    continue
                cx, cy = _centro(c, f, self.paridad)
                if math.hypot(px - cx, py - cy) < RADIO_CHOQUE:
                    return True
        return False

    def _hueco_mas_cercano(self):
        mejor, mejor_dist = None, None
        for f in range(FILAS):
            for c in range(_ancho_fila(f, self.paridad)):
                if self.bolas[f][c] is not None:
                    continue
                if f and not any(self.bolas[nf][nc] is not None
                                 for nc, nf in _vecinas(c, f, self.paridad)):
                    continue
                cx, cy = _centro(c, f, self.paridad)
                distancia = math.hypot(self.px - cx, self.py - cy)
                if mejor_dist is None or distancia < mejor_dist:
                    mejor, mejor_dist = (c, f), distancia
        return mejor

    def _grupo(self, c, f):
        color = self.bolas[f][c]
        encontradas = {(c, f)}
        pendientes = [(c, f)]
        while pendientes:
            actual = pendientes.pop()
            for vecina in _vecinas(actual[0], actual[1], self.paridad):
                if vecina in encontradas or self.bolas[vecina[1]][vecina[0]] != color:
                    continue
                encontradas.add(vecina)
                pendientes.append(vecina)
        return encontradas

    def _huerfanas(self):
        pendientes = [(c, 0) for c in range(_ancho_fila(0, self.paridad))
                      if self.bolas[0][c] is not None]
        sujetas = set(pendientes)
        while pendientes:
            actual = pendientes.pop()
            for vecina in _vecinas(actual[0], actual[1], self.paridad):
                if vecina in sujetas or self.bolas[vecina[1]][vecina[0]] is None:
                    continue
                sujetas.add(vecina)
                pendientes.append(vecina)
        return tuple((c, f) for f in range(FILAS) for c in range(_ancho_fila(f, self.paridad))
                     if self.bolas[f][c] is not None and (c, f) not in sujetas)

    def _bajar_fila(self):
        self.paridad = 1 - self.paridad
        self.bolas.pop()
        self.bolas.insert(0, [random.choice(COLORES) if c < _ancho_fila(0, self.paridad) else None
                              for c in range(COLUMNAS)])
        self._recolocar_celdas()

    def _hay_derrota(self):
        return any(self.bolas[f][c] for f in range(FILA_LIMITE, FILAS)
                   for c in range(COLUMNAS))

    def _aterrizar(self):
        self.volando = False
        destino = self._hueco_mas_cercano()
        if destino is None:
            self._siguiente_turno()
            return
        c, f = destino
        self.bolas[f][c] = self.color_actual
        self._repintar()
        grupo = self._grupo(c, f)
        if len(grupo) < 3:
            self._siguiente_turno()
            return
        self.reventando = tuple(grupo)
        self.momento_fogonazo = time.monotonic()
        for gc, gf in self.reventando:
            self.celdas[gf][gc].setColorDiffuse(COLOR_FOGONAZO)
            self.pintado[gf][gc] = COLOR_FOGONAZO

    def _avanzar_reventon(self):
        for c, f in self.reventando:
            self.bolas[f][c] = None
        self.puntos += 10 * len(self.reventando)
        self.reventando = ()
        self.cayendo = self._huerfanas()
        self.caida_y, self.caida_vy = 0.0, 0.0
        self._repintar()
        self._actualizar_panel()
        if not self.cayendo:
            self._siguiente_turno()

    def _tick_caida(self):
        self.caida_vy += GRAVEDAD_CAIDA
        self.caida_y += self.caida_vy
        for c, f in self.cayendo:
            desfase = ((f + self.paridad) % 2) * CELDA / 2
            self.celdas[f][c].setPosition(self.esc_x(X0 + desfase + c * CELDA),
                                          self.esc_y(Y0 + f * PASO_F + self.caida_y))
        arriba = min(f for _, f in self.cayendo)
        if Y0 + arriba * PASO_F + self.caida_y <= base.ALTO:
            return
        self.puntos += 20 * len(self.cayendo)
        for c, f in self.cayendo:
            self.bolas[f][c] = None
        self.cayendo = ()
        self._recolocar_celdas()
        self._repintar()
        self._actualizar_panel()
        self._siguiente_turno()

    def _siguiente_turno(self):
        self.tiros += 1
        if self.tiros % self.tiros_por_bajada == 0:
            self._bajar_fila()
        if not any(color for fila in self.bolas for color in fila):
            self.puntos += BONUS_TABLERO
            self._llenar_tablero()
        self._repintar()
        self._actualizar_panel()
        if self._hay_derrota():
            self._fin()
            return
        self._cargar_bola()

    def _tick(self):
        sostenida = base.direccion_sostenida(self)
        if (sostenida in (base.IZQUIERDA, base.DERECHA)
                and not (self.volando or self.reventando or self.cayendo)):
            self._girar(-PASO_ANGULO if sostenida == base.IZQUIERDA else PASO_ANGULO)
        if self.reventando:
            if time.monotonic() - self.momento_fogonazo >= FOGONAZO_MS / 1000:
                self._avanzar_reventon()
            return
        if self.cayendo:
            self._tick_caida()
            return
        chocado = False
        for _ in range(PASOS_TICK):
            self.px, self.py, self.vx = _avanzar(self.px, self.py, self.vx, self.vy, SUBPASO)
            if self._choca(self.px, self.py):
                chocado = True
                break
        self.bola.setPosition(self.esc_x(self.px - CELDA / 2), self.esc_y(self.py - CELDA / 2))
        if chocado:
            self._aterrizar()

    def _fin(self):
        self.en_marcha = False
        es_record = scores.registrar('burbujas', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                if not (self.volando or self.reventando or self.cayendo):
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and (self.volando or self.reventando or self.cayendo):
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Burbujas, fallo en el bucle\n{traceback.format_exc()}',
                     xbmc.LOGERROR)
            self.close()

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)
            return
        with self.lock:
            if not self.vivo or self.volando or self.reventando or self.cayendo:
                return
            if self.apuntando and action.getId() == base.GESTO_FIN:
                self.apuntando = False
                self._disparar()
                return
            punto = base.arrastre(self, action)
            if punto is not None and punto[1] < CANON_Y:
                self.apuntando = True
                self._apuntar_a(*punto)
                return
            if accion == base.IZQUIERDA:
                self._girar(-PASO_ANGULO)
            elif accion == base.DERECHA:
                self._girar(PASO_ANGULO)
            elif accion == base.ACEPTAR:
                self._disparar()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaBurbujas()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
