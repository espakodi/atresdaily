# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/lista.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import importlib
import os
import traceback
from collections import namedtuple

import xbmc
import xbmcgui

from minijuegos import base, dificultad, scores

TITULO = 'AtresDaily'
ICONOS = os.path.join(base.MEDIA, 'menu')

Minijuego = namedtuple('Minijuego', 'id nombre modulo icono resumen')

JUEGOS = (
    Minijuego('snake', 'Snake', 'snake', 'ek_snake.png',
              'La serpiente crece con cada fruta y pierdes si te muerdes o te sales. '
              'No se puede dar media vuelta de golpe, hay que girar en dos pasos.'),
    Minijuego('2048', '2048', 'game2048', 'ek_2048.png',
              'Junta fichas iguales para llegar a la de 2048. Cada movimiento las empuja '
              'todas a la vez y saca una nueva.'),
    Minijuego('tetris', 'Tetris', 'tetris', 'ek_tetris.png',
              'Encaja las piezas que caen y completa filas para que desaparezcan. La '
              'sombra marca dónde va a caer la pieza.'),
    Minijuego('buscaminas', 'Buscaminas', 'buscaminas', 'ek_buscaminas.png',
              'Destapa el tablero entero sin pisar una mina; los números dicen cuántas '
              'hay alrededor. Se marca con bandera lo que creas que es mina.'),
    Minijuego('memoria', 'Memoria', 'memoria', 'ek_memoria.png',
              'Levanta cartas de dos en dos y empareja las iguales. El récord es hacerlo '
              'con menos intentos.'),
    Minijuego('solitario', 'Solitario', 'solitario', 'ek_solitario.png',
              'El solitario de siempre: sube las cuatro barajas de as a rey y ordena el '
              'tablero en descendente y alternando color. El récord es acabarlo con menos '
              'movimientos.'),
    Minijuego('flappy', 'Flappy', 'flappy', 'ek_flappy.png',
              'Un solo botón. Cada pulsación da un aletazo y el resto del tiempo caes. '
              'Hay que pasar entre las tuberías.'),
    Minijuego('pong', 'Pong', 'pong', 'ek_pong.png',
              'Devuelve la bola con la pala y cuélala al otro lado. Cada tanto que marcas '
              'la acelera y espabila a la máquina; a los tres fallos se acabó.'),
    Minijuego('invaders', 'Invaders', 'invaders', 'ek_invaders.png',
              'Los marcianos bajan en formación y tú disparas desde abajo. Cuanto menos '
              'quedan, más rápido se mueven.'),
    Minijuego('burbujas', 'Burbujas', 'burbujas', 'ek_burbujas.png',
              'Apunta y dispara burbujas contra el techo. Tres o más del mismo color '
              'revientan y se llevan lo que colgaba de ellas.'),
    Minijuego('frogger', 'Frogger', 'frogger', 'ek_frogger.png',
              'Cruza la carretera esquivando coches y el río saltando de tronco en '
              'tronco. El agua se paga igual que un atropello.'),
    Minijuego('galaga', 'Galaga', 'galaga', 'ek_galaga.png',
              'Naves que entran en formación haciendo curvas y luego se lanzan a por ti. '
              'Cazarlas en picado vale más puntos.'),
    Minijuego('pacman', 'Pac-Man', 'pacman', 'ek_pacman.png',
              'Cómete todos los puntos del laberinto sin que te pillen los fantasmas. '
              'Los cocos grandes los vuelven comestibles un rato.'),
    Minijuego('asteroids', 'Asteroids', 'asteroids', 'ek_asteroids.png',
              'La nave gira y empuja por inercia, y no frena sola. Cada asteroide que '
              'revientas se parte en trozos más pequeños y más rápidos.'),
)


def buscar(juego_id):
    return next((j for j in JUEGOS if j.id == juego_id), None)


def icono(juego):
    return os.path.join(ICONOS, juego.icono)


def _cifra(juego, record):
    if juego.id == 'buscaminas':
        return f'{record}s'
    if juego.id == 'memoria':
        return f'{record} intentos'
    if juego.id == 'solitario':
        return f'{record} movimientos'
    return str(record)


def marca(juego, records=None):
    clave = scores.clave(juego.id)
    record = scores.mejor(juego.id) if records is None else records.get(clave, 0)
    if not record:
        return ''
    titulo = 'mejor tiempo' if juego.id == 'buscaminas' else 'récord'
    nivel = f' ({dificultad.nombre()})' if clave != juego.id else ''
    return f'{titulo}{nivel}: {_cifra(juego, record)}'


def _marcas_de_todos_los_niveles(juego):
    guardadas = scores.marcas(juego.id)
    if list(guardadas) == [juego.id]:
        return _cifra(juego, guardadas[juego.id])
    return ' · '.join(
        f'{dificultad.NIVELES[indice]} {_cifra(juego, guardadas[juego.id + sufijo])}'
        for indice, sufijo in enumerate(dificultad.SUFIJOS)
        if juego.id + sufijo in guardadas)


def etiqueta(juego):
    conseguido = marca(juego)
    return f'{juego.nombre}  ({conseguido})' if conseguido else juego.nombre


def borrar_record():
    marcados = [j for j in JUEGOS if scores.marcas(j.id)]
    dialogo = xbmcgui.Dialog()
    if not marcados:
        dialogo.ok(TITULO, 'Todavía no hay ningún récord que borrar.')
        return

    opciones = [f'{j.nombre}  ({_marcas_de_todos_los_niveles(j)})' for j in marcados]
    opciones.append(f'Borrar los {len(marcados)}')
    elegido = dialogo.select('¿Qué récord se borra?', opciones)
    if elegido < 0:
        return

    if elegido == len(marcados):
        if not dialogo.yesno(TITULO, f'¿Borro los récords de {len(marcados)} juegos?\n\n'
                                     'No se puede deshacer.'):
            return
        borrados, que = scores.borrar(), 'Récords borrados'
    else:
        juego = marcados[elegido]
        conseguido = _marcas_de_todos_los_niveles(juego)
        if not dialogo.yesno(TITULO, f'¿Borro el récord de {juego.nombre}?\n\n'
                                     f'Ahora mismo es {conseguido}. No se puede deshacer.'):
            return
        borrados, que = scores.borrar(juego.id), f'Récord de {juego.nombre} borrado'
    if borrados:
        dialogo.notification(TITULO, que, xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        dialogo.ok(TITULO, 'No se ha podido guardar el cambio; mira el registro de Kodi.')


def abrir(juego_id):
    juego = buscar(juego_id)
    if juego is None:
        xbmc.log(f'{TITULO}: minijuego desconocido {juego_id!r}', xbmc.LOGERROR)
        return
    try:
        importlib.import_module(f'minijuegos.{juego.modulo}').jugar()
    except Exception:
        xbmc.log(f'{TITULO}, fallo en {juego.nombre}\n{traceback.format_exc()}',
                 xbmc.LOGERROR)
        xbmcgui.Dialog().notification(TITULO, 'El juego ha fallado, mira el registro de Kodi',
                                      xbmcgui.NOTIFICATION_ERROR, 4000, False)
