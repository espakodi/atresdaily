# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/flappy.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

TECHO, SUELO = 165, 960
PAJARO_X, PAJARO_LADO = 540, 51
ANCHO_TUBO = 135
HUECO_TUBO = 300
ESPACIADO = 645
N_TUBOS = 4

GRAVEDAD = 2.1
IMPULSO = -16.5
VEL_TUBOS = 9

TICK_MS = 33

NIVELES = ((VEL_TUBOS,        HUECO_TUBO, ESPACIADO,  VEL_TUBOS * 1.55,   40),
           (VEL_TUBOS * 1.20, 264,        600,        VEL_TUBOS * 1.85,   30),
           (VEL_TUBOS * 1.45, 234,        555,        VEL_TUBOS * 2.15,   20),
           (VEL_TUBOS * 1.70, 210,        525,        VEL_TUBOS * 2.45,   15))

COLOR_CIELO = 'FF18222E'
COLOR_PAJARO = 'FFE8C34A'
COLOR_TUBO = 'FF43A05C'


def _hay_choque(y, tubo_x, hueco_y, alto_hueco):
    if PAJARO_X + PAJARO_LADO <= tubo_x or PAJARO_X >= tubo_x + ANCHO_TUBO:
        return False
    return y < hueco_y or y + PAJARO_LADO > hueco_y + alto_hueco


class VentanaFlappy(base.Ventana):
    def __init__(self):
        super().__init__('Flappy', tactil.BOTON)
        self.marcador = self.etiqueta(120, 126, 600, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_record = self.etiqueta(base.ANCHO - 720, 126, 600, 42,
                                        f'Récord: {scores.mejor("flappy")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(0, TECHO - 6, base.ANCHO, 6, base.COLOR_MARCO)
        self.imagen(0, TECHO, base.ANCHO, SUELO - TECHO, COLOR_CIELO)
        self.imagen(0, SUELO, base.ANCHO, 6, base.COLOR_MARCO)
        self.tubos = []
        for _ in range(N_TUBOS):
            self.tubos.append({
                'arriba': self.imagen(base.ANCHO, TECHO, ANCHO_TUBO, 15, COLOR_TUBO),
                'abajo': self.imagen(base.ANCHO, SUELO - 15, ANCHO_TUBO, 15, COLOR_TUBO),
                'x': float(base.ANCHO), 'hueco': TECHO + 150, 'contado': False,
            })
        for lado in (-2 * base.ANCHO, base.ANCHO):
            self.imagen(lado, TECHO - 6, 2 * base.ANCHO, SUELO - TECHO + 12, base.COLOR_FONDO)
        self.pajaro = self.imagen(PAJARO_X, 450, PAJARO_LADO, PAJARO_LADO, COLOR_PAJARO)
        self._pajaro_px = self.esc_x(PAJARO_X)
        self._techo_py = self.esc_y(TECHO)
        self.pie_controles(SUELO + 27,
                           'Aletear: {ok} o arriba   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        (self.vel_inicial, self.hueco, self.espaciado, self.vel_tope,
         self.puntos_al_tope) = NIVELES[dificultad.nivel()]
        self.velocidad = self.vel_inicial
        self.y = (TECHO + SUELO - PAJARO_LADO) / 2
        self.vy = 0.0
        self.puntos = 0
        self.en_marcha = False
        self.marcador.setLabel('Puntos: 0')
        self._pajaro_py = None
        self._mover_pajaro()
        for indice, tubo in enumerate(self.tubos):
            self._recolocar_tubo(tubo, base.ANCHO + 150 + indice * self.espaciado)
        self.pausa = False
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _recolocar_tubo(self, tubo, x):
        tubo['x'] = float(x)
        tubo['hueco'] = random.randint(TECHO + 90, SUELO - 90 - self.hueco)
        tubo['contado'] = False
        tubo['py_abajo'] = self.esc_y(tubo['hueco'] + self.hueco)
        px = self.esc_x(x)
        tubo['arriba'].setPosition(px, self._techo_py)
        tubo['arriba'].setHeight(self.esc_alto(tubo['hueco'] - TECHO))
        tubo['abajo'].setPosition(px, tubo['py_abajo'])
        tubo['abajo'].setHeight(self.esc_alto(SUELO - tubo['hueco'] - self.hueco))

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Flappy, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def _mover_pajaro(self):
        py = self.esc_y(self.y)
        if py != self._pajaro_py:
            self._pajaro_py = py
            self.pajaro.setPosition(self._pajaro_px, py)

    def _tick(self):
        self.vy += GRAVEDAD
        self.y += self.vy
        if self.y < TECHO:
            self.y, self.vy = float(TECHO), 0.0
        if self.y + PAJARO_LADO >= SUELO:
            self.y = SUELO - PAJARO_LADO
            self._mover_pajaro()
            self._fin()
            return
        self._mover_pajaro()
        for tubo in self.tubos:
            tubo['x'] -= self.velocidad
            if tubo['x'] + ANCHO_TUBO < 0:
                self._recolocar_tubo(tubo, tubo['x'] + N_TUBOS * self.espaciado)
            elif tubo['x'] < base.ANCHO:
                px = self.esc_x(tubo['x'])
                tubo['arriba'].setPosition(px, self._techo_py)
                tubo['abajo'].setPosition(px, tubo['py_abajo'])
            if _hay_choque(self.y, tubo['x'], tubo['hueco'], self.hueco):
                self._fin()
                return
            if not tubo['contado'] and tubo['x'] + ANCHO_TUBO < PAJARO_X:
                tubo['contado'] = True
                self.puntos += 1
                avance = min(1.0, self.puntos / self.puntos_al_tope)
                self.velocidad = self.vel_inicial + (self.vel_tope - self.vel_inicial) * avance
                self.marcador.setLabel(f'Puntos: {self.puntos}')

    def _fin(self):
        self.en_marcha = False
        es_record = scores.registrar('flappy', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        if accion in (base.ACEPTAR, base.ARRIBA):
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            self.vy = IMPULSO

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaFlappy()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
