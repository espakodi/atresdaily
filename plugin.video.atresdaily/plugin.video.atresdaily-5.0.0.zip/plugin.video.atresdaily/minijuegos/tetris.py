# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/tetris.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

COLUMNAS, FILAS = 10, 20
CELDA, HUECO = 39, 3
PASO = CELDA + HUECO

COLOR_TABLERO = 'FF171D25'
COLOR_SOMBRA = 'FF313C4A'
PUNTOS_LINEAS = {1: 100, 2: 300, 3: 500, 4: 800}

CAIDA_INICIAL_MS, CAIDA_POR_NIVEL_MS, CAIDA_MINIMA_MS = 600, 45, 120
NIVELES = ((CAIDA_INICIAL_MS, CAIDA_POR_NIVEL_MS, CAIDA_MINIMA_MS),
           (420,              50,                 90),
           (300,              55,                 70),
           (210,              60,                 55))
PIEZAS = {
    'I': {'color': 'FF3AC6E8', 'rotaciones': [
        [(0, 1), (1, 1), (2, 1), (3, 1)],
        [(2, 0), (2, 1), (2, 2), (2, 3)],
    ]},
    'O': {'color': 'FFE8C34A', 'rotaciones': [
        [(1, 0), (2, 0), (1, 1), (2, 1)],
    ]},
    'T': {'color': 'FFB06AE0', 'rotaciones': [
        [(1, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (2, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (1, 2)],
        [(1, 0), (0, 1), (1, 1), (1, 2)],
    ]},
    'S': {'color': 'FF43D675', 'rotaciones': [
        [(1, 0), (2, 0), (0, 1), (1, 1)],
        [(1, 0), (1, 1), (2, 1), (2, 2)],
    ]},
    'Z': {'color': 'FFE85D4A', 'rotaciones': [
        [(0, 0), (1, 0), (1, 1), (2, 1)],
        [(2, 0), (1, 1), (2, 1), (1, 2)],
    ]},
    'J': {'color': 'FF4A78E8', 'rotaciones': [
        [(0, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (2, 0), (1, 1), (1, 2)],
        [(0, 1), (1, 1), (2, 1), (2, 2)],
        [(1, 0), (1, 1), (0, 2), (1, 2)],
    ]},
    'L': {'color': 'FFE8974A', 'rotaciones': [
        [(2, 0), (0, 1), (1, 1), (2, 1)],
        [(1, 0), (1, 1), (1, 2), (2, 2)],
        [(0, 1), (1, 1), (2, 1), (0, 2)],
        [(0, 0), (1, 0), (1, 1), (1, 2)],
    ]},
}


class VentanaTetris(base.Ventana):
    def __init__(self):
        super().__init__('Tetris', tactil.MANDO)
        x0, y0 = 555, 135
        self.imagen(x0 - 9, y0 - 9, COLUMNAS * PASO - HUECO + 18,
                    FILAS * PASO - HUECO + 18, base.COLOR_MARCO)
        self.celdas = self.rejilla(COLUMNAS, FILAS, x0, y0, CELDA, HUECO, COLOR_TABLERO)
        self.pintado = [[COLOR_TABLERO] * COLUMNAS for _ in range(FILAS)]

        panel_x = 1050
        self.etiqueta(panel_x, 165, 450, 45, 'Siguiente', fuente=base.FUENTE_MEDIA)
        self.mini = self.rejilla(4, 4, panel_x, 225, 33, 3, base.COLOR_FONDO)
        self.lab_puntos = self.etiqueta(panel_x, 405, 450, 45, '', fuente=base.FUENTE_MEDIA)
        self.lab_lineas = self.etiqueta(panel_x, 459, 450, 45, '', fuente=base.FUENTE_MEDIA)
        self.lab_nivel = self.etiqueta(panel_x, 513, 450, 45, '', fuente=base.FUENTE_MEDIA)
        self.lab_record = self.etiqueta(panel_x, 567, 450, 45,
                                        f'Récord: {scores.mejor("tetris")}',
                                        fuente=base.FUENTE_MEDIA, color=base.COLOR_TEXTO_SUAVE)
        self.pie_controles(984,
                           'Mover: {mover}   ·   Rotar: arriba   ·   Bajar: abajo'
                           '   ·   Caída: {ok}'
                           '   ·   Pausa: {pausa}'
                           '   ·   Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        self.en_marcha = False
        self.pausa = False
        self.tablero = [[None] * COLUMNAS for _ in range(FILAS)]
        self.bolsa = []
        self.puntos = 0
        self.lineas = 0
        self.nivel = 1
        self.caida_inicial, self.caida_por_nivel, self.caida_minima = \
            NIVELES[dificultad.nivel()]
        self.intervalo = self.caida_inicial
        self.siguiente = self._sacar_pieza()
        self.vivo = True
        self._nueva_pieza()
        self._actualizar_panel()
        self._repintar()
        self.mostrar_aviso(True)
        self.ocultar_overlay()

    def _sacar_pieza(self):
        if not self.bolsa:
            self.bolsa = random.sample(sorted(PIEZAS), len(PIEZAS))
        return self.bolsa.pop()

    def _nueva_pieza(self):
        self.actual = {'tipo': self.siguiente, 'rot': 0, 'c': 3, 'f': -1}
        self.siguiente = self._sacar_pieza()
        self._pintar_siguiente()
        if not self._cabe(self._celdas_actual()):
            self._game_over()

    def _celdas(self, tipo, rot, c0, f0):
        return [(c0 + dc, f0 + df) for dc, df in PIEZAS[tipo]['rotaciones'][rot]]

    def _celdas_actual(self):
        pieza = self.actual
        return self._celdas(pieza['tipo'], pieza['rot'], pieza['c'], pieza['f'])

    def _cabe(self, celdas):
        return all(0 <= c < COLUMNAS and f < FILAS and (f < 0 or self.tablero[f][c] is None)
                   for c, f in celdas)

    def _repintar(self):
        visual = [[self.tablero[f][c] or COLOR_TABLERO for c in range(COLUMNAS)]
                  for f in range(FILAS)]
        if self.actual:
            celdas = self._celdas_actual()
            caida = 0
            while self._cabe([(c, f + caida + 1) for c, f in celdas]):
                caida += 1
            for c, f in celdas:
                if caida and f + caida >= 0:
                    visual[f + caida][c] = COLOR_SOMBRA
            color = PIEZAS[self.actual['tipo']]['color']
            for c, f in celdas:
                if f >= 0:
                    visual[f][c] = color
        for f in range(FILAS):
            for c in range(COLUMNAS):
                if visual[f][c] != self.pintado[f][c]:
                    self.celdas[f][c].setColorDiffuse(visual[f][c])
                    self.pintado[f][c] = visual[f][c]

    def _pintar_siguiente(self):
        color = PIEZAS[self.siguiente]['color']
        ocupadas = set(PIEZAS[self.siguiente]['rotaciones'][0])
        for f in range(4):
            for c in range(4):
                self.mini[f][c].setColorDiffuse(color if (c, f) in ocupadas else base.COLOR_FONDO)

    def _actualizar_panel(self):
        self.lab_puntos.setLabel(f'Puntos: {self.puntos}')
        self.lab_lineas.setLabel(f'Líneas: {self.lineas}')
        self.lab_nivel.setLabel(f'Nivel: {self.nivel}')

    def _mover_pieza(self, dc, df):
        pieza = self.actual
        celdas = self._celdas(pieza['tipo'], pieza['rot'], pieza['c'] + dc, pieza['f'] + df)
        if not self._cabe(celdas):
            return False
        pieza['c'] += dc
        pieza['f'] += df
        self._repintar()
        return True

    def _rotar(self):
        pieza = self.actual
        rot = (pieza['rot'] + 1) % len(PIEZAS[pieza['tipo']]['rotaciones'])
        for dc in (0, -1, 1, -2, 2):
            if self._cabe(self._celdas(pieza['tipo'], rot, pieza['c'] + dc, pieza['f'])):
                pieza['rot'] = rot
                pieza['c'] += dc
                self._repintar()
                return

    def _bajar(self):
        if not self._mover_pieza(0, 1):
            self._fijar()

    def _soltar(self):
        while self._mover_pieza(0, 1):
            self.puntos += 2
        self._actualizar_panel()
        self._fijar()

    def _fijar(self):
        celdas = self._celdas_actual()
        if any(f < 0 for _, f in celdas):
            self._game_over()
            return
        color = PIEZAS[self.actual['tipo']]['color']
        for c, f in celdas:
            self.tablero[f][c] = color
        completas = [f for f in range(FILAS) if all(self.tablero[f])]
        if completas:
            for f in completas:
                del self.tablero[f]
                self.tablero.insert(0, [None] * COLUMNAS)
            self.puntos += PUNTOS_LINEAS[len(completas)] * self.nivel
            self.lineas += len(completas)
            self.nivel = self.lineas // 10 + 1
            self.intervalo = max(self.caida_minima,
                                 self.caida_inicial - self.caida_por_nivel * (self.nivel - 1))
        self._actualizar_panel()
        self._nueva_pieza()
        self._repintar()

    def _game_over(self):
        self.en_marcha = False
        self.vivo = False
        self.actual = None
        self._repintar()
        es_record = scores.registrar('tetris', self.puntos)
        detalle = f'Puntos: {self.puntos}   ·   Líneas: {self.lineas}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay('GAME OVER', detalle, base.ayuda_fin_partida())

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, self.intervalo):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._bajar()
                self.rendimiento.paso(time.monotonic() - desde, self.intervalo)
        except Exception:
            xbmc.log(f'AtresDaily Tetris, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)
            return
        with self.lock:
            if not self.vivo:
                return
            if accion == base.IZQUIERDA:
                self._mover_pieza(-1, 0)
            elif accion == base.DERECHA:
                self._mover_pieza(1, 0)
            elif accion == base.ABAJO:
                if self._mover_pieza(0, 1):
                    self.puntos += 1
                    self._actualizar_panel()
            elif accion == base.ARRIBA:
                self._rotar()
            elif accion == base.ACEPTAR:
                self._soltar()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaTetris()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
