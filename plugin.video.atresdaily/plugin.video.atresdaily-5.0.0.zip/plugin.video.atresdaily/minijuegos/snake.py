# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/snake.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

COLUMNAS, FILAS = 28, 15
CELDA, HUECO = 45, 3
PASO = CELDA + HUECO
VELOCIDAD_INICIAL_MS = 150
VELOCIDAD_MINIMA_MS = 70

NIVELES = ((VELOCIDAD_INICIAL_MS, VELOCIDAD_MINIMA_MS),
           (120,                  55),
           (95,                   45),
           (75,                   38))

COLOR_TABLERO = 'FF1B222B'
COLOR_CUERPO = 'FF3DBE6C'
COLOR_CABEZA = 'FF9CF2BC'
COLOR_COMIDA = 'FFE85D4A'


class VentanaSnake(base.Ventana):
    DIRECCIONES = {
        base.ARRIBA: (0, -1),
        base.ABAJO: (0, 1),
        base.IZQUIERDA: (-1, 0),
        base.DERECHA: (1, 0),
    }

    def __init__(self):
        super().__init__('Snake', tactil.CRUCETA)
        ancho_tablero = COLUMNAS * PASO - HUECO
        x0 = (base.ANCHO - ancho_tablero) // 2
        y0 = 180
        self.marcador = self.etiqueta(x0, 126, 600, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_record = self.etiqueta(x0 + ancho_tablero - 600, 126, 600, 42,
                                        f'Récord: {scores.mejor("snake")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(x0 - 9, y0 - 9, ancho_tablero + 18, FILAS * PASO - HUECO + 18, base.COLOR_MARCO)
        self.celdas = self.rejilla(COLUMNAS, FILAS, x0, y0, CELDA, HUECO, COLOR_TABLERO)
        self.pie_controles(y0 + FILAS * PASO + 24,
                           'Mover: {mover}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso('Pulsa una dirección para empezar')
        self.crear_overlay()

        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _reiniciar(self):
        self.velocidad_inicial, self.velocidad_minima = NIVELES[dificultad.nivel()]
        for fila in self.celdas:
            for control in fila:
                control.setColorDiffuse(COLOR_TABLERO)
        centro = (COLUMNAS // 2, FILAS // 2)
        self.serpiente = [centro, (centro[0] - 1, centro[1]), (centro[0] - 2, centro[1])]
        self.direccion = (1, 0)
        self.direccion_pendiente = (1, 0)
        self.velocidad = self.velocidad_inicial
        self.puntos = 0
        self.en_marcha = False
        self.marcador.setLabel('Puntos: 0')
        for pos in self.serpiente[1:]:
            self._pintar(pos, COLOR_CUERPO)
        self._pintar(self.serpiente[0], COLOR_CABEZA)
        self.comida = self._nueva_comida()
        self._pintar(self.comida, COLOR_COMIDA)
        self.pausa = False
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _pintar(self, pos, color):
        self.celdas[pos[1]][pos[0]].setColorDiffuse(color)

    def _nueva_comida(self):
        ocupadas = set(self.serpiente)
        libres = [(c, f) for c in range(COLUMNAS) for f in range(FILAS)
                  if (c, f) not in ocupadas]
        return random.choice(libres) if libres else None

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, self.velocidad):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                self._avanzar()
                self.rendimiento.paso(time.monotonic() - desde, self.velocidad)
        except Exception:
            xbmc.log(f'AtresDaily Snake, fallo en el bucle\n{traceback.format_exc()}', xbmc.LOGERROR)
            self.close()

    def _avanzar(self):
        self.direccion = self.direccion_pendiente
        cabeza = (self.serpiente[0][0] + self.direccion[0],
                  self.serpiente[0][1] + self.direccion[1])
        if not (0 <= cabeza[0] < COLUMNAS and 0 <= cabeza[1] < FILAS):
            self._fin('GAME OVER')
            return
        come = cabeza == self.comida
        if not come:
            cola = self.serpiente.pop()
            self._pintar(cola, COLOR_TABLERO)
        if cabeza in self.serpiente:
            self._fin('GAME OVER')
            return
        self._pintar(self.serpiente[0], COLOR_CUERPO)
        self.serpiente.insert(0, cabeza)
        self._pintar(cabeza, COLOR_CABEZA)
        if come:
            self.puntos += 10
            self.velocidad = max(self.velocidad_minima, self.velocidad - 3)
            self.marcador.setLabel(f'Puntos: {self.puntos}')
            self.comida = self._nueva_comida()
            if self.comida is None:
                self._fin('¡TABLERO COMPLETO!')
                return
            self._pintar(self.comida, COLOR_COMIDA)

    def _fin(self, titulo):
        self.en_marcha = False
        es_record = scores.registrar('snake', self.puntos)
        detalle = f'Puntos: {self.puntos}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay(titulo, detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        nueva = self.DIRECCIONES.get(accion)
        if nueva:
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            if (nueva[0] + self.direccion[0], nueva[1] + self.direccion[1]) != (0, 0):
                self.direccion_pendiente = nueva

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaSnake()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
