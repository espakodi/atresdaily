# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
# Portado de EKGames (resources/lib/invaders.py) con tools/portar_minijuegos.py.
# No se edita a mano. Los cambios se hacen en EKGames y se vuelve a pasar el script.

import random
import threading
import time
import traceback

import xbmc

from minijuegos import base, dificultad, scores, tactil

TECHO, SUELO = 186, 966
TICK_MS = 33

COLUMNAS, FILAS = 11, 5
ALIEN_ANCHO, ALIEN_ALTO = 72, 42
PASO_X, PASO_Y = 108, 72
OFFSET_X, OFFSET_Y = 384, 258
MARGEN_LATERAL = 60
PASO_MOV = 18
BAJADA = 30
TICKS_LENTOS = 15

NAVE_ANCHO, NAVE_ALTO = 96, 30
NAVE_Y = 900
PASO_NAVE = 54
VIDAS_INICIALES = 3

BALA_ANCHO, BALA_ALTO = 6, 27
VEL_BALA_JUGADOR = 36
VEL_BALA_ALIEN = 12
BALAS_ALIEN = 3
PROB_DISPARO = 0.02
PROB_DISPARO_OLEADA = 0.006

BUNKER_X = (240, 672, 1104, 1536)
BUNKER_Y = 762
BUNKER_COLUMNAS, BUNKER_FILAS = 6, 3
BLOQUE_ANCHO, BLOQUE_ALTO = 24, 21
BUNKER_ANCHO = BUNKER_COLUMNAS * BLOQUE_ANCHO
BUNKER_SUELO = BUNKER_Y + BUNKER_FILAS * BLOQUE_ALTO

OVNI_Y, OVNI_ANCHO, OVNI_ALTO = 198, 96, 36
VEL_OVNI = 9
PROB_OVNI = 0.0015
PREMIOS_OVNI = (50, 100, 150, 300)

COLOR_ESPACIO = 'FF141A22'
COLOR_NAVE = 'FF6FE3A8'
COLOR_BALA = 'FFE8ECEF'
COLOR_BALA_ALIEN = 'FFE85D4A'
COLOR_BUNKER = 'FF3C7A52'
COLOR_OVNI = 'FFE8C34A'
COLOR_FILAS = ('FFB06AE0', 'FF4A9BE8', 'FF4A9BE8', 'FF43D675', 'FF43D675')
PUNTOS_FILA = (30, 20, 20, 10, 10)

NIVELES = ((TICKS_LENTOS, PROB_DISPARO, VIDAS_INICIALES),
           (12,           0.030,        3),
           (9,            0.045,        2),
           (7,            0.060,        2))


def _solapan(a, b):
    return (a[0] < b[0] + b[2] and b[0] < a[0] + a[2]
            and a[1] < b[1] + b[3] and b[1] < a[1] + a[3])


class VentanaInvaders(base.Ventana):
    usa_disparo_automatico = True

    def __init__(self):
        super().__init__('Invaders', tactil.MANDO, ejes=tactil.EJE_HORIZONTAL)
        self.marcador = self.etiqueta(120, 126, 600, 42, 'Puntos: 0', fuente=base.FUENTE_MEDIA)
        self.lab_estado = self.etiqueta(0, 126, base.ANCHO, 42, '', fuente=base.FUENTE_MEDIA,
                                        alineacion=6)
        self.lab_record = self.etiqueta(base.ANCHO - 720, 126, 600, 42,
                                        f'Récord: {scores.mejor("invaders")}',
                                        fuente=base.FUENTE_MEDIA, alineacion=1)
        self.imagen(0, TECHO - 6, base.ANCHO, 6, base.COLOR_MARCO)
        self.imagen(0, TECHO, base.ANCHO, SUELO - TECHO, COLOR_ESPACIO)
        self.imagen(0, SUELO, base.ANCHO, 6, base.COLOR_MARCO)

        self.control_ovni = self.imagen(0, OVNI_Y, OVNI_ANCHO, OVNI_ALTO, COLOR_OVNI)
        self.aliens = [
            self._rectangulos([(OFFSET_X + c * PASO_X, OFFSET_Y + f * PASO_Y,
                                ALIEN_ANCHO, ALIEN_ALTO) for c in range(COLUMNAS)],
                              COLOR_FILAS[f])
            for f in range(FILAS)]
        cajas = [(bx + c * BLOQUE_ANCHO, BUNKER_Y + f * BLOQUE_ALTO, BLOQUE_ANCHO, BLOQUE_ALTO)
                 for bx in BUNKER_X for f in range(BUNKER_FILAS)
                 for c in range(BUNKER_COLUMNAS) if not (f == BUNKER_FILAS - 1 and c in (2, 3))]
        self.bloques = [{'rect': caja, 'control': control, 'vivo': True}
                        for caja, control in zip(cajas, self._rectangulos(cajas, COLOR_BUNKER))]
        self.controles_disparo = [self.imagen(0, TECHO, BALA_ANCHO, BALA_ALTO, COLOR_BALA_ALIEN)
                                  for _ in range(BALAS_ALIEN)]
        self.control_bala = self.imagen(0, NAVE_Y, BALA_ANCHO, BALA_ALTO, COLOR_BALA)
        self.control_nave = self.imagen(0, NAVE_Y, NAVE_ANCHO, NAVE_ALTO, COLOR_NAVE)
        self._nave_py = self.esc_y(NAVE_Y)

        self.pie_controles(SUELO + 27,
                           'Mover: {llevar}   ·   '
                           'Disparar: {ok}   ·   '
                           'Pausa: {pausa}   ·   '
                           'Salir: {atras}')
        self.crear_aviso(f'Pulsa {base.boton("ok")} para empezar')
        self.crear_overlay()

        self.lock = threading.Lock()
        self._reiniciar()
        self.hilo = threading.Thread(target=self._bucle, daemon=True)

    def _rectangulos(self, cajas, color):
        return [self.imagen(x, y, ancho, alto, color) for x, y, ancho, alto in cajas]

    def _reiniciar(self):
        self.ticks_lentos, self.prob_disparo, vidas = NIVELES[dificultad.nivel()]
        self.en_marcha = False
        self.pausa = False
        self.puntos = 0
        self.vidas = vidas
        self.oleada = 1
        self.marcador.setLabel('Puntos: 0')
        self._nueva_oleada()
        self.mostrar_aviso(True)
        self.ocultar_overlay()
        self.vivo = True

    def _nueva_oleada(self):
        self.dx = 0
        self.dy = BAJADA * min(self.oleada - 1, 5)
        self.sentido = 1
        self.ticks = 0
        self.formacion = [[True] * COLUMNAS for _ in range(FILAS)]
        self.bala = None
        self.disparos = [None] * BALAS_ALIEN
        self.ovni_x = None
        self.ovni_sentido = 1
        self.nave_x = (base.ANCHO - NAVE_ANCHO) // 2
        for fila in self.aliens:
            for control in fila:
                control.setVisible(True)
        for bloque in self.bloques:
            bloque['vivo'] = True
            bloque['control'].setVisible(True)
        for control in self.controles_disparo:
            control.setVisible(False)
        self.control_bala.setVisible(False)
        self.control_ovni.setVisible(False)
        self._colocar_formacion()
        self._colocar_nave()
        self._actualizar_estado()

    def _rect_alien(self, columna, fila):
        return (OFFSET_X + columna * PASO_X + self.dx, OFFSET_Y + fila * PASO_Y + self.dy,
                ALIEN_ANCHO, ALIEN_ALTO)

    def _colocar_formacion(self):
        for fila in range(FILAS):
            y = self.esc_y(OFFSET_Y + fila * PASO_Y + self.dy)
            for columna in range(COLUMNAS):
                if self.formacion[fila][columna]:
                    self.aliens[fila][columna].setPosition(
                        self.esc_x(OFFSET_X + columna * PASO_X + self.dx), y)

    def _colocar_nave(self):
        self.control_nave.setPosition(self.esc_x(self.nave_x), self._nave_py)

    def _actualizar_marcador(self):
        self.marcador.setLabel(f'Puntos: {self.puntos}')

    def _actualizar_estado(self):
        self.lab_estado.setLabel(f'Vidas: {self.vidas}   ·   Oleada: {self.oleada}')

    def _columnas_vivas(self):
        return [c for c in range(COLUMNAS) if any(self.formacion[f][c] for f in range(FILAS))]

    def _intervalo(self):
        vivos = sum(fila.count(True) for fila in self.formacion)
        return max(2, round(self.ticks_lentos * vivos / (COLUMNAS * FILAS))
                   - (self.oleada - 1))

    def _bucle(self):
        monitor = xbmc.Monitor()
        try:
            while not self.cerrado:
                if self.esperar(monitor, TICK_MS):
                    return
                if self.pausa or not self.vivo or not self.en_marcha:
                    continue
                desde = time.monotonic()
                with self.lock:
                    if self.vivo and self.en_marcha:
                        self._tick()
                self.rendimiento.paso(time.monotonic() - desde, TICK_MS)
        except Exception:
            xbmc.log(f'AtresDaily Invaders, fallo en el bucle\n{traceback.format_exc()}',
                     xbmc.LOGERROR)
            self.close()

    def _tick(self):
        sostenida = base.direccion_sostenida(self)
        if sostenida in (base.IZQUIERDA, base.DERECHA):
            self._mover_nave(sostenida)
        if self.en_marcha and self.vivo and base.dispara_solo(self) and not self._tapado():
            self._disparar()
        self._mover_bala()
        if not self.vivo:
            return
        self._mover_disparos()
        if not self.vivo:
            return
        self._mover_ovni()
        self._disparar_aliens()
        self.ticks += 1
        if self.ticks >= self._intervalo():
            self.ticks = 0
            self._avanzar_formacion()

    def _mover_bala(self):
        if self.bala is None:
            return
        self.bala[1] -= VEL_BALA_JUGADOR
        if self.bala[1] + BALA_ALTO < TECHO:
            self._quitar_bala()
            return
        rect = (self.bala[0], self.bala[1], BALA_ANCHO, BALA_ALTO)
        if self.ovni_x is not None and _solapan(rect, (self.ovni_x, OVNI_Y,
                                                       OVNI_ANCHO, OVNI_ALTO)):
            self.puntos += random.choice(PREMIOS_OVNI)
            self._quitar_bala()
            self._quitar_ovni()
            self._actualizar_marcador()
            return
        columna = self._columna_bajo(self.bala[0])
        if columna is not None:
            for fila in range(FILAS):
                if not self.formacion[fila][columna]:
                    continue
                if _solapan(rect, self._rect_alien(columna, fila)):
                    self.formacion[fila][columna] = False
                    self.aliens[fila][columna].setVisible(False)
                    self.puntos += PUNTOS_FILA[fila]
                    self._quitar_bala()
                    self._actualizar_marcador()
                    if not self._columnas_vivas():
                        self._limpiar_oleada()
                    return
        if self._destruir_bunker(rect):
            self._quitar_bala()
            return
        self.control_bala.setPosition(self.esc_x(self.bala[0]), self.esc_y(self.bala[1]))

    def _columna_bajo(self, x):
        columna = int((x + BALA_ANCHO - OFFSET_X - self.dx) // PASO_X)
        return columna if 0 <= columna < COLUMNAS else None

    def _tapado(self):
        x = self.nave_x + (NAVE_ANCHO - BALA_ANCHO) // 2
        if not any(bunker <= x < bunker + BUNKER_ANCHO for bunker in BUNKER_X):
            return False
        for bloque in self.bloques:
            izquierda, _, ancho, _ = bloque['rect']
            if bloque['vivo'] and izquierda <= x < izquierda + ancho:
                return True
        return False

    def _quitar_bala(self):
        self.bala = None
        self.control_bala.setVisible(False)

    def _disparar(self):
        if self.bala is not None:
            return
        self.bala = [self.nave_x + (NAVE_ANCHO - BALA_ANCHO) // 2, NAVE_Y - BALA_ALTO]
        self.control_bala.setPosition(self.esc_x(self.bala[0]), self.esc_y(self.bala[1]))
        self.control_bala.setVisible(True)

    def _mover_disparos(self):
        for indice, disparo in enumerate(self.disparos):
            if disparo is None:
                continue
            disparo[1] += VEL_BALA_ALIEN
            rect = (disparo[0], disparo[1], BALA_ANCHO, BALA_ALTO)
            if disparo[1] > SUELO or self._destruir_bunker(rect):
                self._quitar_disparo(indice)
                continue
            if _solapan(rect, (self.nave_x, NAVE_Y, NAVE_ANCHO, NAVE_ALTO)):
                self._quitar_disparo(indice)
                self._perder_vida()
                return
            self.controles_disparo[indice].setPosition(self.esc_x(disparo[0]),
                                                       self.esc_y(disparo[1]))

    def _quitar_disparo(self, indice):
        self.disparos[indice] = None
        self.controles_disparo[indice].setVisible(False)

    def _disparar_aliens(self):
        if None not in self.disparos:
            return
        if random.random() >= self.prob_disparo + PROB_DISPARO_OLEADA * (self.oleada - 1):
            return
        columnas = self._columnas_vivas()
        if not columnas:
            return
        columna = random.choice(columnas)
        fila = max(f for f in range(FILAS) if self.formacion[f][columna])
        x, y = self._rect_alien(columna, fila)[:2]
        indice = self.disparos.index(None)
        self.disparos[indice] = [x + (ALIEN_ANCHO - BALA_ANCHO) // 2, y + ALIEN_ALTO]
        control = self.controles_disparo[indice]
        control.setPosition(self.esc_x(self.disparos[indice][0]),
                            self.esc_y(self.disparos[indice][1]))
        control.setVisible(True)

    def _perder_vida(self):
        self.vidas -= 1
        for indice in range(BALAS_ALIEN):
            self._quitar_disparo(indice)
        self.nave_x = (base.ANCHO - NAVE_ANCHO) // 2
        self._colocar_nave()
        self._actualizar_estado()
        if self.vidas <= 0:
            self._fin('GAME OVER')

    def _destruir_bunker(self, rect):
        if rect[1] + rect[3] <= BUNKER_Y or rect[1] >= BUNKER_SUELO:
            return False
        for bloque in self.bloques:
            if bloque['vivo'] and _solapan(rect, bloque['rect']):
                bloque['vivo'] = False
                bloque['control'].setVisible(False)
                return True
        return False

    def _mover_ovni(self):
        if self.ovni_x is None:
            if random.random() >= PROB_OVNI:
                return
            self.ovni_sentido = random.choice((-1, 1))
            self.ovni_x = -OVNI_ANCHO if self.ovni_sentido > 0 else base.ANCHO
            self.control_ovni.setVisible(True)
        self.ovni_x += self.ovni_sentido * VEL_OVNI
        if self.ovni_x > base.ANCHO or self.ovni_x + OVNI_ANCHO < 0:
            self._quitar_ovni()
            return
        self.control_ovni.setPosition(self.esc_x(self.ovni_x), self.esc_y(OVNI_Y))

    def _quitar_ovni(self):
        self.ovni_x = None
        self.control_ovni.setVisible(False)

    def _avanzar_formacion(self):
        columnas = self._columnas_vivas()
        if not columnas:
            return
        avance = self.sentido * PASO_MOV
        izquierda = OFFSET_X + columnas[0] * PASO_X + self.dx + avance
        derecha = izquierda + (columnas[-1] - columnas[0]) * PASO_X + ALIEN_ANCHO
        if izquierda < MARGEN_LATERAL or derecha > base.ANCHO - MARGEN_LATERAL:
            self.sentido = -self.sentido
            self.dy += BAJADA
            self._arrasar_bunkers()
        else:
            self.dx += avance
        self._colocar_formacion()
        ultima = max(f for f in range(FILAS) if any(self.formacion[f]))
        if OFFSET_Y + ultima * PASO_Y + ALIEN_ALTO + self.dy >= NAVE_Y:
            self._fin('¡INVASIÓN!')

    def _arrasar_bunkers(self):
        alturas = [f for f in range(FILAS)
                   if OFFSET_Y + f * PASO_Y + self.dy < BUNKER_SUELO
                   and OFFSET_Y + f * PASO_Y + self.dy + ALIEN_ALTO > BUNKER_Y]
        if not alturas:
            return
        ocupados = [self._rect_alien(c, f) for f in alturas for c in range(COLUMNAS)
                    if self.formacion[f][c]]
        for bloque in self.bloques:
            if bloque['vivo'] and any(_solapan(bloque['rect'], alien) for alien in ocupados):
                bloque['vivo'] = False
                bloque['control'].setVisible(False)

    def _limpiar_oleada(self):
        self.puntos += 100 * self.oleada
        self.oleada += 1
        self._actualizar_marcador()
        self._nueva_oleada()

    def _fin(self, titulo):
        self.en_marcha = False
        es_record = scores.registrar('invaders', self.puntos)
        detalle = f'Puntos: {self.puntos}   ·   Oleada: {self.oleada}'
        if es_record:
            detalle += '   ·   ¡nuevo récord!'
            self.lab_record.setLabel(f'Récord: {self.puntos}')
        self.mostrar_overlay(titulo, detalle, base.ayuda_fin_partida())
        self.vivo = False

    def onAction(self, action):
        accion = base.accion_tactil(self, action) or action.getId()
        if accion in base.ATRAS:
            if not self.vivo:
                self._salir()
                return
            estaba_pausado = self.pausa
            self.pausa = True
            if self.confirmar_salida():
                self._salir()
            else:
                self.pausa = estaba_pausado
            return
        if not self.vivo:
            if base.quiere_otra_partida(accion) and self.overlay_asentado():
                with self.lock:
                    self._reiniciar()
            return
        if accion == base.MENU_CONTEXTUAL or accion in base.PAUSA:
            if self.en_marcha:
                self.alternar_pausa()
            return
        if self.pausa:
            return
        punto = base.arrastre(self, action)
        if punto is not None:
            if not self.en_marcha:
                self.en_marcha = True
                self.mostrar_aviso(False)
            with self.lock:
                if self.vivo:
                    self._poner_nave(punto[0] - NAVE_ANCHO / 2)
            return
        if accion not in (base.IZQUIERDA, base.DERECHA, base.ACEPTAR):
            return
        if not self.en_marcha:
            self.en_marcha = True
            self.mostrar_aviso(False)
        with self.lock:
            if not self.vivo:
                return
            if accion in (base.IZQUIERDA, base.DERECHA):
                self._mover_nave(accion)
            else:
                self._disparar()

    def _mover_nave(self, accion):
        paso = -PASO_NAVE if accion == base.IZQUIERDA else PASO_NAVE
        self._poner_nave(self.nave_x + paso)

    def _poner_nave(self, x):
        x = min(max(x, MARGEN_LATERAL), base.ANCHO - MARGEN_LATERAL - NAVE_ANCHO)
        if x == self.nave_x:
            return
        self.nave_x = x
        self._colocar_nave()

    def _salir(self):
        self.cerrado = True
        self.close()


def jugar():
    ventana = VentanaInvaders()
    base.ejecutar(ventana, ventana.hilo)
    del ventana
