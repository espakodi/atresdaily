# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""
Telemetría anónima para AtresDaily

Envía ping con un UUID anónimo único por instalación.
Datos enviados: UUID aleatorio no asociado a datos personales, plataforma, versión del addon y versión de Kodi.
El desarrollador no recopila ni tiene acceso a datos personales, IPs, hábitos de uso ni contenido reproducido.

Propósito: Saber el porcentaje de usuarios que tienen cada versión del addon, plataforma y versión de Kodi para planificar el desarrollo (interés legítimo).

Retención de datos: Los datos se borran automáticamente cada 30 días en el servidor remoto.

"""
import os
import json
import time
import uuid
import threading
import xbmc
import xbmcaddon
import xbmcvfs

import core_settings

_API_URL = "https://gpcbfvgxwesvlezaning.supabase.co"
_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdwY2Jmdmd4d2VzdmxlemFuaW5nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM0ODQ1MjYsImV4cCI6MjA4OTA2MDUyNn0.ipnXlrez3yA6CWriqwJU4OzVRYn2nNicpOQSuzpBy-w"
_TABLE = "installs"
_PING_INTERVAL_HOURS = 24
_DATA_FILE = 'stats.json'


def _get_profile():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _data_path():
    return os.path.join(_get_profile(), _DATA_FILE)


def _load_data():
    path = _data_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_data(data):
    profile = _get_profile()
    if not os.path.exists(profile):
        os.makedirs(profile)
    # Atómico, porque un stats.json cortado a mitad haría generar un UUID nuevo.
    core_settings.atomic_write_json(os.path.join(profile, _DATA_FILE), data, ensure_ascii=False)


def activar():
    """Crea stats.json con un UUID nuevo, o conserva el que haya. Se llama al aceptar los
    términos. Sin este fichero no se envía nada, porque el aviso legal ofrece borrarlo para
    desactivar la telemetría."""
    data = _load_data()
    if not data.get('uuid'):
        data['uuid'] = str(uuid.uuid4())
        _save_data(data)


def _get_platform():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return "Android"
    elif xbmc.getCondVisibility("System.Platform.Windows"):
        return "Windows"
    elif xbmc.getCondVisibility("System.Platform.Linux"):
        return "Linux"
    elif xbmc.getCondVisibility("System.Platform.OSX"):
        return "macOS"
    elif xbmc.getCondVisibility("System.Platform.IOS"):
        return "iOS"
    return "Unknown"


def _should_ping():
    data = _load_data()
    if not data.get('uuid'):
        return False
    last_ping = data.get('last_ping', 0)
    hours_passed = (time.time() - last_ping) / 3600
    return hours_passed >= _PING_INTERVAL_HOURS


def _do_ping():
    try:
        import requests

        uid = _load_data().get('uuid')
        if not uid:
            return
        platform = _get_platform()
        addon = xbmcaddon.Addon()
        addon_version = addon.getAddonInfo('version')
        addon_id = addon.getAddonInfo('id')
        kodi_version = xbmc.getInfoLabel("System.BuildVersion").split(' ')[0]

        headers = {
            "apikey": _API_KEY,
            "Authorization": f"Bearer {_API_KEY}",
            "Content-Type": "application/json",
        }

        now = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

        payload = {
            "uuid": uid,  # El UUID evita datos duplicados.
            "addon_name": addon_id,
            "platform": platform,
            "addon_version": addon_version,
            "kodi_version": kodi_version,
            "last_seen": now  # Para no contar en las estadísticas instalaciones inactivas.
        }

        resp = requests.post(
            f"{_API_URL}/rest/v1/{_TABLE}",
            headers=headers,
            json=payload,
            timeout=10
        )

        if resp.status_code == 409:
            update = {
                "platform": platform,
                "addon_version": addon_version,
                "kodi_version": kodi_version,
                "last_seen": now  # Para no contar en las estadísticas instalaciones inactivas.
            }
            resp = requests.patch(
                f"{_API_URL}/rest/v1/{_TABLE}?uuid=eq.{uid}",
                headers=headers,
                json=update,
                timeout=10
            )

        if resp.status_code in (200, 201, 204):
            data = _load_data()
            data['last_ping'] = time.time()
            _save_data(data)
        else:
            pass

    except Exception as e:
        # La telemetría nunca debe molestar al usuario, pero el fallo queda en el log.
        xbmc.log(f"[AtresDaily] Telemetría: {e}", xbmc.LOGDEBUG)


def ping():
    try:
        if not _should_ping():
            return

        t = threading.Thread(target=_do_ping, daemon=True)
        t.start()
    except Exception:
        pass
