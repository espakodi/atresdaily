# -*- coding: utf-8 -*-
# Necesaria en Kodi 19-21 (Python 3.8/3.9), porque bpo-38755 parte las secuencias UTF-8
# en líneas largas al leer el .py, y este fichero tiene líneas de más de 1400 bytes con tildes.
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# AtresDaily nació en 2025, pero se basa en proyectos previos propios, por lo que la licencia y el copyright inician en 2024.
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""
AtresDaily - Explorador del catálogo de A3Player para Kodi.

Busca y reproduce contenido público de Dailymotion, YouTube y otras fuentes
legales asociado al catálogo de A3Player. Gestiona historial, favoritos,
categorías, listas IPTV y descargas.

Addon desarrollado por RubénSDFA1laberot - Fullstackcurso y EspaKodi.
Licencia: Consulta el archivo LICENSE para mas detalles. (Si vas a usar este código, por favor, da crédito al desarrollador original e incluye esta licencia,
ademas intenta contribuir al proyecto original si los cambios no son significativos para no fragmentar el desarrollo y la comunidad).

Este addon se ha hecho intentando que todo sea lo mas legal posible. Si crees que algo no lo es, ponte en contacto.
"""
import sys
import base64
import shutil
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import urllib.parse
import urllib.request
import json
import time
import difflib
import re
import html
import xml.etree.ElementTree as ET
import _user_agents
import categorias
import core_settings
import category_manager
import ui_utils
import exploration_history
import search_shortcuts_manager
import types

_orig_addDirectoryItem = xbmcplugin.addDirectoryItem

# Detección por URL, no por label: el parche de accesibilidad puede reescribir el label.
_LONG_FIRST_ACTIVE = False
_LONG_FIRST_MIN_MINUTES = 30
_dm_buffer = []
_DM_DUR_RX = re.compile(r'\((\d+)m\)')

def _custom_addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
    try:
        label = listitem.getLabel()
        if "¿No es lo que buscas?" in label:
            suffix = " (Pulsa para buscar en más lugares)"
            if suffix not in label:
                if label.endswith("[/B][/COLOR]"):
                    label = label[:-12] + suffix + "[/B][/COLOR]"
                elif label.endswith("[/COLOR]"):
                    label = label[:-8] + suffix + "[/COLOR]"
                else:
                    label = label + suffix
                listitem.setLabel(label)
    except Exception:
        pass
    # El toggle "Desactivar fanart" solo afecta a menús de navegación puros.
    # Se preserva el fanart si el item es contenido con mediatype conocido
    # (movie/tvshow/episode) o si ya tiene un fanart http propio (carpetas del
    # catálogo como programas y temporadas, que traen URL del CDN).
    # Solo se borra cuando el fanart es la ruta local del addon o está vacío.
    if _FANART_DISABLED:
        try:
            tag = listitem.getVideoInfoTag()
            media_type = tag.getMediaType() if tag else ''
            if media_type not in ('movie', 'tvshow', 'episode'):
                current = listitem.getArt('fanart')
                if not current or not current.startswith('http'):
                    listitem.setArt({'fanart': ''})
        except Exception:
            pass
    if _LONG_FIRST_ACTIVE:
        try:
            if url and 'action=play_dm' in url:
                # Duración en minutos desde el label "(Nm)" (tolerante a [B]/[COLOR] alrededor;
                # tomamos la última coincidencia). Si no se puede leer, 0 -> va al grupo corto.
                durs = _DM_DUR_RX.findall(listitem.getLabel() or '')
                _dm_buffer.append((handle, url, listitem, isFolder, totalItems,
                                   int(durs[-1]) if durs else 0))
                return True
        except Exception:
            pass
    return _orig_addDirectoryItem(handle, url, listitem, isFolder, totalItems)

xbmcplugin.addDirectoryItem = _custom_addDirectoryItem

_orig_endOfDirectory = xbmcplugin.endOfDirectory

def _custom_endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
    global _LONG_FIRST_ACTIVE
    if _LONG_FIRST_ACTIVE and _dm_buffer:
        # Partición estable: +30 min primero, luego el resto, conservando el orden de la API.
        largos = [it for it in _dm_buffer if it[5] >= _LONG_FIRST_MIN_MINUTES]
        cortos = [it for it in _dm_buffer if it[5] < _LONG_FIRST_MIN_MINUTES]
        for h, _url, li, folder, tot, _dur in largos + cortos:
            try:
                _orig_addDirectoryItem(h, _url, li, folder, tot)
            except Exception as ex:
                xbmc.log(f"[AtresDaily] Reorden DM, fallo al anadir item: {ex}", xbmc.LOGWARNING)
        _dm_buffer.clear()
    _LONG_FIRST_ACTIVE = False
    return _orig_endOfDirectory(handle, succeeded, updateListing, cacheToDisc)

xbmcplugin.endOfDirectory = _custom_endOfDirectory

_ACC_COLOR_MODE = 'none'
_ACC_BOLD_ENABLED = True
_ACC_STRIP_SYMBOLS = False
_FANART_DISABLED = False
try:
    _acc_addon = xbmcaddon.Addon()
    _ACC_COLOR_MODE = _acc_addon.getSetting('acc_color_mode') or 'none'
    _ACC_BOLD_ENABLED = _acc_addon.getSetting('acc_bold_enabled') != 'false'
    _ACC_STRIP_SYMBOLS = _acc_addon.getSetting('acc_strip_symbols') == 'true'
    _FANART_DISABLED = _acc_addon.getSetting('disable_fanart') == 'true'
    del _acc_addon
except Exception:
    pass

_ACC_DRG_MAP = {
    'red': 'orange', 'tomato': 'orange', 'crimson': 'orange',
    'maroon': 'orange', 'coral': 'orange', 'firebrick': 'orange',
    'green': 'cyan', 'lime': 'cyan', 'limegreen': 'cyan',
    'mediumseagreen': 'cyan', 'palegreen': 'cyan', 'springgreen': 'cyan',
    'darkgreen': 'cyan', 'forestgreen': 'cyan', 'seagreen': 'cyan',
    'aqua': 'cyan', 'cyan': 'cyan', 'deepskyblue': 'deepskyblue',
    'skyblue': 'skyblue', 'lightskyblue': 'lightskyblue',
    'royalblue': 'royalblue', 'cornflowerblue': 'cornflowerblue', 'blue': 'blue',
    'gold': 'yellow', 'khaki': 'yellow', 'yellow': 'yellow',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_DBY_MAP = {
    'yellow': 'magenta', 'gold': 'magenta', 'khaki': 'magenta',
    'lemonchiffon': 'magenta', 'lightyellow': 'magenta',
    'blue': 'red', 'deepskyblue': 'red', 'royalblue': 'red',
    'cornflowerblue': 'red', 'lightskyblue': 'red', 'navy': 'red',
    'aqua': 'red', 'cyan': 'red', 'teal': 'red', 'turquoise': 'red',
    'skyblue': 'red', 'steelblue': 'red', 'cadetblue': 'red',
    'gray': 'gray', 'grey': 'grey', 'white': 'white',
    'darkgray': 'darkgray', 'darkgrey': 'darkgrey',
    'lightgray': 'lightgray', 'lightgrey': 'lightgrey',
    'black': 'black', 'silver': 'silver',
}
_ACC_HCD_KEEP_RED = frozenset({'red', 'tomato', 'crimson', 'maroon', 'coral', 'firebrick'})
_ACC_COLOR_RE = re.compile(r'\[COLOR\s+([a-zA-Z]+)\]')
_ACC_SYMBOL_TABLE = str.maketrans({'★': '*', '●': '*', '○': '-', '▲': '^', '▼': 'v', '◑': '~', '◐': '~'})


def _acc_remap(match):
    c = match.group(1).lower()
    if _ACC_COLOR_MODE == 'white':
        return '[COLOR white]'
    elif _ACC_COLOR_MODE == 'daltonic_rg':
        return '[COLOR ' + _ACC_DRG_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'daltonic_by':
        return '[COLOR ' + _ACC_DBY_MAP.get(c, 'white') + ']'
    elif _ACC_COLOR_MODE == 'hc_dark':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'yellow') + ']'
    elif _ACC_COLOR_MODE == 'hc_light':
        return '[COLOR ' + (c if c in _ACC_HCD_KEEP_RED else 'black') + ']'
    return match.group(0)


def _acc_transform(s):
    if not isinstance(s, str) or not s:
        return s
    if _ACC_STRIP_SYMBOLS:
        s = s.translate(_ACC_SYMBOL_TABLE)
    if _ACC_BOLD_ENABLED and '[B]' not in s:
        s = '[B]' + s + '[/B]'
    if _ACC_COLOR_MODE not in ('', 'none'):
        s = _ACC_COLOR_RE.sub(_acc_remap, s)
    return s


_ACC_NEEDS_TRANSFORM = _ACC_BOLD_ENABLED or _ACC_STRIP_SYMBOLS or (_ACC_COLOR_MODE not in ('', 'none'))

if _ACC_NEEDS_TRANSFORM:
    try:
        _OrigListItem = getattr(xbmcgui, '_OrigListItemAtresdaily', None) or xbmcgui.ListItem
        xbmcgui._OrigListItemAtresdaily = _OrigListItem

        def _ListItemFactory(*args, **kwargs):
            if 'label' in kwargs:
                kwargs['label'] = _acc_transform(kwargs['label'])
            elif args:
                args = (_acc_transform(args[0]),) + args[1:]
            if 'label2' in kwargs:
                kwargs['label2'] = _acc_transform(kwargs['label2'])
            elif len(args) >= 2:
                args = (args[0], _acc_transform(args[1])) + args[2:]
            return _OrigListItem(*args, **kwargs)

        xbmcgui.ListItem = _ListItemFactory
        xbmc.log("[AtresDaily] Accessibility patch installed (color={0} bold={1} symbols={2})".format(
            _ACC_COLOR_MODE, _ACC_BOLD_ENABLED, _ACC_STRIP_SYMBOLS), xbmc.LOGINFO)
    except Exception as _e:
        xbmc.log("[AtresDaily] Accessibility patch failed: {0}".format(_e), xbmc.LOGWARNING)
else:
    try:
        _orig = getattr(xbmcgui, '_OrigListItemAtresdaily', None)
        if _orig is not None and xbmcgui.ListItem is not _orig:
            xbmcgui.ListItem = _orig
    except Exception:
        pass

ui_utils._title_transform = _acc_transform

# no eliminar (mantiene los avisos de autoría)
xbmc.log(
    "[AtresDaily] Addon original por RubénSDFA1laberot — "
    "https://github.com/fullstackcurso — Licencia: Consulta el archivo LICENSE para mas detalles.",
    xbmc.LOGINFO,
)

# Firma de build original: no eliminar
_ORIGIN = "fullstackcurso-RSDFA1-v1"

_DATA_NODES = [
    "aHR0cHM6Ly9hMy5yYXdnaXN0LndvcmtlcnMuZGV2Lw==",
]

def _integration_text(nombre):
    return (
        f"¿Habilitar la búsqueda delegada en tu addon {nombre}?\n\n"
        f"Aprovecha al máximo el addon {nombre}. Esta opción te permite enviarle tus búsquedas directamente desde tu historial, "
        f"favoritos y resultados de AtresDaily, para evitar que tengas que teclear el texto dos veces.\n\n"
        f"El proceso utiliza una URL estándar de Kodi (tipo plugin://) para abrir el addon y "
        f"adjunta el texto de tu consulta. Al tratarse de un simple enlace, esta característica no "
        f"modifica el código de {nombre} ni recopila su información.\n\n"
        f"Nota: Puedes añadir, modificar o desactivar estos atajos en cualquier momento desde los ajustes de AtresDaily."
    )

_INTEGRATION_FIRST_USE_TEXTS = {
    'palantir': ('Palantir', _integration_text('Palantir')),
    'balandro': ('Balandro', _integration_text('Balandro')),
    'jacktook': ('Jacktook', _integration_text('Jacktook')),
    'alfa':     ('Alfa',     _integration_text('Alfa')),
}

def _check_integration_first_use(addon_name):
    if core_settings.is_integration_first_use_shown(addon_name):
        return True
    title, text = _INTEGRATION_FIRST_USE_TEXTS[addon_name]
    accepted = xbmcgui.Dialog().yesno(
        f"Integración con {title}",
        text,
        yeslabel="Aceptar",
        nolabel="Cancelar",
    )
    if accepted:
        core_settings.mark_integration_first_use_shown(addon_name)
    return accepted

def _get_secure_cache_dir():
    """Obtiene un directorio con permisos de escritura verificados."""
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    p_addon = os.path.join(addon_path, 'cache')
    
    if not os.path.exists(p_addon):
        try: os.makedirs(p_addon)
        except Exception: pass
        
    if os.path.exists(p_addon) and os.access(p_addon, os.W_OK):
        try:
            probe = os.path.join(p_addon, '.probe')
            with open(probe, 'wb') as f: f.write(b'\x00')
            os.remove(probe)
            return p_addon
        except Exception:
            pass
        
    p_profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    p_prof_cache = os.path.join(p_profile, 'cache')
    if not os.path.exists(p_prof_cache):
        try: os.makedirs(p_prof_cache)
        except Exception: pass
    return p_prof_cache

def _get_connector_bin_path():
    return os.path.join(_get_secure_cache_dir(), 'cache_data.bin')

def _load_stealth_module(module_name, file_path):
    if module_name in sys.modules:
        return sys.modules[module_name]
    
    if not os.path.exists(file_path):
        return None
        
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read()
            
        source = raw_data.decode('utf-8')
            
        new_module = types.ModuleType(module_name)
        new_module.__file__ = f"<system_metadata_{module_name}>"
        new_module.__package__ = ""
        
        sys.modules[module_name] = new_module
        
        compiled_code = compile(source, new_module.__file__, 'exec')
        exec(compiled_code, new_module.__dict__)
        
        return new_module
    except SyntaxError as se:
        xbmc.log(f"[AtresDaily Stealth] Corrupción de sintaxis detectada en el binario: {se}", xbmc.LOGERROR)
        if module_name in sys.modules:
            del sys.modules[module_name]
        return None
    except Exception as e:
        xbmc.log(f"[AtresDaily Stealth] Error de carga en componente crítico: {e}", xbmc.LOGERROR)
        if module_name in sys.modules:
            del sys.modules[module_name]
        return None

def _get_loader_config_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'loader_config.json')

def _get_connector_path():
    return _get_connector_bin_path()

def _load_custom_urls():
    """Carga URLs personalizadas del archivo de configuración."""
    cfg_path = _get_loader_config_path()
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('custom_urls', [])
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error leyendo loader config: {e}", xbmc.LOGWARNING)
    return []

def _save_custom_url(url):
    """Guarda una URL personalizada en el archivo de configuración."""
    cfg_path = _get_loader_config_path()
    custom_urls = _load_custom_urls()
    if url not in custom_urls:
        custom_urls.append(url)
    if not core_settings.atomic_write_json(cfg_path, {'custom_urls': custom_urls}):
        xbmc.log("[AtresDaily] Error guardando loader config", xbmc.LOGWARNING)

def _download_connector(url):
    ua_list = [
        {"User-Agent": "AtresDaily-SecureGateway-V1-X7"},
        {"User-Agent": "AtresDaily-Updater/SecureClient-v2 (Kr; Lnx)"}
    ]

    for headers in ua_list:
        try:
            r = requests.get(url, headers=headers, timeout=15)
            if r.status_code == 200 and len(r.text) > 500:
                if 'X7-Daily-Secure-992' in r.text:
                    return r.text
        except Exception:
            pass
            
    return None

def _get_sha256(content_bytes):
    """Calcula un hash SHA-256 determinista para la integridad de binarios."""
    import hashlib
    return hashlib.sha256(content_bytes).hexdigest()

def _get_local_hash():
    connector_path = _get_connector_path()
    if not os.path.exists(connector_path):
        return None
    try:
        with open(connector_path, 'rb') as f:
            content = f.read()
        return _get_sha256(content)
    except Exception:
        return None

def _ensure_connector():
    bin_path = _get_connector_bin_path()
    
    # ¿Caducada? La fecha es la del propio archivo, sin JSON aparte.
    try:
        import time as _hf_time
        _cache_hours = 24
        if os.path.exists(bin_path):
            _mtime = os.path.getmtime(bin_path)
            _hours_passed = (_hf_time.time() - _mtime) / 3600
            
            if _hours_passed < _cache_hours:
                # Caché vigente, se carga tal cual
                xbmc.log(f"[AtresDaily Stealth] Caché vigente ({_hours_passed:.1f}h < {_cache_hours}h). Bypass de red.", xbmc.LOGINFO)
                if _load_stealth_module('connector', bin_path):
                    return True
    except Exception as e:
        xbmc.log(f"[AtresDaily Stealth] Error evaluando TTL de caché: {e}", xbmc.LOGWARNING)

    # Si expira o no existe, intentar actualizar
    local_hash = _get_local_hash()
    
    # Limpieza de restos
    try:
        old_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'connector.py')
        if os.path.exists(old_path):
            os.remove(old_path)
            xbmc.log("[AtresDaily Janitor] Purga de archivos obsoletos completada.", xbmc.LOGINFO)
    except Exception: pass
    
    builtin_urls = []
    for b in _DATA_NODES:
        try: builtin_urls.append(base64.b64decode(b).decode('utf-8'))
        except Exception: pass

    all_urls = builtin_urls + _load_custom_urls()
    all_urls = [u for u in all_urls if 'PLACEHOLDER' not in u and u.strip()]
    
    if not all_urls:
        if local_hash:
            return _load_stealth_module('connector', bin_path) is not None
        else:
            xbmcgui.Dialog().ok("AtresDaily - Configuración", "El módulo de conexión no está configurado.")
            return False
            
    code_bytes = None
    for url in all_urls:
        code_str = _download_connector(url)
        if code_str:
            code_bytes = code_str.encode('utf-8')
            break
            
    if code_bytes:
        remote_hash = _get_sha256(code_bytes)
        
        if local_hash == remote_hash:
            # El archivo local ya es idéntico a la red, actualizar el timestamp (touch)
            try:
                os.utime(bin_path, (time.time(), time.time()))
            except OSError:
                pass  # solo retrasa la próxima consulta; si falla, se vuelve a pedir antes
            return _load_stealth_module('connector', bin_path) is not None
        else:
            try:
                with open(bin_path, 'wb') as f:
                    f.write(code_bytes)
                return _load_stealth_module('connector', bin_path) is not None
            except Exception as e:
                xbmc.log(f"[AtresDaily Stealth] Fallo al escribir binario: {e}", xbmc.LOGERROR)
                if local_hash:
                    return _load_stealth_module('connector', bin_path) is not None
                return False
                
    # Si la red falla pero hay caché local (aunque esté caducada), tiramos de ella
    if local_hash:
        xbmc.log("[AtresDaily Stealth] Fallo de red. Degradación a caché caducada.", xbmc.LOGWARNING)
        return _load_stealth_module('connector', bin_path) is not None
        
    xbmcgui.Dialog().ok(
        "AtresDaily - Módulo No Disponible",
        "No se ha podido conectar con los servidores y no hay caché local.\n\n"
        "Comprueba tu conexión o introduce una URL alternativa."
    )
    
    kb = xbmc.Keyboard('', 'URL del módulo connector.py')
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        custom_url = kb.getText().strip()
        code_str = _download_connector(custom_url)
        if code_str:
            _save_custom_url(custom_url)
            try:
                with open(bin_path, 'wb') as f:
                    f.write(code_str.encode('utf-8'))
                xbmcgui.Dialog().notification("AtresDaily", "Módulo descargado", xbmcgui.NOTIFICATION_INFO)
                return _load_stealth_module('connector', bin_path) is not None
            except Exception:
                pass
        xbmcgui.Dialog().ok("Error", "No se pudo descargar el módulo desde esa URL.")
    
    return False


def _get_connector_exp_bin_path():
    return os.path.join(_get_secure_cache_dir(), 'cache_data_exp.bin')


def _ensure_connector_experimental(conn):
    bin_path = _get_connector_exp_bin_path()
    import time as _t
    try:
        if os.path.exists(bin_path) and (_t.time() - os.path.getmtime(bin_path)) / 3600 < 24:
            if _load_stealth_module('connectorexperimental', bin_path):
                return True
    except Exception:
        pass

    url = (getattr(conn, '_XU', '') or '').strip()
    if url:
        code = _download_connector(url)
        if code:
            try:
                with open(bin_path, 'wb') as f:
                    f.write(code.encode('utf-8'))
            except Exception:
                pass
            return _load_stealth_module('connectorexperimental', bin_path) is not None

    if os.path.exists(bin_path):
        return _load_stealth_module('connectorexperimental', bin_path) is not None
    return False


connector = None

# Aceptación legal antes de hacer nada con el conector
_cfg_init = ui_utils.load_json('settings.json')

# Estos 4 booleanos se guardaban en settings.json y ahora son ajustes nativos de
# Kodi. Se migran una sola vez para no perder la configuración de quien actualiza.
# El JSON solo se lee.
_LEGACY_BOOL_KEYS = ('advanced_search_active', 'acestream_enabled', 'prioritize_match_active', 'recent_active')

def _migrate_legacy_bools(cfg):
    addon = xbmcaddon.Addon()
    if addon.getSetting('legacy_bools_migrated') == '1':
        return
    if isinstance(cfg, dict):
        for key in _LEGACY_BOOL_KEYS:
            if key in cfg:
                val = cfg[key]
                is_on = val.lower() == 'true' if isinstance(val, str) else bool(val)
                addon.setSetting(key, 'true' if is_on else 'false')
    addon.setSetting('legacy_bools_migrated', '1')


def _migrate_min_duration(cfg):
    """"Ocultar clips cortos" pasa de settings.json a ajuste nativo (dm_min_duracion)
    para poder cambiarlo también desde los ajustes del addon. Se copia una vez."""
    addon = xbmcaddon.Addon()
    if addon.getSetting('min_duration_migrated') == '1':
        return
    try:
        minutos = int(float(cfg.get('min_duration') or 0)) if isinstance(cfg, dict) else 0
    except (TypeError, ValueError):
        # Un valor corrupto no se migra, pero la bandera se pone igual: si no, se
        # reintentaría y fallaría en cada arranque del addon.
        minutos = 0
    if minutos > 0:
        addon.setSetting('dm_min_duracion', str(minutos))
    addon.setSetting('min_duration_migrated', '1')


try:
    _migrate_legacy_bools(_cfg_init)
    _migrate_min_duration(_cfg_init)
except Exception as _mig_err:
    # Una migración de conveniencia jamás debe impedir que arranque el addon.
    xbmc.log(f"[AtresDaily] Migración de ajustes fallida (se ignora): {_mig_err}", xbmc.LOGWARNING)

if _cfg_init.get('legal_accepted_v2', False):
    # Con los términos aceptados, se carga o se descarga el conector
    if _ensure_connector():
        try:
            import sys as _sys
            connector = _sys.modules.get('connector')
            
            if not connector:
                xbmc.log("[AtresDaily Loader] Error CRÍTICO: Módulo cargado pero no encontrado en sys.modules", xbmc.LOGERROR)
                # Intento de recuperación forzada
                connector = _load_stealth_module('connector', _get_connector_bin_path())
            
            import __main__
            if not hasattr(__main__, 'exploration_history'):
                __main__.exploration_history = exploration_history
            
            if getattr(connector, '_DEBUG_MODE_BACKDOOR', False):
                 xbmc.log("[AtresDaily] HONEYPOT ACTIVADO. Integridad comprometida.", xbmc.LOGERROR)
                 xbmcgui.Dialog().ok("SISTEMA COMPROMETIDO", "ALERTA CRÍTICA DE SEGURIDAD\n\nModificación no autorizada detectada.\nEl sistema se ha bloqueado por seguridad.")
                 time.sleep(300) # Congelar ejecución
                 sys.exit()

            xbmc.log("[AtresDaily Loader] módulo conector cargado correctamente.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[AtresDaily Loader] Error al importar el conector: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("AtresDaily Error", f"Error al cargar el módulo:\n{str(e)}")
            connector = None

    try:
        _ensure_connector_experimental(connector)
    except Exception as _e:
        xbmc.log(f"[AtresDaily] aux module init: {_e}", xbmc.LOGDEBUG)
else:
    # Términos no aceptados -> No tocar red, no descargar, no cargar código.
    xbmc.log("[AtresDaily Loader] Términos legales no aceptados aún. Saltando carga del conector.", xbmc.LOGINFO)

# Mostrar error solo si esperábamos que funcionara (ej: términos aceptados pero carga fallida)
if connector is None and _cfg_init.get('legal_accepted_v2', False):
    xbmcgui.Dialog().ok("AtresDaily", "El addon no puede funcionar sin el módulo de conexión.\nPor favor, reinstala o contacta con el desarrollador.")


# Fin de la carga del conector


# --- Configuración del núcleo ---
ADDON = xbmcaddon.Addon()
ICON_MAIN = ui_utils.ICON_MAIN
HEADERS = ui_utils.HEADERS

# --- Configuración remota ---
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/status.json" 
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/messages.json"
_MESSAGES_TTL = 21600  # 6 h entre consultas de red de mensajes; evita bloquear el menú en cada apertura
_E3 = "https://api.dailymotion.com/videos"

# --- Parámetros del plugin ---
def get_params():
    return ui_utils.get_params()



# --- Comprobaciones remotas ---
def _leer_status():
    """status.json del repositorio, o el incluido en el addon si no hay red. None si no hay ninguno."""
    try:
        # Se consulta de forma síncrona al abrir el addon (semanal), así que con plazo corto.
        r = requests.get(_STATUS_URL, timeout=5)
        if r.status_code == 200:
            data = r.json()
            if isinstance(data, dict):
                return data
    except (requests.RequestException, ValueError):
        pass
    try:
        with open(os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'status.json'), 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def motivo_de_bloqueo():
    """Texto que mostrar si el addon no debe usarse (desactivado, o versión inferior a la
    mínima); None si se puede usar.

    El veredicto se recalcula en cada llamada con los últimos datos de status.json y la
    versión instalada, para que quien actualiza a la versión mínima deje de estar bloqueado."""
    # Corre a nivel de módulo en cada invocación, y un fallo aquí (estado corrupto, un
    # status.json con tipos raros) dejaría el addon entero inservible. Ante cualquier
    # error se deja usar y queda en el log.
    try:
        return _calcular_bloqueo()
    except Exception as ex:
        xbmc.log(f"[AtresDaily] Comprobación de estado fallida, se ignora: {ex}", xbmc.LOGWARNING)
        return None


def _calcular_bloqueo():
    st = ui_utils.load_json('status_check.json', default={})
    if not isinstance(st, dict):
        st = {}
    data = st.get('data') if isinstance(st.get('data'), dict) else None
    last = st.get('last_check')
    if not isinstance(last, (int, float)):
        last = 0

    # Semanal si todo va bien; cada hora si está bloqueado o nunca se ha podido leer, para
    # salir pronto del bloqueo sin lanzar una petición en cada apertura del addon.
    ttl = 604800 if data is not None and not st.get('bloqueado') else 3600
    refrescado = time.time() - last > ttl
    if refrescado:
        data = _leer_status() or data
        st = {'last_check': time.time(), 'data': data}

    motivo = None
    if data is not None:
        def pv(v): return [int(x) for x in str(v).replace('v', '').split('.') if x.isdigit()]
        if not data.get('allowed', True):
            motivo = str(data.get('message') or "El addon está desactivado temporalmente.")
        elif pv(xbmcaddon.Addon().getAddonInfo('version')) < pv(data.get('min_version', '0.0.0')):
            motivo = str(data.get('message') or "Tu versión está obsoleta. Actualiza el addon.")

    if refrescado or st.get('bloqueado') != bool(motivo):
        st['bloqueado'] = bool(motivo)
        ui_utils.save_json('status_check.json', st)
    return motivo

def check_messages():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    os.makedirs(profile, exist_ok=True)  # exist_ok: dos aperturas del menú pueden crearlo a la vez
    cache_path = os.path.join(profile, 'messages_cache.json')

    msg = None
    # Sin caché, la consulta de red bloquearía el menú en cada apertura (hasta 5 s si
    # GitHub va lento). Se guarda la respuesta y solo se vuelve a pedir al caducar, así
    # que un aviso nuevo tarda como mucho _MESSAGES_TTL en salir.
    fetch_remote = True
    if os.path.exists(cache_path):
        try:
            if time.time() - os.path.getmtime(cache_path) < _MESSAGES_TTL:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    msg = json.load(f)
                fetch_remote = False
        except Exception:
            pass

    if fetch_remote:
        try:
            r = requests.get(_MESSAGES_URL, timeout=5)
            if r.status_code == 200:
                msg = r.json()
                # Dos aperturas del menú pueden solaparse. tmp único
                # por proceso/hilo + os.replace -> el caché nunca queda a medio escribir;
                # si el replace falla (p. ej. archivo en uso en Windows), el viejo intacto.
                import threading
                tmp = f'{cache_path}.{os.getpid()}.{threading.get_ident()}.tmp'
                try:
                    with open(tmp, 'w', encoding='utf-8') as f:
                        json.dump(msg, f)
                    os.replace(tmp, cache_path)
                except Exception:
                    try: os.remove(tmp)
                    except OSError: pass
        except Exception:
            pass

    # Alternativa local si no hay red ni caché
    if not msg:
        local_msg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'messages.json')
        if os.path.exists(local_msg):
            try:
                with open(local_msg, 'r', encoding='utf-8') as f: msg = json.load(f)
            except Exception: pass

    avisos = _lista_de_avisos(msg)
    if not avisos:
        return

    # El dir ya existe, lo creó el bloque de caché
    mf = 'messages_state.json'
    st = ui_utils.load_json(mf, default={})
    for aviso in avisos:
        mid = aviso.get('id')
        mrep = aviso.get('repeat', 1)
        if not mid or not isinstance(mrep, int) or mrep == 0:
            continue
        # Las claves de un JSON siempre son texto: con un id numérico el recuento no se
        # encontraría nunca y el aviso saldría en cada apertura.
        mid = str(mid)
        views = st.get(mid, 0)
        if mrep == -1 or views < mrep:
            _mostrar_aviso(aviso)
            st[mid] = views + 1
            ui_utils.save_json(mf, st)


# Formato de messages.json. El objeto de fuera ("id", "title", "message", "repeat") es el
# único aviso que leen las versiones anteriores a la 5.0.0, que fallan si messages.json no
# es un objeto o no es JSON estricto (sin comas al final). Para publicar varios avisos se le
# añade "messages", una lista de avisos con esos mismos campos; entonces las versiones
# nuevas leen solo la lista y el objeto de fuera queda para las viejas. Repetir su id en la
# lista evita que quien ya lo vio en una versión vieja lo vuelva a ver al actualizar.
# Cada aviso admite "text" en vez de "message", y "color" para el título.
# "repeat" es cuántas veces sale al abrir el addon (1 si falta, -1 siempre, 0 nunca, pero
# sigue en "Último aviso").
def _lista_de_avisos(data):
    if not isinstance(data, dict):
        return []
    avisos = data.get('messages')
    if not isinstance(avisos, list):
        avisos = [data]
    return [a for a in avisos if isinstance(a, dict) and (a.get('message') or a.get('text'))]


def _mostrar_aviso(aviso):
    titulo = str(aviso.get('title') or 'Aviso')
    if aviso.get('color'):
        titulo = f"[COLOR {aviso['color']}]{titulo}[/COLOR]"
    xbmcgui.Dialog().ok(titulo, str(aviso.get('message') or aviso.get('text')))


def show_last_message():
    """Muestra los avisos de messages.json, uno tras otro, sin apuntar si ya se han visto."""
    cache_path = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')),
        'messages_cache.json'
    )

    # Vale el caché de cualquier edad, porque menu_root() ya lo refresca con
    # check_messages() al abrir el addon; así el aviso sale al instante sin congelar la
    # interfaz. Solo se va a la red si no hay caché y, como último recurso, se usa el
    # messages.json del addon. isinstance(dict) evita un fallo si el JSON es válido
    # pero no es un objeto (lista, string, null).
    msg = None
    if os.path.exists(cache_path):
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                msg = json.load(f)
        except Exception:
            pass

    if not isinstance(msg, dict):
        try:
            r = requests.get(_MESSAGES_URL, timeout=5)
            if r.status_code == 200:
                msg = r.json()
        except Exception:
            pass

    if not isinstance(msg, dict):
        local_msg = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'messages.json')
        try:
            with open(local_msg, 'r', encoding='utf-8') as f:
                msg = json.load(f)
        except Exception:
            pass

    avisos = _lista_de_avisos(msg)
    if not avisos:
        xbmcgui.Dialog().ok("Último aviso", "No hay mensajes disponibles.")
        return

    for aviso in avisos:
        _mostrar_aviso(aviso)


# --- Menús ---
class LegalScrollDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        try:
            tb = self.getControl(1)
            tb.setText(getattr(self, '_legal_text', ''))
            tb.autoScroll(2000, 4500, 0)
        except Exception as e:
            xbmc.log("[AtresDaily] LegalScrollDialog.onInit: {0}".format(e), xbmc.LOGWARNING)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP):
            self.close()

    def onClick(self, controlId):
        if controlId == 10:
            self.close()


def check_legal_compliance():
    cfg = ui_utils.load_json('settings.json')

    if cfg.get('legal_accepted_v2', False):
        return True

    addon = xbmcaddon.Addon()
    f_path = os.path.join(addon.getAddonInfo('path'), 'AVISO_LEGAL.txt')
    legal_text = "No se encontró el archivo AVISO_LEGAL.txt"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f:
                legal_text = f.read()
        except Exception:
            pass

    dlg = LegalScrollDialog('dialog_legal.xml', addon.getAddonInfo('path'), 'Default', '1080i')
    dlg._legal_text = legal_text
    dlg.doModal()
    del dlg

    prompt_msg = (
        "[COLOR red][B]CONSENTIMIENTO REQUERIDO[/B][/COLOR]\n\n"
        "¿Confirmas haber leído el Acuerdo y aceptas voluntariamente la política integral de uso de AtresDaily?"
    )
    
    user_accepts = xbmcgui.Dialog().yesno(
        "Términos y Condiciones", 
        prompt_msg, 
        yeslabel="SÍ, ACEPTO", 
        nolabel="RECHAZAR"
    )
    
    if user_accepts:
        cfg['legal_accepted_v2'] = True
        ui_utils.save_json('settings.json', cfg)
        verify_cfg = ui_utils.load_json('settings.json')
        if not verify_cfg.get('legal_accepted_v2', False):
            xbmcgui.Dialog().ok("Error del Sistema", "No se pudo guardar el consentimiento en el disco.\nRevisa el espacio y los permisos de la carpeta profile.")
            return False
        try:
            import stats
            stats.activar()
        except Exception as ex:
            xbmc.log(f"[AtresDaily] Telemetría: {ex}", xbmc.LOGDEBUG)
        xbmcgui.Dialog().ok("AtresDaily", "¡Términos Aceptados!\n\nEl sistema se reiniciará para aplicar los cambios.")
        xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")
        return False
    else:
        xbmcgui.Dialog().notification("AtresDaily", "Acceso denegado. Términos rechazados.", xbmcgui.NOTIFICATION_WARNING)
        return False

def menu_root():
    # Bloqueo legal al inicio
    if not check_legal_compliance(): return

    check_messages()
    # Configuración > Al abrir AtresDaily. Se mira antes de pintar el menú (inicio.al_entrar).
    al_entrar = None
    addon = xbmcaddon.Addon()
    if addon.getSetting('inicio_destino') not in ('', '0'):
        import inicio
        al_entrar = inicio.al_entrar(addon, getattr(connector, "CATS", {}))
    _mc = xbmcaddon.Addon().getSetting('menu_colors_enabled') == 'true'
    def _c(color, text):
        return f'[COLOR {color}]{text}[/COLOR]' if _mc else text

    ui_utils.add_item(action="catalog_menu", title="Catálogo", nuevo='catalogo_4.9b', thumbnail=ui_utils.media_icon("catalogo.png"), folder=True)

    # Con menú avanzado activo, el item es una carpeta (navega al submenú). En modo directo
    # es folder=False; abre el prompt y navega a los resultados, sin quedar en el historial.
    _adv_on = xbmcaddon.Addon().getSetting('advanced_search_active') != 'false'
    ui_utils.add_item(action=("advanced_search_menu" if _adv_on else "input_search"), title=_c('dodgerblue', 'Buscar en internet'), thumbnail=ui_utils.media_icon("busqueda.png"), folder=_adv_on)
    ui_utils.add_item(action="view_history", title=_c('aqua', 'Historial de Búsqueda'), thumbnail=ui_utils.media_icon("historial.png"), folder=True)
    ui_utils.add_item(action="live_tv_menu", title=_c('limegreen', 'Directos'), nuevo='directos_4.9', thumbnail=ui_utils.media_icon("directo.png"), folder=True)

    ui_utils.add_item(action="open_url", title=_c('mediumpurple', 'Abrir URL'), thumbnail=ui_utils.media_icon("url.png"), folder=True, plot="Pega una URL de vídeo para reproducirla.")
    ui_utils.add_item(action="loiolink_launch", title=_c('coral', 'loiolink'), thumbnail=ui_utils.media_icon("loiolink.png"), folder=False, plot="Centro de control web y navaja suiza para tu Kodi. Un sistema privado y local que funciona sin instalar aplicaciones ni registrarse.\n\n• Mando a distancia: Controla lo que estás viendo, navega por los menús o gestiona tus addons desde la web.\n• Toda tu colección: Navega por películas, series y música desde el navegador y reprodúcelas en la TV.\n• Streaming al móvil: Envía el vídeo desde el televisor para verlo en la pantalla de tu móvil, tablet o PC.\n• Favoritos: Edita y reordena accesos directos desde el navegador.\n• Escribe sin usar el mando: Escribe búsquedas o enlaces en el navegador y aparecen al instante en Kodi.\n• Copiar y pegar: Pega texto en buscadores de Kodi o copia nombres con el menú contextual.\n• Envío de vídeos, torrents, M3U o AceStream para reproducir, grabar o guardar en local.\n• Escáner web y Telegram: Rastrea páginas y canales para recopilar torrents, vídeos y enlaces.\n• Instalación de addons y archivos: Envía ZIPs o APKs desde el navegador para instalarlos al instante.\n• Grabación HLS: Graba emisiones en directo o programa grabaciones.\n• Explorador de archivos: Navega por carpetas y gestiona fuentes.\n• Apagado y reinicio: Apaga, reinicia o suspende el equipo remotamente.\n• Copia de seguridad: Guarda o restaura addons, favoritos y fuentes.")

    ui_utils.add_item(action="experimental_menu", title=_c('rosybrown', 'Experimental'), nuevo='experimental_4.9', thumbnail=ui_utils.media_icon("experimental.png"), folder=True, plot="Funciones experimentales en pruebas: Modo Cine, AtresDaily WebApp, Megabuscador, Modo Televisión Vintage y Modo Fantasía.")

    ui_utils.add_item(action="view_favorites", title=_c('khaki', 'Mis Favoritos'), thumbnail=ui_utils.media_icon("favoritos.png"), folder=True)
    ui_utils.add_item(action="view_downloads", title=_c('lightblue', 'Mis Descargas'), thumbnail=ui_utils.media_icon("descargas.png"), folder=True)

    import novedades
    clave_info, _ = novedades.claves()
    ui_utils.add_item(action="info_menu", title=_c('thistle', 'EspaKodi e Información'), nuevo=clave_info, thumbnail=ui_utils.media_icon("info.png"), folder=True)


    ui_utils.add_item(action="settings_menu", title=_c('ivory', 'Configuración'), nuevo='configuracion_4.9d', thumbnail=ui_utils.media_icon("opciones.png"), folder=True)
    ui_utils.close_item_list()

    try:
        import welcome_splash
        welcome_splash.show_if_needed()
    except Exception as e:
        xbmc.log(f"[AtresDaily] welcome_splash error: {e}", xbmc.LOGERROR)

    if al_entrar:
        inicio.abrir(*al_entrar)


def experimental_menu():
    ui_utils.visto('experimental_4.9')
    ui_utils.add_item(action="experimental_home",
                      title="Modo Cine",
                      thumbnail=ui_utils.media_icon("modo_cine.png"), folder=False,
                      plot="Interfaz experimental tipo streaming: hero, filas de pósters por categoría y fanart de fondo dinámico. Aún en pruebas.")
    ui_utils.add_item(action="webapp_open", title="AtresDaily WebApp", thumbnail=ui_utils.media_icon("webapp.png"), folder=False, plot="Abre la interfaz web de AtresDaily en el navegador. Navega el catálogo y reproduce vídeos y directos directamente en el navegador.")
    ui_utils.add_item(action="busqueda_total",
                      title="[COLOR white]Megabuscador[/COLOR]",
                      thumbnail=ui_utils.media_icon("busqueda.png"), folder=True,
                      plot="Busca a la vez en varias plataformas (Dailymotion, YouTube, Odysee, PeerTube, BitChute) y une los resultados ordenados por relevancia, indicando la fuente de cada uno. Elige las plataformas y otras opciones (limpiar títulos, variaciones, proxy) en su propio submenú.")
    ui_utils.add_item(action="crt_config_menu",
                      title="Modo Televisión Vintage (CRT)",
                      thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True,
                      plot="Filtro estético que simula una televisión de tubo (CRT) antigua sobre el vídeo: líneas de barrido, viñeta, marco curvo, tinte cálido, grano, barra de desincronización y parpadeo. Cada efecto se activa por separado en su submenú.")
    ui_utils.add_item(action="fantasia",
                      title="Modo Fantasía", nuevo='fantasia',
                      thumbnail=ui_utils.media_icon("modo_fantasia.png"), folder=False,
                      plot="Modo experimental que no aporta ninguna funcionalidad nueva. Busca llevar a Kodi al límite para experimentar, aprender y mostrar de lo que es capaz. La misma AtresDaily de siempre con la interfaz pasada de vueltas, animaciones y efectos por todas partes. Aún en pruebas.")
    ui_utils.close_item_list()


def crt_config_menu():
    addon = xbmcaddon.Addon()
    def _st(k): return addon.getSetting(k) == 'true'
    def _onoff(v): return "[COLOR lime]ON[/COLOR]" if v else "[COLOR red]OFF[/COLOR]"

    master = _st('crt_enabled')
    ui_utils.add_item(
        action="crt_toggle", title=f"Activar Modo CRT: {_onoff(master)}",
        thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_enabled",
        plot="Activa o desactiva el filtro CRT sobre la reproducción de vídeo. Al "
             "activarlo puede que necesites reiniciar Kodi para que empiece a aplicarse.")
    if master:
        ui_utils.add_item(
            action="crt_toggle", title=f"Líneas de barrido (scanlines): {_onoff(_st('crt_scanlines'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_scanlines",
            plot="Finas líneas horizontales oscuras, el rasgo más reconocible de una TV de tubo.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Viñeta (bordes oscuros): {_onoff(_st('crt_vignette'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_vignette",
            plot="Oscurece las esquinas para imitar el brillo desigual del tubo.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Marco curvo del tubo: {_onoff(_st('crt_bezel'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_bezel",
            plot="Marco oscuro con esquinas redondeadas que simula la curvatura de la pantalla.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Tinte cálido (sepia): {_onoff(_st('crt_sepia'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_sepia",
            plot="Da un tono ámbar cálido a la imagen, como el fósforo de las pantallas viejas.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Grano / estática: {_onoff(_st('crt_grain'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_grain",
            plot="Ruido animado superpuesto, como la nieve de una señal débil de antena.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Barra de desincronización: {_onoff(_st('crt_rollbar'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_rollbar",
            plot="Banda de luz tenue que recorre la pantalla de arriba abajo, como una TV mal sintonizada.")
        ui_utils.add_item(
            action="crt_toggle", title=f"Parpadeo de brillo: {_onoff(_st('crt_flicker'))}",
            thumbnail=ui_utils.media_icon("crt_tv.png"), folder=True, key="crt_flicker",
            plot="Leve parpadeo del brillo, como el barrido inestable de un tubo antiguo.")
    ui_utils.close_item_list()


def crt_toggle(key):
    addon = xbmcaddon.Addon()
    if key in ('crt_enabled', 'crt_scanlines', 'crt_vignette', 'crt_bezel', 'crt_sepia',
               'crt_grain', 'crt_rollbar', 'crt_flicker'):
        activado = addon.getSetting(key) != 'true'
        addon.setSetting(key, 'true' if activado else 'false')
        if key == 'crt_enabled' and activado:
            xbmcgui.Dialog().ok(
                "Modo CRT activado",
                "El filtro se aplicará a [B]todos los vídeos[/B] que reproduzcas en "
                "Kodi mientras esté activo, no solo a AtresDaily.\n\n"
                "Si no aparece al reproducir, [B]reinicia Kodi[/B] una vez para que "
                "el servicio del filtro arranque.")
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin('Container.Refresh')


def info_menu():
    """Submenú de información y recursos del addon."""
    try:
        import novedades
        clave_info, clave_novedades = novedades.claves()
        ui_utils.visto(clave_info)

        # Menú contextual con el aviso legal
        cm_info = [
            ("Leer AVISO LEGAL completo", f"RunPlugin({sys.argv[0]}?action=show_legal_txt)"),
            ("REVOCAR Aceptación de Términos", f"RunPlugin({sys.argv[0]}?action=revoke_legal)")
        ]
        cm_web = [("Código base de RubénSDFA1laberot", "Notification(AtresDaily, Código base de RubénSDFA1laberot, 3000)")]

        ui_utils.add_item(action="show_web_info", title="Universo EspaKodi", thumbnail=ui_utils.media_icon("info_universo.png"), folder=False, context=cm_web)

        # Versión instalada
        try:
            ver = xbmcaddon.Addon().getAddonInfo("version") or "?.?.?"
        except Exception:
            ver = "?.?.?"

        ui_utils.add_item(action="play_intro", title=f"Versión {ver}", thumbnail=ui_utils.media_icon("info_version.png"), folder=False)

        ui_utils.add_item(
            action="novedades",
            title="Novedades",
            nuevo=clave_novedades,
            thumbnail=ui_utils.media_icon("info_novedades.png"),
            folder=False,
            plot=("Qué se ha añadido y qué se ha arreglado en cada versión de AtresDaily, por "
                  "apartados.\n\nEl punto verde sale cuando hay novedades que todavía no has "
                  "leído.")
        )

        # Estado del repositorio de actualizaciones
        try:
            from repository import detector
            is_val = detector.is_installed("atresdaily", "repository.atresdaily")
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallo al cargar módulo repository: {e}", xbmc.LOGWARNING)
            from ui_utils import is_repo_installed
            is_val = is_repo_installed("atresdaily", "repository.atresdaily")

        status_tag = "[COLOR lime]● INSTALADO[/COLOR]" if is_val else "[COLOR orange]○ NO DETECTADO[/COLOR]"
        repo_title = f"Actualizaciones: {status_tag}"
        ui_utils.add_item(
            action="check_atres_repo",
            title=repo_title,
            thumbnail=ui_utils.media_icon("info_repo.png"),
            folder=False,
            plot="Verifica que el repositorio oficial está instalado para que el addon se mantenga actualizado solo."
        )

        # Solo son carpetas con las listas clásicas; la ventana propia no usa directorio
        import list_screen
        clasica = list_screen.clasica_activada()
        ui_utils.add_item(
            action="espakodi_addons_menu",
            title="EspaKodi addons",
            nuevo='espakodi_addons_4.9',
            thumbnail=ui_utils.media_icon("espakodi_logo.jpg") or ui_utils.media_icon("descargas.png"),
            folder=clasica,
            plot=("Instala y abre los addons del ecosistema EspaKodi (EspaTV, EspaDaily, EKHorus, "
                  "loiolink, TopZilla, StreamNinja, EKGames y más) y sus dependencias, como "
                  "Elementum, InputStream Adaptive o ResolveURL.\n\n"
                  "Cada addon dice si está instalado, desactivado o sin instalar. Al pulsar uno que "
                  "ya tienes se abre, si tiene menú propio; si estaba desactivado se activa, y si te "
                  "falta se instala desde su repositorio. Kodi pregunta antes y, si le dices que no, "
                  "no se instala. Si le falta alguna dependencia, avisa de cuál.\n\n"
                  "También abre la web de EspaKodi y el Repositorio Unificado, y lleva a Descargar "
                  "EspaKodi.")
        )

        ui_utils.add_item(
            action="espakodi_app_menu",
            title="Descargar EspaKodi (Android y Windows)",
            nuevo='espakodi_app',
            thumbnail=ui_utils.media_icon("ek_apk.png"),
            folder=clasica,
            plot=("Descarga sin salir de Kodi la última versión de la app EspaKodi para Android, "
                  "de 32 o de 64 bits, EspaKodi LaRoja, vestida de selección, y el instalador de "
                  "EspaKodi para Windows.\n\n"
                  "Te deja elegir la carpeta (un USB, por ejemplo) y comprueba que el archivo llega "
                  "entero. En Android instala el APK desde ahí mismo si usas EspaKodi o Kodi 22, o "
                  "con root, y si no te explica cómo hacerlo a mano. En Windows puede abrir el "
                  "instalador al acabar.\n\n"
                  '"Borrar descargas" quita lo descargado cuando ya no hace falta, y "Web del APK" '
                  "abre la página con todas las versiones.\n\n"
                  "En el Telegram de EspaKodi (t.me/espakodi) hay más versiones, para LibreELEC, "
                  "CoreELEC y una distribución Linux, y variantes de la app de Android.")
        )

        ui_utils.add_item(
            action="show_last_message",
            title="Último aviso",
            thumbnail=ui_utils.media_icon("info_aviso.png"),
            folder=False,
            plot="Muestra el último mensaje o aviso."
        )

        ui_utils.add_item(
            action="iptv_guide",
            title="Guía de las listas de canales",
            nuevo='iptv_guide',
            thumbnail=ui_utils.media_icon("info_guia.png"),
            folder=False,
            plot=("Cómo añadir listas de canales en directo (IPTV, AceStream, Telegram, webs, "
                  "Xtream y listas públicas), cómo verlas y gestionarlas y cómo "
                  "llevarlas a la sección TV de Kodi.\n\nLas listas están en TV en directo, "
                  "debajo de TDT Channels.")
        )

        ui_utils.add_item(action="show_info", title="Términos y Condiciones", thumbnail=ui_utils.media_icon("info_terminos.png"), folder=False, context=cm_info)

    except Exception as e:
        xbmc.log(f"[AtresDaily] Error crítico en info_menu: {e}", xbmc.LOGERROR)
    finally:
        # En finally, para que el listado se cierre siempre y Kodi no se quede esperando
        ui_utils.close_item_list()


def _jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return {}


def _addon_is_known(addon_id):
    resp = _jsonrpc("Addons.GetAddonDetails", {
        "addonid": addon_id,
        "properties": ["enabled"]
    })
    return "result" in resp and "addon" in resp.get("result", {})


def espakodi_addons_menu():
    ui_utils.visto('espakodi_addons_4.9')
    import espakodi_installer
    import list_screen
    list_screen.ventana_o_lista("espakodi_addons_menu", espakodi_installer.mostrar_ventana,
                                espakodi_installer.render_menu)


def espakodi_app_menu():
    ui_utils.visto('espakodi_app')
    import espakodi_app
    import list_screen
    list_screen.ventana_o_lista("espakodi_app_menu", espakodi_app.mostrar_ventana,
                                espakodi_app.render_menu)

def history_menu():
    """Submenú que agrupa Historial de Exploración e Historial de Reproducciones."""
    ui_utils.add_item(action="exp_menu", title="[COLOR cyan]Historial de Exploración[/COLOR]", thumbnail=ui_utils.media_icon("hist_exploracion.png"), folder=True)
    ui_utils.add_item(action="watch_history", title="[COLOR mediumpurple]Historial de Reproducciones[/COLOR]", thumbnail=ui_utils.media_icon("hist_reproducciones.png"), folder=True)
    ui_utils.close_item_list()

def _espadaily_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.espadaily")

def show_vpn_info():
    quitar = xbmcgui.Dialog().yesno(
        "Consejo",
        "Si tienes problemas para acceder al catálogo, desactiva la VPN.",
        nolabel="Quitar mensaje",
        yeslabel="OK",
        defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
    )
    if not quitar:
        xbmcaddon.Addon().setSetting('hide_vpn_info', 'true')
        xbmc.executebuiltin("Container.Refresh")


# La instalación de addons está en espakodi_installer.py. _jsonrpc y _addon_is_known
# están aquí porque los usa catalog_menu (SlyGuy).
def _espatv_install():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.espatv")


def _espatv_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.espatv")


def _loiolog_install():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.program.loiolog")


def _loiolog_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.program.loiolog")


def _flowfav_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.program.flowfavmanager")


def _streamninja_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.streamninja")


def _atresdaily_launch():
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.atresdaily")


# --- Instalador del repositorio de SlyGuy ---
_SLYGUY_REPO_ID = "repository.slyguy"
_SLYGUY_REPO_ZIP = "https://k.slyguy.xyz/repository.slyguy.zip"

def _slyguy_install(addon_id, addon_name):
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("AtresDaily", f"Abriendo {addon_name}...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin(f"RunAddon({addon_id})")
        return
    except Exception:
        pass

    try:
        xbmcaddon.Addon(_SLYGUY_REPO_ID)
        if xbmcgui.Dialog().yesno("AtresDaily", f"{addon_name} no está instalado pero el repositorio SlyGuy sí.\n\n¿Instalar {addon_name} ahora?"):
            xbmc.executebuiltin(f"InstallAddon({addon_id})")
            xbmcgui.Dialog().ok("AtresDaily", f"Se ha solicitado la instalación de {addon_name}.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve al Catálogo y pulsa de nuevo para abrirlo.")
        return
    except Exception:
        pass

    opts = [
        "Instalar repositorio automáticamente",
        "Ver instrucciones manuales",
    ]
    sel = xbmcgui.Dialog().select(
        f"Se necesita el repo SlyGuy para {addon_name}", opts
    )

    if sel == 0:
        _auto_install_slyguy_repo(addon_id, addon_name)
    elif sel == 1:
        _show_slyguy_instructions(addon_name)

def _auto_install_slyguy_repo(addon_id, addon_name):
    """Descarga e instala el repo SlyGuy automáticamente."""
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Descargando repositorio SlyGuy...")
    zip_path = None

    try:
        # Descargar ZIP del repo
        dp.update(10, "Descargando repositorio...")
        r = requests.get(_SLYGUY_REPO_ZIP, timeout=30)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        # Validar que el contenido es un ZIP real (magic bytes: PK\x03\x04)
        if len(r.content) < 4 or r.content[:2] != b'PK':
            raise Exception("El archivo descargado no es un ZIP válido")

        # Validar tamaño razonable (no debería ser >50MB para un repo)
        if len(r.content) > 50 * 1024 * 1024:
            raise Exception(f"Tamaño sospechoso: {len(r.content) // 1024}KB")

        zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "repository.slyguy.zip")
        with open(zip_path, "wb") as f:
            f.write(r.content)

        dp.update(50, "Extrayendo repositorio...")

        # Extraer al directorio de addons con validación de seguridad
        addons_dir = xbmcvfs.translatePath("special://home/addons/")
        import zipfile
        with zipfile.ZipFile(zip_path, "r") as zf:
            # Protección contra path traversal. Sin el separador, una carpeta hermana
            # ("addons_x") pasaría el startswith.
            addons_real = os.path.realpath(addons_dir)
            for entry in zf.namelist():
                resolved = os.path.realpath(os.path.join(addons_dir, entry))
                if resolved != addons_real and not resolved.startswith(addons_real + os.sep):
                    raise Exception(f"ZIP contiene ruta sospechosa: {entry}")
            zf.extractall(addons_dir)

        dp.update(80, "Actualizando addons locales...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(2000)

        # Activar el repo
        xbmc.executebuiltin(f"EnableAddon({_SLYGUY_REPO_ID})")
        xbmc.sleep(1000)

        dp.update(90, f"Instalando {addon_name}...")
        xbmc.executebuiltin(f"InstallAddon({addon_id})")

        dp.close()
        xbmcgui.Dialog().notification("AtresDaily", f"Repo SlyGuy instalado. Instalando {addon_name}...", xbmcgui.NOTIFICATION_INFO, 5000)

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error instalando repo SlyGuy: {e}", xbmc.LOGERROR)

        # Si falla (ej: orígenes desconocidos desactivados)
        choice = xbmcgui.Dialog().yesno(
            "Error de instalación",
            f"No se pudo instalar automáticamente.\n\n"
            f"Error: {e}\n\n"
            "Puede que necesites activar 'Orígenes desconocidos' en Ajustes.\n"
            "¿Abrir Ajustes del Sistema?",
        )
        if choice:
            xbmc.executebuiltin("ActivateWindow(systemsettings)")
    finally:
        # Limpiar ZIP temporal siempre
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass

def _show_slyguy_instructions(addon_name):
    """Muestra instrucciones para instalar el repo SlyGuy manualmente."""
    t = (
        f"[B]Cómo instalar {addon_name}[/B]\n\n"
        "1. Ve a [B]Ajustes → Sistema → Addons[/B]\n"
        "   Activa [B]Orígenes desconocidos[/B]\n\n"
        "2. Ve a [B]Ajustes → Administrador de archivos[/B]\n"
        "   Añade fuente: [B]https://k.slyguy.xyz[/B]\n"
        "   Nombre: [B]slyguy[/B]\n\n"
        "3. Ve a [B]Addons → Instalar desde ZIP[/B]\n"
        "   Selecciona [B]slyguy → repository.slyguy.zip[/B]\n\n"
        f"4. Ve a [B]Addons → Instalar desde repositorio[/B]\n"
        f"   SlyGuy → Video addons → [B]{addon_name}[/B]\n\n"
        "Tras instalarlo, vuelve al Catálogo de AtresDaily y pulsa de nuevo."
    )
    xbmcgui.Dialog().textviewer(f"Instalar {addon_name}", t)

# Categorías del catálogo que llevan el punto verde de lo nuevo, con su clave.
_CATS_NUEVAS = {"Telenovelas": "cat_telenovelas", "Snacks": "cat_snacks",
                "Vertical": "cat_vertical", "Pódcast": "cat_podcast"}


def catalog_menu():
    ui_utils.visto('catalogo_4.9b')
    # Botones de gestión
    # [Categorías / Carpetas]
    items_count = len(category_manager.load_cats())
    li = xbmcgui.ListItem(label=f"[COLOR white][Categorías / Carpetas] ({items_count})[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('categorias_usuario.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=cat_menu", listitem=li, isFolder=True)

    # [Historial]
    li = xbmcgui.ListItem(label="[COLOR white]Historial[/COLOR]")
    li.setArt({'icon': ui_utils.media_icon('historial.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=history_menu", listitem=li, isFolder=True)

    # Categorías del catálogo con sus iconos
    icon_map = {
        "Series": "tv.png",
        "Telenovelas": "telenovelas.png",
        "Programas": "pelis.png",
        "Documentales": "documentales.png",
        "Infantil": "dibus.png",
        "Actualidad": "noticias.png",
        "Cine": "cine.png",
        "Snacks": "snacks.png",
        "Vertical": "vertical.png",
        "Pódcast": "podcast.png",
        "Extra": "extra.png"
    }
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    
    cats_dict = getattr(connector, "CATS", {})
    for k, v in cats_dict.items():
        thumb = ui_utils.media_icon("carpeta.png")
        if k in icon_map:
            icon_file = os.path.join(addon_path, "resources", "media", icon_map[k])
            if os.path.exists(icon_file):
                thumb = icon_file
                
        ui_utils.add_item(action="list_cat", title=categorias.nombre(k), url=v, thumbnail=thumb, folder=True,
                          nuevo=_CATS_NUEVAS.get(k, ""))

    # [Listas de Trakt.tv / TopZilla Demo]
    li = xbmcgui.ListItem(label=f"{ui_utils.punto('trakt_4.9')}Top películas y series - TopZilla Mini Demo")
    li.setArt({'icon': ui_utils.media_icon("topzilla_icon.jpg") or 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=trakt_root", listitem=li, isFolder=True)

    # EspaTV
    try:
        xbmcaddon.Addon("plugin.video.espatv")
        espatv_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        espatv_status = "[COLOR gray]No instalado[/COLOR]"
    li = xbmcgui.ListItem(label=f"[COLOR red]Es[/COLOR][COLOR gold]pa[/COLOR][COLOR red]TV[/COLOR] - TV, radio, podcast, agenda deportiva, top películas y series y más - {espatv_status}")
    li.setArt({'icon': ui_utils.media_icon('espatv_icon.jpg')})
    li.setInfo('video', {'plot':
        "[B]EspaTV[/B] - Addon todo-en-uno para contenido en castellano\n\n"
        "TV, Dailymotion, YouTube, radio, podcast, agenda deportiva, top películas y series y más.\n\n"
        "Pulsa para abrir o instalar automáticamente.\n\n"
        "https://github.com/espakodi/espatv"
    })
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=espatv_install", listitem=li, isFolder=False)

    # Publi EspaDaily
    li = xbmcgui.ListItem(label="[COLOR gold]Espa[/COLOR][COLOR blue]Daily[/COLOR] - Más contenido: RTVE, Mitele y otras")
    li.setArt({'icon': ui_utils.media_icon('espadaily_icon.jpg')})
    li.setInfo('video', {'plot':
        "[B]EspaDaily[/B] - Addon complementario de AtresDaily\n\n"
        "Accede al contenido de RTVE, Mitele y otras plataformas españolas.\n\n"
        "Búscalo como plugin.video.espadaily o visita:\n"
        "https://github.com/fullstackcurso"
    })
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=espadaily_launch", listitem=li, isFolder=False)

    # Boton de alerta de conexion (VPN)
    if xbmcaddon.Addon().getSetting('hide_vpn_info') != 'true':
        li = xbmcgui.ListItem(label="[COLOR gold]Si tienes problemas para acceder al catalogo, desactiva la VPN[/COLOR]")
        li.setArt({'icon': ui_utils.media_icon('aviso.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?action=show_vpn_info", listitem=li, isFolder=False)

    ui_utils.close_item_list()

def settings_menu():
    ui_utils.visto('configuracion_4.9d')
    cfg = ui_utils.load_json('settings.json')
    _addon = xbmcaddon.Addon()

    import inicio
    ui_utils.add_item(action="inicio_elegir", nuevo='inicio',
        title=f"Al abrir AtresDaily: [COLOR green]{inicio.texto(_addon, getattr(connector, 'CATS', {}))}[/COLOR]",
        thumbnail=ui_utils.media_icon("adv_inicio.png"), folder=False,
        plot="Lo que se abre nada más entrar en AtresDaily: el menú principal de siempre, el Modo Cine, el "
             "Modo Fantasía o una parte del menú, como el Catálogo o una de sus categorías, Directos, En "
             "Directo A3, Buscar en internet o Mis Favoritos. Con Atrás se vuelve al menú principal.\n\n"
             "Lo mismo está en la pestaña AtresDaily de los ajustes del addon.\n\n[I]Pulsa para elegir.[/I]")

    gratis = _addon.getSetting('gratis_primero') == 'true'
    ui_utils.add_item(action="toggle_gratis_primero", nuevo='gratis_primero',
        title=f"Lo gratis primero: {'[COLOR green]ACTIVADO[/COLOR]' if gratis else '[COLOR gray]DESACTIVADO[/COLOR]'}",
        thumbnail=ui_utils.media_icon("adv_gratis.png"), folder=False,
        plot="En cada página de capítulos de un programa, en el catálogo y en el Modo Cine, van primero "
             "los que se ven sin cuenta, después los que piden una cuenta gratuita de A3Player y al final "
             "los de pago. En las listas de programas del catálogo pasan al final los marcados como de "
             "pago.\n\n"
             "Para saber qué capítulos son gratis, AtresDaily pregunta a A3Player por algunos de cada "
             "página y lo recuerda una semana. Al volver a una página solo pregunta por los pocos que "
             "pueden haber cambiado, como lo recién emitido. Con esas preguntas, la primera vez que abres "
             "una página de capítulos tarda algo más, y por eso viene desactivado.\n\n"
             "Lo mismo está en la pestaña AtresDaily de los ajustes del addon.\n\n"
             f"[I]Pulsa para {'desactivar' if gratis else 'activar'}.[/I]")

    # WebApp, red local y puerto
    _webapp_settings_items(cfg)

    # Menú de búsqueda
    if _addon.getSetting('advanced_search_active') != 'false':
        m_label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        m_plot = "MENÚ AVANZADO: Muestra opciones de búsqueda (Modo Cine, HD, Recientes) antes de buscar.\n\n[I]Pulsa para volver a búsqueda directa.[/I]"
    else:
        m_label = "Menú de Búsqueda: [COLOR gray]SIMPLE (Directa)[/COLOR]"
        m_plot = "BÚSQUEDA DIRECTA: Abre el teclado y busca inmediatamente sin preguntar.\n\n[I]Pulsa para activar menú avanzado.[/I]"
    ui_utils.add_item(action="toggle_advanced_search", title=m_label, thumbnail=ui_utils.media_icon("adv_busqueda.png"), folder=False, plot=m_plot)

    _wmode = cfg.get('web_input_mode', 'keyboard')
    _wmap = {'keyboard': '[COLOR gray]Teclado de Kodi[/COLOR]',
             'ask': '[COLOR green]Preguntar cada vez[/COLOR]',
             'web': '[COLOR green]Móvil/PC (web)[/COLOR]'}
    ui_utils.add_item(action="input_mode_menu",
        title=f"Escribir búsquedas con: {_wmap.get(_wmode, _wmap['keyboard'])}",
        thumbnail=ui_utils.media_icon("adv_teclado.png"), folder=False,
        plot="Cómo introduces el texto al buscar:\n\n"
             "· Teclado de Kodi: el teclado de siempre con el mando.\n"
             "· Preguntar cada vez: al buscar eliges teclado o web.\n"
             "· Móvil/PC (web): abre una web efímera para escribir desde el navegador del móvil o PC.\n\n"
             "[I]Pulsa para cambiar.[/I]")

    ext_on = _addon.getSetting('ext_search_enabled') != 'false'
    if ext_on:
        ext_label = "Buscar en otros addons: [COLOR green]ACTIVADO[/COLOR]"
        ext_plot = "Al buscar un programa, aparece la opción de buscarlo también en otros addons instalados.\n\n[COLOR blue][I]Pulsa para desactivar.[/I][/COLOR]"
    else:
        ext_label = "Buscar en otros addons: [COLOR grey]DESACTIVADO[/COLOR]"
        ext_plot = "Los resultados de búsqueda solo muestran contenido de AtresDaily, sin ofrecer búsqueda en otros addons.\n\n[COLOR blue][I]Pulsa para activar.[/I][/COLOR]"
    ui_utils.add_item(action="toggle_ext_search_enabled", title=ext_label, thumbnail=ui_utils.media_icon("adv_busqueda.png"), folder=False, plot=ext_plot)

    if ext_on:
        dlg_on = _addon.getSetting('ext_search_dialog') != 'false'
        dlg_label = "   Preguntar dónde buscar: [COLOR green]SÍ[/COLOR]" if dlg_on else "   Preguntar dónde buscar: [COLOR grey]NO[/COLOR]"
        dlg_plot = ('Con la búsqueda externa activa, te pregunta en qué destino buscar y ofrece el aviso "¿No es lo que buscas?" en los resultados.\n\n'
                    'Desactivado: no pregunta ni muestra ese aviso; va directo al primer destino configurado.\n\n[I]Pulsa para cambiar.[/I]')
        ui_utils.add_item(action="toggle_ext_search_dialog", title=dlg_label, thumbnail=ui_utils.media_icon("adv_busqueda.png"), folder=False, plot=dlg_plot)
        ui_utils.add_item(action="ssm_menu", title="   Personalizar '¿Dónde buscar?'", thumbnail=ui_utils.media_icon("adv_busqueda.png") or "DefaultAddonProgram.png", folder=True, plot="Añade atajos a addons instalados, comandos personalizados o favoritos de Kodi a la ventana de búsqueda externa.")

    # Interruptor de AceStream
    ace_on = _addon.getSetting('acestream_enabled') == 'true'
    if ace_on:
        ace_label = "Búsqueda AceStream: [COLOR green]ACTIVADO[/COLOR]"
        ace_plot = (
            "Permite buscar identificadores AceStream consultando la API pública oficial (search.acestream.net).\n\n"
            "Esta opción está oculta por defecto porque AceStream es una tecnología P2P de uso dual y existe el riesgo de "
            "persecución injusta a herramientas que la integran. Activarla es una decisión consciente del usuario.\n\n"
            "Pulsa para DESACTIVAR"
        )
    else:
        ace_label = "Búsqueda AceStream: [COLOR gray]DESACTIVADO[/COLOR]"
        ace_plot = (
            "Permite buscar identificadores AceStream consultando la API pública oficial (search.acestream.net).\n\n"
            "Esta opción está oculta por defecto porque AceStream es una tecnología P2P de uso dual y existe el riesgo de "
            "persecución injusta a herramientas que la integran. Activarla es una decisión consciente del usuario.\n\n"
            "Pulsa para ACTIVAR"
        )
    ui_utils.add_item(action="toggle_acestream_enabled", title=ace_label, thumbnail=ui_utils.media_icon("adv_acestream.png"), folder=False, plot=ace_plot)

    ui_utils.add_item(action="acc_menu", title="Accesibilidad", thumbnail=ui_utils.media_icon("adv_acc.png"), folder=True, plot="Opciones de accesibilidad: modo de color, negrita y reemplazo de símbolos.")

    _as_ico = ui_utils.media_icon("adv_autostart.png") or "DefaultAddonService.png"
    ui_utils.add_item(action="autostart_menu", title="Inicio automático de addons", thumbnail=_as_ico, folder=True, plot="Configura hasta 3 addons que se abrirán automáticamente al arrancar Kodi.")
    ui_utils.add_item(action="autofav_menu", title="Inicio automático de favoritos", thumbnail=_as_ico, folder=True, plot="Configura hasta 3 favoritos de Kodi que se abrirán automáticamente al arrancar.")

    # Orden y duración de resultados (agrupado en submenú propio)
    ui_utils.add_item(action="search_order_menu", title="Orden y duración de resultados", nuevo='orden_4.9',
        thumbnail=ui_utils.media_icon("adv_priorizar.png"), folder=True,
        plot='Cómo se ordenan y filtran los resultados de Dailymotion: por parecido con lo '
             'buscado, vídeos largos primero, ocultar clips cortos, recientes primero y exigir '
             'el número de capítulo o todas las palabras. Distingue las dos rutas: el botón '
             '"Buscar" del catálogo y la búsqueda manual en internet. Lo mismo está en la '
             'pestaña Dailymotion de los ajustes del addon.')

    ui_utils.add_item(action="minijuegos_menu", title="Minijuegos", nuevo='minijuegos',
        thumbnail=ui_utils.media_icon("adv_minijuegos.png"), folder=True,
        plot='Ajustes de los catorce minijuegos que esconden los separadores de los menús: el '
             'easter egg, la dificultad, los mandos en pantalla para jugar con los dedos, el '
             'contador de rendimiento y borrar récords. Lo mismo está en la pestaña Minijuegos '
             'de los ajustes del addon.')

    # --- Otras opciones ---
    ui_utils.add_item(action="set_precision", title="Precisión de Búsqueda (Nivel de Contexto)", thumbnail=ui_utils.media_icon("adv_precision.png"), folder=False, plot="Configura el nivel de detalle que el addon usa para buscar contenido alternativo.")

    # Caché configurable
    expiry = cfg.get('cache_expiry')
    if expiry is None: expiry = 2592000 if cfg.get('cache_active', False) else 0

    if expiry == 0: c_txt = "[COLOR gray]APAGADO[/COLOR]"
    elif expiry == 86400: c_txt = "[COLOR green]1 DÍA[/COLOR]"
    elif expiry == 604800: c_txt = "[COLOR green]1 SEMANA[/COLOR]"
    elif expiry == 2592000: c_txt = "[COLOR green]1 MES[/COLOR]"
    elif expiry == 31536000: c_txt = "[COLOR green]1 AÑO[/COLOR]"
    elif expiry == -1: c_txt = "[COLOR gold]INDEFINIDO[/COLOR]"
    else: c_txt = f"[COLOR green]{expiry // 3600}h[/COLOR]"

    c_label = f"Caché: {c_txt}"
    c_plot = "CACHÉ: Configura cuánto tiempo se guardan los menús para cargar más rápido.\n\n[I]Pulsa para seleccionar duración.[/I]"
    ui_utils.add_item(action="set_cache_config", title=c_label, thumbnail=ui_utils.media_icon("adv_cache.png"), folder=False, plot=c_plot)

    ui_utils.add_item(action="clear_ui_cache", title="Limpiar Interfaz (Reload)", thumbnail=ui_utils.media_icon("adv_refrescar.png"), folder=False, plot="Refresca la vista actual para aplicar cambios o ver nuevos contenidos.")
    ui_utils.add_item(action="storage_menu", title="Limpiar caché / almacenamiento", thumbnail=ui_utils.media_icon("adv_cache.png"), folder=False, plot="Muestra cuánto ocupa cada caché del addon y permite borrarlas. Tus favoritos, historial y ajustes nunca se tocan.")
    ui_utils.add_item(action="kodi_maintenance_menu", title="Limpieza y mantenimiento de Kodi", thumbnail=ui_utils.media_icon("adv_mantenimiento.png"), folder=False, plot="Mantenimiento general de Kodi: paquetes de instalación, miniaturas en desuso, compactar bases de datos y copia de tu configuración de Kodi. No toca tus datos de AtresDaily ni los de otros addons.")
    ui_utils.add_item(action="restore_warnings", title="Restaurar mensajes de advertencia", thumbnail=ui_utils.media_icon("info.png") or "DefaultIconInfo.png", folder=False, plot="Vuelve a mostrar los mensajes de aviso que hayas ocultado (nota VPN en directos, aviso VPN en catálogo).")

    ui_utils.add_item(action="backups_menu", title="Copias de Seguridad", thumbnail=ui_utils.media_icon("adv_backup.png"), folder=True)

    # Carpeta de descargas
    d_path = cfg.get('download_path', '')
    d_label = f"Ruta de Descargas: [COLOR green]{d_path}[/COLOR]" if d_path else "Ruta de Descargas: [COLOR gray]NO CONFIGURADA[/COLOR]"
    ui_utils.add_item(action="set_download_path", title=d_label, thumbnail=ui_utils.media_icon("adv_ruta_dl.png"), folder=False, plot="Selecciona la carpeta donde se guardarán los vídeos descargados.")

    # Modo Anti-Errores de Dailymotion, cuatro niveles
    dm_level = cfg.get('dm_safe_level', 0)  # 0=off, 1=basic, 2=extreme, 3=yt-dlp
    if dm_level == 0:
        dm_label = "Modo Anti-Errores DM: [COLOR gray]DESACTIVADO[/COLOR]"
    elif dm_level == 1:
        dm_label = "Modo Anti-Errores DM: [COLOR green]BÁSICO[/COLOR]"
    elif dm_level == 2:
        dm_label = "Modo Anti-Errores DM: [COLOR gold]EXTREMO[/COLOR]"
    else:
        dm_label = "Modo Anti-Errores DM: [COLOR cyan]YT-DLP[/COLOR]"
    dm_plot = (
        "MODO ANTI-ERRORES DAILYMOTION:\n\n"
        "[B]DESACTIVADO:[/B] Conexión normal de AtresDaily.\n\n"
        "[B]BÁSICO:[/B] Simula teléfono móvil Android con cookies de sesión.\n\n"
        "[B]EXTREMO:[/B] Todas las técnicas del addon Dailymotion de Gujal00:\n"
        "- Subtítulos automáticos\n"
        "- Verificación de enlaces (HEAD)\n"
        "- Limitador de calidad\n"
        "- Gestión avanzada de tokens y cookies\n"
        "- API moderna de Kodi (VideoInfoTag)\n\n"
        "[B]YT-DLP:[/B] Usa yt-dlp con TLS spoofing (curl-cffi).\n"
        "Requiere: pip install yt-dlp curl-cffi\n"
        "Recomendado en Windows donde el CDN bloquea Kodi.\n\n"
        "[I]Pulsa para cambiar el nivel.[/I]"
    )
    ui_utils.add_item(action="set_dm_safe_level", title=dm_label, thumbnail=ui_utils.media_icon("adv_anti_errores.png"), folder=False, plot=dm_plot)

    ui_utils.add_item(action="dm_listas_menu", title="Listas de Dailymotion", nuevo='dm_listas',
                      thumbnail=ui_utils.media_icon("adv_listas_dm.png"), folder=True,
                      plot="Qué vídeos de Dailymotion se ocultan de las listas porque no se pueden "
                           "ver (retirados, privados y directos que no están emitiendo) y si las "
                           "búsquedas se rellenan con más resultados.\n\n"
                           "Son los mismos ajustes que la pestaña Dailymotion de los ajustes del addon.")

    # Modo de descarga
    dl_mode = cfg.get('dl_mode', 0)
    if dl_mode == 0:
        d_mode_txt = "[COLOR gray]DIRECTO (Normal)[/COLOR]"
    elif dl_mode == 1:
        d_mode_txt = "[COLOR green]SAFE MODE (Gujal)[/COLOR]"
    elif dl_mode == 2:
        d_mode_txt = "[COLOR gold]MODO ESPADAILY (HLS Process)[/COLOR]"
    elif dl_mode == 3:
        d_mode_txt = "[COLOR cyan]YT-DLP (Externo)[/COLOR]"
    else:
        d_mode_txt = "[COLOR magenta]ULTRA (Multi-hilo HLS+)[/COLOR]"

    dl_s_label = f"Modo de Descarga: {d_mode_txt}"
    dl_s_plot = (
        "MODO DE DESCARGA:\n\n"
        "[B]DIRECTO:[/B] Descarga simple HTTP.\n"
        "[B]SAFE MODE:[/B] Header estandar (Gujal).\n"
        "[B]ESPADAILY:[/B] Procesa HLS secuencialmente.\n"
        "[B]YT-DLP:[/B] Usa binario externo.\n"
        "[B]ULTRA:[/B] Descarga HLS multi-hilo (4x velocidad). Recomendado."
    )
    ui_utils.add_item(action="set_dl_mode", title=dl_s_label, thumbnail=ui_utils.media_icon("adv_modo_dl.png"), folder=False, plot=dl_s_plot)

    # Instantáneas, con un menú contextual escondido para ver el log
    snap_context = [("Ver Log de Kodi (últimas 50 líneas)", f"RunPlugin({sys.argv[0]}?action=view_kodi_log)")]
    ui_utils.add_item(action="snapshots_menu", title="Instantáneas del Catálogo (Offline)", thumbnail=ui_utils.media_icon("adv_snapshot.png"), folder=True, plot="Guarda una copia estática del catálogo de Series y Programas para acceder sin conexión a la lista oficial.", context=snap_context)

    # Motor TDT
    use_ia = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    ia_label = "Motor TDT (En Directo): [COLOR green]INPUTSTREAM ADAPTIVE[/COLOR]" if use_ia else "Motor TDT (En Directo): [COLOR grey]NATIVO (Por defecto)[/COLOR]"
    ia_plot = (
        "REPRODUCTOR AVANZADO: Forzando Kodi a usar el motor InputStream para M3U8. "
        "Mejora la reconexión de red y permite pausar el directo (TimeShift)."
        if use_ia else
        "REPRODUCTOR ESTÁNDAR: Usando el motor de vídeo nativo interno de Kodi. "
        "El directo no se puede pausar, pero es compatible con todos los sistemas operativos."
    )
    ui_utils.add_item(action="toggle_inputstream", title=ia_label, thumbnail=ui_utils.media_icon("adv_motor_tdt.png"), folder=False, plot=ia_plot)

    # Modo Anti-Errores IPTV
    anti_err = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    ae_label = "Modo Anti-Errores IPTV: [COLOR green]ACTIVADO[/COLOR]" if anti_err else "Modo Anti-Errores IPTV: [COLOR grey]DESACTIVADO[/COLOR]"
    ae_plot = "Si un canal IPTV te da 'Playback failed', activa este modo para intentar solucionar el error de reproducción."
    ui_utils.add_item(action="toggle_iptv_anti_errors", title=ae_label, thumbnail=ui_utils.media_icon("adv_anti_errores_iptv.png"), folder=False, plot=ae_plot)

    # Fanart
    fanart_off = xbmcaddon.Addon().getSetting('disable_fanart') == 'true'
    fa_label = "Fanart de fondo: [COLOR grey]DESACTIVADO[/COLOR]" if fanart_off else "Fanart de fondo: [COLOR green]ACTIVADO[/COLOR]"
    fa_plot = "Desactiva las imágenes de fondo (fanart) en los menús y el catálogo. Útil en dispositivos con poca memoria o para reducir distracciones."
    ui_utils.add_item(action="toggle_disable_fanart", title=fa_label, thumbnail=ui_utils.media_icon("adv_fanart.png"), folder=False, plot=fa_plot)

    # LoioLog
    try:
        xbmcaddon.Addon("plugin.program.loiolog")
        loiolog_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        loiolog_status = "[COLOR gray]No instalado[/COLOR]"
    ui_utils.add_item(action="loiolog_install", title=f"loiolog - Gestor avanzado de logs - {loiolog_status}", thumbnail=ui_utils.media_icon("adv_log.png"), folder=False, plot="[B]loiolog[/B] - Visor de logs de Kodi con colores por severidad.\n\nFiltra por addon, texto o regex. Exporta, comparte o abre en el móvil.\n\nPulsa para abrir o instalar automáticamente.\n\nhttps://github.com/loioloio/loiolog")


    if xbmc.getSkinDir() == 'skin.estuary.palantir':
        applied = _ep_sync_state()
        fix_label = "Fix Estuary Palantir: [COLOR green]APLICADO[/COLOR]" if applied else "Fix Estuary Palantir: [COLOR grey]NO APLICADO[/COLOR]"
        ui_utils.add_item(action="toggle_estuary_palantir_fix", title=fix_label, thumbnail=ui_utils.media_icon("fix_skin.png"), folder=False, plot="Instala o desinstala el parche que corrige la pantalla negra al ver resultados de Palantir con la skin Estuary Palantir.\n\nSi la skin se actualiza y el parche desaparece, este botón te permite reaplicarlo.")

    ui_utils.add_item(action="open_addon_settings", title="Ajustes nativos de Kodi", thumbnail=ui_utils.media_icon("ajustes_kodi.png"), folder=False, plot="Abre el panel de ajustes oficial del addon en Kodi.")

    ui_utils.close_item_list()

def backups_menu():
    ui_utils.add_item(action="", title="[I][COLOR aqua]BACKUPS: Guarda tus ajustes, historial y favoritos en un ZIP.[/COLOR][/I]", thumbnail=ui_utils.media_icon("backup_info.png"), folder=False)
    ui_utils.add_item(action="create_backup", title="[COLOR green]+ CREAR COPIA (Ligera)[/COLOR]", thumbnail=ui_utils.media_icon("backup_create.png"), folder=False)
    ui_utils.add_item(action="create_backup_full", title="[COLOR lime]+ CREAR COPIA COMPLETA (Con Caché)[/COLOR]", thumbnail=ui_utils.media_icon("backup_full.png"), folder=False)
    ui_utils.add_item(action="list_backups", title="RESTAURAR COPIA...", thumbnail=ui_utils.media_icon("backup_restore.png"), folder=True)
    ui_utils.add_item(action="export_backups_menu", title="[COLOR gold]EXPORTAR COPIA (Guardar fuera)...[/COLOR]", thumbnail=ui_utils.media_icon("backup_export.png"), folder=True)
    ui_utils.add_item(action="del_backups_menu", title="[COLOR red]BORRAR COPIAS...[/COLOR]", thumbnail=ui_utils.media_icon("backup_delete.png"), folder=True)
    ui_utils.close_item_list()


_AUTOSTART_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']

_AUTOSTART_SKIP_PREFIXES = (
    'xbmc.', 'kodi.', 'service.', 'skin.', 'resource.',
    'script.module.', 'metadata.', 'inputstream.', 'pvr.',
)


def _get_launchable_addons():
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1,
            'method': 'Addons.GetAddons',
            'params': {'enabled': True}
        })))
    except Exception:
        return []
    addons = (resp.get('result') or {}).get('addons') or []
    result = [
        (a.get('name', a['addonid']), a['addonid'])
        for a in addons
        if not any(a['addonid'].startswith(p) for p in _AUTOSTART_SKIP_PREFIXES)
        and a['addonid'] != 'plugin.video.atresdaily'
    ]
    result.sort(key=lambda x: x[0].lower())
    return result


def _autostart_delay_label(raw):
    try:
        idx = int(raw)
        return _AUTOSTART_DELAY_LABELS[idx] if 0 <= idx < len(_AUTOSTART_DELAY_LABELS) else 'Sin espera'
    except (ValueError, TypeError):
        return raw if raw in _AUTOSTART_DELAY_LABELS else 'Sin espera'


def _autostart_menu():
    addon = xbmcaddon.Addon()
    ico = ui_utils.media_icon("adv_autostart.png") or "DefaultAddonService.png"
    for i in range(1, 4):
        enabled = addon.getSetting(f'autostart_{i}_enabled') == 'true'
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{i}_delay'))

        if enabled and addon_id:
            nombre = addon_id
            try:
                nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
            except RuntimeError:
                pass
            label = f"Slot {i}: [COLOR green]{nombre}[/COLOR]  ({delay_label})"
            plot = f"Addon: {nombre}\nID: {addon_id}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Slot {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para configurar un addon que se abrirá automáticamente al arrancar Kodi."

        ui_utils.add_item(action="autostart_config_slot", title=label, thumbnail=ico, folder=False, plot=plot, slot=i)

    ui_utils.close_item_list()


def _autostart_config_slot(slot):
    addon = xbmcaddon.Addon()
    addon_id = addon.getSetting(f'autostart_{slot}_id').strip()
    enabled = addon.getSetting(f'autostart_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autostart_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    nombre = addon_id
    if addon_id:
        try:
            nombre = xbmcaddon.Addon(addon_id).getAddonInfo('name')
        except RuntimeError:
            pass

    if enabled and addon_id:
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Slot {slot}: {nombre} se abre {delay_txt}',
            ['Cambiar addon', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autostart_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autostart_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return

    addons_lista = _get_launchable_addons()
    if not addons_lista:
        xbmcgui.Dialog().notification("Inicio automático", "No se encontraron addons instalados", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [f"{name}  [COLOR grey]({aid})[/COLOR]" for name, aid in addons_lista]
    presel = next((i for i, (_, aid) in enumerate(addons_lista) if aid == addon_id), -1)
    sel_addon = xbmcgui.Dialog().select("Seleccionar addon a lanzar al arrancar", names, preselect=presel)
    if sel_addon < 0:
        return

    nuevo_id = addons_lista[sel_addon][1]
    nuevo_nombre = addons_lista[sel_addon][0]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    addon.setSetting(f'autostart_{slot}_enabled', 'true')
    addon.setSetting(f'autostart_{slot}_id', nuevo_id)
    addon.setSetting(f'autostart_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("Inicio automático", f"Slot {slot}: {nuevo_nombre}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _get_kodi_favourites():
    ruta = xbmcvfs.translatePath('special://profile/favourites.xml')
    try:
        root = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError):
        return []
    favs = []
    for elem in root.findall('favourite'):
        cmd = (elem.text or '').strip()
        name = elem.get('name') or cmd
        if cmd:
            favs.append((name, cmd, elem.get('thumb') or ''))
    return favs


def _autofav_menu():
    addon = xbmcaddon.Addon()
    ico = ui_utils.media_icon("adv_autostart.png") or "DefaultAddonService.png"
    for i in range(1, 4):
        enabled = addon.getSetting(f'autofav_{i}_enabled') == 'true'
        titulo = addon.getSetting(f'autofav_{i}_title').strip()
        delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{i}_delay'))

        if enabled and titulo:
            label = f"Favorito {i}: [COLOR green]{titulo}[/COLOR]  ({delay_label})"
            plot = f"Favorito: {titulo}\nRetardo: {delay_label}\n\n[I]Pulsa para editar o desactivar.[/I]"
        else:
            label = f"Favorito {i}: [COLOR grey]Sin configurar[/COLOR]"
            plot = "Slot vacío. Pulsa para elegir un favorito de Kodi que se abrirá automáticamente al arrancar."

        ui_utils.add_item(action="autofav_config_slot", title=label, thumbnail=ico, folder=False, plot=plot, slot=i)

    ui_utils.close_item_list()


def _autofav_config_slot(slot):
    addon = xbmcaddon.Addon()
    titulo = addon.getSetting(f'autofav_{slot}_title').strip()
    enabled = addon.getSetting(f'autofav_{slot}_enabled') == 'true'
    delay_label = _autostart_delay_label(addon.getSetting(f'autofav_{slot}_delay'))
    delay_idx = next((i for i, l in enumerate(_AUTOSTART_DELAY_LABELS) if l == delay_label), 0)

    if enabled and titulo:
        delay_txt = f'después de {delay_label}' if delay_label != 'Sin espera' else 'en cuanto Kodi arranque'
        sel = xbmcgui.Dialog().select(
            f'Favorito {slot}: {titulo} se abre {delay_txt}',
            ['Cambiar favorito', 'Cambiar retardo', 'Desactivar este slot']
        )
        if sel < 0:
            return
        if sel == 2:
            addon.setSetting(f'autofav_{slot}_enabled', 'false')
            xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot} desactivado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return
        if sel == 1:
            idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
            if idx < 0:
                return
            addon.setSetting(f'autofav_{slot}_delay', _AUTOSTART_DELAY_LABELS[idx])
            xbmcgui.Dialog().notification("Inicio automático", f"Retardo: {_AUTOSTART_DELAY_LABELS[idx]}", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
            return

    favs = _get_kodi_favourites()
    if not favs:
        xbmcgui.Dialog().notification("Inicio automático", "No tienes favoritos guardados en Kodi", xbmcgui.NOTIFICATION_WARNING)
        xbmc.executebuiltin("Container.Refresh")
        return

    names = [name for name, _cmd, _thumb in favs]
    presel = next((i for i, (name, _c, _t) in enumerate(favs) if name == titulo), -1)
    sel_fav = xbmcgui.Dialog().select("Seleccionar favorito a lanzar al arrancar", names, preselect=presel)
    if sel_fav < 0:
        return

    nuevo_titulo, nuevo_cmd, _ = favs[sel_fav]

    idx = xbmcgui.Dialog().select("Retardo antes de lanzar", _AUTOSTART_DELAY_LABELS, preselect=delay_idx)
    nuevo_delay = _AUTOSTART_DELAY_LABELS[idx] if idx >= 0 else delay_label

    addon.setSetting(f'autofav_{slot}_enabled', 'true')
    addon.setSetting(f'autofav_{slot}_title', nuevo_titulo)
    addon.setSetting(f'autofav_{slot}_cmd', nuevo_cmd)
    addon.setSetting(f'autofav_{slot}_delay', nuevo_delay)

    xbmcgui.Dialog().notification("Inicio automático", f"Favorito {slot}: {nuevo_titulo}", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def _toggle_inputstream():
    cur = xbmcaddon.Addon().getSetting('use_inputstream') == 'true'
    xbmcaddon.Addon().setSetting('use_inputstream', 'false' if cur else 'true')
    if not cur:
        try:
            xbmcaddon.Addon('inputstream.adaptive')
            xbmcgui.Dialog().notification("Reproductor", "InputStream Adaptive ACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
        except RuntimeError:
            xbmcgui.Dialog().ok(
                "Aviso Importante",
                "Has activado InputStream Adaptive, pero el componente no está instalado en Kodi.\n\n"
                "Instala 'InputStream Adaptive' desde el repositorio oficial de Kodi antes de usar este modo."
            )
    else:
        xbmcgui.Dialog().notification("Reproductor", "Volviendo al motor NATIVO", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_disable_fanart():
    cur = xbmcaddon.Addon().getSetting('disable_fanart') == 'true'
    xbmcaddon.Addon().setSetting('disable_fanart', 'false' if cur else 'true')
    msg = "Fanart de fondo ACTIVADO" if cur else "Fanart de fondo DESACTIVADO"
    xbmcgui.Dialog().notification("Fanart", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_iptv_anti_errors():
    cur = xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true'
    xbmcaddon.Addon().setSetting('iptv_anti_errors', 'false' if cur else 'true')
    if not cur:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores IPTV ACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification("Anti-Errores", "Modo Anti-Errores IPTV DESACTIVADO", xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_ext_search_enabled():
    cur = xbmcaddon.Addon().getSetting('ext_search_enabled') != 'false'
    xbmcaddon.Addon().setSetting('ext_search_enabled', 'false' if cur else 'true')
    msg = "Buscar en otros addons DESACTIVADO" if cur else "Buscar en otros addons ACTIVADO"
    xbmcgui.Dialog().notification("Búsqueda", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_acestream_enabled():
    cur = xbmcaddon.Addon().getSetting('acestream_enabled') == 'true'
    xbmcaddon.Addon().setSetting('acestream_enabled', 'false' if cur else 'true')
    msg = "Búsqueda AceStream DESACTIVADA" if cur else "Búsqueda AceStream ACTIVADA"
    xbmcgui.Dialog().notification("AceStream", msg, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")

def acc_menu():
    _addon = xbmcaddon.Addon()
    color_mode = _addon.getSetting('acc_color_mode') or 'none'
    bold_on    = _addon.getSetting('acc_bold_enabled') != 'false'
    strip_sym  = _addon.getSetting('acc_strip_symbols') == 'true'

    _COLOR_LABELS = {
        'none':         "Sin modificar (colores originales)",
        'white':        "Texto blanco (todos los colores -> blanco)",
        'daltonic_rg':  "Daltonico rojo-verde (deuteranopia/protanopia)",
        'daltonic_by':  "Daltonico azul-amarillo (tritanopia)",
        'hc_dark':      "Alto contraste, fondo oscuro (amarillo)",
        'hc_light':     "Alto contraste, fondo claro (negro)",
    }
    color_txt = _COLOR_LABELS.get(color_mode, color_mode)
    bold_txt  = "[COLOR green]ACTIVADA[/COLOR]"  if bold_on   else "[COLOR grey]DESACTIVADA[/COLOR]"
    sym_txt   = "[COLOR green]ACTIVADO[/COLOR]"   if strip_sym else "[COLOR grey]DESACTIVADO[/COLOR]"

    menu_colors_on = xbmcaddon.Addon().getSetting('menu_colors_enabled') == 'true'
    mc_txt = "[COLOR green]ACTIVADOS[/COLOR]" if menu_colors_on else "[COLOR grey]DESACTIVADOS[/COLOR]"

    ui_utils.add_item(action="acc_set_color_mode",      title=f"Modo de color: [COLOR gold]{color_txt}[/COLOR]",  thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Cambia el esquema de colores del addon para mejorar la visibilidad.")
    ui_utils.add_item(action="acc_toggle_bold",         title=f"Negrita en menús: {bold_txt}",                    thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Activa o desactiva el texto en negrita en todos los menús del addon.")
    ui_utils.add_item(action="acc_toggle_symbols",      title=f"Reemplazar simbolos: {sym_txt}",                  thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Sustituye simbolos especiales (estrellas, flechas) por caracteres ASCII compatibles.")
    ui_utils.add_item(action="acc_toggle_menu_colors",  title=f"Colores del menú principal: {mc_txt}",            thumbnail=ui_utils.media_icon("adv_acc.png"), folder=False, plot="Activa o desactiva los colores originales de los botones del menú principal.")
    ui_utils.close_item_list()

def _acc_set_color_mode():
    options = [
        "Sin modificar (colores originales)",
        "Texto blanco (todos los colores -> blanco)",
        "Daltonico rojo-verde (deuteranopia/protanopia)",
        "Daltonico azul-amarillo (tritanopia)",
        "Alto contraste, fondo oscuro (amarillo)",
        "Alto contraste, fondo claro (negro)",
    ]
    keys = ['none', 'white', 'daltonic_rg', 'daltonic_by', 'hc_dark', 'hc_light']
    cur_key = xbmcaddon.Addon().getSetting('acc_color_mode') or 'none'
    preselect = keys.index(cur_key) if cur_key in keys else 0
    sel = xbmcgui.Dialog().select("Modo de color", options, preselect=preselect)
    if sel >= 0:
        xbmcaddon.Addon().setSetting('acc_color_mode', keys[sel])
        xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_bold():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('acc_bold_enabled') != 'false'
    addon.setSetting('acc_bold_enabled', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_symbols():
    cur = xbmcaddon.Addon().getSetting('acc_strip_symbols') == 'true'
    xbmcaddon.Addon().setSetting('acc_strip_symbols', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _acc_toggle_menu_colors():
    cur = xbmcaddon.Addon().getSetting('menu_colors_enabled') == 'true'
    xbmcaddon.Addon().setSetting('menu_colors_enabled', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _random_fake_url():
    """Genera una URL falsa de aspecto realista."""
    import random, string
    domains = ['cdn-stream', 'api-media', 'cache-node', 'edge-srv', 'static-res']
    tlds = ['net', 'io', 'cloud', 'media', 'stream']
    path = ''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(8, 16)))
    return f"https://{random.choice(domains)}-{random.randint(1,99)}.{random.choice(tlds)}/{path}"

def _random_token():
    """Genera un token falso de aspecto realista."""
    import random, string
    return ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(20, 40)))

def view_kodi_log():
    """Muestra las últimas 50 líneas del log de Kodi en un diálogo de texto."""
    try:
        log_path = xbmcvfs.translatePath('special://logpath/kodi.log')
        if not os.path.exists(log_path):
            xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo de log.")
            return
        from collections import deque
        with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
            last_50 = deque(f, maxlen=50)
        
        censored_lines = []
        for line in last_50:
            line = re.sub(r'https?://[^\s]*connector\.py[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://gist\.githubusercontent\.com[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*\.netlify\.app[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com[^\s]*/connector[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://raw\.githubusercontent\.com/fullstackcurso[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*/status\.json[^\s]*', _random_fake_url, line)
            line = re.sub(r'https?://[^\s]*/messages\.json[^\s]*', _random_fake_url, line)
            line = re.sub(r'(access_token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(bearer=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(hdnts=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            line = re.sub(r'(token=)[^&\s]+', lambda m: m.group(1) + _random_token(), line)
            censored_lines.append(line)
        
        log_text = ''.join(censored_lines)
        xbmcgui.Dialog().textviewer("Log de Kodi (últimas 50 líneas)", log_text)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo leer el log: {e}")

# --- Interruptores y búsqueda avanzada ---
def _clear_cat_cache():
    """Elimina todos los archivos de caché del catálogo (cat_cache_*.json)."""
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    for f in os.listdir(profile):
        if f.startswith("cat_cache_") and f.endswith(".json"):
            try: os.remove(os.path.join(profile, f))
            except Exception: pass

def set_cache_config():
    # Opciones de configuracion + Acciones extra
    opts = ["Apagado", "1 Día", "1 Semana", "1 Mes (Recomendado)", "1 Año", "Indefinido", "[COLOR red]Borrar solo caché del Addon[/COLOR]", "[COLOR red]Borrar caché de Kodi (Reload Skin)[/COLOR]", "[COLOR gold]Exportar caché...[/COLOR]"]
    vals = [0, 86400, 604800, 2592000, 31536000, -1, -97, -99, -88]
    
    idx = xbmcgui.Dialog().select("Duración de la Caché", opts)
    if idx >= 0:
        # Acciones especiales
        if vals[idx] == -99:
            clear_full_cache()  # recarga el skin
            return
        elif vals[idx] == -97:
            # Solo los ficheros del addon
            if xbmcgui.Dialog().yesno("AtresDaily", "¿Borrar todos los datos descargados del catálogo?\n(No afecta a tus ajustes ni favoritos)"):
                _clear_cat_cache()
                xbmcgui.Dialog().notification("AtresDaily", "Caché del Addon borrada")
            return
        elif vals[idx] == -88:
            export_cache()
            return

        cfg = ui_utils.load_json('settings.json')
        cfg['cache_expiry'] = vals[idx]
        cfg['cache_active'] = (vals[idx] != 0)
        ui_utils.save_json('settings.json', cfg)
        
        if vals[idx] == 0:
            _clear_cat_cache()
            xbmcgui.Dialog().notification("AtresDaily", "Caché desactivada y limpiada")
        else:
            xbmcgui.Dialog().notification("AtresDaily", f"Caché: {opts[idx]}")
        
        xbmc.executebuiltin("Container.Refresh")

def _toggle_advanced_search():
    cur = xbmcaddon.Addon().getSetting('advanced_search_active') != 'false'
    xbmcaddon.Addon().setSetting('advanced_search_active', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("AtresDaily", "Búsqueda Directa" if cur else "Menú Avanzado ACTIVADO")
    xbmc.executebuiltin("Container.Refresh")

def input_mode_menu():
    """Elige cómo se introduce el texto en las búsquedas, ya sea teclado, preguntar o web."""
    keys = ['keyboard', 'ask', 'web']
    opts = ['Teclado de Kodi (siempre)',
            'Preguntar cada vez (teclado o web)',
            'Escribir desde el móvil/PC (web)']
    cfg = ui_utils.load_json('settings.json')
    cur = cfg.get('web_input_mode', 'keyboard')
    preselect = keys.index(cur) if cur in keys else 0
    sel = xbmcgui.Dialog().select('Método de escritura para búsquedas', opts, preselect=preselect)
    if sel >= 0:
        cfg['web_input_mode'] = keys[sel]
        ui_utils.save_json('settings.json', cfg)
        xbmc.executebuiltin("Container.Refresh")

def _toggle_prioritize_match():
    cur = xbmcaddon.Addon().getSetting('prioritize_match_active') == 'true'
    xbmcaddon.Addon().setSetting('prioritize_match_active', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("AtresDaily", "Modo Duración" if cur else "Modo Precisión")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    cur = xbmcaddon.Addon().getSetting('recent_active') == 'true'
    xbmcaddon.Addon().setSetting('recent_active', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("AtresDaily", "Orden Relevancia" if cur else "Orden Reciente")
    xbmc.executebuiltin("Container.Refresh")

def _toggle_catalog_long_first():
    cur = xbmcaddon.Addon().getSetting('catalog_long_first') != 'false'
    xbmcaddon.Addon().setSetting('catalog_long_first', 'false' if cur else 'true')
    xbmcgui.Dialog().notification("AtresDaily", "Vídeos largos primero: OFF" if cur else "Vídeos largos primero: ON")
    xbmc.executebuiltin("Container.Refresh")

def search_order_menu():
    ui_utils.visto('orden_4.9')
    _addon = xbmcaddon.Addon()

    # --- Catálogo (botón "Buscar") ---
    ui_utils.add_item(action="separador", title='[COLOR gold]— Catálogo (botón "Buscar") —[/COLOR]',
        thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    if _addon.getSetting('catalog_long_first') != 'false':
        lf_label = "Catálogo · Vídeos largos primero: [COLOR green]ACTIVADO[/COLOR]"
        lf_plot = 'Al pulsar "Buscar" en el catálogo, los vídeos de +30 min (capítulos completos) van antes que los clips cortos.\n\n[I]Pulsa para desactivar.[/I]'
    else:
        lf_label = "Catálogo · Vídeos largos primero: [COLOR gray]DESACTIVADO[/COLOR]"
        lf_plot = 'Los resultados del botón "Buscar" del catálogo se muestran en el orden original de la plataforma.\n\n[I]Pulsa para activar.[/I]'
    ui_utils.add_item(action="toggle_catalog_long_first", title=lf_label,
        thumbnail=ui_utils.media_icon("adv_antitrailers.png"), folder=False, plot=lf_plot)
    _item_ajuste_busqueda(_addon, *_DM_BUSQUEDA[0])

    # --- Búsqueda manual (en internet) ---
    ui_utils.add_item(action="separador", title="[COLOR gold]— Búsqueda manual (en internet) —[/COLOR]",
        thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    if _addon.getSetting('prioritize_match_active') == 'true':
        p_label = "Búsqueda · Prioriza: [COLOR green]COINCIDENCIA DEL TÍTULO[/COLOR]"
        p_plot = "Ordena por coincidencia exacta de palabras del título, por encima de la duración.\n\n[I]Pulsa para priorizar vídeos largos.[/I]"
    else:
        p_label = "Búsqueda · Prioriza: [COLOR green]VÍDEOS LARGOS[/COLOR]"
        p_plot = "Sube los vídeos largos (capítulos completos) sobre trailers o clips cortos.\n\n[I]Pulsa para priorizar la coincidencia del título.[/I]"
    ui_utils.add_item(action="toggle_prioritize_match", title=p_label,
        thumbnail=ui_utils.media_icon("adv_priorizar.png"), folder=False, plot=p_plot)

    try:
        min_m = int(float(_addon.getSetting('dm_min_duracion') or 0))
    except ValueError:
        min_m = 0
    a_label = (f"Búsqueda · Ocultar clips cortos: [COLOR green]+{min_m} MIN[/COLOR]"
               if min_m > 0 else "Búsqueda · Ocultar clips cortos: [COLOR gray]NO[/COLOR]")
    a_plot = ("Quita de la búsqueda manual los vídeos más cortos que el tiempo elegido. Se piden "
              "ya así a Dailymotion, de modo que la lista sale completa con vídeos largos.\n\n"
              "[I]Pulsa para configurar.[/I]")
    ui_utils.add_item(action="set_min_duration", title=a_label,
        thumbnail=ui_utils.media_icon("adv_antitrailers.png"), folder=False, plot=a_plot)

    if _addon.getSetting('recent_active') == 'true':
        t_label = "Búsqueda · Recientes primero: [COLOR green]ACTIVADO[/COLOR]"
        t_plot = "Prioriza los vídeos subidos más recientemente.\n\n[I]Pulsa para volver a orden por relevancia.[/I]"
    else:
        t_label = "Búsqueda · Recientes primero: [COLOR gray]DESACTIVADO[/COLOR]"
        t_plot = "Ordena por relevancia (parecido del título), sin importar la fecha.\n\n[I]Pulsa para priorizar recientes.[/I]"
    ui_utils.add_item(action="toggle_recent", title=t_label,
        thumbnail=ui_utils.media_icon("adv_filtro_tiempo.png"), folder=False, plot=t_plot)

    # --- Las dos ---
    ui_utils.add_item(action="separador", title="[COLOR gold]— Las dos búsquedas —[/COLOR]",
        thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    for ajuste in _DM_BUSQUEDA[1:]:
        _item_ajuste_busqueda(_addon, *ajuste)

    ui_utils.close_item_list()


# Interruptores de las búsquedas de DM que cambia toggle_dm_ajuste:
# (ajuste nativo, rótulo, explicación). También están en la pestaña Dailymotion
# de los ajustes del addon.
_DM_BUSQUEDA = (
    ("dm_catalogo_coincidencia", "Catálogo · Ordenar por parecido con lo buscado",
     'Al pulsar "Buscar", los resultados se ordenan por parecido con el nombre de la serie y el '
     'número de capítulo, y el episodio sale el primero. Desactivada, se usa el orden de '
     'Dailymotion, que a veces deja el episodio fuera de los 20 que se enseñan.'),
    ("dm_exigir_numero", "Solo resultados con el número de capítulo buscado",
     "Si lo buscado lleva un número (capítulo, programa, año), se ocultan los resultados que no lo "
     "tienen en el título; con temporada y capítulo, cuenta el del capítulo. Los capítulos con "
     "otro número ya van detrás aunque no la actives."),
    ("dm_exigir_palabras", "Solo resultados con todas las palabras buscadas",
     'Se ocultan los resultados a los que les falta alguna palabra de lo buscado (sin contar '
     'artículos ni palabras como "capítulo"). Da listas más cortas pero sin vídeos de otra serie.'),
)


def _item_ajuste_busqueda(addon, clave, rotulo, explicacion):
    activo = addon.getSetting(clave) == 'true'
    estado = "[COLOR green]ACTIVADO[/COLOR]" if activo else "[COLOR gray]DESACTIVADO[/COLOR]"
    ui_utils.add_item(action="toggle_dm_ajuste", url=clave, title=f"{rotulo}: {estado}", nuevo=clave,
        thumbnail=ui_utils.media_icon("adv_precision.png"), folder=False,
        plot=f"{explicacion}\n\n[I]Pulsa para {'desactivar' if activo else 'activar'}.[/I]")

def _toggle_ext_search_dialog():
    cur = xbmcaddon.Addon().getSetting('ext_search_dialog') != 'false'
    xbmcaddon.Addon().setSetting('ext_search_dialog', 'false' if cur else 'true')
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min"]
    vals = [0, 2, 5, 10, 20]
    idx = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if idx >= 0:
        xbmcaddon.Addon().setSetting('dm_min_duracion', str(vals[idx]))
        xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    ui_utils.add_item(action="separador", title="[I]— CATÁLOGO A3PLAYER —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="atresplayer_catalog_search", title="Buscar en Catálogo de A3Player", thumbnail=ui_utils.media_icon("srch_catalogo.png"), folder=False, plot="Busca directamente en el catálogo oficial de A3Player por nombre aproximado.\n\nEscribe el nombre de una serie o programa y se buscará la coincidencia más cercana.")

    ui_utils.add_item(action="separador", title="[I]— BUSCAR EN INTERNET —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="busqueda_total", title="[COLOR white]Megabuscador[/COLOR]", thumbnail=ui_utils.media_icon("busqueda.png"), folder=True, plot="Busca a la vez en varias plataformas (Dailymotion, YouTube, Odysee, PeerTube, BitChute) y une los resultados ordenados por relevancia, indicando la fuente de cada uno. Elige las plataformas y otras opciones (limpiar títulos, variaciones, proxy) en su propio submenú.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Estándar (Por Título)", url="standard", thumbnail=ui_utils.media_icon("srch_estandar.png"), folder=False, plot="Búsqueda tradicional por palabras clave en todo el catálogo.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Películas (Modo Cine)", url="movie", thumbnail=ui_utils.media_icon("srch_peliculas.png"), folder=False, plot="Optimiza la búsqueda añadiendo filtros para localizar vídeos de películas en castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Series (Temporada + Capítulo)", url="series", thumbnail=ui_utils.media_icon("srch_series.png"), folder=False, plot="Asistente guiado para construir la búsqueda exacta de un episodio (Ej: Serie T1x01).")
    ui_utils.add_item(action="execute_adv_search", title="Buscar con Elementum (P2P - Torrent)", url="torrent_p2p", thumbnail=ui_utils.media_icon("srch_torrent.png"), folder=False, plot="Busca vídeos usando Elementum, el addon de streaming P2P para Kodi.")
    ui_utils.add_item(action="search_youtube_prompt", title="Buscar en YouTube", thumbnail=ui_utils.media_icon("srch_youtube.png"), folder=False, plot="Busca vídeos en YouTube por scraping HTML. Requiere el addon plugin.video.youtube para reproducir.")
    ui_utils.add_item(action="search_odysee_prompt", title="Buscar en Odysee (descentralizado)", thumbnail=ui_utils.media_icon("srch_odysee.png"), folder=False, plot="Busca vídeos en Odysee/LBRY, plataforma descentralizada con moderación mínima. Stream directo, sin addon externo.")
    ui_utils.add_item(action="search_peertube_prompt", title="Buscar en PeerTube (federado)", thumbnail=ui_utils.media_icon("srch_peertube.png"), folder=False, plot="Busca vídeos en PeerTube (peertube.tv), red federada de vídeo libre. Stream directo, sin addon externo.")
    ui_utils.add_item(action="search_bitchute_prompt", title="Buscar en BitChute (P2P)", thumbnail=ui_utils.media_icon("srch_bitchute.png"), folder=False, plot="Busca vídeos en BitChute, red P2P resistente a la censura. Stream directo MP4, sin addon externo.")

    ui_utils.add_item(action="separador", title="[I]— FILTROS DE DURACIÓN —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Largos (+20 min)", url="long", thumbnail=ui_utils.media_icon("srch_largos.png"), folder=False, plot="Filtra resultados cortos. Ideal para programas completos, documentales o episodios.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda de Vídeos Cortos (-10 min)", url="short", thumbnail=ui_utils.media_icon("srch_cortos.png"), folder=False, plot="Ideal para buscar clips, noticias rápidas, trailers o momentos destacados.")

    ui_utils.add_item(action="separador", title="[I]— FILTROS TEMPORALES —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Hoy (Últimas 24h)", url="recent_24h", thumbnail=ui_utils.media_icon("srch_hoy.png"), folder=False, plot="Muestra solo contenido subido en el último día.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Esta Semana", url="week", thumbnail=ui_utils.media_icon("srch_semana.png"), folder=False, plot="Amplía el rango a los últimos 7 días.")
    ui_utils.add_item(action="execute_adv_search", title="Contenido de Este Mes", url="month", thumbnail=ui_utils.media_icon("srch_mes.png"), folder=False, plot="Busca contenido subido en los últimos 30 días.")

    ui_utils.add_item(action="separador", title="[I]— FILTROS AVANZADOS —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="execute_adv_search", title="Solo Contenido en Español", url="spanish", thumbnail=ui_utils.media_icon("srch_espanol.png"), folder=False, plot="Añade términos de idioma a la búsqueda para priorizar castellano.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Usuario / Canal", url="by_user", thumbnail=ui_utils.media_icon("srch_canal.png"), folder=False, plot="Restringe la búsqueda a un canal o usuario de Dailymotion específico.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Inversa (Excluir palabras)", url="inverse", thumbnail=ui_utils.media_icon("srch_inversa.png"), folder=False, plot="Define qué palabras NO quieres que aparezcan en los resultados.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Exacta (Sin limpieza)", url="exact", thumbnail=ui_utils.media_icon("srch_exacta.png"), folder=False, plot="Envía el término tal cual a la API, sin procesado inteligente de texto.")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda por Palabras Clave", url="tags", thumbnail=ui_utils.media_icon("srch_tags.png"), folder=False, plot="Busca utilizando el sistema de etiquetas (tags) de la plataforma.")
    ui_utils.add_item(action="search_user_playlists", title="Buscar Playlists de un Canal", thumbnail=ui_utils.media_icon("srch_playlists.png"), folder=True, plot="Introduce el nombre de un canal de Dailymotion para ver sus listas de reproducción organizadas.")

    ui_utils.add_item(action="separador", title="[I]— UTILIDADES —[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    ui_utils.add_item(action="search_external", title="Búsqueda externa", thumbnail=ui_utils.media_icon("srch_externa.png"), folder=False, plot="Introduce un texto y abre directamente el menú '¿No es lo que buscas?' con todas las opciones de búsqueda disponibles.")
    ui_utils.add_item(action="multi_search", title="Búsqueda Múltiple (varios términos)", thumbnail=ui_utils.media_icon("srch_multiple.png"), folder=False, plot="Busca varios términos a la vez separados por comas.\nEjemplo: La Promesa, Sueños de libertad, El Hormiguero")
    ui_utils.add_item(action="execute_adv_search", title="Búsqueda Personalizada (Combinar Filtros)", url="custom", thumbnail=ui_utils.media_icon("srch_custom.png"), folder=False, plot="Crea una búsqueda a medida combinando múltiples filtros (HD + Fecha + Duración + Idioma).")
    ui_utils.add_item(action="execute_adv_search", title="Repetir Última Búsqueda", url="repeat", thumbnail=ui_utils.media_icon("srch_repetir.png"), folder=True, plot="Vuelve a lanzar la última búsqueda realizada, manteniendo sus filtros si los tenía.")
    ui_utils.close_item_list()

def _search_atresplayer_catalog(pre_query=None):
    """Busca en el catálogo de A3Player por nombre aproximado.
    pre_query: si viene predefinida, se usa sin teclado."""

    if pre_query:
        query = pre_query.strip().lower()
    else:
        t = ui_utils.get_text('Nombre del programa o serie').strip()
        if not t:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        # Con folder=False navegamos a la versión con q (carpeta de resultados idempotente).
        xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=atresplayer_catalog_search&q={urllib.parse.quote(t)}")')
        return

    xbmcgui.Dialog().notification("AtresDaily",
        "Cargando catálogo...", xbmcgui.NOTIFICATION_INFO, 2000)

    # Es una carpeta, así que cada salida sin resultados cierra el listado como fallido;
    # si no, Kodi añade su propio error al diálogo del addon.
    try:
        catalog = connector._fetch_all_catalog()
    except Exception as e:
        xbmcgui.Dialog().ok("AtresDaily",
            f"Error al obtener el catálogo: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    if not catalog:
        xbmcgui.Dialog().ok("AtresDaily",
            "No se pudo obtener el catálogo de A3Player.\n\n"
            "Puede que el conector no esté instalado o haya un error de red.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    # Recopilar todos los programas
    # Formato del catálogo: {categoria: [{t: titulo, u: url, th: thumb, p: plot}, ...]}
    all_programs = []
    por_url = {}
    for cat_name, cat_items in catalog.items():
        cat_name = categorias.nombre(cat_name)
        if isinstance(cat_items, list):
            for item in cat_items:
                if isinstance(item, dict):
                    # Claves cortas (t, u) o largas (title, url)
                    title = item.get('t') or item.get('title') or item.get('name') or ''
                    url = item.get('u') or item.get('url') or item.get('link') or ''
                    thumb = item.get('th') or item.get('thumbnail') or ''
                    plot = item.get('p') or item.get('plot') or ''
                    clave = url if isinstance(url, str) else ''
                    if clave in por_url:
                        # Un mismo programa está en varias secciones: sale una vez, con todas.
                        por_url[clave]['category'] += f", {cat_name}"
                    elif title:
                        all_programs.append({
                            'title': title,
                            'url': url,
                            'thumb': thumb,
                            'plot': plot,
                            'category': cat_name
                        })
                        if clave:
                            por_url[clave] = all_programs[-1]
                elif isinstance(item, str) and item:
                    all_programs.append({
                        'title': item,
                        'url': '',
                        'thumb': '',
                        'plot': '',
                        'category': cat_name
                    })

    if not all_programs:
        xbmcgui.Dialog().ok("AtresDaily",
            "No se encontraron programas en el catálogo.\n\n"
            f"Categorías encontradas: {', '.join(categorias.nombre(c) for c in list(catalog.keys())[:5])}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    xbmc.log(f"[AtresDaily] Catalog search: {len(all_programs)} programs found, searching '{query}'", xbmc.LOGINFO)

    scored = []
    for prog in all_programs:
        title_lower = prog['title'].lower()
        # La coincidencia exacta de subcadena va antes que la difusa
        if query in title_lower:
            score = 0.95 + (len(query) / max(len(title_lower), 1)) * 0.05
        else:
            score = difflib.SequenceMatcher(None, query, title_lower).ratio()
        if score > 0.3:
            scored.append((score, prog))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = scored[:20]

    if not results:
        # Sin resultados de coincidencia difusa, ofrecer búsqueda en Dailymotion
        if xbmcgui.Dialog().yesno("AtresDaily",
            f"No se encontró '{query}' en el catálogo.\n\n"
            "¿Buscar en Dailymotion en su lugar?"):
            connector.search_internet(query)
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    h = int(sys.argv[1])
    for score, prog in results:
        pct = int(score * 100)
        title = prog['title']
        cat = prog['category']
        url = prog.get('url', '')
        thumb = prog.get('thumb', '')

        label = f"{title} [COLOR gray]({cat})[/COLOR] [COLOR lime]{pct}%[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb or 'DefaultVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': prog.get('plot') or f"Programa: {title}\nCategoría: {cat}\nCoincidencia: {pct}%"})

        if url:
            # Navegar al programa en A3Player (temporadas/capítulos)
            nav_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'list_details', 'url': url, 'extra': title})
        else:
            # Sin URL directa, se busca por título en Dailymotion como alternativa
            nav_url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'search', 'url': title})

        xbmcplugin.addDirectoryItem(handle=h, url=nav_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def _execute_adv_search(mode):
    if mode == "torrent_p2p":
        q = ui_utils.get_text("Buscar en Torrents (P2P)")
        if q:
            _search_elementum(q)
        else:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    if mode == "repeat":
        last = ui_utils.load_json('last_adv.json')
        if not last:
            xbmcgui.Dialog().notification("AtresDaily", "No hay búsquedas previas", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        connector.search_internet(last["q"], extra_params=last.get("ep", {}), direct=last.get("direct", False))
        return

    # Preguntas especiales según el modo
    if mode == "series":
        title = ui_utils.get_text("Nombre de la Serie")
        if not title:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        so = xbmcgui.Dialog().input("Temporada (Ej: 1)", type=xbmcgui.INPUT_NUMERIC)
        if so:
             q = f"{title} Temporada {int(so)}"
        else:
            q = title
    elif mode == "inverse":
        q = ui_utils.get_text("¿Qué buscas?")
        if not q:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        exc = ui_utils.get_text("Palabras a EXCLUIR (separadas por espacio)")
        ep = {}
        if exc: ep["_exclude"] = exc.lower().split()
    elif mode == "by_user":
        user = ui_utils.get_text("Nombre de Usuario / Canal (ID)")
        if not user:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        q_filter = ui_utils.get_text(f"¿Qué buscar dentro de {user}? (Dejar vacío para ver todo)")
        q = q_filter # Permitimos vacio
    else:
        # Traducción de títulos de cuadro de dialogo
        mod_titles = {
            "movie": "Búsqueda de Película (Cine)",
            "long": "Búsqueda de Vídeos Largos (+20min)",
            "short": "Búsqueda de Vídeos Cortos (-10min)",
            "standard": "Búsqueda Estándar",
            "recent_24h": "Contenido de Hoy (24h)",
            "week": "Contenido de la Semana",
            "month": "Contenido del Mes",
            "hd": "Búsqueda en Alta Definición (HD)",
            "spanish": "Contenido en Español",
            "exact": "Búsqueda Exacta",
            "tags": "Búsqueda por Etiquetas",
            "custom": "Búsqueda Personalizada (Introducir término)"
        }
        dlg_title = mod_titles.get(mode, f"Búsqueda Avanzada: {mode.upper()}")

        q = ui_utils.get_text(dlg_title)
        if not q:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
    
    if 'ep' not in locals():
        ep = {}
    
    if mode == "movie":
        # Menos restrictivo, sin "castellano" obligatorio
        q = f"{q} pelicula completa"
    elif mode == "series":
        pass
    elif mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "week":
        ep = {"created_after": int(time.time()) - (86400 * 7), "sort": "recent"}
    elif mode == "month":
        ep = {"created_after": int(time.time()) - (86400 * 30), "sort": "recent"}
    elif mode == "hd":
        # En lugar de buscar texto "hd" (que falla mucho), activamos un filtro interno
        # para verificar la calidad real del vídeo devuelto.
        ep = {"_hd": True}
    elif mode == "spanish":
        # Se añade " español" (más amplio que "castellano") solo si la búsqueda no lleva ya un
        # idioma.
        q = f"{q} español"
    elif mode == "by_user":
        # Resuelve el nombre de usuario a su ID real antes de filtrar vídeos.
        try:
           base_api = "https://api.dailymotion.com"
           u_search = requests.get(f"{base_api}/users", params={"search": user, "fields": "id,screenname", "limit": 1}, timeout=5)
           if u_search.status_code == 200:
               u_list = u_search.json().get("list", [])
               if u_list:
                   real_user_id = u_list[0].get("id")
                   # Notificar si el ID es diferente
                   if real_user_id != user:
                        xbmcgui.Dialog().notification("AtresDaily", f"Canal encontrado: {u_list[0].get('screenname')}")
                   user = real_user_id
        except Exception: pass

        ep = {"owner": user}
        if not q: q = "" # Si está vacío, buscará todo del propietario
    elif mode == "tags":
        ep = {"tags": q} # Búsqueda real por etiquetas
        # Solo por etiquetas
        q = "" 
    elif mode == "custom":
        # Dialogo multiseleccion para combinar filtros
        opts = [
            "Alta Definición (HD)",           # 0
            "Larga Duración (+20 min)",       # 1
            "Corta Duración (-10 min)",       # 2
            "Subido Hoy (24h)",               # 3
            "Subido esta Semana",             # 4
            "Subido este Mes",                # 5
            "Ordenar por Recientes",          # 6
            "Solo Español (Añadir texto)"     # 7
        ]
        sel = xbmcgui.Dialog().multiselect("Combinar Filtros", opts)
        if not sel: 
            # Si cancela, buscamos normal sin filtros extra
            pass 
        else:
            if 0 in sel: ep["_hd"] = True
            
            # Conflictos de duración
            if 1 in sel: ep["longer_than"] = 20
            elif 2 in sel: ep["shorter_than"] = 10
            
            # Conflictos de fecha
            now = int(time.time())
            if 3 in sel: ep["created_after"] = now - 86400
            elif 4 in sel: ep["created_after"] = now - (86400 * 7)
            elif 5 in sel: ep["created_after"] = now - (86400 * 30)
            
            if 6 in sel: ep["sort"] = "recent"
            if 7 in sel: q = f"{q} español"

    if q: connector.add_hist(q)

    # Guardar para repetir (incluye 'direct' para no perder el modo exacto al repetir)
    ui_utils.save_json('last_adv.json', {"q": f"adv:{q}", "ep": ep, "direct": (mode == "exact")})

    # Mostrar resultados vía la action idempotente 'repeat'. El item es folder=False, así
    # que el prompt no queda en el historial: "volver atrás" regresa al menú, no al prompt.
    xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=execute_adv_search&url=repeat")')


def set_precision():
    opts = ["Nivel 1: BÁSICO (Solo Título)", "Nivel 2: ESTÁNDAR (Serie + Título - Recomendado)", "Nivel 3: AVANZADO (Serie + Temporada)"]
    idx = xbmcgui.Dialog().select("Contexto de Búsqueda", opts)
    if idx >= 0:
        d = ui_utils.load_json('settings.json')
        d['context_level'] = idx + 1
        ui_utils.save_json('settings.json', d)
        xbmcgui.Dialog().notification("AtresDaily", f"Nivel {idx+1} guardado")

def clear_ui_cache():
    xbmc.executebuiltin("Container.Refresh")
    xbmcgui.Dialog().notification("AtresDaily", "Interfaz actualizada", xbmcgui.NOTIFICATION_INFO)

def set_download_path():
    d = xbmcgui.Dialog().browse(0, 'Seleccionar carpeta de descargas', 'files')
    if d:
        cfg = ui_utils.load_json('settings.json')
        cfg['download_path'] = d
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", "Ruta de descargas guardada")
        xbmc.executebuiltin("Container.Refresh")

def set_dm_safe_level():
    # Selector de 4 niveles para el modo anti-errores de Dailymotion
    options = [
        "Desactivado (Conexión Normal)",
        "Básico (Móvil + Cookies)",
        "Extremo (Todas las técnicas de Gujal00)",
        "YT-DLP (TLS Spoofing - Recomendado en PC)"
    ]
    cfg = ui_utils.load_json('settings.json')
    current = cfg.get('dm_safe_level', 0)
    
    sel = xbmcgui.Dialog().select("Modo Anti-Errores Dailymotion", options, preselect=current)
    if sel >= 0:
        # Si selecciona yt-dlp, verificar que está disponible
        if sel == 3:
            try:
                import yt_dlp
                xbmc.log(f"[AtresDaily] yt-dlp v{yt_dlp.version.__version__} disponible", xbmc.LOGINFO)
            except ImportError:
                xbmcgui.Dialog().ok("AtresDaily", "yt-dlp no está instalado.\n\n"
                    "Instálalo con:\npip install yt-dlp curl-cffi")
                return
        cfg['dm_safe_level'] = sel
        # Mantener compatibilidad con la antigua variable booleana
        cfg['dm_safe_mode'] = sel > 0
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo Anti-Errores DM: {options[sel].split(' (')[0]}")
        xbmc.executebuiltin("Container.Refresh")

# Interruptores de las listas de Dailymotion: (ajuste nativo, rótulo, explicación).
# Al ser ajustes de Kodi, este submenú y la pestaña Dailymotion de los ajustes del
# addon leen y cambian lo mismo.
_DM_LISTAS = (
    ("dm_filtrar_retirados", "Ocultar vídeos retirados",
     "El buscador de Dailymotion sigue devolviendo vídeos que ya han sido retirados: "
     "aparecen en la lista y al pulsarlos no reproducen. Con esta opción no se muestran."),
    ("dm_ocultar_privados", "Ocultar vídeos privados",
     "Algunos vídeos salen en las búsquedas aunque su autor los ha hecho privados, y no se "
     "pueden ver de ninguna forma. Distinguirlos de los que sí se pueden ver cuesta una "
     "consulta por cada uno, y suelen ser menos de 1 de cada 100 resultados."),
    ("dm_ocultar_directos_apagados", "Ocultar directos que no están emitiendo",
     "Un canal en directo que ahora mismo no emite no se puede reproducir. Desactívala si "
     "prefieres encontrar esos canales en las búsquedas aunque estén apagados."),
    ("dm_rellenar_listas", "Rellenar las listas con más resultados",
     "Al ocultar vídeos, algunas búsquedas se quedan en 4 o 5 resultados. Con esta opción se "
     "piden más a Dailymotion para que la lista salga completa, en la misma consulta."),
)


def dm_listas_menu():
    ui_utils.visto('dm_listas')
    addon = xbmcaddon.Addon()
    for clave, rotulo, explicacion in _DM_LISTAS:
        estado = ("[COLOR gray]NO[/COLOR]" if addon.getSetting(clave) == 'false'
                  else "[COLOR green]SÍ[/COLOR]")
        ui_utils.add_item(action="toggle_dm_ajuste", url=clave, title=f"{rotulo}: {estado}",
                          thumbnail=ui_utils.media_icon("adv_anti_errores.png"), folder=False,
                          plot=f"{explicacion}\n\n[I]Pulsa para cambiar.[/I]")
    ui_utils.close_item_list()


def toggle_dm_ajuste(clave):
    rotulos = {c: r for c, r, _ in _DM_LISTAS + _DM_BUSQUEDA}
    if clave not in rotulos:
        return
    if clave in {c for c, _, _ in _DM_BUSQUEDA}:
        ui_utils.visto(clave)
    addon = xbmcaddon.Addon()
    activo = addon.getSetting(clave) == 'false'
    addon.setSetting(clave, 'true' if activo else 'false')
    xbmcgui.Dialog().notification("AtresDaily", f"{rotulos[clave]}: {'SÍ' if activo else 'NO'}")
    xbmc.executebuiltin("Container.Refresh")


def set_dl_mode():
    opts = [
        "Nivel 1: DIRECTO (Normal)", 
        "Nivel 2: SAFE MODE (Gujal Style)", 
        "Nivel 3: MODO ESPADAILY (Procesado HLS)",
        "Nivel 4: YT-DLP (Requiere yt-dlp instalado)",
        "Nivel 5: ULTRA (Multi-hilo HLS+)"
    ]
    idx = xbmcgui.Dialog().select("Modo de Descarga", opts)
    if idx >= 0:
        cfg = ui_utils.load_json('settings.json')
        cfg['dl_mode'] = idx # 0=Direct, 1=Safe, 2=EspaDaily, 3=yt-dlp, 4=Ultra
        
        # Mantener compatibilidad hacia atrás
        cfg['dl_safe_mode'] = (idx == 1)
        
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().notification("AtresDaily", f"Modo descarga: Nivel {idx+1} guardado")
        xbmc.executebuiltin("Container.Refresh")

def _do_download_ultra(url, dest, title):
    """
    Modo ULTRA: Descarga HLS Multi-hilo.
    Usa concurrent.futures para maximizar el ancho de banda.
    """
    import concurrent.futures
    import tempfile
    import threading

    dp = None
    temp_dir = None
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)

        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo ULTRA)", "Analizando stream de alta velocidad...")

        # Lista maestra
        session = requests.Session()
        session.headers.update(HEADERS)

        r = session.get(url, timeout=15)
        m3u8_content = r.text
        playlist_url = r.url

        # Seleccionar mejor calidad
        if "#EXT-X-STREAM-INF" in m3u8_content:
             dp.update(0, "Optimizando calidad...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1].strip() if i+1 < len(lines) else ''
             if best_url:
                 r = session.get(urllib.parse.urljoin(playlist_url, best_url), timeout=15)
                 m3u8_content = r.text
                 playlist_url = r.url

        # Segmentos, con urljoin y no concatenando, porque una URI que empieza por "/" es
        # relativa a la raíz del host y no a la carpeta de la lista.
        segments = [urllib.parse.urljoin(playlist_url, l.strip()) for l in m3u8_content.splitlines()
                    if l.strip() and not l.strip().startswith("#")]
        total_segs = len(segments)
        if total_segs == 0: raise Exception("Stream vacío")

        # Descarga paralela (4 hilos) a ficheros temporales, en una carpeta propia de esta
        # descarga. Con una fija, otra descarga ULTRA simultánea borraría los segmentos.
        temp_dir = tempfile.mkdtemp(prefix="atresdaily_ultra_", dir=xbmcvfs.translatePath("special://temp/"))
        cancelado = threading.Event()

        def download_segment(idx, seg_url):
            t_path = os.path.join(temp_dir, f"{idx:05d}.ts")
            # El try va dentro del bucle; fuera, el primer fallo de red se saltaría los reintentos.
            for _ in range(3):
                if cancelado.is_set():
                    return False
                try:
                    sr = session.get(seg_url, timeout=10)
                    if sr.status_code == 200:
                        with open(t_path, 'wb') as f: f.write(sr.content)
                        return True
                except requests.RequestException:
                    pass
                time.sleep(0.5)
            return False

        completed = failed = 0
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
        futures = [executor.submit(download_segment, i, s) for i, s in enumerate(segments)]
        try:
            for future in concurrent.futures.as_completed(futures):
                if dp.iscanceled():
                    cancelado.set()
                    break
                if future.result():
                    completed += 1
                else:
                    failed += 1
                dp.update(int((completed + failed) * 100 / total_segs), f"Bajando paquetes: {completed}/{total_segs}")
        finally:
            if cancelado.is_set():
                # Los segmentos en curso (4 como mucho) tardan unos segundos en soltarse.
                dp.update(int((completed + failed) * 100 / total_segs), "Cancelando...")
            # En Python 3.8 shutdown() no cancela lo pendiente, así que sin cancelar a mano
            # "Cancelar" esperaría a que se bajaran todos los segmentos.
            for fut in futures:
                fut.cancel()
            executor.shutdown(wait=True)

        if cancelado.is_set():
            xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada")
            return

        # Se unen los segmentos
        dp.update(100, "Ensamblando archivo final...")
        with open(dest, 'wb') as final_file:
            for i in range(total_segs):
                t_path = os.path.join(temp_dir, f"{i:05d}.ts")
                if os.path.exists(t_path):
                    with open(t_path, 'rb') as tf:
                        shutil.copyfileobj(tf, final_file)
        dp.close()
        dp = None

        connector._log_download_complete(title, dest, "MP4 (ULTRA)")
        if failed:
            xbmcgui.Dialog().ok("AtresDaily", f"Descarga finalizada con {failed} segmento(s) fallido(s).\nEl vídeo puede tener cortes.")
        else:
            xbmcgui.Dialog().ok("AtresDaily", "¡Descarga ULTRA completada!")

    except Exception as e:
        if dp is not None:
            dp.close()
            dp = None
        xbmc.log(f"[AtresDaily] Ultra Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error Ultra", f"Fallo en descarga Ultra:\n{str(e)}")
    finally:
        if dp is not None:
            dp.close()
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)

def _do_download_ytdlp(vid, dest, title):
    """Descarga con yt-dlp, que tiene que estar instalado en el sistema."""
    import subprocess
    import threading

    ytdlp_path = shutil.which('yt-dlp')
    if not ytdlp_path:
        # Intentar rutas comunes en Windows/Linux
        common_paths = [
            'yt-dlp',
            'yt-dlp.exe',
            '/usr/local/bin/yt-dlp',
            '/usr/bin/yt-dlp',
            os.path.expanduser('~/.local/bin/yt-dlp'),
        ]
        for p in common_paths:
            if os.path.exists(p):
                ytdlp_path = p
                break
    
    if not ytdlp_path:
        xbmcgui.Dialog().ok("AtresDaily - yt-dlp", 
            "yt-dlp no está instalado en el sistema.\n\n"
            "Para usar este modo, instala yt-dlp:\n"
            "- Windows: winget install yt-dlp\n"
            "- Linux: pip install yt-dlp\n"
            "- Más info: github.com/yt-dlp/yt-dlp")
        return
    
    dm_url = f"https://www.dailymotion.com/video/{vid}"
    
    safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
    if not safe_title: safe_title = vid
    
    output_template = os.path.join(os.path.dirname(dest), f"{safe_title}.%(ext)s")
    
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando con yt-dlp", f"Iniciando descarga de:\n{title}")
    
    try:
        cmd = [
            ytdlp_path,
            '-f', 'best[ext=mp4]/best',  # Preferir MP4
            '-o', output_template,
            '--no-playlist',
            '--no-warnings',
            '--newline',  # progreso en líneas nuevas, no reescrito con \r
            dm_url
        ]

        xbmc.log(f"[AtresDaily] Ejecutando: {' '.join(cmd)}", xbmc.LOGINFO)

        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        )

        # readline() bloquea hasta la siguiente línea, así que se lee en un hilo aparte.
        # Leyendo aquí, "Cancelar" no respondería mientras yt-dlp no escriba nada.
        progreso = {'pct': None}

        def _leer_salida():
            for line in process.stdout:
                if '[download]' in line:
                    m = re.search(r'(\d+(?:\.\d+)?)%', line)
                    if m:
                        progreso['pct'] = float(m.group(1))

        lector = threading.Thread(target=_leer_salida, daemon=True)
        lector.start()

        monitor = xbmc.Monitor()
        cancelado = False
        while process.poll() is None:
            if dp.iscanceled() or monitor.waitForAbort(0.2):
                cancelado = True
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                break
            if progreso['pct'] is not None:
                dp.update(int(progreso['pct']), f"Descargando: {int(progreso['pct'])}%")
        lector.join(timeout=2)
        dp.close()

        if cancelado:
            # yt-dlp deja el parcial como .part (y .ytdl para reanudar) junto al destino.
            base_dir = os.path.dirname(dest)
            for f in os.listdir(base_dir):
                if f.startswith(safe_title) and f.endswith(('.part', '.ytdl')):
                    try:
                        os.remove(os.path.join(base_dir, f))
                    except OSError:
                        pass
            xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada")
            return

        retcode = process.returncode
        if retcode == 0:
            base_dir = os.path.dirname(dest)
            for f in os.listdir(base_dir):
                if f.startswith(safe_title) and (f.endswith('.mp4') or f.endswith('.mkv') or f.endswith('.webm')):
                    final_path = os.path.join(base_dir, f)
                    connector._log_download_complete(title, final_path, "yt-dlp")
                    xbmcgui.Dialog().ok("AtresDaily", f"Descarga completada con yt-dlp:\n{f}")
                    return
            
            xbmcgui.Dialog().ok("AtresDaily", "yt-dlp terminó pero no se encontró el archivo descargado.")
        else:
            xbmcgui.Dialog().ok("AtresDaily Error", f"yt-dlp falló con código: {retcode}\n\nPrueba otro modo de descarga.")
            
    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] yt-dlp Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error yt-dlp", f"Error ejecutando yt-dlp:\n{str(e)}")

def _do_download_espadaily(url, dest, title):
    # Descarga segmentos secuenciales y los une en un solo archivo MP4/TS
    tmp_dest = None
    try:
        if xbmcvfs.exists(dest):
             if not xbmcgui.Dialog().yesno("AtresDaily", "El archivo ya existe. ¿Sobrescribir?"): return
             xbmcvfs.delete(dest)

        dp = xbmcgui.DialogProgress()
        dp.create("Descargando (Modo EspaDaily)", "Analizando lista de reproducción...")

        # Lista M3U8, siguiendo las redirecciones
        r = requests.get(url, headers=HEADERS, timeout=15)
        m3u8_content = r.text
        playlist_url = r.url

        # Si es una lista de reproducción maestra, necesitamos elegir la mejor calidad primero
        if "#EXT-X-STREAM-INF" in m3u8_content:
             dp.update(0, "Resolviendo flujo final...")
             lines = m3u8_content.splitlines()
             best_bw = 0
             best_url = ""
             for i, l in enumerate(lines):
                 if l.startswith("#EXT-X-STREAM-INF"):
                     bw = 0
                     bwm = re.search(r'BANDWIDTH=(\d+)', l)
                     if bwm: bw = int(bwm.group(1))
                     if bw > best_bw:
                         best_bw = bw
                         best_url = lines[i+1].strip() if i+1 < len(lines) else ''

             if best_url:
                 r = requests.get(urllib.parse.urljoin(playlist_url, best_url), headers=HEADERS, timeout=15)
                 m3u8_content = r.text
                 playlist_url = r.url

        # Segmentos, con urljoin y no concatenando, porque una URI que empieza por "/" es
        # relativa a la raíz del host y no a la carpeta de la lista.
        segments = []
        lines = m3u8_content.splitlines()

        for l in lines:
            l = l.strip()
            if not l: continue
            if l.startswith("#EXT-X-KEY"):
                xbmc.log("[AtresDaily] Encriptación detectada en HLS. La descarga 'raw' podría no ser reproducible.", xbmc.LOGWARNING)
            if not l.startswith("#"):
                segments.append(urllib.parse.urljoin(playlist_url, l))
        
        total_segs = len(segments)
        if total_segs == 0:
            raise Exception("No se encontraron segmentos de video")
            
        dp.update(0, f"Descargando 0/{total_segs} segmentos")
        
        # A un archivo temporal, para no dejar uno roto si se cancela
        tmp_dest = dest + '.tmp'
        failed_segs = 0
        cancelado = False
        with open(tmp_dest, 'wb') as outfile:
            for i, seg in enumerate(segments):
                if dp.iscanceled():
                    cancelado = True
                    break

                success = False
                for attempt in range(3):
                    try:
                        sr = requests.get(seg, headers=HEADERS, timeout=10)
                        if sr.status_code == 200:
                            outfile.write(sr.content)
                            success = True
                            break
                    except requests.RequestException:
                        pass
                    if attempt < 2:
                        time.sleep(1 << attempt)  # 1s, 2s

                if not success:
                    xbmc.log(f"[AtresDaily] Fallo al descargar segmento {i}", xbmc.LOGWARNING)
                    failed_segs += 1

                percent = int((i + 1) * 100 / total_segs)
                dp.update(percent, f"Procesando segmento {i+1}/{total_segs}")

        dp.close()

        # La cancelación se guarda en el bucle porque, al cerrarse, Kodi reinicia el diálogo
        # (Reset() en GUI_MSG_WINDOW_DEINIT) e iscanceled() deja de reflejarla; sin eso, el
        # parcial acabaría renombrado como descarga completa.
        if not cancelado:
            # Renombrar temporal al destino final solo si se completó
            os.replace(tmp_dest, dest)
            tmp_dest = None  # Ya no hay que limpiar
            connector._log_download_complete(title, dest, "MP4 (EspaDaily)")
            if failed_segs > 0:
                xbmcgui.Dialog().ok("AtresDaily", f"Descarga finalizada con {failed_segs} segmento(s) fallido(s).\nEl vídeo puede tener cortes.")
            else:
                xbmcgui.Dialog().ok("AtresDaily", "Descarga finalizada correctamente (Modo EspaDaily)")
        else:
            xbmcgui.Dialog().notification("AtresDaily", "Descarga cancelada")

    except Exception as e:
        if 'dp' in locals(): dp.close()
        xbmc.log(f"[AtresDaily] EspaDaily Download Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Error en descarga EspaDaily:\n{str(e)}")
    finally:
        # Limpiar temporal si existe (cancelación o error)
        if tmp_dest and os.path.exists(tmp_dest):
            try: os.remove(tmp_dest)
            except Exception: pass

def clear_full_cache():
    # Limpiar caché JSON de catálogo y otros temporales
    if xbmcgui.Dialog().yesno("Limpiar Caché", "¿Borrar todos los datos de caché del catálogo?\nEsto forzará a recargar la información de A3Player."):
        try:
             _clear_cat_cache()
             xbmcgui.Dialog().notification("AtresDaily", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
             xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
             xbmcgui.Dialog().notification("AtresDaily", f"Error borrando caché: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

def export_cache():
    # Exportar archivos de caché del catálogo
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return
    
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
    
    if not files:
        xbmcgui.Dialog().notification("AtresDaily", "No hay caché para exportar")
        return
        
    import shutil
    count = 0
    try:
        for f in files:
            shutil.copy2(os.path.join(profile, f), os.path.join(d, f))
            count += 1
        xbmcgui.Dialog().notification("AtresDaily", f"{count} archivos exportados")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo al exportar caché: {e}")

def show_info():
    t = (
        "[B]Términos y Condiciones:[/B]\n• Este addon es completamente GRATUITO y siempre lo será, además es sin ánimo de lucro. Si alguien te lo ha vendido, te han estafado. Las etiquetas ATP+ o Premium hacen referencia a la suscripción de la plataforma de origen, no a este addon.\n"
        "• NO aloja ningún contenido\n\n"
        "[B]Exención de responsabilidad:[/B]\n"
        "Los desarrolladores de este addon NO se hacen responsables del uso "
        "que los usuarios hagan del mismo, ni del contenido que puedan "
        "encontrar a través de búsquedas externas.\n\n"
        "[B]¿Cómo funciona?[/B]\nAccede a contenido de internet replicando el comportamiento de un navegador web estándar. No elude restricciones técnicas ni sistemas de autenticación. El usuario es responsable de verificar que el uso cumple con los términos de cada plataforma que accede.\n\n"
        "Además del catálogo directo, permite buscar vídeos relacionados en plataformas de terceros. No está configurado para buscar contenido ilegal ni protegido. "
        "Los resultados pueden variar: es posible que encuentres un trailer, un resumen, o contenido similar subido por otros usuarios.\n\n"
        "El addon no garantiza ni controla qué resultados aparecen, "
        "ya que depende de lo que esté disponible de forma libre en internet.\n\n"
        "[COLOR red][B]AVISO LEGAL:[/B][/COLOR] El uso de este addon implica la lectura y aceptación estricta del documento [B]AVISO_LEGAL.txt[/B] incluido en esta instalación."
    )
    xbmcgui.Dialog().textviewer("AtresDaily - Términos y Condiciones", t)

def show_legal_txt():
    f_path = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'AVISO_LEGAL.txt')
    content = "[B]No se encontró el archivo AVISO_LEGAL.txt[/B]"
    if os.path.exists(f_path):
        try:
            with open(f_path, 'r', encoding='utf-8') as f: content = f.read()
        except Exception: pass
    xbmcgui.Dialog().textviewer("AVISO LEGAL - AtresDaily", content)

def revoke_legal():
    if xbmcgui.Dialog().yesno(
        "Revocar Términos",
        "¿Estás seguro de que deseas REVOCAR tu aceptación de los términos legales?\n\nEl addon dejará de funcionar hasta que vuelvas a aceptarlos explícitamente."
    ):
        cfg = ui_utils.load_json('settings.json')
        cfg['legal_accepted_v2'] = False
        ui_utils.save_json('settings.json', cfg)
        xbmcgui.Dialog().ok("AtresDaily", "Términos revocados.\n\nEl addon se reiniciará para aplicar los cambios.")
        xbmc.executebuiltin(f"RunAddon({xbmcaddon.Addon().getAddonInfo('id')})")

def show_web_info():
    import universo; universo.show()

# --- Instantáneas del catálogo ---
def snapshots_menu():

    ui_utils.add_item(action="create_catalog_snapshot", title="[COLOR green]+ CREAR NUEVA FOTO DEL CATÁLOGO[/COLOR]", thumbnail=ui_utils.media_icon("snapshot_create.png"), folder=False)
    ui_utils.add_item(action="delete_snapshot_menu", title="[COLOR red]BORRAR INSTANTÁNEA...[/COLOR]", thumbnail=ui_utils.media_icon("snapshot_delete.png"), folder=True)
    
    # Contexto de búsqueda independiente para instantáneas
    cfg = ui_utils.load_json('settings.json')
    lvl = cfg.get('snapshot_context_level', 2)
    labels = ["", "BÁSICO (Título)", "ESTÁNDAR (Recomendado)", "AVANZADO"]
    cur_label = labels[lvl] if lvl < len(labels) else labels[2]
    
    c_plot = (
        "CONTEXTO DE BÚSQUEDA: Define cómo se busca el vídeo al pulsar en la foto.\n\n"
        "• BÁSICO: Solo el título (Ej: 'Capítulo 1')\n"
        "• ESTÁNDAR: Añade la categoría (Ej: 'Series Capítulo 1')\n"
        "• AVANZADO: Añade plataforma (Ej: 'Atresplayer Series Capítulo 1')\n\n"
        "[I]Pulsa para cambiar de nivel.[/I]"
    )
    ui_utils.add_item(action="toggle_snapshot_precision", title=f"Contexto en Instantánea: [COLOR yellow]{cur_label}[/COLOR]", thumbnail=ui_utils.media_icon("adv_precision.png"), folder=False, plot=c_plot)
    
    # Listar instantáneas JSON existentes
    sdir = _get_snapshot_dir()
    if os.path.exists(sdir):
        files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
        for f in files:
            ts = f.replace("snap_", "").replace(".json", "")
            # Formateo visual de fecha
            try: d_str = f"{ts[6:8]}/{ts[4:6]}/{ts[0:4]} {ts[9:11]}:{ts[11:13]}"
            except Exception: d_str = ts
            ui_utils.add_item(action="view_snapshot", title=f"Instantánea: {d_str}", url=f, extra="root", thumbnail=ui_utils.media_icon("adv_snapshot.png") or "DefaultFolder.png", folder=True)
            
    ui_utils.close_item_list()

def snapshot_help():
    t = (
        "[B]¿Qué es el Contexto de Búsqueda?[/B]\n\n"
        "Como una instantánea es solo una 'foto' (título y foto), cuando pulsas en una serie, "
        "el addon tiene que buscarla en Dailymotion.\n\n"
        "El [B]Contexto[/B] le dice a esa búsqueda cuánta información extra debe usar:\n\n"
        "- [B]BÁSICO:[/B] Solo busca el nombre. Si la serie se llama 'Eva', puede que encuentre mil cosas.\n"
        "- [B]ESTÁNDAR:[/B] Busca 'Series Eva'. Mucho más preciso.\n"
        "- [B]AVANZADO:[/B] Busca 'Atresplayer Series Eva'. Máxima precisión, pero si el título en Dailymotion "
        "no incluye 'Atresplayer', podría no encontrar nada.\n\n"
        "Se recomienda el nivel [B]ESTÁNDAR[/B]."
    )
    xbmcgui.Dialog().textviewer("Ayuda de Instantáneas", t)

def toggle_snapshot_precision():
    d = ui_utils.load_json('settings.json')
    cur = d.get('snapshot_context_level', 2)
    cur += 1
    if cur > 3: cur = 1
    d['snapshot_context_level'] = cur
    ui_utils.save_json('settings.json', d)
    xbmc.executebuiltin("Container.Refresh")

def _get_snapshot_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'snapshots_json')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_catalog_snapshot():
    if not xbmcgui.Dialog().yesno("AtresDaily", "¿Crear una foto completa del catálogo actual?\nEsto guardará todas las series y programas para acceso offline."):
        return
        
    catalog = connector._fetch_all_catalog()
    if not catalog: return
    
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"snap_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)

    if core_settings.atomic_write_json(fpath, catalog):
        xbmcgui.Dialog().notification("AtresDaily", "Foto del catálogo guardada")
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo guardar la instantánea.")

def view_snapshot(fname, path="root"):
    # El nombre llega en la URL del plugin; basename() impide que salga de la carpeta.
    fpath = os.path.join(_get_snapshot_dir(), os.path.basename(fname))
    if not os.path.exists(fpath):
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (json.JSONDecodeError, ValueError):
        xbmcgui.Dialog().ok("AtresDaily", "La instantánea está corrupta o vacía.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    if path == "root":
        for cat_name in data.keys():
            ui_utils.add_item(action="view_snapshot", title=categorias.nombre(cat_name), url=fname, extra=cat_name,
                              thumbnail=ui_utils.media_icon("carpeta.png"), folder=True)
    else:
        items = data.get(path, [])
        cfg = ui_utils.load_json('settings.json')
        lvl = cfg.get('snapshot_context_level', 2)
        
        for i in items:
            t = i.get("t"); th = i.get("th"); pl = i.get("p")
            # En modo instantánea la query incorpora el contexto (path) según el nivel
            q = t
            if lvl == 2: q = f"{path} {t}"
            elif lvl == 3: q = f"Atresplayer {path} {t}"
            
            # Los elementos de las instantáneas siempre van a búsqueda externa (catalog_search)
            ui_utils.add_item(action="catalog_search", title=t, url=q, thumbnail=th, plot=pl, folder=True)
            
    ui_utils.close_item_list()

def delete_snapshot_menu():
    sdir = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sdir) if f.endswith('.json')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_snap", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f, thumbnail=ui_utils.media_icon("backup_delete.png"), folder=False)
    ui_utils.close_item_list()

def delete_single_snap(fname):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar instantánea {fname}?"):
        try:
            os.remove(os.path.join(_get_snapshot_dir(), os.path.basename(fname)))
        except Exception as e:
            xbmcgui.Dialog().ok("Error", f"No se pudo borrar: {e}")
            return
        xbmc.executebuiltin("Container.Refresh")

# --- Copias de seguridad (ZIP) ---
def _get_backup_dir():
    p = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'backups_zip')
    if not os.path.exists(p): os.makedirs(p)
    return p

def create_backup(include_cache=False):
    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Creando backup ZIP...")
    try:
        ts = time.strftime("%Y%m%d_%H%M%S")
        suffix = "_FULL" if include_cache else ""
        target = os.path.join(_get_backup_dir(), f"Backup_{ts}{suffix}.zip")
        files = ['settings.json', 'history.json', 'search_history.json', 'last_adv.json', 'favorites.json', 'exploration_history.json', 'custom_categories.json', 'loader_config.json']
        profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
        import zipfile
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for f in files:
                fp = os.path.join(profile, f)
                if os.path.exists(fp): zf.write(fp, f)
            import iptv_lists
            for fp, arcname in iptv_lists.backup_files():
                zf.write(fp, arcname)
            # Incluir caché si se solicita
            if include_cache:
                cache_files = [f for f in os.listdir(profile) if f.startswith("cat_cache_") and f.endswith(".json")]
                for cf in cache_files:
                    cfp = os.path.join(profile, cf)
                    if os.path.exists(cfp): zf.write(cfp, cf)
        # Verificar integridad del ZIP
        with zipfile.ZipFile(target, 'r') as zf:
            bad = zf.testzip()
            if bad:
                xbmc.log(f"[AtresDaily] ZIP corrupto: {bad}", xbmc.LOGWARNING)
                xbmcgui.Dialog().notification("AtresDaily", "Backup creado con advertencias", xbmcgui.NOTIFICATION_WARNING)
            else:
                xbmcgui.Dialog().notification("AtresDaily", "Copia ZIP creada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e: xbmcgui.Dialog().ok("Error", str(e))
    finally: dp.close()

def _list_backups():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="restore_backup", title=f"Restaurar: {f}", url=f,
                          thumbnail=ui_utils.media_icon("backup_restore.png"), folder=False)
    ui_utils.close_item_list()

def restore_backup(fname):
    """Restaurar backup con opciones granulares."""
    source = os.path.join(_get_backup_dir(), os.path.basename(fname))
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    import zipfile
    
    # Mapeo de archivos a nombres amigables (sin revelar información sensible)
    file_labels = {
        'settings.json': 'Configuración General',
        'history.json': 'Historial de Búsquedas',
        'search_history.json': 'Historial de Búsquedas (v2)',
        'last_adv.json': 'Última Búsqueda Avanzada',
        'favorites.json': 'Favoritos',
        'exploration_history.json': 'Historial de Navegación',
        'custom_categories.json': 'Categorías Personalizadas',
        'loader_config.json': 'Otros (Avanzado)',
        'custom_iptv_lists.json': 'Listas de canales',
    }
    
    # Archivos que permiten fusión (listas JSON)
    mergeable_files = ['favorites.json', 'history.json', 'search_history.json', 'exploration_history.json']
    
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available_files = zf.namelist()
        
        known_files = [f for f in available_files if f in file_labels]

        if not known_files:
            xbmcgui.Dialog().ok("AtresDaily", "Este backup no contiene datos reconocidos.")
            return

        options = [file_labels.get(f, f) for f in known_files]
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        
        if selected is None or len(selected) == 0:
            return
        
        files_to_restore = [known_files[i] for i in selected]
        # Las listas de canales avisan por su cuenta y no cuentan aquí.
        restaurados, fallidos = [], []

        with zipfile.ZipFile(source, 'r') as zf:
            for fname_zip in files_to_restore:
                dest_path = os.path.join(profile, fname_zip)
                # Las listas de canales llevan sus propios archivos y se fusionan por id.
                if fname_zip == 'custom_iptv_lists.json':
                    import iptv_lists
                    iptv_lists.restore_from_backup(zf)
                    continue

                # Si el archivo es fusionable y ya existe, preguntar
                if fname_zip in mergeable_files and os.path.exists(dest_path):
                    choice = xbmcgui.Dialog().select(
                        f"{file_labels[fname_zip]}", 
                        ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"]
                    )
                    
                    if choice == 2 or choice == -1:  # Omitir
                        continue
                    elif choice == 1:  # Fusionar
                        merged = None
                        try:
                            with open(dest_path, 'r', encoding='utf-8') as f:
                                current_data = json.load(f)
                            with zf.open(fname_zip) as zfile:
                                backup_data = json.load(zfile)
                            if isinstance(current_data, list) and isinstance(backup_data, list):
                                merged = current_data + [x for x in backup_data if x not in current_data]
                            elif isinstance(current_data, dict) and isinstance(backup_data, dict):
                                merged = {**current_data, **backup_data}
                        except (OSError, ValueError, KeyError) as e:
                            xbmc.log(f"[AtresDaily] Error fusionando {fname_zip}: {e}", xbmc.LOGWARNING)
                        # Se pidió fusionar, así que si no se puede se omite, para no sustituir los datos
                        # actuales sin avisar.
                        if merged is None or not core_settings.atomic_write_json(dest_path, merged, ensure_ascii=False):
                            fallidos.append(file_labels[fname_zip])
                        else:
                            restaurados.append(fname_zip)
                        continue

                # Extracción normal (sustituir)
                zf.extract(fname_zip, profile)
                restaurados.append(fname_zip)

        if fallidos:
            xbmcgui.Dialog().ok("AtresDaily", "No se pudo fusionar y se ha dejado como estaba:\n"
                                + "\n".join(fallidos)
                                + ("\n\nEl resto se ha restaurado." if restaurados else ""))
        elif restaurados:
            xbmcgui.Dialog().notification("AtresDaily", "Restauración completada")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo en restauración: {e}")

def _del_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    for f in files:
        ui_utils.add_item(action="delete_single_backup", title=f"[COLOR red]Borrar: {f}[/COLOR]", url=f,
                          thumbnail=ui_utils.media_icon("backup_delete.png"), folder=False)
    ui_utils.close_item_list()

def delete_single_backup(fname):
    try:
        # El nombre llega en la URL del plugin; basename() impide que salga de la carpeta.
        os.remove(os.path.join(_get_backup_dir(), os.path.basename(fname)))
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"No se pudo borrar: {e}")
        return
    xbmc.executebuiltin("Container.Refresh")

def _export_backups_menu():
    bdir = _get_backup_dir()
    files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    ui_utils.add_item(action="", title="[I]Selecciona copia para exportar:[/I]", thumbnail=ui_utils.media_icon("seccion.png"), folder=False)
    for f in files:
        ui_utils.add_item(action="export_single_backup", title=f"Exportar: {f}", url=f,
                          thumbnail=ui_utils.media_icon("backup_export.png"), folder=False)
    ui_utils.close_item_list()

def export_single_backup(fname):
    fname = os.path.basename(fname)
    source = os.path.join(_get_backup_dir(), fname)
    # Tipo 3: ShowAndGetWriteableDirectory
    dest_folder = xbmcgui.Dialog().browse(3, f'Guardar {fname} en...', 'files')
    if dest_folder:
        # Con xbmcvfs y no shutil, porque browse() puede devolver una carpeta de red.
        if xbmcvfs.copy(source, _vfs_join(dest_folder, fname)):
            xbmcgui.Dialog().notification("AtresDaily", f"Exportado a: {dest_folder}")
        else:
            xbmcgui.Dialog().ok("Error al Exportar", "No se pudo copiar la copia de seguridad a esa carpeta.")

# --- TV en directo ---
_ACE_RE_URL  = re.compile(r'^acestream://([a-fA-F0-9]{40})$', re.I)
_ACE_RE_ID   = re.compile(r'^[a-fA-F0-9]{40}$', re.I)

# Escaneo de webs/Telegram. _ACE_ANCHOR_RE: <a> cuyo href lleva el hash (acestream:// o
# content_id/infohash) y captura el texto visible como nombre. _ACE_LOOSE_RE: el mismo hash
# suelto en el texto, sin nombre, como red de seguridad (hrefs sin comillas, texto plano...).
_ACE_ANCHOR_RE = re.compile(
    r'<a\b[^>]*href\s*=\s*["\'][^"\']*?(?:acestream://|(?:content_id|infohash)=)([a-fA-F0-9]{40})[^"\']*["\'][^>]*>(.*?)</a>',
    re.I | re.S)
_ACE_LOOSE_RE = re.compile(
    r'(?:acestream://|(?:content_id|infohash)=)([a-fA-F0-9]{40})(?![a-fA-F0-9])', re.I)
_ACE_TAG_RE = re.compile(r'<[^>]+>')
# BBCode que Kodi interpreta en los labels; se quita de nombres no confiables (scrapeados o
# del índice de AceStream) para que no descuadren el label. No toca corchetes como [HD]/[ES].
_KODI_TAG_RE = re.compile(r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR|TABS|COLOR\b[^\]]*)\]', re.I)
_TDT_M3U_URL = "https://www.tdtchannels.com/lists/tv.m3u8"
_TDT_JSON_URL = "https://www.tdtchannels.com/lists/tv.json"

def _parse_m3u_content(text):
    """Parsea contenido M3U/M3U8 y devuelve lista de canales."""
    lines = text.splitlines()
    channels = []
    current_name = ""
    current_logo = ""
    current_group = ""

    for line in lines:
        line = line.strip()
        if line.startswith("#EXTINF:"):
            current_name = line.split(",", 1)[-1].strip() if "," in line else "Canal"
            logo_match = re.search(r'tvg-logo="([^"]*)"', line)
            current_logo = logo_match.group(1) if logo_match else ""
            group_match = re.search(r'group-title="([^"]*)"', line)
            current_group = group_match.group(1) if group_match else ""
        elif line and not line.startswith("#"):
            channels.append({
                "name": current_name or "Canal",
                "url": line,
                "logo": current_logo,
                "group": current_group,
            })
    return channels

def live_tv_menu():
    """TV en directo con canales A3Player + TDT + listas personalizadas."""
    ui_utils.visto('directos_4.9')
    if xbmcaddon.Addon().getSetting('hide_vpn_nota') != 'true':
        li_vpn = xbmcgui.ListItem(label="[B][COLOR yellow]NOTA: Los directos suelen fallar con VPN activa[/COLOR][/B] (pulsa aquí para quitar este mensaje)")
        li_vpn.setInfo('video', {'plot': "Las emisiones en directo de A3Player tienen sistemas de detección que suelen bloquear las conexiones a través de VPN. Si tienes problemas, prueba a desactivarla."})
        li_vpn.setArt({'icon': ui_utils.media_icon("info.png"), 'thumb': ui_utils.media_icon("info.png")})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0] + "?action=vpn_nota", listitem=li_vpn, isFolder=False)

    # Interceptar endOfDirectory para añadir más elementos al final
    _original_end = xbmcplugin.endOfDirectory
    xbmcplugin.endOfDirectory = lambda *a, **kw: None
    try:
        connector.list_live()
    except Exception:
        pass
    finally:
        xbmcplugin.endOfDirectory = _original_end
    addon_path = xbmcaddon.Addon().getAddonInfo('path')
    directo_icon = os.path.join(addon_path, "resources", "media", "directo.png")
    directo_thumb = directo_icon if os.path.exists(directo_icon) else "DefaultAddonPVRClient.png"
    ui_utils.add_item(action="list_live_cats", title="En Directo A3", thumbnail=directo_thumb, folder=True)

    ui_utils.add_item(
        action="epg_texto_atres",
        title="[B][COLOR lightcyan]EPG (guía de televisión)[/COLOR][/B]",
        thumbnail=ui_utils.media_icon("cat_epg_texto.png") or "DefaultIconInfo.png",
        folder=True,
        plot="EPG de los canales aquí listados.\nParrilla completa disponible en EspaTV."
    )

    # EspaTV, instalar/abrir
    try:
        xbmcaddon.Addon("plugin.video.espatv")
        _espatv_live_status = "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        _espatv_live_status = "[COLOR gray]No instalado[/COLOR]"
    li = xbmcgui.ListItem(label=f"[COLOR red]Es[/COLOR][COLOR gold]pa[/COLOR][COLOR red]TV[/COLOR] - Canales, TV, radio, agenda deportiva, top películas y series y más - {_espatv_live_status}")
    li.setArt({'icon': ui_utils.media_icon('espatv_icon.jpg')})
    li.setInfo('video', {'plot': (
        "[B]EspaTV[/B] - Addon todo-en-uno para contenido en castellano\n\n"
        "• TV España (nacionales, autonómicos, temáticos)\n"
        "• Samsung TV Plus y Pluto TV\n"
        "• Radio y podcast\n"
        "• Agenda deportiva\n"
        "• Top películas y series\n"
        "• Dailymotion y YouTube\n\n"
        "Pulsa para abrir o instalar automáticamente.\n\n"
        "https://github.com/espakodi/espatv"
    )})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=sys.argv[0] + "?action=espatv_install",
        listitem=li,
        isFolder=False
    )

    _ace_dot = "[COLOR lime]●[/COLOR] " if xbmcaddon.Addon().getSetting('acestream_seen') != '1' else ""
    li_ace = xbmcgui.ListItem(label=f"{_ace_dot}Buscar directos en AceStream (mejor con VPN)")
    li_ace.setArt({'icon': ui_utils.media_icon('adv_acestream.png'), 'thumb': ui_utils.media_icon('adv_acestream.png')})
    li_ace.setInfo('video', {'plot': (
        "[COLOR yellow]AceStream es P2P y tu IP queda a la vista de los demás equipos, así que es mejor tener una VPN activa.[/COLOR]\n\n"
        "Busca canales y streams en la red AceStream. Consulta primero el motor local (127.0.0.1:6878) y, si no responde, el servidor público search.acestream.net.\n\n"
        "El protocolo acestream:// no es nativo de Kodi, así que necesitas un addon que lo reproduzca: EKHorus (script.module.horus) o StreamNinja. Dependiendo del addon y la plataforma, puede que también necesites el AceStream Engine instalado en el sistema."
    )})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0] + "?action=search_acestream", listitem=li_ace, isFolder=True)

    ui_utils.add_item(action="tdt_channels_json", title="TDT Channels España", thumbnail=ui_utils.media_icon("tdt.png"), folder=True, plot="Lista completa de canales de la TDT española organizada por categorías.\n\nIncluye nacionales, autonómicos, temáticos y más.")

    # --- Addons recomendados (SlyGuy) ---
    _slyguy_addons = [
        ("slyguy.samsung.tv.plus", "Samsung TV Plus", "TV gratis: canales en directo y películas bajo demanda sin necesidad de cuenta."),
        ("slyguy.pluto.tv.provider", "Pluto TV", "Cientos de canales de TV en directo y contenido bajo demanda totalmente gratis."),
    ]
    for addon_id, addon_name, addon_desc in _slyguy_addons:
        status = "[COLOR lime]Instalado[/COLOR]" if _addon_is_known(addon_id) else "[COLOR gray]No instalado[/COLOR]"

        li = xbmcgui.ListItem(label=f"{addon_name} - {status}")
        li.setArt({'icon': ui_utils.media_icon('addon_externo.png')})
        li.setInfo('video', {'plot': f"{addon_desc}\n\nRequiere el repositorio SlyGuy.\nPulsa para abrir o instalar."})
        url = f"{sys.argv[0]}?action=slyguy_install&url={addon_id}&title={urllib.parse.quote(addon_name)}"
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

    # TDT M3U
    ui_utils.add_item(action="tdt_channels", title="TDT Channels España (M3U)", thumbnail=ui_utils.media_icon("tdt.png"), folder=True, plot="Lista M3U alternativa de canales TDT.\nMismo contenido en formato plano.")

    import iptv_lists
    iptv_lists.add_menu_items()

    ui_utils.close_item_list()

def _render_m3u_channels(channels, source_label=""):
    """Renderiza una lista de canales parseados de M3U en el directorio de Kodi."""
    h = int(sys.argv[1])
    xbmcplugin.setContent(h, 'videos')

    for ch in channels:
        label = ch["name"]
        if ch["group"]:
            label = f"[COLOR gray][{ch['group']}][/COLOR] {ch['name']}"

        li = xbmcgui.ListItem(label=label)
        thumb = ch["logo"] or ui_utils.media_icon("directo.png")
        li.setArt({'icon': thumb, 'thumb': thumb})
        li.setInfo('video', {
            'title': ch["name"],
            'plot': f"Canal: {ch['name']}\nGrupo: {ch['group']}\n\nFuente: {source_label}" if source_label else f"Canal: {ch['name']}\nGrupo: {ch['group']}"
        })

        cm = []
        cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(ch['name'], safe='')}&url={urllib.parse.quote(ch['url'], safe='')}&thumbnail={urllib.parse.quote(thumb, safe='')}&extra=&fav_action=play_tdt)"))
        li.addContextMenuItems(cm)

        play_url = f"{sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(ch['url'], safe='')}&title={urllib.parse.quote(ch['name'], safe='')}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

# Cache temporal del JSON de TDT (se descarga cada vez que entras a la sección)
_tdt_json_cache = {"data": None}

def search_acestream():
    _addon = xbmcaddon.Addon()
    _addon.setSetting('acestream_seen', '1')
    if _addon.getSetting('acestream_enabled') != 'true':
        accepted = xbmcgui.Dialog().yesno(
            "AceStream - Activar",
            (
                "AceStream es una red P2P de streaming. Para usarla necesitas:\n\n"
                "· AceStream Engine instalado en el sistema (Android/Windows/Linux)\n"
                "· Un addon de Kodi compatible: EKHorus (script.module.horus) o StreamNinja\n\n"
                "Ten en cuenta que al conectarte tu IP es visible para otros nodos de la red, "
                "como en cualquier protocolo P2P (BitTorrent).\n\n"
                "¿Quieres activar AceStream?"
            ),
            yeslabel="Activar",
            nolabel="Cancelar",
        )
        if not accepted:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
            return
        _addon.setSetting('acestream_enabled', 'true')

    ui_utils.add_item(
        action="acestream_search_name",
        title="Buscar en AceStream",
        thumbnail=ui_utils.media_icon("busqueda.png"),
        folder=True,
        plot="Busca canales y streams por nombre en la red AceStream.",
    )
    ui_utils.add_item(
        action="acestream_enter_url",
        title="Introducir URL acestream://",
        thumbnail=ui_utils.media_icon("url_paste.png"),
        folder=True,
        plot="Pega una URL completa del tipo acestream://[hash de 40 hex].",
    )
    ui_utils.add_item(
        action="acestream_enter_id",
        title="Introducir ID (hash)",
        thumbnail=ui_utils.media_icon("bt_episodio.png"),
        folder=True,
        plot="Pega directamente el hash de 40 caracteres hexadecimales sin prefijo.",
    )
    ui_utils.add_item(
        action="acestream_scan_url",
        title="Escanear web o Telegram",
        thumbnail=ui_utils.media_icon("url_scan.png"),
        folder=True,
        plot="Pega la URL de una página web o un canal de Telegram (ej: @canal, t.me/canal, canal) para buscar enlaces acestream automáticamente.",
    )
    ui_utils.add_item(
        action="acestream_history",
        title="Historial",
        thumbnail=ui_utils.media_icon('historial.png'),
        folder=True,
        plot="Accede al historial de búsquedas, URLs, hashes y webs escaneadas.",
    )

    _ap = _ace_proxy_cfg()
    _ap_state = "[COLOR lime]ON[/COLOR]" if _ap['enabled'] else "[COLOR gray]OFF[/COLOR]"
    ui_utils.add_item(
        action="acestream_proxy_toggle",
        title=f"Proxy: {_ap_state}",
        thumbnail=ui_utils.media_icon("bt_proxy.png"),
        folder=True,
        plot=("Usa un proxy para sortear el bloqueo de algunos operadores: en la búsqueda del "
              "servidor público (search.acestream.net) y como reintento del escaneo de webs/"
              "Telegram si el acceso directo falla. No afecta al motor local ni a la "
              "reproducción del stream. Lento y poco fiable con proxies gratis."),
    )
    if _ap['enabled']:
        ui_utils.add_item(
            action="acestream_proxy_find",
            title=f"Buscar proxy gratis ahora (actual: {_proxy_display(_ap['addr']) or 'ninguno'})",
            thumbnail=ui_utils.media_icon("bt_proxy_find.png"), folder=True,
            plot="Busca y valida un proxy público gratuito vivo (puede tardar o no encontrar ninguno).",
        )
        ui_utils.add_item(
            action="acestream_proxy_manual",
            title="Introducir proxy manual",
            thumbnail=ui_utils.media_icon("adv_teclado.png"), folder=True,
            plot="Escribe tu propio proxy HTTP en formato host:puerto (ej: 1.2.3.4:8080).",
        )
        if _ap['addr']:
            ui_utils.add_item(
                action="acestream_proxy_clear",
                title="Quitar proxy", thumbnail=ui_utils.media_icon("bt_proxy_clear.png"), folder=True,
                plot="Olvida el proxy guardado.",
            )
    ui_utils.close_item_list()


_ACE_HISTORY_MAX = 50


def _ace_save_history(type_, value):
    hist = ui_utils.load_json('acestream_history.json', default=[])
    hist = [e for e in hist if not (e.get('type') == type_ and e.get('value') == value)]
    hist.append({
        'type': type_,
        'value': value,
        'date': time.strftime('%d/%m/%Y %H:%M'),
        'ts': int(time.time()),
    })
    if len(hist) > _ACE_HISTORY_MAX:
        hist = hist[-_ACE_HISTORY_MAX:]
    ui_utils.save_json('acestream_history.json', hist)


# --- Proxy opcional para la búsqueda en el servidor público ---
_ACE_PROXY_FILE = 'acestream_proxy.json'
_ACE_PROXY_RX = re.compile(r'^(?:https?://)?(?:[^\s:@/]+(?::[^\s@/]*)?@)?[A-Za-z0-9.\-]+:\d{1,5}$')


def _ace_proxy_cfg():
    c = ui_utils.load_json(_ACE_PROXY_FILE, default={})
    if not isinstance(c, dict):
        c = {}
    return {'enabled': bool(c.get('enabled')), 'addr': str(c.get('addr') or '')}


def _proxy_url(addr):
    """Normaliza un proxy a URL con esquema. 'host:port' -> 'http://host:port'; respeta un
    http(s):// ya presente. requests/urllib lo tratan así de forma uniforme entre versiones."""
    return addr if '://' in addr else f'http://{addr}'


def _proxy_display(addr):
    """Oculta la contraseña del proxy al mostrarlo, de usuario:clave@host a usuario:***@host."""
    m = re.match(r'^((?:https?://)?[^:@/\s]+):[^@/\s]*@(.+)$', addr)
    return f'{m.group(1)}:***@{m.group(2)}' if m else addr


def _ace_proxy_set(**kv):
    c = _ace_proxy_cfg()
    c.update(kv)
    ui_utils.save_json(_ACE_PROXY_FILE, c)


def _ace_proxy_refresh(h):
    xbmcplugin.endOfDirectory(h, succeeded=False)
    xbmc.executebuiltin('Container.Refresh')


def _acestream_proxy_toggle():
    _ace_proxy_set(enabled=not _ace_proxy_cfg()['enabled'])
    _ace_proxy_refresh(int(sys.argv[1]))


def _acestream_proxy_find():
    h = int(sys.argv[1])
    import busqueda_total
    bg = xbmcgui.DialogProgressBG()
    bg.create("AceStream", "Buscando proxy disponible...")
    try:
        addr = busqueda_total.obtener_proxy_valido()
    finally:
        bg.close()
    if addr:
        _ace_proxy_set(addr=addr)
        xbmcgui.Dialog().notification("AceStream", f"Proxy: {_proxy_display(addr)}", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("AceStream", "No se encontró proxy disponible",
                                      xbmcgui.NOTIFICATION_WARNING)
    _ace_proxy_refresh(h)


def _acestream_proxy_manual():
    h = int(sys.argv[1])
    kb = xbmc.Keyboard(_ace_proxy_cfg()['addr'], 'Proxy (host:puerto o usuario:clave@host:puerto)')
    kb.doModal()
    addr = kb.getText().strip() if kb.isConfirmed() else ''
    if not addr:   # cancelado o vacío: no tocar nada (para borrar está "Quitar proxy")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_PROXY_RX.match(addr):
        xbmcgui.Dialog().ok("AceStream", "Formato no válido.\nUsa host:puerto o usuario:clave@host:puerto")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _ace_proxy_set(addr=addr, enabled=True)
    _ace_proxy_refresh(h)


def _acestream_proxy_clear():
    _ace_proxy_set(addr='')
    _ace_proxy_refresh(int(sys.argv[1]))


def _acestream_search_by_name():
    query = ui_utils.get_text('Buscar en AceStream').strip()
    if not query:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _ace_save_history('search', query)
    _search_acestream_results(query)


def _acestream_enter_url():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('URL acestream:// (40 hex)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_RE_URL.match(raw):
        xbmcgui.Dialog().ok("AceStream", "URL no válida.\nFormato esperado: acestream://[40 caracteres hex]")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    url = raw.lower()
    _ace_save_history('url', url)
    play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title=AceStream"
    xbmc.executebuiltin(f'RunPlugin({play_url})')
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _acestream_enter_id():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('ID AceStream (40 hex)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    if not _ACE_RE_ID.match(raw):
        xbmcgui.Dialog().ok("AceStream", "ID no válido.\nDebe ser exactamente 40 caracteres hexadecimales (0-9, a-f).")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    url = 'acestream://' + raw.lower()
    _ace_save_history('id', url)
    play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title=AceStream"
    xbmc.executebuiltin(f'RunPlugin({play_url})')
    xbmcplugin.endOfDirectory(h, succeeded=False)

def _clean_ace_name(fragment):
    """Extrae el texto visible de un <a>. Quita etiquetas HTML, descodifica entidades, quita el BBCode
    que Kodi interpretaría en el label y colapsa espacios."""
    txt = html.unescape(_ACE_TAG_RE.sub(' ', fragment or ''))
    txt = _KODI_TAG_RE.sub('', txt)
    return re.sub(r'\s+', ' ', txt).strip()


def _extract_ace_links(text):
    """[(hash, nombre|None)] de los enlaces acestream del HTML, deduplicados por hash (gana
    el primer nombre). Prioriza el texto de los <a>; los hashes sueltos (acestream:// o
    content_id/infohash) entran sin nombre como red de seguridad. Preserva orden."""
    out = {}   # dict conserva el orden de inserción
    for m in _ACE_ANCHOR_RE.finditer(text):
        hid = m.group(1).lower()
        name = _clean_ace_name(m.group(2))
        if name and (name.lower().startswith('acestream://') or _ACE_RE_ID.match(name)):
            name = ''   # el texto del enlace es la propia URL/hash: no aporta nombre
        if hid not in out:
            out[hid] = name or None
        elif name and not out[hid]:
            out[hid] = name
    for m in _ACE_LOOSE_RE.finditer(text):
        out.setdefault(m.group(1).lower(), None)
    return list(out.items())


_SCAN_MAX_BYTES = 5 * 1024 * 1024   # las páginas de listas/Telegram son HTML pequeño


def _fetch_scan_text(url, proxies):
    """Descarga una página para escanearla, con tope de tamaño y cierre del recurso.
    proxies=None -> conexión directa; dict {'http','https'} -> a través del proxy."""
    with requests.get(url, headers={"User-Agent": ui_utils.HEADERS["User-Agent"]},
                      timeout=15, proxies=proxies, stream=True) as r:
        r.raise_for_status()
        chunks, total = [], 0
        for chunk in r.iter_content(16384):
            chunks.append(chunk)
            total += len(chunk)
            if total > _SCAN_MAX_BYTES:
                break
        return b"".join(chunks).decode(r.encoding or "utf-8", "replace")


def _do_acestream_scan(h, raw):
    dp = xbmcgui.DialogProgress()
    dp.create("AceStream - Escaneando", f"Conectando con {raw[:60]}...")
    try:
        dp.update(30, "Descargando página...")
        ap = _ace_proxy_cfg()
        proxy = None
        if ap['enabled'] and ap['addr']:
            purl = _proxy_url(ap['addr'])
            proxy = {'http': purl, 'https': purl}
        try:
            page = _fetch_scan_text(raw, None)
        except Exception as e_direct:
            if not proxy:
                raise
            xbmc.log(f"[AtresDaily AceStream] escaneo directo falló, reintento con proxy: {e_direct}", xbmc.LOGWARNING)
            dp.update(45, "Reintentando con proxy...")
            page = _fetch_scan_text(raw, proxy)
        dp.update(70, "Buscando enlaces acestream...")

        found = _extract_ace_links(page)
        dp.close()

        if not found:
            xbmcgui.Dialog().ok("AceStream", f"No se encontraron enlaces acestream en:\n{raw}")
            xbmcplugin.endOfDirectory(h, succeeded=False)
            return

        xbmcplugin.setPluginCategory(h, f"AceStream · {raw[:50]}")
        xbmcplugin.setContent(h, "videos")
        for hash_id, name in found:
            url = f"acestream://{hash_id}"
            label = name[:80] if name else f"Acestream {hash_id[:8]}..."
            li = xbmcgui.ListItem(label=label)
            li.setInfo("video", {"title": label, "plot": url})
            li.setArt({"icon": ui_utils.media_icon("adv_acestream.png")})
            li.setProperty("IsPlayable", "true")
            play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title={urllib.parse.quote(label)}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        try: dp.close()
        except Exception: pass
        xbmc.log(f"[AtresDaily AceStream] escaneo falló ({raw[:80]}): {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("Error", f"No se pudo escanear la URL:\n{str(e)[:200]}")
        xbmcplugin.endOfDirectory(h, succeeded=False)


def _acestream_scan_url():
    h = int(sys.argv[1])
    raw = ui_utils.get_text('URL de web o canal Telegram (t.me/canal)').strip()
    if not raw:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    # Normalizar entrada de Telegram o URL web
    input_text = raw
    clean_tg = re.sub(r'^https?://', '', input_text)
    if clean_tg.startswith('t.me/'):
        clean_tg = re.sub(r'^t\.me/(?:s/)?', '', clean_tg)
    elif clean_tg.startswith('@'):
        clean_tg = clean_tg.lstrip('@')
    # Quitar posibles barras o parámetros de consulta al final del canal
    clean_tg = clean_tg.split('/')[0].split('?')[0].strip()

    # Si es un formato válido de canal de Telegram (ej: letras, números o _ con longitud >= 4)
    if re.match(r'^[a-zA-Z][a-zA-Z0-9_]{3,}$', clean_tg):
        raw = f'https://t.me/s/{clean_tg}'
    else:
        # Si es una dirección web y no tiene protocolo, se lo añadimos
        if not input_text.startswith(('http://', 'https://')):
            raw = 'https://' + input_text

    _ace_save_history('scan', raw)
    _do_acestream_scan(h, raw)


def _acestream_show_history():
    h = int(sys.argv[1])
    hist = ui_utils.load_json('acestream_history.json', default=[])
    if not hist:
        xbmcgui.Dialog().ok("Historial AceStream", "El historial está vacío.")
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    xbmcplugin.setPluginCategory(h, "Historial AceStream")
    xbmcplugin.setContent(h, "videos")

    type_label = {
        'search': 'Búsqueda',
        'url': 'URL acestream://',
        'id': 'Hash directo',
        'scan': 'Web / Telegram',
    }
    type_icon = {
        'search': ui_utils.media_icon('busqueda.png'),
        'url': ui_utils.media_icon('url.png'),
        'id': ui_utils.media_icon('bt_episodio.png'),
        'scan': ui_utils.media_icon('url_scan.png'),
    }

    for entry in reversed(hist):
        t      = entry.get('type', '')
        val    = entry.get('value', '')
        date   = entry.get('date', '')
        ts     = entry.get('ts', 0)
        tlabel = type_label.get(t, t)
        icon   = type_icon.get(t) or ui_utils.media_icon('adv_acestream.png')
        display = val if len(val) <= 55 else val[:52] + '...'
        title  = f"[{tlabel}] {display}"
        plot   = f"Tipo: {tlabel}\nValor: {val}\nFecha: {date}"
        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {"title": title, "plot": plot})
        li.setArt({"icon": icon, "thumb": icon})
        del_url = f"{sys.argv[0]}?action=acestream_history_delete&ts={ts}"
        li.addContextMenuItems([("Eliminar del historial", f"RunPlugin({del_url})")])
        if t in ('url', 'id'):
            li.setProperty("IsPlayable", "true")
            item_url = f"{sys.argv[0]}?action=acestream_history_play&url={urllib.parse.quote(val)}"
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=False)
        elif t == 'search':
            item_url = f"{sys.argv[0]}?action=acestream_history_search&q={urllib.parse.quote(val)}"
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)
        elif t == 'scan':
            item_url = f"{sys.argv[0]}?action=acestream_history_scan&url={urllib.parse.quote(val)}"
            xbmcplugin.addDirectoryItem(handle=h, url=item_url, listitem=li, isFolder=True)

    li_clear = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial[/COLOR]")
    li_clear.setInfo("video", {"title": "Borrar todo el historial"})
    li_clear.setArt({"icon": ui_utils.media_icon("backup_delete.png")})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=f"{sys.argv[0]}?action=acestream_history_clear",
        listitem=li_clear,
        isFolder=False,
    )
    xbmcplugin.endOfDirectory(h)


def _acestream_history_search(query):
    if not query:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    _search_acestream_results(query)


def _acestream_history_scan(url):
    h = int(sys.argv[1])
    if not url:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _do_acestream_scan(h, url)


def _acestream_history_play(url):
    h = int(sys.argv[1])
    if not url:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote(url)}&title=AceStream"
    xbmc.executebuiltin(f'RunPlugin({play_url})')
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _acestream_history_delete(ts_str):
    try:
        ts = int(ts_str)
    except (TypeError, ValueError):
        return
    hist = ui_utils.load_json('acestream_history.json', default=[])
    hist = [e for e in hist if e.get('ts') != ts]
    ui_utils.save_json('acestream_history.json', hist)
    xbmc.executebuiltin("Container.Refresh")


def _acestream_history_clear():
    h = int(sys.argv[1])
    if not xbmcgui.Dialog().yesno("Historial AceStream", "¿Borrar todo el historial?"):
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    ui_utils.save_json('acestream_history.json', [])
    xbmcgui.Dialog().notification("AceStream", "Historial borrado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _search_acestream_results(query):
    h = int(sys.argv[1])
    encoded_q = urllib.parse.quote_plus(query)
    api_urls = [
        ("motor local",    f"http://127.0.0.1:6878/server/api?method=search&query={encoded_q}&page=0"),
        ("servidor público", f"https://search.acestream.net/?method=search&api_key=test_api_key&api_version=1&query={encoded_q}&page=0"),
    ]
    progress = xbmcgui.DialogProgressBG()
    try: progress.create("AceStream", f"Buscando: {query}")
    except Exception: progress = None

    data = None; last_error = None
    _ap = _ace_proxy_cfg()
    proxy_addr = _proxy_url(_ap['addr']) if (_ap['enabled'] and _ap['addr']) else ''
    plain_opener = urllib.request.build_opener()
    proxy_opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({'http': proxy_addr, 'https': proxy_addr})
    ) if proxy_addr else None
    for label, api_url in api_urls:
        try:
            # Proxy solo para el servidor público; el motor local (127.0.0.1) va directo.
            use_proxy = proxy_opener is not None and api_url.startswith("https://search.acestream.net")
            opener = proxy_opener if use_proxy else plain_opener
            xbmc.log(f"[AtresDaily AceStream] Buscando '{query}' via {label}"
                     f"{' (proxy)' if use_proxy else ''}", xbmc.LOGINFO)
            req = urllib.request.Request(api_url, headers={"User-Agent": _user_agents.UA_DESKTOP})
            raw = opener.open(req, timeout=10).read().decode("utf-8", errors="replace")
            parsed = json.loads(raw)
            if isinstance(parsed, dict) and parsed.get("error"):
                last_error = f"{label}: {parsed.get('error')}"
                xbmc.log(f"[AtresDaily AceStream] {label} devolvió error: {parsed.get('error')}", xbmc.LOGWARNING)
                continue
            xbmc.log(f"[AtresDaily AceStream] {label} OK ({len(raw)} chars)", xbmc.LOGINFO)
            data = parsed; break
        except Exception as e:
            last_error = f"{label}: {e}"
            xbmc.log(f"[AtresDaily AceStream] {label} falló: {e}", xbmc.LOGWARNING)
            continue

    if progress:
        try: progress.close()
        except Exception: pass

    if data is None:
        xbmcgui.Dialog().ok("Buscar en AceStream", f"No se pudo realizar la búsqueda.\n\n{last_error or 'error desconocido'}")
        xbmcplugin.endOfDirectory(h, succeeded=False); return

    results = []
    if isinstance(data, list): results = data
    elif isinstance(data, dict):
        results = (data.get("result") or {}).get("results") or data.get("results") or []

    if not results:
        xbmcgui.Dialog().ok("AceStream", f"Sin resultados para: {query}")
        xbmcplugin.endOfDirectory(h, succeeded=True); return

    xbmcplugin.setPluginCategory(h, f"AceStream: {query}")
    xbmcplugin.setContent(h, "videos")
    for item in results:
        if not isinstance(item, dict): continue
        name = _KODI_TAG_RE.sub('', str(item.get("name") or item.get("title") or "Sin nombre")).strip() or "Sin nombre"
        infohash = str(item.get("infohash") or item.get("id") or "").strip()
        if not infohash: continue
        availability = item.get("availability") or 0
        try:
            availability = float(availability)
            if availability > 1: availability /= 100.0
        except (TypeError, ValueError): availability = 0
        plot_parts = []
        cats = item.get("categories") or []
        if isinstance(cats, list) and cats: plot_parts.append("Categoría: " + ", ".join(str(c) for c in cats if c))
        if availability > 0: plot_parts.append(f"Disponibilidad: {availability*100:.0f}%")
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name, "plot": "\n".join(plot_parts) or name})
        li.setArt({"icon": ui_utils.media_icon("adv_acestream.png")})
        li.setProperty("IsPlayable", "true")
        play_url = f"{sys.argv[0]}?action=play_ace&url={urllib.parse.quote('acestream://'+infohash)}&title={urllib.parse.quote(name)}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)

def tdt_channels_json():
    """Descarga y muestra las categorías de TDT Channels España (JSON)."""
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")

    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_JSON_URL, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        dp.update(70, "Procesando canales...")
        data = r.json()
        dp.close()

        countries = data.get("countries", [])
        if not countries:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron datos.")
            xbmcplugin.endOfDirectory(h)
            return

        # Guardar en caché para acceso rápido desde tdt_json_ambit
        _tdt_json_cache["data"] = countries[0].get("ambits", [])

        for ambit in _tdt_json_cache["data"]:
            name = ambit.get("name", "Sin nombre")
            num = len(ambit.get("channels", []))
            ui_utils.add_item(
                action="tdt_json_ambit", title=f"{name} [COLOR gray]({num})[/COLOR]",
                url=name, thumbnail=ui_utils.media_icon("carpeta.png"), folder=True,
                plot=f"Categoría: {name}\nCanales: {num}"
            )

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error TDT JSON: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TDT Channels", f"No se pudo cargar:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def tdt_json_ambit(ambit_name):
    """Muestra los canales de un ambit concreto del JSON de TDT Channels."""
    h = int(sys.argv[1])

    # Si no hay caché, volver a descargar
    ambits = _tdt_json_cache.get("data")
    if not ambits:
        try:
            r = requests.get(_TDT_JSON_URL, timeout=15)
            data = r.json()
            countries = data.get("countries", [])
            ambits = countries[0].get("ambits", []) if countries else []
            _tdt_json_cache["data"] = ambits
        except Exception as e:
            xbmcgui.Dialog().ok("Error", f"No se pudo descargar: {e}")
            xbmcplugin.endOfDirectory(h)
            return

    # Buscar el ámbito por nombre
    ambit = next((a for a in ambits if a.get("name") == ambit_name), None)
    if not ambit:
        xbmcgui.Dialog().ok("TDT Channels", f"Categoría '{ambit_name}' no encontrada.")
        xbmcplugin.endOfDirectory(h)
        return

    xbmcplugin.setContent(h, 'videos')
    import grabaciones
    estado_grabar = grabaciones.estado()

    for ch in ambit.get("channels", []):
        name = ch.get("name", "Canal")
        logo = ch.get("logo", "")
        options = ch.get("options", [])
        extra_info = ch.get("extra_info", [])
        web_url = ch.get("web", "")

        # Buscar el primer flujo válido
        stream_url = ""
        stream_format = ""
        for opt in options:
            u = opt.get("url", "")
            if u:
                stream_url = u
                stream_format = opt.get("format", "")
                break

        # Grabar, solo los HLS (el JSON dice el formato de cada enlace)
        rec_mark, rec_entry = "", None
        if stream_url and stream_format == "m3u8" and grabaciones.admite(stream_url):
            rec_mark, rec_entry = grabaciones.entrada(
                estado_grabar, stream_url, grabaciones.orden_tdt(stream_url, name, ch.get("epg_id")))

        # Etiqueta
        label = rec_mark + name
        if "GEO" in extra_info:
            label += " [COLOR orange][GEO][/COLOR]"

        thumb = logo or ui_utils.media_icon("directo.png")
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb})

        if stream_url:
            # Canal con flujo directo
            opts_text = "\n".join([f"  • {o.get('url','')[:60]}..." for o in options[:4]])
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\nFormato: {stream_format}\n\nStreams disponibles ({len(options)}):\n{opts_text}"
            })

            cm = []
            cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&title={urllib.parse.quote(name, safe='')}&url={urllib.parse.quote(stream_url, safe='')}&thumbnail={urllib.parse.quote(thumb, safe='')}&extra=&fav_action=play_tdt)"))
            if len(options) > 1 and options[1].get("url"):
                cm.append(("Probar otro stream", f"RunPlugin({sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(options[1].get('url',''), safe='')}&title={urllib.parse.quote(name, safe='')})"))
            if rec_entry:
                cm.append(rec_entry)
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_tdt&url={urllib.parse.quote(stream_url, safe='')}&title={urllib.parse.quote(name, safe='')}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        elif web_url:
            # Canal sin flujo pero con web oficial (Mediaset, etc.)
            label = f"{name} [COLOR skyblue][WEB][/COLOR]"
            if "GEO" in extra_info:
                label += " [COLOR orange][GEO][/COLOR]"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {
                'title': name,
                'plot': f"Canal: {name}\nCategoría: {ambit_name}\n\nEste canal no tiene stream directo.\nSe abrirá en el navegador:\n{web_url}"
            })
            open_url = f"{sys.argv[0]}?action=open_browser_url&url={urllib.parse.quote(web_url, safe='')}"
            xbmcplugin.addDirectoryItem(handle=h, url=open_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def tdt_channels():
    """Descarga y muestra la lista M3U de TDT Channels España."""
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("TDT Channels", "Descargando lista actualizada...")

    try:
        dp.update(30, "Conectando con tdtchannels.com...")
        r = requests.get(_TDT_M3U_URL, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error HTTP {r.status_code}")

        dp.update(70, "Procesando canales...")
        channels = _parse_m3u_content(r.text)
        dp.close()

        if not channels:
            xbmcgui.Dialog().ok("TDT Channels", "No se encontraron canales en la lista.")
            xbmcplugin.endOfDirectory(h)
            return

        _render_m3u_channels(channels, "TDT Channels España")

    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Error TDT Channels: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TDT Channels", f"No se pudo cargar la lista:\n{e}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def open_browser_url(url):
    """Abre una URL en el navegador. Soporta Android (TV/Fire Stick) y PC."""
    h = int(sys.argv[1])
    try:
        # Android (Fire Stick, TV Box, tablets...)
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin(f"StartAndroidActivity(,android.intent.action.VIEW,,{url})")
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            # PC (Windows, Mac, Linux)
            import webbrowser
            webbrowser.open(url)
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)

    except Exception:
        # Si no, se enseña la URL para copiarla a mano
        xbmcgui.Dialog().ok("Abrir en navegador",
            f"No se pudo abrir el navegador automáticamente.\n\n"
            f"Abre esta URL manualmente:\n{url}")
    finally:
        # Cerrar directorio Kodi para que no se quede colgado
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except Exception:
            pass

def _webapp_settings_items(cfg):
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    port = int(cfg.get('webapp_port', 8092))

    # Estado real (lo consulta a cualquier invocación que aloje el servidor) y la forma
    # de detenerlo desde Kodi.
    try:
        from webapp import bootstrap
        running_url = bootstrap.get_url()
    except Exception as ex:
        xbmc.log(f"[AtresDaily] Estado de la WebApp: {ex}", xbmc.LOGWARNING)
        running_url = None
    if running_url:
        ui_utils.add_item(action="webapp_stop", title=f"WebApp: [COLOR green]EN MARCHA[/COLOR] ({running_url})",
                          nuevo='webapp_estado', thumbnail=ui_utils.media_icon("webapp.png"), folder=False,
                          plot="El servidor de la WebApp está en marcha.\n\n[I]Pulsa para detenerlo.[/I]")
    else:
        # url="ajustes" para distinguirlo del botón de Experimental, que no lleva el punto.
        ui_utils.add_item(action="webapp_open", url="ajustes", title="WebApp: [COLOR gray]DETENIDA[/COLOR]",
                          nuevo='webapp_estado',
                          thumbnail=ui_utils.media_icon("webapp.png"), folder=False,
                          plot="El servidor de la WebApp está parado.\n\n[I]Pulsa para arrancarla y abrirla en el navegador.[/I]")

    if not is_android:
        lan = cfg.get('webapp_lan_mode', False)
        if lan:
            try:
                from webapp.bootstrap import get_lan_ip
                ip = get_lan_ip()
            except Exception:
                ip = '?'
            lan_label = f"WebApp LAN: [COLOR green]ACTIVADO ({ip})[/COLOR]"
            lan_plot = (f"La WebApp es accesible desde cualquier dispositivo de la red local.\n\n"
                        f"Abre esta URL en otro dispositivo:\n\nhttp://{ip}:{port}/\n\n"
                        f"[I]Pulsa para desactivar (solo este dispositivo).[/I]")
        else:
            lan_label = "WebApp LAN: [COLOR gray]DESACTIVADO (solo este dispositivo)[/COLOR]"
            lan_plot = ("La WebApp solo es accesible desde este dispositivo.\n\n"
                        "[I]Pulsa para activar y compartir en la red local.[/I]")
        ui_utils.add_item(action="webapp_toggle_lan", title=lan_label,
                          thumbnail=ui_utils.media_icon("webapp.png"), folder=False, plot=lan_plot)

    port_label = f"WebApp Puerto: [COLOR green]{port}[/COLOR]"
    port_plot = ("Puerto en el que escucha el servidor de la WebApp.\n\n"
                 "[I]Pulsa para cambiarlo. Rango válido: 1024-65535.[/I]")
    ui_utils.add_item(action="webapp_set_port", title=port_label,
                      thumbnail=ui_utils.media_icon("webapp.png"), folder=False, plot=port_plot)


def play_tdt(url, title="", ua="", ref=""):
    """Reproduce un canal TDT/IPTV (stream M3U8/MP4)."""
    try:
        play_url = url
        is_m3u8 = '.m3u8' in url.lower()

        use_ia = False
        if is_m3u8 and xbmcaddon.Addon().getSetting('use_inputstream') == 'true':
            try:
                xbmcaddon.Addon('inputstream.adaptive')
                use_ia = True
            except RuntimeError:
                xbmc.log("[AtresDaily] InputStream Adaptive activado pero no instalado.", xbmc.LOGWARNING)

        if xbmcaddon.Addon().getSetting('iptv_anti_errors') == 'true' and not ua:
            ua = ui_utils.HEADERS["User-Agent"]

        if (ua or ref) and not use_ia:
            parts = []
            if ua:  parts.append("User-Agent=" + urllib.parse.quote(ua))
            if ref: parts.append("Referer="    + urllib.parse.quote(ref))
            play_url = url + "|" + "&".join(parts)

        li = xbmcgui.ListItem(path=play_url)
        if title:   li.setInfo('video', {'title': title})
        if is_m3u8: li.setMimeType('application/x-mpegURL')

        if use_ia:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstreamaddon', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if ua:
                li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + ua)

        xbmc.Player().play(play_url, li)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error TDT play: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"No se pudo reproducir:\n{e}")

def input_search():
    # Con folder=False no construimos carpeta aquí, navegamos con Container.Update.
    # Así "volver atrás" no re-ejecuta el prompt (ni relanza el teclado / la web).
    if xbmcaddon.Addon().getSetting('advanced_search_active') != 'false':
        xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=advanced_search_menu")')
        return
    t = ui_utils.get_text('AtresDaily Search')
    if t:
        connector.add_hist(t)
        xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=search&url={urllib.parse.quote(t)}")')
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


def view_history():
    ui_utils.add_item(action="del_history", title="[COLOR red]Borrar Historial[/COLOR]", thumbnail=ui_utils.media_icon("backup_delete.png"), folder=False)
    h = ui_utils.load_json('history.json')
    for q in h:
        cm = [("Añadir a Favoritos de AtresDaily", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=search&url={urllib.parse.quote(q)}&title={urllib.parse.quote(q)}&f_thumb={urllib.parse.quote(ICON_MAIN)})")]
        cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(q)})"))
        ui_utils.add_item(action="search", title=q, url=q, thumbnail=ICON_MAIN, folder=True, direct="true", context=cm)
    ui_utils.close_item_list()

def del_history():
    ui_utils.save_json('history.json', [])
    xbmc.executebuiltin("Container.Refresh")

# --- Favoritos ---
def view_favorites():
    favs = core_settings.get_favorites()

    # --- Flow FavManager ---
    try:
        xbmcaddon.Addon('plugin.program.flowfavmanager')
        flow_installed = True
    except Exception:
        flow_installed = False

    if flow_installed:
        li_flow = xbmcgui.ListItem(label="[COLOR violet]Flow FavManager[/COLOR]")
        li_flow.setArt({'icon': ui_utils.media_icon('fav_gestor.png')})
        li_flow.setInfo('video', {'plot': 'Abre el editor avanzado de favoritos de Kodi.\nOrganiza, personaliza colores, iconos, formatos, crea secciones, perfiles y copias de seguridad.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=flowfav_launch", listitem=li_flow, isFolder=False)
    else:
        li_flow = xbmcgui.ListItem(label="[COLOR gray]Flow FavManager (No instalado)[/COLOR]")
        li_flow.setArt({'icon': ui_utils.media_icon('fav_gestor.png')})
        li_flow.setInfo('video', {'plot': 'Gestor avanzado de favoritos para Kodi. Pulsa para instalarlo automáticamente o ver las instrucciones.'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=flowfav_launch", listitem=li_flow, isFolder=False)

    # --- Añadir categorías personalizadas ---
    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow]Mis Categorías ({len(cats)})[/COLOR]")
         li_c.setArt({'icon': ui_utils.media_icon('categorias_usuario.png')})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=cat_menu", listitem=li_c, isFolder=True)

    # --- Novedades de mis favoritos ---
    if favs:
        li_news = xbmcgui.ListItem(label="[COLOR orange]Novedades de mis Favoritos[/COLOR]")
        li_news.setArt({'icon': ui_utils.media_icon('fav_novedades.png')})
        li_news.setInfo('video', {'plot': 'Busca contenido reciente subido a Dailymotion relacionado con tus favoritos.\nElige un margen de tiempo (24h, 48h, 7 días, 30 días).'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=f"{sys.argv[0]}?action=fav_news", listitem=li_news, isFolder=True)

    # --- Copia de seguridad ---
    ui_utils.add_item(action="backup_favs_dialog", title="[COLOR cyan]Copia de Seguridad[/COLOR]", thumbnail=ui_utils.media_icon("backup_favs.png"), folder=False, plot="Exportar o importar favoritos (JSON o TXT).")

    if not favs:
        if not cats:
             ui_utils.add_item(action="", title="No tienes favoritos guardados", thumbnail=ui_utils.media_icon("info.png"), folder=False)
    else:
        for f in favs:
            if not isinstance(f, dict): continue
            # Tipos comprobados, porque un favorites.json antiguo o editado a mano con un número o
            # una lista en estos campos tumbaría el menú entero.
            u = f.get('url')
            if not isinstance(u, str) or not u: continue
            t = str(f.get('title') or u)

            icon = f.get('icon') if isinstance(f.get('icon'), str) and f.get('icon') else ICON_MAIN
            action = f.get('action') or 'search'
            params = f.get('params') if isinstance(f.get('params'), dict) else {}
            # Los canales guardados sin fav_action quedaron como búsqueda de la URL del stream,
            # que en Dailymotion no encuentra nada.
            if action == 'search' and u.startswith(('http://', 'https://')):
                action = 'play_tdt'

            # Menú contextual
            cm = []
            
            cm.append(("Renombrar...", f"RunPlugin({sys.argv[0]}?action=fav_rename&fav_url={urllib.parse.quote(u)}&old_title={urllib.parse.quote(t)})"))
            cm.append(("Mover arriba", f"RunPlugin({sys.argv[0]}?action=fav_move_up&fav_url={urllib.parse.quote(u)})"))
            cm.append(("Mover abajo", f"RunPlugin({sys.argv[0]}?action=fav_move_down&fav_url={urllib.parse.quote(u)})"))
            
            # Soporte de categorías
            cm.append(("Mover a Categoría...", f"RunPlugin({sys.argv[0]}?action=cat_move_from_favs&fav_url={urllib.parse.quote(u)}&q={urllib.parse.quote(t)})"))
            
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(t)})"))

            cm.append(("Eliminar de Favoritos", f"RunPlugin({sys.argv[0]}?action=del_fav&url={urllib.parse.quote(u)})"))
            
            extra = params.get('extra') if isinstance(params.get('extra'), str) else ''

            # play_dm solo reproduce con setResolvedUrl, que exige un ítem IsPlayable.
            # play_media no lo necesita. Ante un 403 ofrece "Buscar" con Container.Update y
            # sale sin resolver (por eso el connector marca los premium sin IsPlayable), y si
            # no hay vídeo en marcha reproduce con Player().play(). Igual que play_tdt, basta
            # con que no sea carpeta.
            if action == "play_dm":
                ui_utils.add_item(action=action, title=t, url=u, thumbnail=icon, extra=extra, isPlayable=True, context=cm)
                continue

            # Forzar direct=true para saltar el menú avanzado
            kwargs = {}
            if action == "search":
                kwargs["direct"] = "true"

            ui_utils.add_item(action=action, title=t, url=u, thumbnail=icon, extra=extra,
                              folder=action not in ("play_tdt", "play_media"), context=cm, **kwargs)
        
    ui_utils.close_item_list()

def show_fav_news():
    h = int(sys.argv[1])
    try:
        favs = core_settings.get_favorites()
        if not favs:
            xbmcgui.Dialog().notification("AtresDaily", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(h)
            return

        if connector is None:
            xbmcgui.Dialog().notification("AtresDaily", "Conector no disponible", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(h)
            return

        # Margen de tiempo
        opts = [
            "Últimas 24 horas",
            "Últimas 48 horas (Recomendado)",
            "Última semana (7 días)",
            "Último mes (30 días - Lento)"
        ]
        sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
        if sel < 0:
            xbmcplugin.endOfDirectory(h)
            return

        margins = [86400, 172800, 604800, 2592000]
        time_limit = int(time.time()) - margins[sel]
        sel_label = opts[sel]

        # Búsquedas únicas de los favoritos
        queries = []
        seen = set()
        for f in favs:
            q = None
            act = f.get('action', '')
            # en search/trakt_search_dialog el título del favorito es la búsqueda
            if act in ('search', 'trakt_search_dialog'):
                q = str(f.get('title') or '').strip()
            # Para otros tipos, usar el título limpio
            elif act in ('list_details', 'play_media', 'list_cat'):
                q = str(f.get('title') or '').strip()
                # Limpiar prefijos de color Kodi
                if q.startswith('['):
                    q = re.sub(r'\[/?[A-Za-z ]+\]', '', q).strip()

            if q and q.lower() not in seen:
                queries.append(q)
                seen.add(q.lower())

        if not queries:
            xbmcgui.Dialog().ok("Novedades", "No hay búsquedas válidas en tus favoritos para analizar.")
            xbmcplugin.endOfDirectory(h)
            return

        # Búsqueda con diálogo de progreso cancelable
        pdp = xbmcgui.DialogProgress()
        pdp.create("Novedades de mis Favoritos", f"Buscando: {sel_label}...")

        all_results = []
        seen_ids = set()
        total = len(queries)
        cancelled = False

        for i, q in enumerate(queries):
            if pdp.iscanceled():
                cancelled = True
                break
            pdp.update(int((i / total) * 100), f"Analizando: [B]{q}[/B]")

            try:
                rs = connector._sr(q, {"created_after": time_limit})
                if rs:
                    sr = connector._gsr(q, rs)
                    for score, v in sr:
                        if score > 0.35:  # Filtro de calidad
                            vid = v.get("id")
                            if vid and vid not in seen_ids:
                                seen_ids.add(vid)
                                all_results.append((score, v, q))
            except Exception:
                pass  # Silenciar errores individuales, seguir con el resto

        pdp.close()

        if not all_results:
            if cancelled:
                xbmcgui.Dialog().notification("AtresDaily", "Búsqueda cancelada", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().ok("Novedades de mis Favoritos",
                    f"No se han encontrado novedades en '{sel_label}' para tus favoritos.")
            xbmcplugin.endOfDirectory(h)
            return

        # Resultados juntos, por parecido
        all_results.sort(key=lambda x: x[0], reverse=True)
        xbmcplugin.setContent(h, 'videos')

        for score, v, origin in all_results:
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.username", "Unknown")
            du = v.get("duration", 0)
            try:
                du = int(du)
            except (ValueError, TypeError):
                du = 0
            dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ICON_MAIN

            label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {
                'title': vt,
                'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du // 60}m {du % 60}s",
                'duration': du
            })
            li.setProperty("IsPlayable", "true")

            # Menú contextual
            cm = []
            cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vi or '')})"))
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
            if vi:
                cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vi)}&title={urllib.parse.quote(vt)})"))
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vi or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al buscar novedades:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def show_trending():
    h = int(sys.argv[1])
    try:
        # Llamada directa a la API pública de Dailymotion
        time_limit = int(time.time()) - 604800  # 7 días
        api_url = "https://api.dailymotion.com/videos"
        params = {
            "sort": "trending",
            "language": "es",
            "created_after": time_limit,
            "limit": ui_utils.dm_limite_lista(50),
            "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
        }
        resp = ui_utils.dm_api_videos(api_url, params, timeout=15)
        data = resp.json()
        rs = ui_utils.filtrar_dm_borrados(data.get("list", []), cuantos=50)

        if not rs:
            xbmcgui.Dialog().ok("Top Semanal", "No se han encontrado vídeos en tendencia.")
            xbmcplugin.endOfDirectory(h)
            return

        xbmcplugin.setContent(h, 'videos')

        watched_ids = core_settings.get_watched_ids()

        for i, v in enumerate(rs):
            vt = v.get("title", "Video")
            vi = v.get("id")
            ow = v.get("owner.screenname") or v.get("owner.username", "")
            du = v.get("duration", 0)
            try:
                du = int(du)
            except (ValueError, TypeError):
                du = 0
            vw = v.get("views_total", 0)
            try:
                vw = int(vw)
            except (ValueError, TypeError):
                vw = 0
            dth = v.get("thumbnail_720_url") or v.get("thumbnail_url") or ICON_MAIN

            # Indicador de visto
            is_watched = vi in watched_ids if vi else False
            watched_mark = "[COLOR lime][V][/COLOR] " if is_watched else ""
            label = f"[COLOR orange]{i+1}.[/COLOR] {watched_mark}{vt}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'thumb': dth, 'icon': dth})
            li.setInfo('video', {
                'title': vt,
                'plot': f"Canal: {ow}\nVistas: {vw:,}\nDuración: {du // 60}m {du % 60}s",
                'duration': du
            })
            li.setProperty("IsPlayable", "true")

            # Menú contextual
            cm = []
            cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vi or '')})"))
            cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
            if vi:
                cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vi)}&title={urllib.parse.quote(vt)})"))
                cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=search&url={urllib.parse.quote(vt)}&title={urllib.parse.quote(vt)}&f_thumb={urllib.parse.quote(dth)})"))
            li.addContextMenuItems(cm)

            play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vi or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar tendencias:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass

def view_watch_history():
    import datetime
    h = int(sys.argv[1])
    try:
        history = core_settings.get_watch_history()

        # Botón limpiar historial (solo si hay historial)
        if history:
            li_clear = xbmcgui.ListItem(label="[COLOR red]Borrar todo el historial[/COLOR]")
            li_clear.setArt({'icon': ui_utils.media_icon('backup_delete.png')})
            li_clear.setInfo('video', {'plot': f"Tienes {len(history)} vídeos en el historial.\nPulsa para borrar todo."})
            li_clear.addContextMenuItems([])
            xbmcplugin.addDirectoryItem(handle=h, url=f"{sys.argv[0]}?action=clear_watch_history", listitem=li_clear, isFolder=True)

        if not history:
            ui_utils.add_item(action="", title="No has reproducido ningún vídeo aún", thumbnail=ui_utils.media_icon("info.png"), folder=False)
        else:
            xbmcplugin.setContent(h, 'videos')
            for entry in history:
                vid = entry.get('vid', '')
                vt = entry.get('title', 'Video')
                dth = entry.get('thumb', '') or ICON_MAIN
                du = entry.get('duration', 0)
                try:
                    du = int(du)
                except (ValueError, TypeError):
                    du = 0
                watched_at = entry.get('watched_at', 0)

                try:
                    dt = datetime.datetime.fromtimestamp(watched_at)
                    date_str = dt.strftime("%d/%m/%Y %H:%M")
                except Exception:
                    date_str = ""

                label = f"[COLOR lime][V][/COLOR] {vt}"
                li = xbmcgui.ListItem(label=label)
                li.setArt({'thumb': dth, 'icon': dth})
                li.setInfo('video', {
                    'title': vt,
                    'plot': f"Visto: {date_str}\nDuración: {du // 60}m {du % 60}s",
                    'duration': du
                })
                li.setProperty("IsPlayable", "true")

                # Menú contextual
                cm = []
                cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vid or '')})"))
                cm.append(("Buscar en webs de torrent", f"RunPlugin({sys.argv[0]}?action=elementum_search_prompt&q={urllib.parse.quote(vt)})"))
                if vid:
                    cm.append(("Descargar Video", f"RunPlugin({sys.argv[0]}?action=download_video&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(vt)})"))
                    cm.append(("Eliminar del historial", f"RunPlugin({sys.argv[0]}?action=del_watch_entry&url={urllib.parse.quote(vid)})"))
                li.addContextMenuItems(cm)

                play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vid or '')}&title={urllib.parse.quote(vt)}&thumb={urllib.parse.quote(dth)}&duration={du}"
                xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(h)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al cargar historial:\n{str(e)}")
        try:
            xbmcplugin.endOfDirectory(h)
        except Exception:
            pass


def backup_favs_dialog():
    opts = [
        "Exportar a JSON (para restaurar)",
        "Exportar a Texto (.txt)",
        "Importar Favoritos (JSON)",
    ]
    sel = xbmcgui.Dialog().select("Copia de Seguridad de Favoritos", opts)
    if sel == 0:
        export_favs()
    elif sel == 1:
        export_favs_txt()
    elif sel == 2:
        import_favs()

def export_favs_menu():
    """Submenú con opciones de exportación e importación de favoritos."""
    ui_utils.add_item(action="export_favs_txt", title="[COLOR gold]Exportar a Texto (.txt)[/COLOR]", thumbnail=ui_utils.media_icon("backup_export.png"), folder=False, plot="Genera un archivo de texto plano legible con todos tus favoritos.")
    ui_utils.add_item(action="export_favs", title="[COLOR gold]Exportar a JSON (para restaurar)[/COLOR]", thumbnail=ui_utils.media_icon("backup_export.png"), folder=False, plot="Exporta tus favoritos como archivo JSON que puedes restaurar después.")
    ui_utils.add_item(action="import_favs", title="[COLOR lightblue]Importar Favoritos (JSON)[/COLOR]", thumbnail=ui_utils.media_icon("backup_restore.png"), folder=False, plot="Restaura favoritos desde un archivo JSON exportado previamente.")
    ui_utils.close_item_list()

def _vfs_join(folder, name):
    """Une carpeta y fichero también para las rutas de red (smb://, nfs://) que devuelve
    Dialog().browse(), que os.path.join estropea en Windows."""
    sep = '' if folder.endswith(('/', '\\')) else '/'
    return f"{folder}{sep}{name}"

def export_favs():
    if not core_settings.get_favorites():
        xbmcgui.Dialog().notification("AtresDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return
    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    # Con xbmcvfs y no shutil, porque browse() puede devolver una carpeta de red.
    if xbmcvfs.copy(ui_utils.get_path('favorites.json'), _vfs_join(d, 'favorites_backup.json')):
        xbmcgui.Dialog().notification("AtresDaily", "Favoritos exportados con éxito")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar los favoritos a esa carpeta.")

def export_favs_txt():
    """Exporta la lista de favoritos a un archivo de texto plano."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("AtresDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    lines = [f"Favoritos AtresDaily - {time.strftime('%d/%m/%Y %H:%M')}",
             f"Total: {len(favs)} favoritos", "=" * 50, ""]
    for fav in favs:
        lines.append(f"{fav.get('title', 'Sin título')}")
        if fav.get('url'):
            lines.append(f"  URL: {fav['url']}")
        if fav.get('action'):
            lines.append(f"  Tipo: {fav['action']}")
        lines.append("")

    with xbmcvfs.File(_vfs_join(d, 'favoritos_atresdaily.txt'), 'w') as fh:
        ok = fh.write("\n".join(lines).encode('utf-8'))
    if ok:
        xbmcgui.Dialog().notification("AtresDaily", f"Exportados {len(favs)} favoritos a TXT")
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo escribir el archivo en esa carpeta.")

def multi_search():
    """Búsqueda múltiple. Pide los términos y navega a la vista de resultados."""
    if connector is None:
        xbmcgui.Dialog().ok("AtresDaily", "El conector no está disponible.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    raw = ui_utils.get_text('Términos separados por comas').strip()
    if not raw:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    # Con folder=False el prompt no queda en el historial, "volver atrás" va al menú.
    xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=multi_run&q={urllib.parse.quote(raw)}")')


def multi_run(raw):
    """Ejecuta y muestra la búsqueda múltiple (idempotente, los términos vienen en la URL)."""
    if connector is None:
        xbmcgui.Dialog().ok("AtresDaily", "El conector no está disponible.")
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    terms = [t.strip() for t in raw.split(',') if t.strip()]
    if not terms:
        xbmcgui.Dialog().notification("AtresDaily", "No se encontraron términos válidos", xbmcgui.NOTIFICATION_WARNING)
        ui_utils.close_item_list()
        return

    if len(terms) > 10:
        terms = terms[:10]
        xbmcgui.Dialog().notification("AtresDaily", "Limitado a 10 términos", xbmcgui.NOTIFICATION_INFO)

    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Búsqueda Múltiple", f"Buscando {len(terms)} términos...")

    all_results = []
    seen_ids = set()

    for idx, term in enumerate(terms):
        if dp.iscanceled(): break
        dp.update(int((idx / len(terms)) * 100), f"Buscando: {term}")

        try:
            params = {
                "search": term,
                "sort": "relevance",
                "language": "es",
                "limit": ui_utils.dm_limite_lista(10),
                "fields": "id,title,thumbnail_720_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
            }
            resp = ui_utils.dm_api_videos(_E3, params, timeout=15)
            data = resp.json()
            for item in ui_utils.filtrar_dm_borrados(data.get("list", []), cuantos=10):
                vid = item.get("id", "")
                if vid and vid not in seen_ids:
                    seen_ids.add(vid)
                    all_results.append((term, item))
        except Exception:
            pass

    dp.close()

    if not all_results:
        xbmcgui.Dialog().ok("Búsqueda Múltiple", "No se encontraron resultados para ningún término.")
        xbmcplugin.endOfDirectory(h)
        return

    # Agrupar por término de búsqueda
    for term, item in all_results:
        vid = item.get("id", "")
        title = item.get("title", "Sin título")
        thumb = item.get("thumbnail_720_url") or item.get("thumbnail_url", "")
        try:
            dur = int(item.get("duration", 0))
        except (ValueError, TypeError):
            dur = 0
        owner = item.get("owner.screenname") or item.get("owner.username", "")
        try:
            views = int(item.get("views_total", 0))
        except (ValueError, TypeError):
            views = 0

        dur_min = dur // 60 if dur else 0
        label = f"{title} [COLOR gray]({term})[/COLOR]"
        if dur_min:
            label += f" [COLOR cyan]{dur_min}min[/COLOR]"

        plot = f"Canal: {owner}\nBúsqueda: {term}\nDuración: {dur_min}min\nVisitas: {views:,}"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb or 'DefaultVideo.png', 'thumb': thumb})
        li.setInfo('video', {'plot': plot, 'duration': dur})
        # play_dm reproduce con setResolvedUrl, y sin IsPlayable Kodi lo lanza con handle -1.
        li.setProperty('IsPlayable', 'true')

        cm = []
        cm.append(("[COLOR lime]Abrir en navegador[/COLOR]", f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(vid)})"))
        cm.append(("Añadir a Favoritos", f"RunPlugin({sys.argv[0]}?action=add_fav&f_action=play_dm&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(title)}&f_thumb={urllib.parse.quote(thumb)})"))
        li.addContextMenuItems(cm)

        play_url = f"{sys.argv[0]}?action=play_dm&url={urllib.parse.quote(vid)}&title={urllib.parse.quote(title)}&thumb={urllib.parse.quote(thumb)}&duration={dur}"
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
    xbmcgui.Dialog().notification("Búsqueda Múltiple", f"{len(all_results)} resultados de {len(terms)} términos")

def import_favs():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo favorites.json', 'files', '.json')
    if not f: return

    with xbmcvfs.File(f) as fh:
        raw = bytes(fh.readBytes())
    try:
        data = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeDecodeError) as e:
        xbmcgui.Dialog().ok("Error", f"Archivo no válido o corrupto: {e}")
        return

    # Sin 'url' un favorito no se puede abrir, y además rompe add/remove_favorite.
    favs = [x for x in data if isinstance(x, dict) and isinstance(x.get('url'), str) and x['url']] \
        if isinstance(data, list) else []
    if not favs:
        xbmcgui.Dialog().ok("Error", "El archivo no contiene favoritos válidos.")
        return
    descartados = len(data) - len(favs)
    aviso = f"\n({descartados} entradas sin URL se descartarán)" if descartados else ""
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Importar {len(favs)} favoritos?{aviso}\n\nSe borrarán los favoritos actuales."):
        ui_utils.save_json('favorites.json', favs)
        xbmcgui.Dialog().notification("AtresDaily", "Favoritos importados")
        xbmc.executebuiltin("Container.Refresh")

def add_fav(title, action, url, thumbnail, extra):
    params = {"extra": extra}
    if core_settings.add_favorite(title, url, thumbnail, "atresdaily", action, params):
        xbmcgui.Dialog().notification("AtresDaily", "Añadido a favoritos")
    else:
        xbmcgui.Dialog().notification("AtresDaily", "Ya está en favoritos")

def del_fav(url):
    if core_settings.remove_favorite(url):
        xbmcgui.Dialog().notification("AtresDaily", "Eliminado de favoritos")
        xbmc.executebuiltin("Container.Refresh")

# --- Descargas ---
def view_downloads():
    dls = ui_utils.load_json('downloads.json')
    if not isinstance(dls, list): dls = []

    if not dls:
        ui_utils.add_item(action="", title="No hay historial de descargas", thumbnail=ui_utils.media_icon("info.png"), folder=False, plot="Cuando descargues o grabes algo, aparecerá aquí.\n\n[B]Descargo de responsabilidad:[/B]\nLa función de descarga es una herramienta técnica del reproductor. El usuario es el único responsable del uso que haga de ella y de asegurarse de que cumple con las leyes de su jurisdicción y los derechos de propiedad intelectual aplicables.\n\nEste addon no promueve la descarga de contenido protegido sin autorización.")
    else:
        import grabaciones
        grabando = {info.get('ruta'): k for k, info in grabaciones.en_marcha().items() if info.get('ruta')}
        for d in dls:
            path = d.get('path', '')
            title = d.get('title', 'Desconocido')
            date = d.get('date', '')

            # Una grabación en marcha: pulsarla pregunta si pararla (reproduciría un archivo a
            # medias) y no se ofrece borrar el archivo mientras se escribe.
            k = grabando.get(path)
            if k:
                stop = f"RunPlugin({sys.argv[0]}?action=iptv_record_stop&k={k}&refresh=1)"
                ui_utils.add_item(action="iptv_record_stop", title=f"{grabaciones.MARCA}{title} ({date})", thumbnail=ui_utils.media_icon("archivo_video.png"), folder=False, context=[("Parar la grabación", stop)], plot=f"{path}\n\nSe está grabando. Púlsala para pararla.", k=k, ask='1', refresh='1')
                continue

            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {title}"
                is_valid = False
            else:
                label = f"{title} ({date})"
                is_valid = True
            
            # Menú contextual
            cm = [("Quitar del historial", f"RunPlugin({sys.argv[0]}?action=del_dl_history&url={urllib.parse.quote(path)})")]
            if is_valid:
                cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({sys.argv[0]}?action=del_file&url={urllib.parse.quote(path)})"))
                action = "play_local"
            else:
                action = ""  # sin archivo no se puede reproducir
            
            ui_utils.add_item(action=action, title=label, url=path, thumbnail=ui_utils.media_icon("archivo_video.png"), isPlayable=is_valid, folder=False, context=cm, plot=path)

    ui_utils.close_item_list()




def del_dl_history(path):
    dls = ui_utils.load_json('downloads.json')
    new_dls = [d for d in dls if d.get('path') != path]
    ui_utils.save_json('downloads.json', new_dls)
    xbmc.executebuiltin("Container.Refresh")

def del_file(path):
    if xbmcgui.Dialog().yesno("AtresDaily", f"¿Borrar definitivamente?\n{os.path.basename(path)}"):
        try: 
            if os.path.exists(path): os.remove(path)
            del_dl_history(path) # Quitar también del historial
            xbmcgui.Dialog().notification("AtresDaily", "Archivo borrado", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().notification("AtresDaily", f"Error al borrar: {e}", xbmcgui.NOTIFICATION_ERROR)

def play_local(path):
    li = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

def _search_elementum(query):
    if not query: return
    if xbmcaddon.Addon().getSetting('ext_search_enabled') == 'false':
        xbmcgui.Dialog().notification("AtresDaily", "Buscar en otros addons está desactivado", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if not ui_utils.addon_listo("plugin.video.elementum", "Elementum",
            "El addon Elementum no está instalado.\n\n"
            "Esta función requiere Elementum para buscar torrents en webs como 1337x, RARBG, etc.\n\n"
            "Puedes instalarlo desde el repositorio oficial de Kodi o desde GitHub."):
        return
    
    # Abrir búsqueda en Elementum
    elementum_url = f"plugin://plugin.video.elementum/search?q={urllib.parse.quote(query)}"
    
    # Container.Update mantiene historial de navegación (vs ActivateWindow)
    xbmc.executebuiltin(f'Container.Update("{elementum_url}")')

def _search_external_prompt():
    if xbmcaddon.Addon().getSetting('ext_search_enabled') == 'false':
        xbmcgui.Dialog().notification("AtresDaily", "Buscar en otros addons está desactivado", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return
    q = ui_utils.get_text('Búsqueda externa').strip()
    if q:
        _search_elementum_prompt(q)
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)

def _execute_search_shortcut(shortcut, query):
    handler = shortcut.get('handler')
    if handler == 'elementum':
        texto = ui_utils.get_text('Buscar en webs de torrent', query or '')
        if texto:
            _search_elementum(texto)
    elif handler == 'dm_gujal':
        _search_dailymotion_gujal(query)
    elif handler == 'palantir':
        _search_palantir_from_results(query)
    elif handler == 'youtube':
        _search_youtube_from_results(query)
    elif handler == 'odysee':
        _search_odysee_from_results(query)
    elif handler == 'balandro':
        _search_balandro_from_results(query)
    elif handler == 'jacktook':
        _search_jacktook_from_results(query)
    elif handler == 'alfa':
        _search_alfa_from_results(query)
    else:
        addon_id = shortcut.get('addon_id')
        if addon_id and not ui_utils.addon_listo(addon_id, shortcut.get('name') or addon_id):
            return
        cmd = shortcut.get('command', '').replace('{query}', urllib.parse.quote_plus(query))
        if cmd:
            xbmc.executebuiltin(cmd)


def _search_elementum_prompt(query):
    if xbmcaddon.Addon().getSetting('ext_search_enabled') == 'false':
        xbmcgui.Dialog().notification("AtresDaily", "Buscar en otros addons está desactivado", xbmcgui.NOTIFICATION_INFO, 3000)
        return
    shortcuts = search_shortcuts_manager.load_active_shortcuts()
    if not shortcuts:
        return

    if len(shortcuts) == 1 and shortcuts[0].get('handler') == 'elementum':
        texto = ui_utils.get_text('Buscar en webs de torrent', query or '')
        if texto:
            _search_elementum(texto)
        return

    if xbmcaddon.Addon().getSetting('ext_search_dialog') == 'false':
        _execute_search_shortcut(shortcuts[0], query)
        return

    opciones = (["[COLOR gold]Editar búsqueda / Reintentar...[/COLOR]",
                 "[COLOR cyan]Buscar en Megabuscador (varias plataformas)[/COLOR]"]
                + [s['name'] for s in shortcuts])
    sel = xbmcgui.Dialog().select(f"¿Dónde quieres buscar '{query}'?", opciones)
    if sel == 0:
        texto = ui_utils.get_text('Editar búsqueda', query or '')
        if texto:
            _search_elementum_prompt(texto)
    elif sel == 1:
        # Megabuscador, abre el teclado pre-rellenado y, si se confirma, lanza la búsqueda.
        texto = ui_utils.get_text('Megabuscador', query or '').strip()
        if texto:
            xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=bt_run&q={urllib.parse.quote(texto)}")')
    elif sel > 1:
        _execute_search_shortcut(shortcuts[sel - 2], query)

def _ep_fix_disk_state():
    """Lee Includes.xml de la skin y devuelve True si el parche está físicamente aplicado."""
    try:
        includes_xml = os.path.join(
            xbmcvfs.translatePath('special://skin/'), 'xml', 'Includes.xml')
        if not os.path.exists(includes_xml):
            return False
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()
        return 'ATRESDAILY_PATCH_VIDEOS' in content or 'ESPADAILY_PATCH_VIDEOS' in content
    except Exception:
        return False

def _ep_sync_state():
    """Verifica el disco y devuelve el estado real, resincronizando el setting si hay desfase."""
    _addon = xbmcaddon.Addon()
    real_applied = _ep_fix_disk_state()
    cached = _addon.getSetting('ep_fix_state')
    if real_applied and cached != 'applied':
        _addon.setSetting('ep_fix_state', 'applied')
    elif not real_applied and cached == 'applied':
        # La skin se actualizó y borró el parche -> resetear para volver a preguntar
        _addon.setSetting('ep_fix_state', '')
    return real_applied

def _check_estuary_palantir_fix():
    """
    Comprueba si hace falta el arreglo para Estuary Palantir y lo ofrece al usuario.
    Usa un setting interno para no leer el disco en cada búsqueda.
    Estados: '' = nunca preguntado, 'applied' = aplicado, 'skipped' = usuario rechazó.
    """
    if xbmc.getSkinDir() != 'skin.estuary.palantir':
        return

    _addon = xbmcaddon.Addon()
    state = _addon.getSetting('ep_fix_state')

    if state == 'applied' or state == 'skipped':
        return

    # Primera vez o estado desconocido, verificar en disco
    if _ep_fix_disk_state():
        _addon.setSetting('ep_fix_state', 'applied')
        return

    # No está aplicado, preguntar al usuario
    apply = xbmcgui.Dialog().yesno(
        "AtresDaily - Compatibilidad Palantir",
        "Usas la skin [B]Estuary Palantir[/B] y sin el parche de compatibilidad "
        "los resultados de Palantir aparecen en pantalla negra.\n\n"
        "[B]Que hace el parche:[/B] Modifica un archivo XML de la skin (con backup automatico) "
        "para que reconozca el contenido enviado desde AtresDaily.\n\n"
        "[B]Como cambiarlo despues:[/B] Configuracion del addon -> 'Fix Estuary Palantir'. "
        "Desde ahi puedes aplicarlo o desinstalarlo cuando quieras.\n\n"
        "[COLOR grey]Si pulsas 'Ahora no' no preguntaremos otra vez en busquedas, "
        "pero podras activarlo desde Configuracion.[/COLOR]",
        nolabel="Ahora no",
        yeslabel="Aplicar parche"
    )
    if apply:
        _toggle_estuary_palantir_fix()
    else:
        _addon.setSetting('ep_fix_state', 'skipped')

def _search_palantir_from_results(query):
    """Búsqueda en Palantir (dinámico) desde resultados, con detección de parche Estuary."""
    palantir_id = core_settings.get_palantir_addon_id()
    if not palantir_id:
        xbmcgui.Dialog().ok("AtresDaily",
            "Palantir no está instalado.\n\n"
            "Instala Palantir para usar esta función.")
        return
    if not ui_utils.addon_listo(palantir_id, "Palantir"):
        return
    if not _check_integration_first_use('palantir'):
        return

    _check_estuary_palantir_fix()

    # Teclado/web con consulta pre-rellenada
    texto = ui_utils.get_text('Buscar en Palantir (Detectado)', query or '')
    if texto:
        _search_palantir(texto)

def _search_youtube_from_results(query):
    """Búsqueda en YouTube por scraping HTML (sin API key). Reproduce vía plugin.video.youtube/play."""
    if not ui_utils.addon_listo("plugin.video.youtube", "YouTube",
            "El plugin de YouTube no está instalado.\n\n"
            "Es necesario para reproducir los videos encontrados."):
        return
    texto = ui_utils.get_text('Buscar en YouTube', query or '').strip()
    if texto:
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'yt_html_search', 'q': texto})
        xbmc.executebuiltin(f"Container.Update({url})")

def _search_odysee_from_results(query):
    """Búsqueda en Odysee (LBRY). Stream directo, sin addon externo."""
    texto = ui_utils.get_text('Buscar en Odysee', query or '').strip()
    if texto:
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'odysee_search', 'q': texto})
        xbmc.executebuiltin(f"Container.Update({url})")

def _search_peertube_from_results(query):
    """Búsqueda en PeerTube (red federada). Stream directo, sin addon externo."""
    texto = ui_utils.get_text('Buscar en PeerTube', query or '').strip()
    if texto:
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'peertube_search', 'q': texto})
        xbmc.executebuiltin(f"Container.Update({url})")

def _search_bitchute_from_results(query):
    """Búsqueda en BitChute (red P2P). Stream directo, sin addon externo."""
    texto = ui_utils.get_text('Buscar en BitChute', query or '').strip()
    if texto:
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'bitchute_search', 'q': texto})
        xbmc.executebuiltin(f"Container.Update({url})")

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en AtresDaily que permite
# abrir la función de búsqueda del addon B-._ alandro desde este menú rápido.
# AtresDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon B-:alandro,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_balandro_from_results(query):
    balandro_id = 'plugin.video.balandro'
    if not ui_utils.addon_listo(balandro_id, "Balandro",
            "El plugin de Balandro no está instalado.\n\n"
            "Instala Balandro para usar esta función."):
        return
    if not _check_integration_first_use('balandro'):
        return

    # Teclado/web con consulta pre-rellenada
    texto = ui_utils.get_text('Buscar en Balandro', query or '').strip()
    if texto:
        # Reutilizamos el sistema de codificación de BuscaBalandro (JSON + Base64)
        item_data = {
            'channel': 'search',
            'action': 'search',
            'search_type': 'all',
            'buscando': texto,
        }
        payload = base64.b64encode(json.dumps(item_data).encode('utf-8')).decode('utf-8')
        balandro_url = f"plugin://{balandro_id}/?{urllib.parse.quote_plus(payload)}"
        xbmc.executebuiltin(f"Container.Update({balandro_url})")

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en AtresDaily que permite
# abrir la función de búsqueda del addon Jackt-.-.. ook desde este menú rápido.
# AtresDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon Jacktoo-.-..-k,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_jacktook_from_results(query):
    jacktook_id = 'plugin.video.jacktook'
    if not ui_utils.addon_listo(jacktook_id, "Jacktook",
            "El plugin Jacktook no está instalado.\n\n"
            "Instala Jacktook para usar esta función."):
        return
    if not _check_integration_first_use('jacktook'):
        return
    texto = ui_utils.get_text('Buscar en Jacktook', query or '').strip()
    if texto:
        # Misma ruta interna que usa Jacktook en su propia UI de búsqueda multimodal
        params = {'action': 'handle_tmdb_search', 'mode': 'multi', 'page': '1', 'query': texto}
        url = f"plugin://{jacktook_id}/?{urllib.parse.urlencode(params)}"
        xbmc.executebuiltin(f"Container.Update({url})")

# AVISO LEGAL:
# Este buscador es un lanzador independiente integrado en AtresDaily que permite
# abrir la función de búsqueda del addon Alfa desde este menú rápido.
# AtresDaily NO aloja, distribuye, enlaza ni reproduce contenido de ningún tipo.
# Toda la funcionalidad de búsqueda es proporcionada íntegramente por el addon A-.-.lfa,
# sobre el cual este proyecto no tiene control ni responsabilidad alguna.
def _search_alfa_from_results(query):
    alfa_id = core_settings.get_alfa_addon_id()
    if not alfa_id:
        xbmcgui.Dialog().ok("AtresDaily",
            "El plugin Alfa no está instalado.\n\n"
            "Instala Alfa para usar esta función.")
        return
    if not ui_utils.addon_listo(alfa_id, "Alfa"):
        return
    if not _check_integration_first_use('alfa'):
        return
    texto = ui_utils.get_text('Buscar en Alfa', query or '').strip()
    if texto:
        item_data = {'module': 'search', 'action': 'new_search', 'search_text': texto, 'mode': 'all'}
        payload = urllib.parse.quote(
            base64.b64encode(json.dumps(item_data, separators=(',', ':')).encode('utf-8')).decode('utf-8')
        )
        xbmc.executebuiltin(f"Container.Update(plugin://{alfa_id}/?{payload})")

def _search_dailymotion_gujal(query):
    """Búsqueda en el addon de Dailymotion de Gujal (plugin.video.dailymotion_com)."""
    if not query: return

    if not ui_utils.addon_listo("plugin.video.dailymotion_com", "Dailymotion (Gujal)",
            "El addon de Dailymotion (Gujal) no está instalado.\n\n"
            "Puedes instalarlo desde el repositorio de Gujal en GitHub:\n"
            "https://github.com/Gujal00/Kodi-Official"):
        return

    texto = ui_utils.get_text('Buscar en addon Dailymotion', query or '')
    if texto:
        dm_url = (
            f"plugin://plugin.video.dailymotion_com/"
            f"?action=search&query={urllib.parse.quote(texto)}"
        )
        xbmc.executebuiltin(f"Container.Update({dm_url})")

def _search_palantir_prompt(query):
    if not _check_integration_first_use('palantir'):
        return
    nq = ui_utils.get_text('Buscar en Palantir (Detectado)', query or '')
    if nq:
        _search_palantir(nq)

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3 (Créditos: EspaDaily)"""
    import base64
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = length // 4
    value = re.sub(b'=', b'', value)
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _search_palantir(query):
    if not query: return
    
    palantir_id = core_settings.get_palantir_addon_id()
    if not palantir_id:
        xbmcgui.Dialog().ok("AtresDaily", "El addon Palantir no parece estar instalado.\n\nEsta función requiere Palantir para funcionar.")
        return
    if not ui_utils.addon_listo(palantir_id, "Palantir"):
        return

    # formato que Palantir 3 espera vía window property p3_item_buscar
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    encoded_item = _p3_b64encode(str(item_dict))
    
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar la búsqueda usando el ID detectado dinámicamente
    plugin_url = f"plugin://{palantir_id}/?{encoded_item}"
    
    xbmc.log(f"[AtresDaily] Enviando búsqueda a Palantir ({palantir_id}): {query}", xbmc.LOGINFO)
    xbmc.log(f"[AtresDaily] URL generada: {plugin_url}", xbmc.LOGINFO)
    
    # Container.Update, para que al volver atrás se regrese a AtresDaily
    xbmc.executebuiltin(f"Container.Update({plugin_url})")

# Arreglo para el skin Estuary Palantir, que no está en los menús. Parchea el skin para
# evitar la pantalla negra en los resultados de Palantir y se desinstala sin dejar rastro.
def _toggle_estuary_palantir_fix():
    """
    Instala o desinstala el parche de compatibilidad para skin.estuary.palantir.
    Usa un sistema de backup: al instalar guarda una copia del archivo original,
    al desinstalar restaura la copia, así que no deja restos.
    """
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        xbmcgui.Dialog().ok("AtresDaily",
            "Este fix solo es necesario si usas la skin 'Estuary Palantir'.\n\n"
            f"Tu skin actual es: {skin_id}")
        return

    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')
    backup_xml = includes_xml + '.atresdaily_backup'

    if not os.path.exists(includes_xml):
        xbmcgui.Dialog().ok("AtresDaily", "No se encontró el archivo Includes.xml de la skin.")
        return

    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()

        patch_marker = '<!-- ATRESDAILY_PATCH_VIDEOS -->'
        espadaily_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'

        is_patched = patch_marker in content or espadaily_marker in content

        if is_patched:
            if xbmcgui.Dialog().yesno("AtresDaily - Desinstalar Fix",
                "El fix de compatibilidad está instalado.\n\n¿Quieres desinstalarlo?"):

                restored = False

                if os.path.exists(backup_xml):
                    try:
                        with open(backup_xml, 'r', encoding='utf-8') as f:
                            original_content = f.read()
                        with open(includes_xml, 'w', encoding='utf-8') as f:
                            f.write(original_content)
                        os.remove(backup_xml)
                        restored = True
                    except Exception as backup_err:
                        xbmc.log(f"[AtresDaily] No se pudo restaurar backup: {backup_err}", xbmc.LOGWARNING)

                if not restored:
                    content = content.replace('\n\t' + patch_marker, '')
                    content = content.replace(patch_marker, '')
                    content = content.replace('\n\t' + espadaily_marker, '')
                    content = content.replace(espadaily_marker, '')
                    content = re.sub(
                        r'\s*\[Container\.Content\(videos\)\s*\|\s*Container\.Content\(\)\]\s*\|',
                        '', content)
                    with open(includes_xml, 'w', encoding='utf-8') as f:
                        f.write(content)

                xbmcaddon.Addon().setSetting('ep_fix_state', '')
                xbmcgui.Dialog().notification('AtresDaily', 'Fix desinstalado. Recargando skin...',
                    xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin('ReloadSkin()')
        else:
            if xbmcgui.Dialog().yesno("AtresDaily - Instalar Fix",
                "¿Quieres instalar el fix de compatibilidad para Estuary Palantir?\n\n"
                "Esto corrige la pantalla negra al mostrar resultados de Palantir."):

                import shutil
                try:
                    shutil.copy2(includes_xml, backup_xml)
                except Exception as bk_err:
                    xbmc.log(f"[AtresDaily] No se pudo crear backup: {bk_err}", xbmc.LOGWARNING)

                modified = False
                vistas_palantir = [
                    'Vista50', 'Vista54', 'Vista55', 'Vista500',
                    'Vista504', 'Vista505', 'Vista506', 'Vista507'
                ]

                for vista in vistas_palantir:
                    pattern = (
                        r'(<expression name="' + vista +
                        r'">\s*\[\s*\$EXP\[IsPalantirVistas\]\s*\+)'
                    )
                    if re.search(pattern, content):
                        replacement = r'\1\n\t\t\t[Container.Content(videos) | Container.Content()] |'
                        new_content = re.sub(pattern, replacement, content)
                        if new_content != content:
                            content = new_content
                            modified = True

                if modified:
                    content = content.replace('<includes>', '<includes>\n\t' + patch_marker)
                    with open(includes_xml, 'w', encoding='utf-8') as f:
                        f.write(content)
                    xbmcaddon.Addon().setSetting('ep_fix_state', 'applied')
                    xbmcgui.Dialog().notification('AtresDaily', 'Fix instalado. Recargando skin...',
                        xbmcgui.NOTIFICATION_INFO, 3000)
                    xbmc.executebuiltin('ReloadSkin()')
                else:
                    xbmcgui.Dialog().ok("AtresDaily",
                        "No se encontraron las expresiones a parchear.\n"
                        "Puede que tu versión de Estuary Palantir sea diferente.")

    except Exception as e:
        xbmc.log(f"[AtresDaily] Error en toggle_estuary_palantir_fix: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("AtresDaily", f"Error: {str(e)}")



def _u(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)


def _toggle_remote_secure():
    cur = xbmcaddon.Addon().getSetting('remote_secure') == 'true'
    xbmcaddon.Addon().setSetting('remote_secure', "false" if cur else "true")
    if not cur:
        xbmcgui.Dialog().notification("Mando web", "Seguridad ACTIVADA", xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("Mando web", "Seguridad DESACTIVADA", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _url_player_config_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])

    # webremote_mode es labelenum: puede venir como etiqueta o como índice
    mode_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
    mode_internet = mode_raw in ('1', 'Internet')

    # Modo de conexión
    mode_label = "[COLOR cyan]Internet (relay ntfy)[/COLOR]" if mode_internet else "[COLOR green]Red local[/COLOR]"
    li = xbmcgui.ListItem(label=f"Modo de conexión: {mode_label}")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': (
        "Cómo escucha el receptor de URLs.\n\n"
        "[B]Red local:[/B] accesible solo en tu WiFi. Rápido y sin dependencias.\n\n"
        "[B]Internet (relay ntfy):[/B] usa el servidor ntfy para recibir URLs desde fuera de casa.\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_mode"), listitem=li, isFolder=False)

    # Puerto (con la acción config_remote_port)
    cur_port = addon.getSetting('remote_port') or '8089'
    li = xbmcgui.ListItem(label=f"Puerto servidor: [COLOR deepskyblue]{cur_port}[/COLOR]")
    li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
    li.setInfo('video', {'plot': (
        f"Puerto inicial del servidor HTTP local para enviar URLs desde el móvil o PC.\n"
        f"Si está ocupado, se prueban los 10 siguientes.\nPuerto actual: {cur_port}\n\n"
        "[COLOR blue][I]Pulsa para cambiar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="config_remote_port"), listitem=li, isFolder=False)

    # Seguridad (con la acción toggle_remote_secure)
    secure = addon.getSetting('remote_secure') == 'true'
    secure_label = "[COLOR lime]ACTIVADA[/COLOR]" if secure else "[COLOR gray]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label=f"Seguridad (código de acceso): {secure_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonProgram.png')})
    li.setInfo('video', {'plot': (
        "Protección del mando web.\n\n"
        "DESACTIVADA (por defecto): cualquier dispositivo de tu WiFi puede acceder. Ideal en casa.\n\n"
        "ACTIVADA: la URL incluye un código único; sin él nadie accede aunque esté en tu red. "
        "Recomendado en redes públicas.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_remote_secure"), listitem=li, isFolder=False)

    # Confirmar antes de reproducir
    confirm = addon.getSetting('webremote_confirm') == 'true'
    confirm_label = "[COLOR lime]SÍ[/COLOR]" if confirm else "[COLOR grey]NO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Confirmar antes de reproducir: {confirm_label}")
    li.setArt({'icon': _ico('adv_anti_errores.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': (
        "Si está activo, Kodi pregunta antes de reproducir cada URL recibida desde el móvil o PC. "
        "Evita reproducciones accidentales.\n\n"
        "[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="toggle_webremote_confirm"), listitem=li, isFolder=False)

    # Solo en modo Internet
    if mode_internet:
        ntfy_server = (addon.getSetting('webremote_server') or 'https://ntfy.sh').rstrip('/')
        ntfy_topic = addon.getSetting('webremote_topic') or '(se genera al primer uso)'

        li = xbmcgui.ListItem(label=f"Servidor relay: [COLOR deepskyblue]{ntfy_server}[/COLOR]")
        li.setArt({'icon': _ico('adv_puerto.png', 'DefaultNetwork.png')})
        li.setInfo('video', {'plot': (
            f"URL del servidor ntfy para el relay de Internet.\nActual: {ntfy_server}\n\n"
            f"Canal asignado: {ntfy_topic}\n\n"
            "Puedes usar el público ntfy.sh o alojar el tuyo.\n\n"
            "[COLOR blue][I]Pulsa para cambiar la URL.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="set_webremote_server"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR orange]Regenerar canal ntfy[/COLOR]")
        li.setArt({'icon': _ico('adv_refrescar.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': (
            f"Canal actual: {ntfy_topic}\n\n"
            "Borra el canal para que se genere uno nuevo aleatorio al próximo arranque del mando.\n"
            "Tendrás que actualizar la suscripción en tu móvil.\n\n"
            "[COLOR blue][I]Pulsa para regenerar.[/I][/COLOR]"
        )})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="reset_webremote_topic"), listitem=li, isFolder=False)

    # Resolver Debrid (estado leído de settings, sin llamadas de red)
    deb_enabled = addon.getSetting('debrid_enabled') == 'true'
    deb_provider, deb_auth, deb_user = _debrid_status()
    if deb_enabled and deb_auth:
        deb_label = "Resolver Debrid: [COLOR lime]{0}[/COLOR]".format(
            "{0} · {1}".format(deb_provider, deb_user) if deb_user else deb_provider)
    elif deb_enabled:
        deb_label = "Resolver Debrid: [COLOR orange]activado, sin vincular[/COLOR]"
    else:
        deb_label = "Resolver Debrid: [COLOR gray]desactivado[/COLOR]"
    li = xbmcgui.ListItem(label=deb_label)
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': (
        "Reproduce enlaces de hosters premium (1fichier, Mega, Rapidgator...) y "
        "convierte magnets en streams directos usando tu cuenta Debrid.\n\n"
        "Vincula la cuenta, elige proveedor y opciones.\n\n"
        "[COLOR blue][I]Pulsa para gestionar.[/I][/COLOR]"
    )})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_menu"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)

def _debrid_status():
    """Devuelve (provider, authorized, user) del proveedor activo, sin red."""
    provider = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    try:
        import debrid_resolver
        r = debrid_resolver.get_resolver()
        return provider, r.is_authorized(), r.stored_user()
    except Exception:
        return provider, False, ""

def _debrid_menu():
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    h = int(sys.argv[1])
    enabled = addon.getSetting('debrid_enabled') == 'true'
    provider, authorized, user = _debrid_status()

    # Estado (informativo, sin red)
    if authorized:
        estado = "[COLOR lime]{0} · {1}[/COLOR]".format(provider, user) if user else "[COLOR lime]{0}[/COLOR]".format(provider)
    else:
        estado = "[COLOR gray]Sin vincular[/COLOR]"
    li = xbmcgui.ListItem(label="Estado: {0}".format(estado))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Proveedor activo y cuenta vinculada."})
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    # Activar/desactivar resolución
    en_label = "[COLOR lime]ACTIVADA[/COLOR]" if enabled else "[COLOR grey]DESACTIVADA[/COLOR]"
    li = xbmcgui.ListItem(label="Resolución Debrid: {0}".format(en_label))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activa, magnets y enlaces de hosters premium se resuelven con tu cuenta antes del método normal.\n\n[COLOR blue][I]Pulsa para activar/desactivar.[/I][/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_enabled"), listitem=li, isFolder=False)

    # Proveedor
    li = xbmcgui.ListItem(label="Proveedor: [COLOR deepskyblue]{0}[/COLOR]".format(provider))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Servicio Debrid a usar: AllDebrid, Real-Debrid, TorBox o Premiumize."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_set_provider"), listitem=li, isFolder=False)

    if not authorized:
        supports_pin = True
        try:
            import debrid_resolver
            supports_pin = debrid_resolver.get_resolver().SUPPORTS_PIN
        except Exception:
            pass
        if supports_pin:
            li = xbmcgui.ListItem(label="[COLOR limegreen]Vincular cuenta (código PIN)[/COLOR]")
            li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
            li.setInfo('video', {'plot': "Muestra un código para introducir en la web del proveedor y vincula tu cuenta automáticamente."})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_pin"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR limegreen]Introducir API Key manualmente[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Pega la API key de tu cuenta (la encuentras en la web del proveedor)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_authorize_key"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Comprobar cuenta / tráfico")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Consulta el estado de tu cuenta (premium, caducidad)."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_account"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR lightsalmon]Desconectar cuenta[/COLOR]")
        li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
        li.setInfo('video', {'plot': "Elimina la cuenta vinculada de este addon."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_deauthorize"), listitem=li, isFolder=False)

    # Interruptores
    cached = addon.getSetting('debrid_cached_only') == 'true'
    li = xbmcgui.ListItem(label="Solo caché (no esperar descargas): {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cached else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activo, un magnet que no esté ya en la nube se omite (cae a Elementum) en lugar de esperar a que se descargue."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cached"), listitem=li, isFolder=False)

    cleanup = addon.getSetting('debrid_auto_cleanup') == 'true'
    li = xbmcgui.ListItem(label="Borrar torrent tras reproducir: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if cleanup else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Elimina el torrent de tu cuenta tras obtener el enlace, para no llenar la nube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_cleanup"), listitem=li, isFolder=False)

    quality = addon.getSetting('debrid_auto_quality') == 'true'
    li = xbmcgui.ListItem(label="Auto-seleccionar mayor calidad/archivo: {0}".format(
        "[COLOR lime]SÍ[/COLOR]" if quality else "[COLOR grey]NO[/COLOR]"))
    li.setArt({'icon': _ico('p2p.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Si está activo, elige automáticamente el archivo de vídeo más grande y la mayor calidad sin preguntar."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="debrid_toggle_quality"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)

def _debrid_reset_instance():
    try:
        import debrid_resolver
        debrid_resolver.reset_resolver()
    except Exception:
        pass

def _debrid_toggle_enabled():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('debrid_enabled') == 'true'
    if not cur:
        # Aviso de uso responsable la primera vez que se activa
        if addon.getSetting('debrid_disclaimer_seen') != 'true':
            if not xbmcgui.Dialog().yesno(
                "Resolver Debrid - Uso responsable",
                "El resolver usa TU cuenta Debrid para reproducir los enlaces y magnets que TÚ proporcionas.\n\n"
                "Eres responsable del contenido al que accedes y de respetar la ley de tu país y los términos de tu servicio Debrid.\n\n"
                "¿Activar el Resolver Debrid?"):
                return
            addon.setSetting('debrid_disclaimer_seen', 'true')
        addon.setSetting('debrid_enabled', 'true')
        xbmcgui.Dialog().notification("Debrid", "Resolución ACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        addon.setSetting('debrid_enabled', 'false')
        xbmcgui.Dialog().notification("Debrid", "Resolución DESACTIVADA", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_set_provider():
    opciones = ["AllDebrid", "Real-Debrid", "TorBox", "Premiumize"]
    cur = xbmcaddon.Addon().getSetting('debrid_provider') or 'AllDebrid'
    pre = opciones.index(cur) if cur in opciones else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid", opciones, preselect=pre)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('debrid_provider', opciones[sel])
    _debrid_reset_instance()
    xbmcaddon.Addon().setSetting('debrid_hosts_cache', '')  # invalida cache de hosts del anterior
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_pin():
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_pin()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error al vincular:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_authorize_key():
    key = xbmcgui.Dialog().input("API Key del proveedor")
    if not key:
        return
    try:
        import debrid_resolver
        ok = debrid_resolver.get_resolver().authorize_apikey(key)
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "Error:\n{0}".format(e))
        return
    if ok:
        xbmcgui.Dialog().notification("Debrid", "Cuenta vinculada", xbmcgui.NOTIFICATION_INFO, 2500)
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_deauthorize():
    if not xbmcgui.Dialog().yesno("Debrid", "¿Desconectar la cuenta de este addon?"):
        return
    try:
        import debrid_resolver
        debrid_resolver.get_resolver().deauthorize()
    except Exception:
        pass
    _debrid_reset_instance()
    xbmcgui.Dialog().notification("Debrid", "Cuenta desconectada", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _debrid_account():
    try:
        import debrid_resolver
        info = debrid_resolver.get_resolver().account_info()
    except Exception as e:
        xbmcgui.Dialog().ok("Debrid", "No se pudo consultar la cuenta:\n{0}".format(e))
        return
    estado = "Premium" if info.get("premium") else "No premium"
    expiry = info.get("expiry_text") or ""
    days = info.get("days")
    extra = info.get("extra") or ""
    lineas = ["Usuario: {0}".format(info.get("username", "?")), "Estado: {0}".format(estado)]
    if expiry:
        dtxt = " ({0} días)".format(days) if isinstance(days, int) else ""
        lineas.append("Válida hasta: {0}{1}".format(expiry, dtxt))
    if extra:
        lineas.append(extra)
    xbmcgui.Dialog().ok("Cuenta Debrid", "\n".join(lineas))

def _debrid_toggle_cached():
    cur = xbmcaddon.Addon().getSetting('debrid_cached_only') == 'true'
    xbmcaddon.Addon().setSetting('debrid_cached_only', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_cleanup():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_cleanup') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_cleanup', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _debrid_toggle_quality():
    cur = xbmcaddon.Addon().getSetting('debrid_auto_quality') == 'true'
    xbmcaddon.Addon().setSetting('debrid_auto_quality', "false" if cur else "true")
    _debrid_reset_instance()
    xbmc.executebuiltin("Container.Refresh")

def _set_webremote_mode():
    # labelenum: se guarda la etiqueta (igual que _set_search_input_method)
    labels = ["Red local", "Internet"]
    addon = xbmcaddon.Addon()
    cur_raw = (addon.getSetting('webremote_mode') or 'Red local').strip()
    cur = 1 if cur_raw in ('1', 'Internet') else 0
    sel = xbmcgui.Dialog().select("Modo de conexión del receptor de URLs",
                                  ["Red local (solo WiFi)", "Internet (relay ntfy)"], preselect=cur)
    if sel < 0:
        return
    addon.setSetting('webremote_mode', labels[sel])
    xbmcgui.Dialog().notification("Mando web", f"Modo: {labels[sel]}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_webremote_confirm():
    cur = xbmcaddon.Addon().getSetting('webremote_confirm') == 'true'
    xbmcaddon.Addon().setSetting('webremote_confirm', "false" if cur else "true")
    msg = "Confirmación ACTIVADA" if not cur else "Confirmación DESACTIVADA"
    xbmcgui.Dialog().notification("Mando web", msg, xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _set_webremote_server():
    addon = xbmcaddon.Addon()
    cur = (addon.getSetting('webremote_server') or 'https://ntfy.sh').strip()
    nuevo = xbmcgui.Dialog().input("Servidor relay ntfy (URL completa)", defaultt=cur)
    if not nuevo:
        return
    nuevo = nuevo.strip().rstrip('/')
    if not nuevo.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok("AtresDaily", "URL no válida. Debe empezar por http:// o https://")
        return
    addon.setSetting('webremote_server', nuevo)
    xbmcgui.Dialog().notification("Mando web", "Servidor actualizado", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def _reset_webremote_topic():
    addon = xbmcaddon.Addon()
    cur = addon.getSetting('webremote_topic') or '(no asignado)'
    if not xbmcgui.Dialog().yesno(
        "Regenerar canal ntfy",
        f"Canal actual: {cur}\n\nSe generará uno nuevo al próximo arranque del mando.\n"
        "Tendrás que actualizar la suscripción en tu móvil.\n\n¿Continuar?"
    ):
        return
    addon.setSetting('webremote_topic', '')
    xbmcgui.Dialog().notification("Mando web", "Canal regenerado al próximo uso", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


# tests/test_installers.py corta este archivo por la marca de la línea siguiente.
# --- DESPACHO ---
_bloqueo = motivo_de_bloqueo()
if _bloqueo:
    xbmcgui.Dialog().ok("AtresDaily", _bloqueo)
else:
    p = get_params()
    a = p.get("action")
    u = p.get("url")
    e = p.get("extra")
    d = p.get("direct")

    # Con el Modo Fantasía abierto, lo que esta llamada mande a la ventana actual va a él.
    # Kodi compila cada módulo en cada llamada (su Python no guarda bytecode), así que
    # fantasia solo se importa si su ventana ha dejado puesta la propiedad (_PROPIEDAD).
    # Un fallo del modo experimental no puede tumbar el resto del addon.
    if xbmcgui.Window(10000).getProperty("atresdaily.fantasia"):
        try:
            import fantasia
            fantasia.instalar_puente()
        except Exception as ex:
            xbmc.log(f"[AtresDaily] Modo Fantasía, puente: {ex}", xbmc.LOGERROR)

    # Acciones que necesitan el conector cuando no está cargado (términos sin aceptar, por ejemplo)
    if connector is None and a in [
        "list_cat", "list_details", "atresplayer_details", "download_video", "play_media",
        "search_movie", "live_tv", "play_live_channel", "search", "play_dm",
        "input_search", "advanced_search_menu", "catalog_search", "view_playlist",
        "list_user_playlists", "search_user_playlists", "execute_adv_search",
        "catalog_menu", "fav_news", "show_trending",
        "list_live_cats"
    ]:
         # Sin conector se va al inicio, donde salta check_legal_compliance(). Basta con
         # vaciar la acción, porque la cadena de abajo ya llama a menu_root() una vez.
         xbmcgui.Dialog().notification("AtresDaily", "Función restringida", xbmcgui.NOTIFICATION_WARNING)
         a = None

    # Telemetría anónima, solo con los términos aceptados, que explican qué se envía
    if _cfg_init.get('legal_accepted_v2', False):
        try:
            import stats
            stats.ping()
        except Exception as ex:
            xbmc.log(f"[AtresDaily] Telemetría: {ex}", xbmc.LOGDEBUG)

    if not a: menu_root()
    elif a == "experimental_home":
        import experimental_home
        experimental_home.show()
    elif a == "fantasia":
        ui_utils.visto('fantasia')
        import fantasia
        fantasia.mostrar()
    elif a == "fantasia_orden":
        import fantasia
        fantasia.reenviar(p.get("orden", ""))
    elif a == "list_cat":
        if p.get("title") in _CATS_NUEVAS:
            ui_utils.visto(_CATS_NUEVAS[p["title"]])
        connector.list_cat(u, int(e) if e else 0)
    elif a == "list_live_cats": connector.list_live_cats()
    elif a == "play_live_channel": connector.play_live_channel(u)
    # Los favoritos guardados desde la WebApp usan la acción atresplayer_details.
    elif a in ("list_details", "atresplayer_details"): connector.list_details(u, e)
    elif a == "catalog_menu": catalog_menu()
    elif a == "history_menu": history_menu()
    elif a == "view_favorites": view_favorites()
    elif a == "flowfav_launch": _flowfav_launch()
    elif a == "add_fav":
        # Los menús de canales IPTV/TDT envían fav_action/thumbnail; sin leerlos, el canal
        # se guardaría como búsqueda de su URL.
        add_fav(title=p.get("title", "Favorito"),
                action=p.get("f_action") or p.get("fav_action") or "search",
                url=u, thumbnail=p.get("f_thumb") or p.get("thumbnail") or ICON_MAIN, extra=e)
    elif a == "fav_news": show_fav_news()
    elif a == "trending": show_trending()
    elif a == "del_fav": 
        if core_settings.remove_favorite(u): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
        kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
        kb.doModal()
        if kb.isConfirmed():
            new_t = kb.getText()
            if new_t:
                core_settings.rename_favorite(p.get("fav_url"), new_t)
                xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"): xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"): xbmc.executebuiltin("Container.Refresh")
    
    # --- Categorías ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_backup_menu": category_manager.cat_backup_menu()
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         if category_manager.add_item_dialog(p.get("q")):
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if removed:
                 time.sleep(0.2) 
                 xbmc.executebuiltin("Container.Refresh")
                 
    # --- Historial de exploración ---
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))

    # --- EPG en texto ---
    # epg_texto arrastra ElementTree/gzip/datetime y solo se usa aquí, así que se importa aquí.
    elif a in ("epg_texto_menu", "epg_texto_atres", "epg_texto_grupo",
               "epg_texto_canal", "epg_texto_programa", "epg_texto_refresh"):
        import epg_texto
        if a == "epg_texto_menu": epg_texto.epg_texto_menu()
        elif a == "epg_texto_atres": epg_texto.epg_texto_atres()
        elif a == "epg_texto_grupo": epg_texto.epg_texto_grupo(p.get("grupo"))
        elif a == "epg_texto_canal": epg_texto.epg_texto_canal(p.get("ch_id"), p.get("ch_name"))
        elif a == "epg_texto_programa": epg_texto.epg_texto_programa(p.get("title"), p.get("plot"))
        elif a == "epg_texto_refresh": epg_texto.epg_texto_refresh()
    elif a == "vpn_nota":
        quitar = xbmcgui.Dialog().yesno(
            "Directos y VPN",
            "Las emisiones en directo de A3Player tienen sistemas de detección que suelen bloquear las conexiones a través de VPN.\n\nSi tienes problemas, prueba a desactivarla.",
            nolabel="Quitar mensaje",
            yeslabel="OK",
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
        )
        if not quitar:
            xbmcaddon.Addon().setSetting('hide_vpn_nota', 'true')
            xbmc.executebuiltin("Container.Refresh")
    elif a == "play_intro":
        _INTRO_URL = "https://raw.githubusercontent.com/fullstackcurso/atresdaily/main/resources/logoatresdaily.mp4"
        li = xbmcgui.ListItem(path=_INTRO_URL)
        li.setMimeType("video/mp4")
        li.setContentLookup(False)
        xbmc.Player().play(_INTRO_URL, li)
    elif a == "restore_warnings":
        addon = xbmcaddon.Addon()
        addon.setSetting('hide_vpn_nota', 'false')
        addon.setSetting('hide_vpn_info', 'false')
        xbmcgui.Dialog().notification("AtresDaily", "Mensajes de advertencia restaurados", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")

    elif a == "dm_open_browser":
        try:
            dm_url = f"https://www.dailymotion.com/video/{u}"
            if xbmc.getCondVisibility("System.Platform.Android"):
                xbmc.executebuiltin(f'StartAndroidActivity(,"android.intent.action.VIEW","","{dm_url}")')
            else:
                import webbrowser; webbrowser.open(dm_url)
            xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
        except Exception:
            xbmcgui.Dialog().ok("AtresDaily", f"Abre esta URL:\n\nhttps://www.dailymotion.com/video/{u}")
    elif a == "view_downloads": view_downloads()
    elif a == "download_video": connector.download_video(vid=u, title=p.get('title', 'Video'))
    elif a == "del_dl_history": del_dl_history(u)
    elif a == "del_file": del_file(u)
    elif a == "play_local": play_local(u)
    elif a == "export_favs": export_favs()
    elif a == "backup_favs_dialog": backup_favs_dialog()
    elif a == "export_favs_menu": export_favs_menu()
    elif a == "export_favs_txt": export_favs_txt()
    elif a == "multi_search": multi_search()
    elif a == "multi_run": multi_run(p.get("q", ""))
    elif a == "import_favs": import_favs()
    elif a == "play_media": connector.play_media(u, e)
    elif a == "live_tv_menu": live_tv_menu()
    elif a == "live_tv": connector.list_live()
    elif a == "tdt_channels": tdt_channels()
    elif a == "tdt_channels_json": tdt_channels_json()
    elif a == "tdt_json_ambit": tdt_json_ambit(u)
    elif a == "search_acestream":           search_acestream()
    elif a == "acestream_search_name":      _acestream_search_by_name()
    elif a == "acestream_enter_url":        _acestream_enter_url()
    elif a == "acestream_enter_id":         _acestream_enter_id()
    elif a == "acestream_scan_url":         _acestream_scan_url()
    elif a == "acestream_history":          _acestream_show_history()
    elif a == "acestream_history_search":   _acestream_history_search(p.get("q"))
    elif a == "acestream_history_scan":     _acestream_history_scan(u)
    elif a == "acestream_history_play":     _acestream_history_play(u)
    elif a == "acestream_history_delete":   _acestream_history_delete(p.get("ts"))
    elif a == "acestream_history_clear":    _acestream_history_clear()
    elif a == "acestream_proxy_toggle":     _acestream_proxy_toggle()
    elif a == "acestream_proxy_find":       _acestream_proxy_find()
    elif a == "acestream_proxy_manual":     _acestream_proxy_manual()
    elif a == "acestream_proxy_clear":      _acestream_proxy_clear()
    elif a == "play_ace":
        import url_player; url_player.play_url_action(u)
    elif a == "play_tdt": play_tdt(u, p.get("title", ""))
    elif a == "open_browser_url": open_browser_url(u)
    # Listas de canales. Los tres primeros son los nombres de antes, así que favoritos y atajos de
    # versiones anteriores siguen abriendo lo mismo.
    elif a == "add_custom_iptv":
        import iptv_lists; iptv_lists.add_list()
    elif a == "view_custom_iptv":
        import iptv_lists; iptv_lists.open_legacy(u)
    elif a == "delete_custom_iptv":
        import iptv_lists; iptv_lists.delete_legacy(u)
    elif a and a.startswith("iptv_"):
        import iptv_lists; iptv_lists.route(a, p)
    elif a == "search": connector.search_internet(u, direct=(p.get('direct') == 'true'))
    elif a == "search_movie": connector.search_internet(e)
    elif a == "search_external": _search_external_prompt()
    elif a == "play_dm":
        # Registrar en historial antes de reproducir
        if u:
            title_for_history = p.get('title', u)
            thumb_for_history = p.get('thumb', '')
            dur_for_history = p.get('duration', 0)
            try: dur_for_history = int(dur_for_history)
            except Exception: dur_for_history = 0
            try:
                core_settings.add_to_watch_history(u, title_for_history, thumb_for_history, dur_for_history)
            except Exception: pass
        # En la reproducción DM, Windows tiene problemas con CDN; el resto usa connector directamente
        _is_windows = xbmc.getCondVisibility("System.Platform.Windows")
        if not _is_windows:
            # En Android/Fire Stick el connector reproduce DM directo, sin la cascada de Windows
            connector.play_dm(u)
        else:
            # Primero el connector, que no necesita nada instalado y tarda ~1 s; yt-dlp
            # del sistema detrás, porque arrancarlo cuesta 2-3 s más. Cada paso solo
            # se intenta si el anterior no resolvió: Kodi admite un único
            # setResolvedUrl por reproducción.
            _dm_ok = False
            _connector_antiguo = False
            dm_web_url = f"https://www.dailymotion.com/video/{u}"
            # Método 1: connector. Se le pide que no cierre la resolución si falla,
            # o los métodos siguientes se quedarían sin turno.
            try:
                xbmc.log("[AtresDaily] DM: Trying connector.play_dm...", xbmc.LOGINFO)
                _dm_ok = bool(connector.play_dm(u, cerrar_si_falla=False))
            except TypeError:
                # No admite el parámetro y cierra la resolución él mismo, así que va
                # después de yt-dlp.
                _connector_antiguo = True
            except Exception as ex:
                xbmc.log(f"[AtresDaily] DM: connector.play_dm failed: {ex}", xbmc.LOGWARNING)
            # Método 2: yt-dlp via subprocess (usa Python del sistema, no el de Kodi)
            if not _dm_ok:
                try:
                    import subprocess, json as _json
                    xbmc.log("[AtresDaily] DM: Trying yt-dlp via subprocess...", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification("AtresDaily", "Resolviendo con yt-dlp...", xbmcgui.NOTIFICATION_INFO, 2000)
                    _proc = subprocess.run(
                        ['python', '-m', 'yt_dlp', '--dump-json', '--no-download',
                         '--format', 'best[ext=mp4]/best', '--no-playlist',
                         f'https://www.dailymotion.com/video/{u}'],
                        capture_output=True, text=True, timeout=30,
                        creationflags=0x08000000  # CREATE_NO_WINDOW
                    )
                    if _proc.returncode == 0 and _proc.stdout.strip():
                        info = _json.loads(_proc.stdout)
                        stream_url = info.get('url', '')
                        if stream_url:
                            xbmc.log(f"[AtresDaily] DM yt-dlp OK: {stream_url[:80]}...", xbmc.LOGINFO)
                            li = xbmcgui.ListItem(path=stream_url)
                            li.setProperty('IsPlayable', 'true')
                            li.setContentLookup(False)
                            try:
                                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                            except Exception:
                                xbmc.Player().play(stream_url, li)
                            _dm_ok = True
                        else:
                            xbmc.log("[AtresDaily] DM: yt-dlp returned no URL", xbmc.LOGWARNING)
                    else:
                        _err = _proc.stderr[:200] if _proc.stderr else 'no output'
                        xbmc.log(f"[AtresDaily] DM: yt-dlp exit={_proc.returncode}: {_err}", xbmc.LOGWARNING)
                except FileNotFoundError:
                    xbmc.log("[AtresDaily] DM: python not found in PATH", xbmc.LOGINFO)
                # "ex" y no "e", porque a nivel de módulo except ... as e borraría el extra de la URL.
                except Exception as ex:
                    xbmc.log(f"[AtresDaily] DM: yt-dlp subprocess failed: {ex}", xbmc.LOGWARNING)
            if not _dm_ok and _connector_antiguo:
                connector.play_dm(u)
                _dm_ok = True
            # Método 3: delegar en plugin.video.dailymotion_com resolviendo a su URL,
            # no con PlayMedia: el item es IsPlayable y Kodi espera un setResolvedUrl.
            if not _dm_ok and xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.dailymotion_com)"):
                try:
                    xbmc.log("[AtresDaily] DM: delegando en plugin.video.dailymotion_com", xbmc.LOGINFO)
                    dm_plugin_url = f"plugin://plugin.video.dailymotion_com/?url={u}&mode=playVideo"
                    li = xbmcgui.ListItem(path=dm_plugin_url)
                    li.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                    _dm_ok = True
                except Exception as ex:
                    xbmc.log(f"[AtresDaily] DM: DM addon failed: {ex}", xbmc.LOGWARNING)
            # Método 4: el navegador, ya como último recurso y no antes de haber
            # probado lo que sí puede reproducir dentro de Kodi.
            if not _dm_ok:
                try:
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
                except Exception:
                    pass
                if xbmcgui.Dialog().yesno("AtresDaily - Dailymotion",
                        "No se pudo reproducir este vídeo en Kodi.\n\n"
                        "¿Quieres abrirlo en el navegador?",
                        yeslabel="Navegador", nolabel="Cancelar"):
                    try:
                        import webbrowser
                        webbrowser.open(dm_web_url)
                        xbmcgui.Dialog().notification("AtresDaily", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
                    except Exception:
                        xbmcgui.Dialog().ok("AtresDaily", f"Abre esta URL en tu navegador:\n\n{dm_web_url}")
    elif a == "input_search": input_search()
    elif a == "advanced_search_menu": _advanced_search_menu()
    elif a == "view_history": view_history()
    elif a == "del_history": del_history()
    elif a == "settings_menu": settings_menu()
    elif a == "ssm_menu":    search_shortcuts_manager.main_menu()
    elif a == "ssm_reorder": search_shortcuts_manager.reorder_menu()
    elif a == "ssm_actions":
        search_shortcuts_manager.shortcut_actions(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_addon":
        search_shortcuts_manager.add_from_installed_addon()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_command":
        search_shortcuts_manager.add_command()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_add_fav":
        search_shortcuts_manager.add_from_kodi_favorites()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_delete":
        search_shortcuts_manager.delete_shortcut(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_rename":
        search_shortcuts_manager.rename_shortcut(int(p.get("idx", 0)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_move_up":
        search_shortcuts_manager.move_shortcut(int(p.get("idx", 0)), "up")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "ssm_move_down":
        search_shortcuts_manager.move_shortcut(int(p.get("idx", 0)), "down")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif a == "watch_history": view_watch_history()
    elif a == "clear_watch_history":
        if xbmcgui.Dialog().yesno("Borrar Historial", "¿Seguro que quieres borrar todo el historial de reproducciones?"):
            core_settings.clear_watch_history()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "del_watch_entry":
        core_settings.remove_watch_entry(u)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "input_mode_menu": input_mode_menu()
    elif a == "inicio_elegir":
        ui_utils.visto('inicio')
        import inicio
        inicio.elegir(getattr(connector, "CATS", {}))
    elif a == "toggle_gratis_primero":
        ui_utils.visto('gratis_primero')
        _addon = xbmcaddon.Addon()
        _addon.setSetting('gratis_primero', 'false' if _addon.getSetting('gratis_primero') == 'true' else 'true')
        xbmc.executebuiltin("Container.Refresh")
    elif a == "set_cache_config": set_cache_config()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "toggle_catalog_long_first": _toggle_catalog_long_first()
    elif a == "search_order_menu": search_order_menu()
    elif a == "separador":
        from minijuegos import sorpresa
        sorpresa.ofrecer()
    elif a == "minijuegos_borrar_record":
        from minijuegos import lista
        lista.borrar_record()
    elif a == "minijuegos_menu":
        from minijuegos import ajustes
        ajustes.menu()
    elif a == "minijuegos_ajuste":
        from minijuegos import ajustes
        ajustes.cambiar(u)
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "execute_adv_search": _execute_adv_search(u)
    elif a == "catalog_search":
        _addon = xbmcaddon.Addon()
        # Si el connector ordena por parecido, "largos primero" ya va dentro de su
        # puntuación, y partir aquí la lista hundiría el capítulo buscado cuando dura
        # menos de 30 minutos. Un connector que no puntúa sigue necesitándolo.
        _puntua = (hasattr(connector, '_puntuar')
                   and _addon.getSetting('dm_catalogo_coincidencia') != 'false')
        if _addon.getSetting('catalog_long_first') != 'false' and not _puntua:
            _LONG_FIRST_ACTIVE = True
        connector.catalog_search(u)
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_catalog_snapshot": create_catalog_snapshot()
    elif a == "view_snapshot": view_snapshot(u, e)
    elif a == "delete_snapshot_menu": delete_snapshot_menu()
    elif a == "delete_single_snap": delete_single_snap(u)
    elif a == "toggle_snapshot_precision": toggle_snapshot_precision()
    elif a == "backups_menu": backups_menu()
    elif a == "create_backup": create_backup()
    elif a == "create_backup_full": create_backup(include_cache=True)
    elif a == "list_backups": _list_backups()
    elif a == "restore_backup": restore_backup(u)
    elif a == "del_backups_menu": _del_backups_menu()
    elif a == "export_backups_menu": _export_backups_menu()
    elif a == "export_single_backup": export_single_backup(u)
    elif a == "delete_single_backup": delete_single_backup(u)
    elif a == "set_download_path": set_download_path()
    elif a == "set_dm_safe_level": set_dm_safe_level()
    elif a == "dm_listas_menu": dm_listas_menu()
    elif a == "toggle_dm_ajuste": toggle_dm_ajuste(u)
    elif a == "set_dl_mode": set_dl_mode()
    elif a == "toggle_inputstream": _toggle_inputstream()
    elif a == "toggle_disable_fanart": _toggle_disable_fanart()
    elif a == "toggle_iptv_anti_errors": _toggle_iptv_anti_errors()
    elif a == "toggle_ext_search_enabled": _toggle_ext_search_enabled()
    elif a == "toggle_ext_search_dialog": _toggle_ext_search_dialog()
    elif a == "toggle_acestream_enabled": _toggle_acestream_enabled()
    elif a == "acc_menu": acc_menu()
    elif a == "acc_set_color_mode": _acc_set_color_mode()
    elif a == "acc_toggle_bold": _acc_toggle_bold()
    elif a == "acc_toggle_symbols": _acc_toggle_symbols()
    elif a == "acc_toggle_menu_colors": _acc_toggle_menu_colors()
    elif a == "list_user_playlists": connector.list_user_playlists(p.get("user"))
    elif a == "view_playlist": connector.view_playlist(p.get("id"))
    elif a == "search_user_playlists": connector.search_user_playlists()
    elif a == "show_legal_txt": show_legal_txt()
    elif a == "revoke_legal": revoke_legal()
    elif a == "set_precision": set_precision()
    elif a == "clear_ui_cache": clear_ui_cache()
    elif a == "storage_menu":
        import storage_manager; storage_manager.storage_menu()
    elif a == "kodi_maintenance_menu":
        import kodi_maintenance; kodi_maintenance.maintenance_menu()
    elif a == "export_cache": export_cache()
    elif a == "clear_full_cache": clear_full_cache()
    elif a == "show_info": show_info()
    elif a == "show_web_info": show_web_info()
    elif a == "info_menu": info_menu()
    elif a == "espadaily_launch": _espadaily_launch()
    elif a == "elementum_search": _search_elementum(p.get("q"))
    elif a == "elementum_search_prompt": _search_elementum_prompt(p.get("q"))
    elif a == "dm_gujal_search": _search_dailymotion_gujal(p.get("q"))
    elif a == "atresplayer_catalog_search": _search_atresplayer_catalog(p.get("q") or None)
    elif a == "palantir_search_prompt": _search_palantir_prompt(p.get("q"))
    elif a == "toggle_estuary_palantir_fix": _toggle_estuary_palantir_fix()
    elif a == "search_balandro_from_results": _search_balandro_from_results(p.get("q"))
    elif a == "search_jacktook_from_results": _search_jacktook_from_results(p.get("q"))
    elif a == "search_alfa_from_results": _search_alfa_from_results(p.get("q"))
    elif a == "yt_html_search":
        import youtube_search; youtube_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "odysee_search":
        import odysee_search; odysee_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "odysee_play":
        import odysee_search; odysee_search.play_item(int(sys.argv[1]), p.get("name", ""), p.get("claim_id", ""),
                                                      p.get("sd_hash", ""), p.get("media_type", ""))
    elif a == "search_odysee_prompt": _search_odysee_from_results("")
    elif a == "search_youtube_prompt": _search_youtube_from_results("")
    elif a == "peertube_search":
        import peertube_search; peertube_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "peertube_play":
        import peertube_search; peertube_search.play_item(int(sys.argv[1]), p.get("uuid", ""))
    elif a == "search_peertube_prompt": _search_peertube_from_results("")
    elif a == "bitchute_search":
        import bitchute_search; bitchute_search.render_results(int(sys.argv[1]), p.get("q", ""))
    elif a == "bitchute_play":
        import bitchute_search; bitchute_search.play_item(int(sys.argv[1]), p.get("video_id", ""))
    elif a == "search_bitchute_prompt": _search_bitchute_from_results("")
    elif a == "busqueda_total":
        import busqueda_total; busqueda_total.show_menu(int(sys.argv[1]))
    elif a == "bt_search":
        import busqueda_total; busqueda_total.prompt_and_run(int(sys.argv[1]))
    elif a == "bt_run":
        import busqueda_total; busqueda_total.run(int(sys.argv[1]), p.get("q", ""))
    elif a == "bt_toggle":
        import busqueda_total; busqueda_total.toggle(int(sys.argv[1]), p.get("key", ""))
    elif a == "bt_rank_menu":
        import busqueda_total; busqueda_total.show_rank_menu(int(sys.argv[1]))
    elif a == "bt_sources_menu":
        import busqueda_total; busqueda_total.show_sources_menu(int(sys.argv[1]))
    elif a == "bt_cine_menu":
        import busqueda_total; busqueda_total.show_cine_menu(int(sys.argv[1]))
    elif a == "bt_set_mindur":
        import busqueda_total; busqueda_total.set_min_duration(int(sys.argv[1]))
    elif a == "bt_proxy_find":
        import busqueda_total; busqueda_total.proxy_find(int(sys.argv[1]))
    elif a == "bt_proxy_clear":
        import busqueda_total; busqueda_total.proxy_clear(int(sys.argv[1]))
    elif a == "view_kodi_log": view_kodi_log()
    # --- Trakt y mejores películas ---
    elif a == "trakt_root":
        ui_utils.visto('trakt_4.9')
        import trakt_manager; trakt_manager.menu_trakt_root()
    elif a == "trakt_options":
        import trakt_manager; trakt_manager.menu_options()
    elif a == "trakt_help_guide":
        import trakt_manager; trakt_manager.help_guide()
    elif a == "trakt_set_key":
        import trakt_manager; trakt_manager.set_api_key()
    elif a == "trakt_import":
        import trakt_manager; trakt_manager.import_list()
    elif a == "trakt_import_espatv":
        import trakt_manager; trakt_manager.import_from_espatv()
    elif a == "trakt_view_list":
        import trakt_manager; trakt_manager.view_list(p.get("list_id"), p.get("show_covers") == "1")
    elif a == "trakt_delete_list":
        import trakt_manager; trakt_manager.delete_list(p.get("list_id"))
    elif a == "trakt_cache_covers":
        import trakt_manager; trakt_manager.cache_covers(p.get("list_id"))
    elif a == "trakt_clear_cache":
        import trakt_manager; trakt_manager.clear_cache(p.get("list_id"))
    elif a == "top_movies":
        import trakt_manager; trakt_manager.top_movies(p.get("page"))
    elif a == "cache_top_movies_covers":
        import trakt_manager; trakt_manager.cache_top_movies_covers()
    elif a == "clear_top_movies_cache":
        import trakt_manager; trakt_manager.clear_top_movies_cache()
    elif a == "trakt_search_dialog":
        import trakt_manager; trakt_manager.search_dialog(p.get("q") or u)
    elif a == "search_alt_prompt":
        import trakt_manager; trakt_manager.search_dialog(p.get("q") or u)
    elif a == "mejores_peliculas":
        import filmaffinity; filmaffinity.show_top()
    elif a == "filmaffinity_root":
        import filmaffinity; filmaffinity.show_root_menu()
    elif a == "filmaffinity_cartelera":
        import filmaffinity; filmaffinity.show_cartelera()
    elif a == "filmaffinity_top":
        import filmaffinity; filmaffinity.show_top()
    elif a == "filmaffinity_list_menu":
        import filmaffinity; filmaffinity.menu()
    elif a == "filmaffinity_list":
        import filmaffinity; filmaffinity.show_list(p.get("genre", ""))
    elif a == "filmaffinity_cache_cartelera_meta":
        import filmaffinity; filmaffinity.cache_cartelera_meta()
    elif a == "filmaffinity_clear_cartelera_meta":
        import filmaffinity; filmaffinity.clear_cartelera_meta()
    elif a == "filmaffinity_cache_top_meta":
        import filmaffinity; filmaffinity.cache_top_meta()
    elif a == "filmaffinity_clear_top_meta":
        import filmaffinity; filmaffinity.clear_top_meta()
    elif a == "sensacine_root":
        import sensacine; sensacine.show_menu()
    elif a == "sensacine_cartelera":
        import sensacine; sensacine.show_cartelera()
    elif a == "sensacine_estrenos":
        import sensacine; sensacine.show_estrenos()
    elif a == "sensacine_cache_cartelera_meta":
        import sensacine; sensacine.cache_cartelera_meta()
    elif a == "sensacine_clear_cartelera_meta":
        import sensacine; sensacine.clear_cartelera_meta()
    elif a == "sensacine_cache_estrenos_meta":
        import sensacine; sensacine.cache_estrenos_meta()
    elif a == "sensacine_clear_estrenos_meta":
        import sensacine; sensacine.clear_estrenos_meta()
    elif a == "cinemeta_top":
        import cinemeta; cinemeta.show_top()
    elif a == "cinemeta_cache_meta":
        import cinemeta; cinemeta.cache_meta()
    elif a == "cinemeta_clear_meta":
        import cinemeta; cinemeta.clear_meta()
    elif a == "tmdb_lists_menu":
        import tmdb_lists; tmdb_lists.show_menu()
    elif a == "tmdb_lists_show":
        import tmdb_lists; tmdb_lists.show_list(p.get("endpoint", ""), p.get("media_type", "movie"), p.get("page", 1))
    elif a == "trakt_covers_menu":
        import trakt_manager; trakt_manager.covers_menu(p.get("list_id", ""), p.get("show_covers", "0"))
    elif a == "trakt_refresh_defaults":
        import trakt_manager; trakt_manager.refresh_all_lists()
    elif a == "trakt_cache_all_meta":
        import trakt_manager; trakt_manager.cache_all_meta()
    elif a == "trakt_clear_all_meta":
        import trakt_manager; trakt_manager.clear_all_meta()
    # --- Abrir URL ---
    elif a == "open_url":
        import url_player; url_player.open_url_dialog()
    elif a == "url_input":
        import url_player; url_player.url_input()
    elif a == "url_history":
        import url_player; url_player.url_history_menu()
    elif a == "url_history_clear":
        import url_player; url_player.history_clear()
    elif a == "url_history_remove":
        import url_player; url_player.history_remove(u)
    elif a == "url_bookmarks":
        import url_player; url_player.url_bookmarks_menu()
    elif a == "url_bookmark_save_from_history":
        import url_player; url_player.bookmark_save_from_history(u)
    elif a == "url_bookmark_rename":
        import url_player; url_player.bookmark_rename(u)
    elif a == "url_bookmark_delete":
        import url_player; url_player.bookmark_delete(u)
    elif a == "url_play":
        import url_player; url_player.play_url_action(u)
    elif a == "url_player_ensure_sn":
        import url_player; url_player.url_player_ensure_streamninja()
    elif a == "url_remote":
        import url_remote; url_remote.start_remote()
    elif a == "url_scan":
        import url_player; url_player.scan_videos_dialog()
    elif a == "url_player_config":
        _url_player_config_menu()
    elif a == "config_remote_port":
        _addon = xbmcaddon.Addon()
        _old = _addon.getSetting('remote_port') or '8089'
        _new = xbmcgui.Dialog().input("Puerto del servidor remoto", defaultt=_old, type=xbmcgui.INPUT_NUMERIC)
        if _new:
            try:
                _port_num = int(_new)
            except ValueError:
                _port_num = -1
            if 1024 <= _port_num <= 65535:
                _addon.setSetting('remote_port', str(_port_num))
                xbmcgui.Dialog().notification("AtresDaily", f"Puerto cambiado a {_port_num}", xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("AtresDaily", "Puerto no válido.\nDebe estar entre 1024 y 65535.")
    elif a == "toggle_remote_secure": _toggle_remote_secure()
    elif a == "set_webremote_mode": _set_webremote_mode()
    elif a == "toggle_webremote_confirm": _toggle_webremote_confirm()
    elif a == "set_webremote_server": _set_webremote_server()
    elif a == "reset_webremote_topic": _reset_webremote_topic()
    elif a == "debrid_menu": _debrid_menu()
    elif a == "debrid_toggle_enabled": _debrid_toggle_enabled()
    elif a == "debrid_set_provider": _debrid_set_provider()
    elif a == "debrid_authorize_pin": _debrid_authorize_pin()
    elif a == "debrid_authorize_key": _debrid_authorize_key()
    elif a == "debrid_deauthorize": _debrid_deauthorize()
    elif a == "debrid_account": _debrid_account()
    elif a == "debrid_toggle_cached": _debrid_toggle_cached()
    elif a == "debrid_toggle_cleanup": _debrid_toggle_cleanup()
    elif a == "debrid_toggle_quality": _debrid_toggle_quality()
    elif a == "debrid_library":
        import url_player; url_player.debrid_library_menu()
    elif a == "debrid_library_files":
        import url_player; url_player.debrid_library_files(p.get("id"))
    elif a == "debrid_library_play":
        import url_player; url_player.debrid_library_play(p.get("id"), p.get("file"))
    elif a == "debrid_library_delete":
        import url_player; url_player.debrid_library_delete(p.get("id"))
    elif a == "debrid_download":
        import url_player; url_player.debrid_download(p.get("id"), p.get("title", ""))
    elif a == "slyguy_install": _slyguy_install(u, p.get("title", "Addon"))
    elif a == "espatv_install": _espatv_install()
    elif a == "espatv_launch": _espatv_launch()
    elif a == "show_vpn_info": show_vpn_info()
    elif a == "loiolog_install": _loiolog_install()
    elif a == "loiolog_launch": _loiolog_launch()
    elif a == "streamninja_launch": _streamninja_launch()
    elif a == "atresdaily_launch": _atresdaily_launch()
    elif a == "espakodi_addons_menu": espakodi_addons_menu()
    elif a == "ek_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id(p.get("addon_id", ""))
    elif a == "ek_open_repo":
        import espakodi_installer
        espakodi_installer.open_repo_unificado()
    elif a == "ek_open_web":
        import espakodi_installer
        espakodi_installer.open_web()
    elif a == "espakodi_app_menu": espakodi_app_menu()
    elif a == "ek_apk":
        import espakodi_app
        espakodi_app.descargar(p.get("nombre", ""))
        xbmc.executebuiltin("Container.Refresh")
    elif a == "ek_apk_bits":
        import espakodi_app
        espakodi_app.info_bits()
    elif a == "ek_apk_web":
        import espakodi_app
        espakodi_app.abrir_web()
    elif a == "ek_telegram":
        import espakodi_app
        espakodi_app.abrir_telegram()
    elif a == "ek_apk_borrar":
        import espakodi_app
        if espakodi_app.borrar_descargas() == "refrescar":
            xbmc.executebuiltin("Container.Refresh")
    elif a == "topzilla_launch":
        ui_utils.visto('topzilla')
        import espakodi_installer
        espakodi_installer.launch_by_id("plugin.video.topzilla")
    elif a == "loiolink_launch":
        import espakodi_installer
        espakodi_installer.launch_by_id("plugin.program.loiolink")
    elif a == "experimental_menu": experimental_menu()
    elif a == "crt_config_menu": crt_config_menu()
    elif a == "crt_toggle": crt_toggle(p.get("key", ""))
    elif a == "open_addon_settings": xbmc.executebuiltin("Addon.OpenSettings(plugin.video.atresdaily)")
    elif a == "autostart_menu":        _autostart_menu()
    elif a == "autostart_config_slot": _autostart_config_slot(int(p.get("slot", 1)))
    elif a == "autofav_menu":          _autofav_menu()
    elif a == "autofav_config_slot":   _autofav_config_slot(int(p.get("slot", 1)))
    elif a == "check_atres_repo": ui_utils.check_repo_status()
    elif a == "show_last_message": show_last_message()
    elif a == "novedades":
        import novedades
        novedades.mostrar()
    elif a == "webapp_open":
        from webapp import bootstrap
        url = bootstrap.ensure_running()
        if not url:
            xbmcgui.Dialog().ok("AtresDaily WebApp",
                "No se pudo arrancar el servidor de la WebApp.\n\n"
                "Prueba con otro puerto en Configuración o revisa el registro de Kodi.")
        else:
            xbmcgui.Dialog().notification("AtresDaily WebApp", "Iniciando...", xbmcgui.NOTIFICATION_INFO, 1500)
            _opened = False
            try:
                if xbmc.getCondVisibility("System.Platform.Android"):
                    xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
                    _opened = True
                else:
                    import webbrowser
                    _opened = webbrowser.open(url)
            except Exception:
                pass
            if _opened:
                if xbmc.getCondVisibility("System.Platform.Android"):
                    xbmcgui.Dialog().ok("AtresDaily WebApp",
                        f"Se ha intentado abrir la WebApp en tu navegador.\n\n"
                        f"Si no se ha abierto, puedes acceder manualmente introduciendo esta URL en el navegador de cualquier dispositivo:\n\n{url}")
                else:
                    xbmcgui.Dialog().notification("AtresDaily WebApp", "Abierto en el navegador", xbmcgui.NOTIFICATION_INFO, 2500)
            else:
                xbmcgui.Dialog().ok("AtresDaily WebApp",
                    f"El servidor está en marcha.\n\nAbre esta dirección en tu navegador:\n\n{url}")
        if u == "ajustes":
            # Configuración pasa de DETENIDA a EN MARCHA y pierde el punto verde.
            ui_utils.visto('webapp_estado')
            xbmc.executebuiltin("Container.Refresh")
    elif a == "webapp_stop":
        ui_utils.visto('webapp_estado')
        from webapp import bootstrap
        if bootstrap.get_url() is None:
            xbmcgui.Dialog().notification("AtresDaily WebApp", "La WebApp no estaba en marcha.", xbmcgui.NOTIFICATION_INFO, 2000)
        elif bootstrap.stop():
            xbmcgui.Dialog().notification("AtresDaily WebApp", "Servidor detenido.", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("AtresDaily WebApp", "El servidor no respondió a la parada.", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "webapp_toggle_lan":
        cfg = ui_utils.load_json('settings.json')
        cfg['webapp_lan_mode'] = not cfg.get('webapp_lan_mode', False)
        ui_utils.save_json('settings.json', cfg)
        from webapp import bootstrap
        if cfg['webapp_lan_mode']:
            # Se arranca ya para poder dar la URL a los demás dispositivos.
            url = bootstrap.ensure_running()
            if url:
                # Cuatro líneas como mucho, porque el cuadro centra el texto y corta lo que sobra por arriba.
                xbmcgui.Dialog().ok("WebApp - Red Local ACTIVADA",
                    f"Abre esta URL en cualquier dispositivo de tu red:\n\n{url}")
            else:
                xbmcgui.Dialog().ok("WebApp - Red Local ACTIVADA",
                    "El modo red local queda activado, pero el servidor no arrancó.\n\n"
                    "Prueba con otro puerto o revisa el registro de Kodi.")
        else:
            # Solo se reinicia si estaba en marcha; arrancar otro dejaría el anterior escuchando
            # en toda la red hasta cerrar Kodi.
            url = bootstrap.restart_if_running()
            xbmcgui.Dialog().notification("WebApp - Solo este dispositivo",
                url or "Se aplicará al abrir la WebApp", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
    elif a == "webapp_set_port":
        cfg = ui_utils.load_json('settings.json')
        current = str(cfg.get('webapp_port', 8092))
        kb = xbmc.Keyboard(current, 'Puerto de la WebApp (1024-65535)')
        kb.doModal()
        if kb.isConfirmed():
            txt = kb.getText().strip()
            try:
                new_port = int(txt)
                if not (1024 <= new_port <= 65535):
                    raise ValueError
                cfg['webapp_port'] = new_port
                ui_utils.save_json('settings.json', cfg)
                from webapp import bootstrap
                # Si la WebApp estaba en marcha se reinicia en el puerto nuevo; si no, se
                # aplicará al abrirla.
                url = bootstrap.restart_if_running()
                msg = f"Puerto cambiado a {new_port}" + (f"  |  {url}" if url else "")
                xbmcgui.Dialog().notification("WebApp Puerto", msg, xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin("Container.Refresh")
            except ValueError:
                xbmcgui.Dialog().notification("WebApp Puerto", f"'{txt}' no es un puerto válido (1024-65535)", xbmcgui.NOTIFICATION_WARNING, 3000)
    else: menu_root()