# -*- coding: utf-8 -*-
# AtresDaily - Copyright (C) 2024-2026 RubénSDFA1laberot
# Descarga de EspaKodi sin salir de Kodi, los APK de Android y el instalador de Windows.
# La descarga está portada de EKHorus (download_apk y compañía, en lib/utils.py).

import hashlib
import json
import os
import subprocess
import sys
import urllib.parse
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import espakodi_installer
import list_screen

HEADING = "AtresDaily"

# Lo regenera una GitHub Action del repo espakodi/apk en cada release y una vez al día, así que
# siempre trae la última versión con el sha256 de cada APK.
APK_RELEASES = "https://espakodi.github.io/apk/releases.json"
APK_WEB = "https://espakodi.github.io/apk/"
TELEGRAM = "https://t.me/espakodi"
# Clave de su fila en la ventana; las de las descargas son el nombre del fichero
_CLAVE_TELEGRAM = "telegram"
# El repo del .exe no publica un releases.json. La API de GitHub da lo mismo de la última
# release, con un cupo de 60 consultas por hora y por IP sin cuenta.
WINDOWS_RELEASE = "https://api.github.com/repos/espakodi/exe/releases/latest"

# Bloquea la apertura de la pantalla, así que corto
RELEASES_TIMEOUT_S = 5
DESCARGA_TIMEOUT_S = 30
TROZO = 128 * 1024
PM_INSTALL_TIMEOUT_S = 180

# No es una barrera de seguridad (quien controla el repositorio publica el addon entero); evita
# que una errata en releases.json mande a descargar de cualquier sitio.
_HOSTS = ("github.com", "archive.org")

_UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) "
                     "Gecko/20100101 Firefox/128.0"}

ESPAKODI = "EspaKodi"
LAROJA = "EspaKodi LaRoja"
WINDOWS = "Windows"

# Si releases.json no contesta, la 0.1.2. Su copia de archive.org tiene el mismo sha256 que
# la release de GitHub.
_RESPALDO = (
    {"app": ESPAKODI, "version": "0.1.2", "bits": 32, "nombre": "EspaKodi-0.1.2-armeabi-v7a.apk",
     "tamano": 101104892,
     "url": "https://github.com/espakodi/apk/releases/download/v0.1.2/EspaKodi-0.1.2-armeabi-v7a.apk",
     "copia": "https://archive.org/download/ekh_20260918/ekh.zip/ekh%2FEKdi-0.1.2-armeabi-v7a.apk",
     "sha256": "a27beae6199fd15082689a91aea8c53ac45d2606e24d80b387732e7d505f0912"},
    {"app": ESPAKODI, "version": "0.1.2", "bits": 64, "nombre": "EspaKodi-0.1.2-arm64-v8a.apk",
     "tamano": 101658096,
     "url": "https://github.com/espakodi/apk/releases/download/v0.1.2/EspaKodi-0.1.2-arm64-v8a.apk",
     "copia": "https://archive.org/download/ekh_20260918/ekh.zip/ekh%2FEKdi-0.1.2-arm64-v8a.apk",
     "sha256": "9f9666c694b5ac88c2e68056e813e5e8659f60e2e47f2ba7cfe3d25aab481d52"},
)

_NOTA_LAROJA = (
    "Kodi ligero basado en EspaKodi Warp y vestido de selección, con tema rojo y amarillo, la "
    "foto de España levantando la copa de fondo y sonido de tambor al moverte con el mando. El "
    "botón de apagar cierra Kodi del todo y no deja la pantalla negra al volver a entrar. Trae "
    "EKHorus.\n\nPuede convivir con EspaKodi y con Warp."
)

# No tiene web con releases.json, así que va fija, con la copia de archive.org de respaldo.
_LAROJA = (
    {"app": LAROJA, "version": "0.0.3", "bits": 32, "nombre": "EKlRoja-0.0.3_32bits.apk",
     "tamano": 62150621,
     "url": "https://github.com/espakodi/misappsfavoritas/releases/download/v0.0.1test/EKlRoja-0.0.3_32bits.apk",
     "copia": "https://archive.org/download/ekh_20260918/ekh.zip/ekh%2FEKlRoja-0.0.3_32bits.apk",
     "sha256": "e806fe28e6608223e7aba505ecaa73b57ab40b7407ca11c6d6b5cdd58b3a1f0c",
     "nota": _NOTA_LAROJA + " La de 32 bits está pensada para usarla con mando y no lleva "
                            "cruceta en pantalla."},
    {"app": LAROJA, "version": "0.0.3", "bits": 64, "nombre": "EKlRoja-0.0.3_64bits.apk",
     "tamano": 62913508,
     "url": "https://github.com/espakodi/misappsfavoritas/releases/download/v0.0.1test/EKlRoja-0.0.3_64bits.apk",
     "copia": "https://archive.org/download/ekh_20260918/ekh.zip/ekh%2FEKlRoja-0.0.3_64bits.apk",
     "sha256": "b9b2aa7364ac7a72b566bc1705fb14c290b1d58fe64d1c41578fd368bf43386c",
     "nota": _NOTA_LAROJA + " La de 64 bits lleva la cruceta en pantalla de EspaKodi Venom, para "
                            "el móvil."},
)

# Si la API de GitHub no contesta o se ha gastado el cupo, la 0.0.4. No tiene copia en archive.org.
_WINDOWS_RESPALDO = {
    "app": WINDOWS, "version": "0.0.4", "bits": 64, "nombre": "EspaKodi_Instalador_v0.0.4.exe",
    "tamano": 61363793,
    "url": "https://github.com/espakodi/exe/releases/download/v0.0.4/EspaKodi_Instalador_v0.0.4.exe",
    "copia": "",
    "sha256": "b4d80cdc62a63906d836c069f0ebfb59dc5ccdf9e6687b414ea90d3b3bb03d1f",
}

# Así empiezan los APK y el .exe que se descargan desde aquí; lo demás de la carpeta no se toca
# al borrar
_PREFIJOS = ("EspaKodi-", "EKlRoja-", "EspaKodi_")

# Carpetas de Android donde el instalador y los gestores de archivos ven el APK
_CARPETAS_ANDROID = (
    "/storage/emulated/0/Download/",
    "/storage/self/primary/Download/",
    "/sdcard/Download/",
)

# Con la versión en la clave: una sesión de Kodi que actualice el addon no lee la lista con el
# formato anterior
_PROP_CACHE = "atresdaily.espakodi_apk.2"
_PROP_WINDOWS = "atresdaily.espakodi_exe"
_PROP_FALLO = "fallo"
# Seguido del nombre del fichero, la propiedad de Home de una descarga en marcha
_PESTILLO = "atresdaily.descargando."
_AJUSTE_CARPETA = "espakodi_apk_carpeta"

_CONSEJO_BITS = ("Si dudas, prueba con la de 32 bits. Si el sistema no te deja instalarla, tu "
                 "aparato es solo de 64 bits y te toca la de 64.")

_TEXTO_BITS = (
    "EspaKodi y EspaKodi LaRoja vienen en dos versiones, de 32 bits (armeabi-v7a) y de 64 bits "
    "(arm64-v8a).\n\n"
    "La de 32 bits es la del Fire TV Stick y la mayoría de TV box, y casi todos los aparatos de "
    "64 bits también la instalan sin problema. Solo algunos muy modernos, sobre todo móviles, han "
    "dejado de admitir apps de 32 bits, y para esos está la de 64.\n\n"
    f"{_CONSEJO_BITS}\n\n"
    "Más ayuda en el chat de EspaKodi (t.me/espakodi) y en espakodi.github.io/apk."
)

_NOTA_ESPAKODI = (
    "Kodi en español con los addons de EspaKodi ya instalados, AtresDaily incluido. Convive con "
    "el Kodi oficial.\n\n"
    "Se instala encima de la versión anterior de EspaKodi sin perder favoritos, addons ni ajustes."
)

_NOTA_BITS = {
    32: "La de 32 bits es la del Fire TV Stick y los TV box, pensada para usarla con mando.",
    64: "La de 64 bits es para el móvil y los aparatos que ya no instalan apps de 32 bits. Trae "
        "la cruceta en pantalla para moverte donde no llega el dedo.",
}

# Cortas, porque con la pastilla de "Descargado" al lado la pista con su tamaño solo tiene unos
# 34 caracteres antes de cortarse con puntos
_PISTAS = {
    (ESPAKODI, 32): "Fire TV, TV box y más",
    (ESPAKODI, 64): "Móviles solo de 64 bits",
    (LAROJA, 32): "Tema rojo, con mando",
    (LAROJA, 64): "Tema rojo, en el móvil",
    (WINDOWS, 64): "PC con Windows 10 y 11",
}

_PLOT_LAROJA = (
    "EspaKodi LaRoja es un Kodi más ligero, basado en EspaKodi Warp y vestido de selección. "
    "Puede convivir con EspaKodi."
)

_PLOT_WINDOWS = (
    "EspaKodi también está para Windows 10 y 11 de 64 bits. Es el mismo Kodi en español con los "
    "addons ya instalados, en un instalador .exe que se descarga desde aquí y, en Windows, se "
    "puede abrir al acabar la descarga. También lo tienes en el Telegram de EspaKodi "
    "(t.me/espakodi).\n\n"
    'Al abrirlo puede que Windows avise con "Windows protegió tu PC", porque el instalador no está '
    'firmado con un certificado de pago. Pulsa "Más información" y después "Ejecutar de todas '
    'formas". Solo hace falta la primera vez.\n\n'
    "Se instala en tu carpeta de usuario sin permisos de administrador (no lo pongas en Archivos de "
    "programa) y crea el acceso EspaKodi en el Escritorio y en el menú Inicio.\n\n"
    "Si ya tienes EspaKodi en el PC, tiene que estar cerrado mientras se instala, e instalarlo "
    "encima deja los favoritos y los ajustes de Kodi como vienen de fábrica.\n\n"
    "Guarda sus datos aparte, así que convive con el Kodi oficial sin tocar su configuración."
)

_PLOT_WEB = (
    "Abre espakodi.github.io/apk en el navegador, con todas las versiones de la app EspaKodi y "
    "sus novedades."
)

_PLOT_TELEGRAM = (
    "En el Telegram de EspaKodi (t.me/espakodi) hay más versiones que las de esta lista: para "
    "LibreELEC y CoreELEC, una distribución Linux y variantes de la app de Android."
)

_PLOT_BORRAR = (
    "Borra los APK de EspaKodi y de LaRoja y el instalador de Windows que hayas descargado. Una "
    "vez instalados solo ocupan sitio, y en un TV box sobra poco."
)

_PLOT_SEPARADOR = {ESPAKODI: _NOTA_ESPAKODI, LAROJA: _PLOT_LAROJA, WINDOWS: _PLOT_WINDOWS}


class _Cancelada(Exception):
    """El usuario ha pulsado Cancelar en la descarga."""


class _SinEspacio(Exception):
    """El disco ha rechazado un trozo porque está lleno o ya no está (un USB sacado)."""


def _log(msg, nivel=xbmc.LOGINFO):
    xbmc.log(f"[AtresDaily] App EspaKodi: {msg}", nivel)


# --- Qué hay para descargar ---------------------------------------------------------------------

def _url_valida(url):
    """La URL si se puede descargar de ella, o ''."""
    if not isinstance(url, str) or not url.startswith("https://"):
        return ""
    host = urllib.parse.urlparse(url).hostname or ""
    if host not in _HOSTS:
        _log(f"dominio no permitido: {host}", xbmc.LOGWARNING)
        return ""
    return url


def _fichero(asset, extension):
    """Nombre, URL, tamaño y sha256 de un fichero de una release de GitHub con esa extensión, o
    None si no vale."""
    if not isinstance(asset, dict):
        return None
    # basename() porque un nombre con '../' escribiría fuera de la carpeta elegida
    nombre = os.path.basename(str(asset.get("name") or ""))
    if not nombre.lower().endswith(extension):
        return None
    url = _url_valida(asset.get("browser_download_url"))
    if not url:
        return None
    digest = str(asset.get("digest") or "")
    return {"nombre": nombre, "url": url, "tamano": int(asset.get("size") or 0),
            "sha256": digest[len("sha256:"):].lower() if digest.startswith("sha256:") else ""}


def _de_releases(datos):
    """Los APK de la release más nueva que no sea borrador ni prerelease, la de 32 bits primero."""
    if not isinstance(datos, list):
        return []
    copias = {r["sha256"]: r["copia"] for r in _RESPALDO}

    for release in datos:
        if not isinstance(release, dict) or release.get("draft") or release.get("prerelease"):
            continue
        apks = []
        for asset in release.get("assets") or []:
            apk = _fichero(asset, ".apk")
            if apk:
                nombre = apk["nombre"]
                apk.update(app=ESPAKODI, version=str(release.get("tag_name") or "").lstrip("vV"),
                           bits=64 if "arm64" in nombre else 32 if "armeabi" in nombre else 0,
                           copia=copias.get(apk["sha256"], ""))
                apks.append(apk)
        if apks:
            return sorted(apks, key=lambda a: a["bits"])
    return []


def _de_release_windows(release):
    """El .exe de la release que da la API de GitHub, que ya es la última publicada, o None."""
    if not isinstance(release, dict):
        return None
    for asset in release.get("assets") or []:
        exe = _fichero(asset, ".exe")
        if exe:
            exe.update(app=WINDOWS, version=str(release.get("tag_name") or "").lstrip("vV"),
                       bits=64, copia="")
            return exe
    return None


def _consultar(prop, url, extraer):
    """extraer() sobre el JSON de url, o None si falla. Queda en Home para el resto de la sesión.

    Se guarda el acierto y también el fallo. Cada pulsación relanza el addon, y sin guardar el
    fallo, con mala red cada visita a la pantalla volvería a esperar."""
    ventana = xbmcgui.Window(10000)
    guardado = ventana.getProperty(prop)
    if guardado == _PROP_FALLO:
        return None
    if guardado:
        try:
            return json.loads(guardado)
        except ValueError:
            pass

    valor = None
    try:
        r = requests.get(url, headers=_UA, timeout=RELEASES_TIMEOUT_S)
        r.raise_for_status()
        # Bytes con utf-8-sig y no r.json(), porque con un BOM delante r.json() falla y se usaría
        # el respaldo sin avisar
        valor = extraer(json.loads(r.content.decode("utf-8-sig")))
    except (requests.RequestException, ValueError) as e:
        _log(f"{url}: {e}", xbmc.LOGWARNING)
    ventana.setProperty(prop, json.dumps(valor) if valor else _PROP_FALLO)
    return valor or None


def entradas():
    """Lo que se puede descargar: los APK de la última EspaKodi, detrás los de EspaKodi LaRoja y,
    al final, el instalador de Windows."""
    return _espakodi() + [dict(e) for e in _LAROJA] + [_windows()]


def _espakodi():
    """Los APK de la última EspaKodi, de releases.json o, si no contesta, los de respaldo."""
    return _consultar(_PROP_CACHE, APK_RELEASES, _de_releases) or [dict(e) for e in _RESPALDO]


def _windows():
    """El instalador de la última EspaKodi para Windows o, si GitHub no contesta, el de respaldo."""
    return (_consultar(_PROP_WINDOWS, WINDOWS_RELEASE, _de_release_windows)
            or dict(_WINDOWS_RESPALDO))


def _titulo(entrada, corto=False):
    """corto, para la ventana: bajo su separador basta con "LaRoja", o con los bits en el .exe, y
    el título entero no cabe al lado de la pastilla de "Descargado"."""
    bits = f"{entrada['bits']} bits" if entrada["bits"] else entrada["nombre"]
    if entrada["app"] == WINDOWS:
        return f"EspaKodi {entrada['version']} · {bits if corto else 'Windows'}"
    app = "LaRoja" if corto and entrada["app"] == LAROJA else entrada["app"]
    return f"{app} {entrada['version']} · {bits}"


def _nota(entrada):
    if entrada["app"] == WINDOWS:
        return _PLOT_WINDOWS
    if entrada.get("nota"):
        partes = [entrada["nota"], _CONSEJO_BITS, "Más ayuda en el chat de EspaKodi (t.me/espakodi)."]
    else:
        partes = [_NOTA_ESPAKODI, _NOTA_BITS.get(entrada["bits"], ""), _CONSEJO_BITS,
                  "Más ayuda en el chat de EspaKodi (t.me/espakodi) y en espakodi.github.io/apk."]
    return "\n\n".join(p for p in partes if p)


def _tamano(n):
    n = float(n)
    for unidad in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unidad}"
        n /= 1024
    return f"{n:.1f} TB"


# --- Plataforma ---------------------------------------------------------------------------------

def _es_android():
    return xbmc.getCondVisibility("System.Platform.Android")


def _es_windows():
    return xbmc.getCondVisibility("System.Platform.Windows")


def _es_espakodi():
    """Si corremos dentro de la app EspaKodi, que trae su propio puente al instalador.

    Se reconoce por la ruta del addon, que en Android cuelga siempre de la carpeta de datos de la
    aplicación que lleva Kodi."""
    return "espakodi.kodi" in xbmcaddon.Addon().getAddonInfo("path")


def _kodi_mayor():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    except ValueError:
        return 0


def _autoinstala():
    # Con el puente de EspaKodi da igual la versión de Kodi, porque el paso de file:// a
    # content:// lo hace el propio APK con su FileProvider. Sin puente hace falta Kodi 22; hasta
    # la 21 el intent no instala nada y puede llegar a cerrar Kodi, así que ni se intenta.
    return _es_android() and (_es_espakodi() or _kodi_mayor() >= 22)


def _pista_instalacion():
    """La línea de estado de la ventana, que dice cómo acaba instalado lo descargado aquí."""
    if _es_windows():
        return "Los APK se instalan en un aparato Android y el .exe, en este PC"
    if not _es_android():
        return "Se descargan aquí para instalarlos en otro aparato"
    if _es_espakodi():
        return "Se instalan desde aquí; la primera vez, dale permiso a EspaKodi"
    if _autoinstala():
        return "Se instalan desde aquí; la primera vez, Android te pedirá permiso"
    return "Se descargan aquí y se instalan con un gestor de archivos"


# --- Carpetas -----------------------------------------------------------------------------------

def _unir(carpeta, nombre):
    # En Windows os.path.join mete '\' y rompe rutas VFS como smb://
    if "://" in carpeta:
        return carpeta.rstrip("/") + "/" + nombre
    return os.path.join(carpeta, nombre)


def _carpeta_android():
    return next((c for c in _CARPETAS_ANDROID if xbmcvfs.exists(c)), "")


def _ultima_carpeta():
    ultima = xbmcaddon.Addon().getSetting(_AJUSTE_CARPETA)
    return ultima if ultima and xbmcvfs.exists(ultima) else ""


def _carpeta_del_sistema():
    """La Download pública en Android y, en el resto, la de Descargas del usuario si la hay."""
    if _es_android():
        return _carpeta_android()
    descargas = os.path.join(os.path.expanduser("~"), "Downloads", "")
    return descargas if xbmcvfs.exists(descargas) else ""


def _carpeta_por_defecto():
    """La de la última descarga y, si no hay, la de descargas del sistema."""
    return _ultima_carpeta() or _carpeta_del_sistema()


def _carpetas_de_descarga():
    """Donde puede haber quedado una descarga: la última carpeta usada y la del sistema."""
    carpetas = [_ultima_carpeta(), _carpeta_del_sistema()]
    # /sdcard es /storage/emulated/0 con otro nombre, y la misma carpeta no se cuenta dos veces
    unicas = {}
    for c in filter(None, carpetas):
        unicas.setdefault(c.rstrip("/") if "://" in c else os.path.realpath(c), c)
    return list(unicas.values())


def _se_puede_escribir(carpeta):
    # Mejor saberlo ahora que después de bajar 100 MB
    prueba = _unir(carpeta, ".atresdaily_prueba")
    escrito = False
    fichero = xbmcvfs.File(prueba, "w")
    try:
        escrito = bool(fichero.write(bytearray(b"0")))
    finally:
        fichero.close()
    xbmcvfs.delete(prueba)
    return escrito


def _elegir_carpeta(nombre):
    """Carpeta donde guardar la descarga, o '' si el usuario se echa atrás.

    La de la última vez (la primera vez, Download en Android y Descargas en el PC) se ofrece como
    atajo, y el explorador permite otra, un USB por ejemplo. El explorador empieza vacío porque
    browse() devuelve la carpeta de partida al cancelar, y con la de siempre de partida Atrás
    descargaría igual."""
    titulo = f"Elige la carpeta donde guardar {nombre}"
    carpeta = _carpeta_por_defecto()
    if carpeta:
        eleccion = xbmcgui.Dialog().select(titulo, [f"Guardar en {carpeta}", "Elegir otra carpeta"])
        if eleccion < 0:
            return ""
        if eleccion == 0:
            return carpeta
    return xbmcgui.Dialog().browse(3, titulo, "files", "", False, False, "")


# --- Descarga -----------------------------------------------------------------------------------

def _bajar_a(url, destino, dp, mensaje):
    r = requests.get(url, headers=_UA, timeout=DESCARGA_TIMEOUT_S, stream=True)
    try:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or 0)
        bajado = 0
        fichero = xbmcvfs.File(destino, "w")
        try:
            for trozo in r.iter_content(TROZO):
                if dp.iscanceled():
                    raise _Cancelada()
                # write() no lanza, devuelve False. Sin mirarlo, un disco lleno daría una
                # descarga "correcta" con el fichero cortado dentro.
                if not fichero.write(bytearray(trozo)):
                    raise _SinEspacio("No se ha podido escribir en el disco. Puede que no quede "
                                      "espacio libre en el aparato.")
                bajado += len(trozo)
                if total:
                    dp.update(min(int(bajado * 100 / total), 100),
                              f"{mensaje}\n{_tamano(bajado)} / {_tamano(total)}")
                else:
                    dp.update(0, f"{mensaje}\n{_tamano(bajado)}")
        finally:
            fichero.close()
    finally:
        r.close()

    # bajado es lo que llegó de la red, no lo que se escribió
    escrito = xbmcvfs.Stat(destino).st_size()
    if total and escrito < total:
        raise OSError(f"Descarga incompleta ({_tamano(escrito)} de {_tamano(total)})")


def _entero(ruta, nombre):
    """False si se ve que el fichero no es lo que dice su nombre o que le falta un trozo, y None
    cuando no hay forma de saberlo, como en smb://"""
    if "://" in ruta:
        return None
    if nombre.endswith(".exe"):
        # De un .exe solo se mira la cabecera, que basta para no dar por buena una página de
        # error. Si llega cortado lo pillan el tamaño y el sha256.
        try:
            with open(ruta, "rb") as f:
                return f.read(2) == b"MZ"
        except OSError:
            return False
    # Un APK es un zip. Si llega cortado le falta el índice del final, y se ve sin tocar la red.
    return zipfile.is_zipfile(ruta)


def _sha256(ruta):
    suma = hashlib.sha256()
    fichero = xbmcvfs.File(ruta)
    try:
        while True:
            trozo = fichero.readBytes(TROZO)
            if not trozo:
                break
            suma.update(trozo)
    finally:
        fichero.close()
    return suma.hexdigest()


def _descarga_mala(ruta, nombre, sha256):
    """Por qué no se puede aceptar el fichero descargado, o '' si está bien."""
    if _entero(ruta, nombre) is False:
        _log(f"descarga dañada: {ruta}", xbmc.LOGERROR)
        return (f"{nombre} ha terminado de descargarse, pero el archivo está dañado o "
                "incompleto.\n\nInténtalo de nuevo.")
    if sha256:
        try:
            calculado = _sha256(ruta)
        except Exception as e:  # xbmcvfs no documenta qué lanza al leer; tirar 100 MB por eso no
            _log(f"no se pudo calcular el sha256 de {ruta}: {e}", xbmc.LOGWARNING)
            calculado = ""
        if calculado and calculado != sha256:
            _log(f"sha256 de {nombre}: {calculado}, se esperaba {sha256}", xbmc.LOGERROR)
            return (f"{nombre} ha terminado de descargarse, pero no es igual al publicado.\n\n"
                    "Inténtalo de nuevo.")
    return ""


def descargar(nombre):
    """Descarga uno de los ficheros de entradas() y después dice cómo instalarlo."""
    entrada = next((e for e in entradas() if e["nombre"] == nombre), None)
    if entrada is None:
        _log(f"descarga desconocida: {nombre}", xbmc.LOGWARNING)
        return

    # Cada pulsación relanza el addon, así que un Lock de Python no serviría. Sin esta marca, dos
    # pulsaciones seguidas escribirían a la vez en el mismo .part y lo romperían.
    ventana = xbmcgui.Window(10000)
    pestillo = _PESTILLO + nombre
    if ventana.getProperty(pestillo) == "true":
        xbmcgui.Dialog().notification(HEADING, f"Ya se está descargando {nombre}",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return
    ventana.setProperty(pestillo, "true")
    try:
        _descargar(entrada)
    finally:
        ventana.clearProperty(pestillo)


def _descargar(entrada):
    nombre = entrada["nombre"]
    carpeta = _elegir_carpeta(nombre)
    if not carpeta:
        return
    if not _se_puede_escribir(carpeta):
        xbmcgui.Dialog().ok(HEADING, f"No se puede escribir en esta carpeta:\n{carpeta}\n\nElige otra.")
        return
    xbmcaddon.Addon().setSetting(_AJUSTE_CARPETA, carpeta)

    destino = _unir(carpeta, nombre)
    parcial = destino + ".part"

    if xbmcvfs.exists(destino):
        if _entero(destino, nombre) is False:
            xbmcgui.Dialog().ok(HEADING, f"El {nombre} que ya tenías está dañado o incompleto.\n\n"
                                         "Se va a descargar de nuevo.")
            xbmcvfs.delete(destino)
        elif not xbmcgui.Dialog().yesno(HEADING, f"{nombre} ya está en esa carpeta.\n\n"
                                                 "¿Quieres descargarlo de nuevo?",
                                        nolabel="Usar el que ya está", yeslabel="Descargar de nuevo"):
            # Ya está y está bien, así que se sigue con ese en vez de bajar otros 100 MB para nada
            _tras_descarga(destino, nombre)
            return
        else:
            xbmcvfs.delete(destino)
    if xbmcvfs.exists(parcial):
        xbmcvfs.delete(parcial)

    mensaje = f"Descargando {nombre}..."
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, mensaje)
    error = ""
    try:
        # Un fichero cortado o distinto del publicado también pasa a la copia. Es el mismo APK, y
        # una copia mala en un sitio no dice nada del otro.
        for url in filter(None, (entrada["url"], entrada.get("copia"))):
            try:
                _bajar_a(url, parcial, dp, mensaje)
            except _Cancelada:
                xbmcvfs.delete(parcial)
                xbmcgui.Dialog().notification(HEADING, "Descarga cancelada",
                                              xbmcgui.NOTIFICATION_INFO, 3000)
                return
            except _SinEspacio as e:
                # Es el disco y no el servidor; con la copia se llenaría igual, tras otra espera
                error = f"No se ha podido guardar {nombre}.\n\n{e}"
                xbmcvfs.delete(parcial)
                break
            except (requests.RequestException, OSError) as e:
                _log(f"descargando {nombre} de {url}: {e}", xbmc.LOGWARNING)
                error = f"No se ha podido descargar {nombre}.\n\n{e}"
            else:
                error = _descarga_mala(parcial, nombre, entrada.get("sha256", ""))
                if not error:
                    break
            xbmcvfs.delete(parcial)
    finally:
        dp.close()

    if error:
        xbmcgui.Dialog().ok(HEADING, error)
        return

    # El nombre final solo lo lleva una descarga completa, así un APK a medias nunca parece
    # instalable.
    if not xbmcvfs.rename(parcial, destino):
        if not xbmcvfs.copy(parcial, destino):
            xbmcvfs.delete(parcial)
            xbmcgui.Dialog().ok(HEADING, f"{nombre} se ha descargado bien, pero no se ha podido "
                                         "guardar en la carpeta elegida.\n\nPrueba con otra carpeta.")
            return
        xbmcvfs.delete(parcial)

    _log(f"descargado en {destino}")
    _tras_descarga(destino, nombre)


# --- Instalación --------------------------------------------------------------------------------

def _lanzar_instalador(ruta):
    uri = "file://" + urllib.parse.quote(ruta, safe="/")
    if _es_espakodi():
        # El puente del propio APK hace el paso a content:// que Kodi 21 no hace; sin él, en
        # EspaKodi el intent directo no instala nada.
        orden = (f'StartAndroidActivity("espakodi.kodi","ekapk.install","","{uri}",'
                 f'"","","","","espakodi.kodi.EkApk")')
    else:
        orden = ('StartAndroidActivity("", "android.intent.action.VIEW", '
                 f'"application/vnd.android.package-archive", "{uri}", "1")')
    _log(f"instalador de Android: {orden}")
    xbmc.executebuiltin(orden)


def _instrucciones(ruta):
    return (f"APK descargado en:\n{ruta}\n\nPara instalarlo:\n"
            '1) Abre un gestor de archivos del aparato (en Fire TV, la app "Downloader"; en el '
            'móvil, "Archivos" o "Mis archivos").\n'
            "2) Entra en esa carpeta y pulsa el APK.\n"
            "3) Si Android pide permiso para instalar apps de origen desconocido, dáselo a ESA app "
            "(el gestor de archivos), no a Kodi.")


def _copiar_con_progreso(origen, destino, mensaje):
    # xbmcvfs.copy() deja Kodi congelado, sin barra ni forma de cancelar, y un APK son 100 MB.
    # Se copia a trozos, como al descargar.
    dp = xbmcgui.DialogProgress()
    dp.create(HEADING, mensaje)
    try:
        fuente = xbmcvfs.File(origen)
        try:
            total = fuente.size()
            copia = xbmcvfs.File(destino, "w")
            try:
                copiado = 0
                while True:
                    if dp.iscanceled():
                        raise _Cancelada()
                    trozo = fuente.readBytes(TROZO)
                    if not trozo:
                        break
                    if not copia.write(trozo):
                        raise _SinEspacio("No se ha podido escribir en el disco. Puede que no "
                                          "quede espacio libre en el aparato.")
                    copiado += len(trozo)
                    if total:
                        dp.update(min(int(copiado * 100 / total), 100),
                                  f"{mensaje}\n{_tamano(copiado)} / {_tamano(total)}")
            finally:
                copia.close()
        finally:
            fuente.close()
    finally:
        dp.close()

    escrito = xbmcvfs.Stat(destino).st_size()
    if total and escrito < total:
        raise OSError(f"Copia incompleta ({_tamano(escrito)} de {_tamano(total)})")


def _preparar_publico(ruta):
    """La ruta del APK en la zona pública, la única que ve el instalador de Android, o None.

    Si se guardó en otra (la privada de Kodi, por ejemplo), se copia a Download."""
    if ruta.startswith("/storage/"):
        return ruta

    carpeta = _carpeta_android()
    if not carpeta:
        _log("sin almacenamiento público donde preparar el APK", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(HEADING, "No se encuentra la carpeta Download del aparato para "
                                     "dárselo al instalador.\n\nInstálalo a mano desde un gestor "
                                     "de archivos.")
        return None

    destino = _unir(carpeta, os.path.basename(ruta))
    # /sdcard/Download es /storage/emulated/0/Download con otro nombre, y copiar el APK encima de
    # sí mismo empezaría borrando la única copia que hay
    if "://" not in ruta and os.path.realpath(ruta) == os.path.realpath(destino):
        return destino

    if xbmcvfs.exists(destino):
        xbmcvfs.delete(destino)
    try:
        _copiar_con_progreso(ruta, destino, "Preparando el APK para el instalador...")
    except _Cancelada:
        xbmcvfs.delete(destino)
        return None
    except (OSError, _SinEspacio) as e:
        xbmcvfs.delete(destino)
        _log(f"no se pudo copiar {ruta} a la zona pública: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(HEADING, f"No se ha podido preparar {os.path.basename(ruta)} para el "
                                     f"instalador.\n\n{e}")
        return None
    _log(f"APK preparado en la zona pública: {destino}")
    return destino


def _instalar_con_root(ruta):
    """pm install con el permiso de Kodi o con su. Solo funciona con root o con Kodi como app de
    sistema, como lo traen algunos TV box."""
    for orden in (["pm", "install", "-r", ruta], ["su", "-c", f'pm install -r "{ruta}"']):
        try:
            proc = subprocess.run(orden, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                  timeout=PM_INSTALL_TIMEOUT_S, check=False)
        except (OSError, subprocess.SubprocessError) as e:
            _log(f"pm install ({orden[0]}): {e}")
            continue
        salida = (proc.stdout or b"").decode("utf-8", "replace").strip()
        _log(f"pm install ({orden[0]}): rc={proc.returncode} {salida}")
        if proc.returncode == 0 and "Success" in salida:
            return True
    return False


def _en_espakodi_windows():
    """Si este Kodi es EspaKodi para Windows, que lleva en su carpeta el icono de sus accesos."""
    return xbmcvfs.exists("special://xbmc/EspaKodi.ico")


def _abrir_instalador(ruta, cerrar_kodi):
    try:
        os.startfile(ruta)
    except OSError as e:
        _log(f"no se pudo abrir {ruta}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(HEADING, f"No se ha podido abrir el instalador ({e}).\n\nÁbrelo desde "
                                     f"el Explorador de archivos:\n{ruta}")
        return
    # A pantalla completa, Kodi taparía el instalador. EspaKodi, además, tiene que estar cerrado
    # para que el instalador pueda sustituir sus ficheros.
    xbmc.executebuiltin("Quit" if cerrar_kodi else "Minimize")


def _tras_descarga_exe(ruta):
    if not _es_windows():
        xbmcgui.Dialog().ok(HEADING, "Es el instalador de EspaKodi para Windows 10 y 11, así que "
                                     "solo se instala en un PC con Windows.\n\nSe ha guardado "
                                     f"en:\n{ruta}")
        return
    # El Python de Kodi para Windows lo trae; el de la tienda de Microsoft puede que no
    if getattr(os, "startfile", None) is None:
        xbmcgui.Dialog().ok(HEADING, f"Se ha guardado en:\n{ruta}\n\nÁbrelo desde el Explorador de "
                                     "archivos para instalar EspaKodi.")
        return

    # Cuatro líneas como mucho, que es lo que enseña el diálogo sin desplazar el texto
    en_espakodi = _en_espakodi_windows()
    if en_espakodi:
        # El instalador 0.0.4 no mira si EspaKodi está abierto, y copia encima su portable_data
        # con favourites.xml y guisettings.xml incluidos
        texto = (f"Se ha guardado en:\n{ruta}\nAl abrirlo se cierra EspaKodi, y encima de la que "
                 "tienes deja los favoritos y los ajustes como vienen de fábrica.")
    else:
        texto = (f"Se ha guardado en:\n{ruta}\n\nPuedes abrirlo ahora o luego desde el Explorador "
                 "de archivos.")
    if xbmcgui.Dialog().yesno(HEADING, texto, nolabel="Cerrar", yeslabel="Abrir el instalador"):
        _abrir_instalador(ruta, cerrar_kodi=en_espakodi)


def _tras_descarga(ruta, nombre):
    if nombre.endswith(".exe"):
        _tras_descarga_exe(ruta)
        return

    if not _es_android():
        xbmcgui.Dialog().ok(HEADING, f"{nombre}\n\nEs un instalador de Android (APK), así que solo "
                                     "se instala en aparatos Android (Fire TV, Android TV, "
                                     f"móviles...).\n\nSe ha guardado en:\n{ruta}")
        return

    autoinstala = _autoinstala()
    while True:
        opciones, acciones = [], []
        if autoinstala:
            opciones.append("Instalar ahora")
            acciones.append("instalar")
        opciones += ["Instalar a mano (cualquier aparato)", "Abrir ajustes de orígenes desconocidos"]
        acciones += ["mano", "origenes"]
        if not autoinstala:
            # Sin puente ni Kodi 22 el intent no instala, pero con root o con Kodi como app de
            # sistema pm install sí
            opciones.append("Instalar ahora (root o Kodi como app de sistema)")
            acciones.append("root")
        opciones.append("Cerrar")
        acciones.append("cerrar")

        elegida = xbmcgui.Dialog().select(f"{HEADING}: instalar {nombre}", opciones)
        accion = acciones[elegida] if elegida >= 0 else "cerrar"
        if accion == "cerrar":
            return
        if accion == "origenes":
            xbmc.executebuiltin('StartAndroidActivity("", "android.settings.MANAGE_UNKNOWN_APP_SOURCES")')
            return
        if accion == "mano":
            xbmcgui.Dialog().ok(HEADING, _instrucciones(ruta))
            continue

        publica = _preparar_publico(ruta)
        if not publica:
            continue
        if accion == "instalar":
            _lanzar_instalador(publica)
            return
        if _instalar_con_root(publica):
            xbmcgui.Dialog().ok(HEADING, "APK instalado correctamente.")
            return
        xbmcgui.Dialog().ok(HEADING, "No se ha podido instalar solo, porque hace falta root o que "
                                     "Kodi sea una app de sistema.\n\nInstálalo a mano desde un "
                                     "gestor de archivos.")


# --- Borrar lo descargado -----------------------------------------------------------------------

def _restos():
    """[(ruta, tamaño)] de los APK y los .exe de EspaKodi, enteros o a medias, en las carpetas de
    descarga.

    Solo los que se llaman como los publica EspaKodi, así nunca se ofrece un fichero ajeno."""
    en_marcha = xbmcgui.Window(10000)
    restos = []
    for carpeta in _carpetas_de_descarga():
        _dirs, ficheros = xbmcvfs.listdir(carpeta)
        for f in sorted(ficheros):
            nombre = f[:-len(".part")] if f.endswith(".part") else f
            if not nombre.startswith(_PREFIJOS) or not nombre.endswith((".apk", ".exe")):
                continue
            # Lo que aún se está descargando no es un resto, y borrar su .part lo rompería
            if en_marcha.getProperty(_PESTILLO + nombre) == "true":
                continue
            ruta = _unir(carpeta, f)
            restos.append((ruta, xbmcvfs.Stat(ruta).st_size()))
    return restos


def borrar_descargas():
    """El botón "Borrar descargas". Devuelve 'refrescar' si ha borrado algo."""
    restos = _restos()
    if not restos:
        xbmcgui.Dialog().notification(HEADING, "No hay ninguna descarga de EspaKodi",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return None

    opciones = [f"{os.path.basename(ruta)}  ·  {_tamano(tam)}"
                + (", descarga a medias" if ruta.endswith(".part") else "")
                for ruta, tam in restos]
    # Todo marcado, porque una vez instalados lo normal es borrarlos todos; quien quiera guardar
    # uno lo desmarca.
    elegidos = xbmcgui.Dialog().multiselect("Borrar lo marcado", opciones,
                                            preselect=list(range(len(restos))))
    if not elegidos:
        return None

    liberado, fallidos = 0, []
    for ruta, tam in (restos[i] for i in elegidos):
        # Si ya no está (se borró por otro nombre de su carpeta o con un gestor), cuenta igual
        if xbmcvfs.delete(ruta) or not xbmcvfs.exists(ruta):
            liberado += tam
        else:
            fallidos.append(os.path.basename(ruta))

    if fallidos:
        xbmcgui.Dialog().ok(HEADING, "Esto no se ha podido borrar:\n" + "\n".join(fallidos)
                            + "\n\nPrueba desde un gestor de archivos.")
    else:
        xbmcgui.Dialog().notification(HEADING, f"Liberados {_tamano(liberado)}",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    return "refrescar"


# --- Bits y web ---------------------------------------------------------------------------------

def info_bits():
    xbmcgui.Dialog().textviewer("¿32 o 64 bits?", _TEXTO_BITS)


def abrir_web():
    espakodi_installer.abrir_url(APK_WEB, "Web del APK de EspaKodi",
                                 "Todas las versiones de la app EspaKodi, con sus novedades:",
                                 "Abriendo la web...")


def abrir_telegram():
    espakodi_installer.abrir_url(TELEGRAM, "Telegram de EspaKodi",
                                 "Más versiones de EspaKodi, para LibreELEC, CoreELEC, Linux y "
                                 "variantes de Android:",
                                 "Abriendo Telegram...")


# --- Pantallas ----------------------------------------------------------------------------------

def _icono(nombre):
    return os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media", nombre)


def _descargado(carpeta, entrada):
    return bool(carpeta) and xbmcvfs.exists(_unir(carpeta, entrada["nombre"]))


def _filas(lista):
    carpeta = _carpeta_por_defecto()
    # Arriba del todo, porque la ventana abre con el foco en la primera fila y un separador no lo
    # recibe
    filas = [list_screen.Fila(clave=_CLAVE_TELEGRAM, titulo="Más versiones en Telegram",
                              pista="LibreELEC, CoreELEC, Linux y más",
                              icono=_icono("ek_telegram.png"), plot=_PLOT_TELEGRAM)]
    for n, e in enumerate(lista):
        if not n or e["app"] != lista[n - 1]["app"]:
            filas.append(list_screen.Fila(clave="", titulo=e["app"], sep=True,
                                          plot=_PLOT_SEPARADOR.get(e["app"], "")))
        pista = _PISTAS.get((e["app"], e["bits"]), e["nombre"])
        if e["tamano"]:
            pista += f" · {_tamano(e['tamano'])}"
        filas.append(list_screen.Fila(
            clave=e["nombre"], titulo=_titulo(e, corto=True), pista=pista,
            icono=_icono("ek_windows.png" if e["app"] == WINDOWS else "ek_apk.png"),
            pastilla=(list_screen.color("Descargado", list_screen.TINTA_VERDE), "on")
            if _descargado(carpeta, e) else None,
            plot=_nota(e)))
    return filas


def mostrar_ventana():
    """Descargar EspaKodi en ventana propia. False si no se pudo abrir."""
    # La primera visita de la sesión lee releases.json y la release de Windows, y sin el spinner
    # serían segundos de menú congelado
    with list_screen.ocupado():
        lista = entradas()
    nombres = {e["nombre"] for e in lista}

    def pulsar(fila):
        if fila.clave == _CLAVE_TELEGRAM:
            abrir_telegram()
        elif fila.clave in nombres:
            descargar(fila.clave)

    return list_screen.mostrar(
        titulo=list_screen.titulo_ventana("Descargar EspaKodi"),
        subtitulo="Android y Windows",
        hacer_filas=lambda: _filas(lista),
        al_pulsar=pulsar,
        botones=(("Web del APK", abrir_web), ("Borrar descargas", borrar_descargas)),
        estado=_pista_instalacion(),
        pista="[B]OK[/B] descarga    ·    [B]Derecha[/B] lee    ·    [B]Atrás[/B] cierra")


def render_menu(handle):
    """Descargar EspaKodi como lista de Kodi, para cuando no se usa la ventana propia."""
    lista = entradas()
    carpeta = _carpeta_por_defecto()
    fanart = xbmcaddon.Addon().getAddonInfo("fanart")

    def fila(label, icono, plot, **params):
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _icono(icono), "fanart": fanart})
        li.setInfo("video", {"plot": plot})
        url = sys.argv[0] + "?" + urllib.parse.urlencode(params)
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

    fila("[COLOR FF2AABEE]Más versiones en Telegram[/COLOR] (LibreELEC, CoreELEC, Linux y más)",
         "ek_telegram.png", _PLOT_TELEGRAM, action="ek_telegram")
    # La ayuda de los bits va arriba y no junto a los APK, porque detrás de ellos va el .exe
    fila("[COLOR yellow]¿32 o 64 bits?[/COLOR] Pulsa para saber cuál bajar", "info.png", _TEXTO_BITS,
         action="ek_apk_bits")
    for e in lista:
        marca = " - [COLOR lime]Descargado[/COLOR]" if _descargado(carpeta, e) else ""
        fila(f"{_titulo(e)}{marca}", "ek_windows.png" if e["app"] == WINDOWS else "ek_apk.png",
             _nota(e), action="ek_apk", nombre=e["nombre"])
    fila("Web del APK (todas las versiones)", "ek_web.png", _PLOT_WEB, action="ek_apk_web")
    fila("Borrar descargas", "backup_delete.png", _PLOT_BORRAR, action="ek_apk_borrar")
    xbmcplugin.endOfDirectory(handle)
