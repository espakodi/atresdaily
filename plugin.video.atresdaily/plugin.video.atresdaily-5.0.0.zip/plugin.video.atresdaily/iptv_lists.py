# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Listas de canales del usuario: añadirlas, verlas, gestionarlas y reproducirlas.

Cada lista es solo su descripción (iptv_store); los canales se leen de la fuente al
abrirla con iptv_parse. AceStream, los torrents y las
páginas de plataformas no se reproducen aquí, sino por la cadena de url_player (StreamNinja,
EKHorus/Horus, motor local; Debrid, Elementum; resolvers de Dailymotion y YouTube).
"""
import functools
import json
import os
import re
import socket
import sys
import time
import urllib.parse
import warnings
from contextlib import contextmanager

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import epg_texto
import grabaciones
import iptv_guide
import iptv_parse as P
import iptv_store
import telegram_scanner
import ui_utils

_ADDON = xbmcaddon.Addon()
_HEADING = 'AtresDaily'
_LOG = '[AtresDaily/IPTV]'
_BASE = 'plugin://plugin.video.atresdaily/'
STORE = iptv_store.Store(xbmcvfs.translatePath(_ADDON.getAddonInfo('profile')))

_TTL = {'url': 6 * 3600, 'xtream': 6 * 3600, 'web': 1800, 'telegram': 1800, 'engine': 24 * 3600}
_ENGINE_PAGE = 200
# Tope por si un motor devolviera páginas sin fin. Hoy el catálogo son unas diez.
_ENGINE_MAX_PAGES = 20
_ENGINE_NAME = 'Canales AceStream'
_EKHORUS = 'script.module.horus'
_ENGINE_LOCAL = ('127.0.0.1', 'localhost', '::1')
_ENGINE_FACET_ICON = {'cats': 'iptv_categorias.png', 'countries': 'iptv_paises.png',
                      'langs': 'iptv_idiomas.png', 'pl': 'iptv_grupos.png'}
_MAX_DOWNLOAD = 20 * 1024 * 1024
_MAX_FILE = 20 * 1024 * 1024
_MAX_XTREAM = 30 * 1024 * 1024
_TIMEOUT = (6, 20)
_TIMEOUT_QUIET = (6, 15)
_SUBLISTS_BUDGET_S = 90
_TELEGRAM_PAGES = 3
# Al actualizar a mano, perder más de la mitad de los canales se pregunta. Al abrir, una
# fuente que de golpe devuelve menos de la quinta parte no sustituye la copia buena.
_ASK_BELOW = 0.5
_KEEP_BELOW = 0.2
_SEARCH_ITEM_FROM = 50
_NAME_MAX = 60
_UA_VLC = 'VLC/3.0.20 LibVLC/3.0.20'
_GUIDE_SEEN = 'iptv_guide_seen'
_LINK_RE = re.compile(r'^(?:https?://|acestream://|@|(?:www\.)?t\.me/|[0-9a-f]{40}$)', re.I)
_ACE_TOKEN_RE = re.compile(r'(acestream://[0-9a-fA-F]{40}|(?<![0-9A-Za-z])[0-9a-fA-F]{40}(?![0-9A-Za-z]))')

_KIND_LABEL = {'url': 'Lista de internet', 'file': 'Archivo', 'text': 'Pegada o enviada',
               'web': 'Web', 'telegram': 'Canal de Telegram', 'xtream': 'Servidor Xtream',
               'engine': _ENGINE_NAME}
_KIND_ICON = {'url': 'url.png', 'file': 'adv_ruta_dl.png', 'text': 'url_paste.png',
              'web': 'url_scan.png', 'telegram': 'url_scan.png', 'xtream': 'tv.png',
              'engine': 'adv_acestream.png'}

_FAST_M3U = 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/refs/heads/main/playlists/'
# all.api apunta a los servidores de Radio Browser que estén en marcha, que cambian con los años.
# En JSON y no en M3U, porque solo el JSON trae con qué repartirlas en carpetas (iptv_parse).
_RADIO_JSON = 'https://all.api.radio-browser.info/json/stations/'
_RADIO_QUERY = '?hidebroken=true&limit=100000'

CATALOG = (
    ('TDTChannels · Televisión', 'https://www.tdtchannels.com/lists/tv.m3u8',
     'Los canales de la TDT española en abierto (nacionales, autonómicos y locales), con '
     'guía de programación.'),
    ('iptv-org · España', 'https://iptv-org.github.io/iptv/countries/es.m3u',
     'Canales españoles en abierto recopilados por el proyecto iptv-org.'),
    ('Samsung TV Plus · España', _FAST_M3U + 'samsungtvplus_es.m3u',
     'Los canales gratuitos de Samsung TV Plus en España, por temáticas y con guía de '
     'programación.'),
    ('LG Channels · España', 'https://www.apsattv.com/eslg.m3u',
     'Los canales gratuitos de LG Channels en España, con La 1 y La 2 entre ellos.'),
    ('Rakuten TV · España', 'https://www.apsattv.com/rakuten_es.m3u',
     'Los canales gratuitos de Rakuten TV en España, por temáticas.'),
    ('Pluto TV · España', _FAST_M3U + 'plutotv_es.m3u',
     'Los canales gratuitos de Pluto TV en España, por temáticas y con guía de programación.'),
    ('Plex · España', _FAST_M3U + 'plex_es.m3u',
     'Los canales gratuitos de Plex en España, con guía de programación.'),
    ('TDTChannels · Radio', 'https://www.tdtchannels.com/lists/radio.m3u8',
     'Emisoras de radio españolas en directo, por comunidades y temáticas.'),
    ('Radio Browser · España', _RADIO_JSON + 'bycountrycodeexact/es' + _RADIO_QUERY,
     'Más de mil emisoras españolas por géneros, con una carpeta de las más escuchadas.'),
    ('Radio Browser · En español', _RADIO_JSON + 'bylanguageexact/spanish' + _RADIO_QUERY,
     'Emisoras en español de todo el mundo por países, con las más escuchadas. Lista grande.'),
    ('iptv-org · En español', 'https://iptv-org.github.io/iptv/languages/spa.m3u',
     'Canales en español de todo el mundo. Lista grande.'),
    ('iptv-org · Noticias', 'https://iptv-org.github.io/iptv/categories/news.m3u',
     'Canales de noticias de todo el mundo.'),
    ('iptv-org · Deportes', 'https://iptv-org.github.io/iptv/categories/sports.m3u',
     'Canales deportivos en abierto de todo el mundo.'),
    ('iptv-org · Música', 'https://iptv-org.github.io/iptv/categories/music.m3u',
     'Canales de música de todo el mundo.'),
    ('Free-TV', 'https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8',
     'Canales gratuitos de todo el mundo revisados a mano por el proyecto Free-TV.'),
)

ADD_PLOT = (
    'Guarda una lista de canales en directo para tenerla aquí mismo, debajo de TDT Channels.\n\n'
    'Puedes añadirla de nueve formas:\n'
    '• Escribir o pegar un enlace: listas M3U, M3U8 o de Wiseplay (W3U), webs, canales de Telegram, '
    'enlaces AceStream o la dirección de un servidor Xtream.\n'
    '• Enviar desde el móvil o el PC: pega la lista o sube el archivo desde el navegador, '
    'sin escribir con el mando.\n'
    '• Archivo del dispositivo: de este aparato, de una memoria USB o de una carpeta de red.\n'
    '• Pegar del portapapeles (Windows, macOS y Linux).\n'
    '• Canal de Telegram o web con enlaces: recoge las emisiones que se publican.\n'
    '• Enlaces AceStream sueltos.\n'
    '• Canales AceStream: canales de televisión en directo, con buscador y filtros por '
    'categoría, país e idioma, como en EKHorus.\n'
    '• Servidor Xtream Codes, con sus canales por categorías.\n'
    '• Listas públicas listas para usar.\n\n'
    'Con el menú contextual de cada lista puedes actualizarla, renombrarla, ordenarla, verla '
    'en la TV de Kodi o borrarla.\n\n'
    'La primera vez se abre la guía. Después la tienes dentro de este botón, en el menú de '
    'cada lista y en EspaKodi e Información.')

_LIST_CONTEXT_HELP = (
    'Menú contextual: Actualizar ahora, Renombrar, Subir, Bajar, Mostrar u ocultar en la TV '
    'de Kodi, Información, Eliminar y la guía.')


class _Cancelled(Exception):
    """El usuario ha cancelado."""


class _NeedsInsecure(Exception):
    """El servidor tiene un certificado HTTPS no válido."""


class _NoXtreamApi(P.ListError):
    """El servidor no contesta a player_api.php como un Xtream."""


def _u(**params):
    return _BASE + '?' + urllib.parse.urlencode({k: v for k, v in params.items() if v not in (None, '')})


def _icon(name):
    return ui_utils.media_icon(name) or 'DefaultAddonPVRClient.png'


@functools.lru_cache(maxsize=None)
def _media_names(folder):
    """PNG de una carpeta de resources/media. Se lee una sola vez, porque una vista de países
    tiene hasta setenta filas."""
    try:
        return frozenset(n[:-4] for n in os.listdir(_media_dir(folder)) if n.endswith('.png'))
    except OSError:
        return frozenset()


def _media_dir(folder):
    return os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'media', folder)


def _media(folder, name):
    """Ruta de resources/media/<folder>/<name>.png, o '' si no está."""
    return os.path.join(_media_dir(folder), name + '.png') if name in _media_names(folder) else ''


@functools.lru_cache(maxsize=1)
def _no_logo():
    return _icon('directo.png')


def _facet_icon(field, key):
    """Como en Canales de EKHorus: bandera en países e idiomas (el globo si no hay una fiel) e
    icono propio en categorías y grupos."""
    if field in ('countries', 'langs'):
        return _media('banderas', P.engine_flag(field, key)) or _media('banderas', 'mundo') or 'DefaultFolder.png'
    return _media('categorias', P.engine_icon_key(field, key)) or _icon('directo.png')


def _notify(text, level=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(_HEADING, text, level, ms)


# El cuadro de Aceptar de Kodi enseña unas cuatro líneas de este ancho y corta el resto sin
# avisar ni dejar desplazarse.
_DIALOG_LINES = 4
_DIALOG_CHARS = 58


def show_message(text):
    """Un aviso que siempre se lee entero: el cuadro de Aceptar si cabe y, si no, el visor de
    texto, que se puede desplazar."""
    lines = sum(max(1, -(-len(par) // _DIALOG_CHARS)) for par in str(text).split('\n'))
    if lines <= _DIALOG_LINES:
        xbmcgui.Dialog().ok(_HEADING, text)
    else:
        xbmcgui.Dialog().textviewer(_HEADING, text)


def _mask(text):
    """Quita las credenciales de Xtream y los tokens de un texto para el log."""
    s = re.sub(r'(/(?:live|movie|series)/)[^/]+/[^/]+/', r'\1***/***/', str(text or ''))
    return re.sub(r'((?:username|password|pass|token|key)=)[^&\s]+', r'\1***', s, flags=re.I)


def _log(text, level=xbmc.LOGINFO):
    xbmc.log(f'{_LOG} {_mask(text)}', level)


def _kodi_major():
    try:
        return int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
    except ValueError:
        return 21


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _end(succeeded=True, cache=True):
    h = _handle()
    if h >= 0:
        xbmcplugin.endOfDirectory(h, succeeded=succeeded, cacheToDisc=cache)


def _refresh_container():
    xbmc.executebuiltin('Container.Refresh')


@contextmanager
def _progress(text):
    dp = xbmcgui.DialogProgress()
    dp.create(_HEADING, text)
    try:
        yield dp
    finally:
        dp.close()


def _fmt_date(ts):
    try:
        return time.strftime('%d/%m/%Y %H:%M', time.localtime(float(ts))) if ts else 'nunca'
    except (TypeError, ValueError, OverflowError, OSError):
        return 'nunca'


def _canales(n):
    return '1 canal' if n == 1 else f'{n} canales'


# --- Descargas ---

def _refuse_lan_redirect(r, *_args, **_kwargs):
    """Hook de requests para las listas enlazadas desde internet: no siguen una redirección a la
    red de casa."""
    if r.is_redirect and P.is_lan_url(urllib.parse.urljoin(r.url, r.headers.get('location', ''))):
        r.close()
        raise P.ListError('La lista redirige a una dirección de la red de casa.')


def _download(url, insecure=False, dp=None, limit=_MAX_DOWNLOAD, proxies=None, timeout=_TIMEOUT,
              deadline=None, lan_ok=True):
    """bytes de url, con tope de tamaño y cancelable desde dp. Lanza P.ListError con el
    motivo, _NeedsInsecure o _Cancelled. Ante un 403 se reintenta una vez como VLC: hay
    proveedores que solo sirven a reproductores. deadline (time.monotonic) corta a un servidor
    que manda la lista gota a gota, que el timeout de lectura no para."""
    status = None
    hooks = None if lan_ok else {'response': _refuse_lan_redirect}
    for ua in (ui_utils.HEADERS['User-Agent'], _UA_VLC):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                with requests.get(url, headers={'User-Agent': ua, 'Accept': '*/*'}, timeout=timeout,
                                  stream=True, verify=not insecure, proxies=proxies, hooks=hooks) as r:
                    status = r.status_code
                    if status == 403 and ua != _UA_VLC:
                        continue
                    if status != 200:
                        raise P.ListError(f'El servidor ha respondido con un error {status}.')
                    chunks, total = [], 0
                    for chunk in r.iter_content(65536):
                        if dp is not None and dp.iscanceled():
                            raise _Cancelled()
                        if deadline is not None and time.monotonic() > deadline:
                            raise P.ListError('La lista tarda demasiado en llegar.')
                        total += len(chunk)
                        if total > limit:
                            raise P.ListError(f'La lista pasa de {limit // (1024 * 1024)} MB y no se puede cargar.')
                        chunks.append(chunk)
                    return b''.join(chunks)
        except requests.exceptions.SSLError as e:
            raise _NeedsInsecure() from e
        except requests.exceptions.Timeout as e:
            raise P.ListError('El servidor no ha respondido a tiempo.') from e
        except requests.exceptions.ConnectionError as e:
            raise P.ListError('No se ha podido conectar con el servidor. Revisa la dirección '
                              'y la conexión (y la VPN, si usas una).') from e
        except requests.RequestException as e:
            raise P.ListError(f'No se ha podido descargar: {e}') from e
    raise P.ListError(f'El servidor ha respondido con un error {status}.')


def _proxy():
    """El proxy de "Buscar directos en AceStream", si está activado. Es el mismo respaldo que
    usa el escáner de webs y Telegram cuando la operadora los bloquea."""
    cfg = ui_utils.load_json('acestream_proxy.json', default={})
    if isinstance(cfg, dict) and cfg.get('enabled') and cfg.get('addr'):
        addr = str(cfg['addr'])
        url = addr if '://' in addr else f'http://{addr}'
        return {'http': url, 'https': url}
    return None


def _download_page(url, insecure=False, dp=None, timeout=_TIMEOUT):
    try:
        return _download(url, insecure, dp, timeout=timeout)
    except P.ListError:
        proxies = _proxy()
        if not proxies:
            raise
        _log(f'descarga directa de {url} fallida, reintento con el proxy', xbmc.LOGWARNING)
        return _download(url, insecure, dp, proxies=proxies, timeout=timeout)


def _read_file(path):
    if not xbmcvfs.exists(path):
        raise P.ListError('El archivo ya no está en su sitio (¿una memoria USB que se ha quitado?).')
    f = xbmcvfs.File(path)
    try:
        if f.size() > _MAX_FILE:
            raise P.ListError('El archivo pasa de 20 MB y no se puede cargar.')
        return bytes(f.readBytes())
    finally:
        f.close()


def _file_mtime(path):
    try:
        return int(xbmcvfs.Stat(path).st_mtime())
    except (RuntimeError, OSError, TypeError, ValueError) as e:
        _log(f'sin fecha para {path}: {e}', xbmc.LOGDEBUG)
        return None


def _parse_file(path, fetch=None):
    """Canales de un archivo. Si enlaza otras listas, se apunta su fecha, que _is_fresh compara
    con la de ahora. Se toma antes de leerlo, así que si cambia mientras se bajan las listas
    enlazadas, la próxima vez no coincide y se vuelve a leer."""
    mtime = _file_mtime(path) if fetch is not None else None
    parsed = P.parse_any(P.decode(_read_file(path)), base_url=path, fetch=fetch)
    if parsed.get('sublists'):
        parsed['mtime'] = mtime
    return parsed


def _sublist_fetcher(insecure, dp, timeout):
    """El fetch de parse_any para las listas que enlaza una W3U. Corta al cancelar o al cerrarse
    Kodi. Pasados _SUBLISTS_BUDGET_S, o bajado entre todas lo que puede pesar una lista
    (_MAX_DOWNLOAD), las que quedan se saltan como las que fallan."""
    deadline = time.monotonic() + _SUBLISTS_BUDGET_S
    read = 0
    logged = set()

    def skip(reason):
        if reason not in logged:
            logged.add(reason)
            _log(f'listas enlazadas: {reason}; las que faltan no se leen', xbmc.LOGWARNING)
        raise P.ListError(reason)

    def fetch(url, n, total, lan_ok):
        nonlocal read
        if (dp is not None and dp.iscanceled()) or xbmc.Monitor().abortRequested():
            raise _Cancelled()
        if time.monotonic() > deadline:
            skip('se ha agotado el tiempo')
        if read >= _MAX_DOWNLOAD:
            skip(f'entre todas pasan de {_MAX_DOWNLOAD // (1024 * 1024)} MB')
        total = max(total, n, 1)
        if dp is not None:
            dp.update(n * 100 // total, f'Leyendo las listas enlazadas ({n} de {total})...')
        try:
            text = P.decode(_download(url, insecure, dp, timeout=timeout, deadline=deadline, lan_ok=lan_ok))
        except (P.ListError, _NeedsInsecure) as e:
            reason = str(e) or 'El certificado HTTPS no es válido.'
            _log(f'lista enlazada {url} sin leer: {reason}', xbmc.LOGWARNING)
            raise P.ListError(reason) from e
        read += len(text)
        return text
    return fetch


def _telegram_html(channel, dp=None, timeout=_TIMEOUT):
    """Las últimas páginas públicas del canal (t.me/s/canal), de la más nueva a la más vieja."""
    pages, before = [], None
    for _ in range(_TELEGRAM_PAGES):
        url = f'https://t.me/s/{channel}' + (f'?before={before}' if before else '')
        try:
            html = P.decode(_download_page(url, dp=dp, timeout=timeout))
        except P.ListError:
            if not pages:
                raise
            break
        if 'tgme_widget_message' not in html:
            if not pages:
                raise P.ListError('Ese canal no existe, es privado o Telegram no enseña sus '
                                  'mensajes en la web.')
            break
        pages.append(html)
        oldest = P.telegram_oldest_id(html)
        if not oldest or oldest == before or oldest <= 1:
            break
        before = oldest
    return '\n'.join(pages)


def _xtream_api(xt, insecure, dp=None, timeout=_TIMEOUT, **params):
    query = {'username': xt['user'], 'password': xt['pass']}
    query.update(params)
    url = f"{xt['server']}/player_api.php?{urllib.parse.urlencode(query)}"
    try:
        data = _download(url, insecure, dp, limit=_MAX_XTREAM, timeout=timeout)
    except P.ListError as e:
        raise _NoXtreamApi(str(e)) from e
    try:
        return json.loads(P.decode(data))
    except ValueError as e:
        raise _NoXtreamApi('El servidor no ha respondido como un servidor Xtream.') from e


def _xtream_fetch(xt, insecure=False, dp=None, timeout=_TIMEOUT):
    """Los canales de get_live_streams o, si la API está apagada, la lista M3U del servidor.
    Devuelve (resultado de parse, datos de la cuenta)."""
    try:
        info = _xtream_api(xt, insecure, dp, timeout)
        user = info.get('user_info') if isinstance(info, dict) else None
        if not isinstance(user, dict):
            raise _NoXtreamApi('El servidor no ha respondido como un servidor Xtream.')
    except _NoXtreamApi:
        query = urllib.parse.urlencode({'username': xt['user'], 'password': xt['pass'],
                                        'type': 'm3u_plus', 'output': 'm3u8'})
        try:
            data = _download(f"{xt['server']}/get.php?{query}", insecure, dp, limit=_MAX_XTREAM,
                             timeout=timeout)
        except P.ListError as e:
            raise P.ListError('El servidor no responde como un servidor Xtream. Revisa la '
                              f'dirección y el puerto.\n\n{e}') from e
        return P.parse_any(P.decode(data)), {}

    status = str(user.get('status') or '').strip()
    if str(user.get('auth')) != '1' or status.lower() in ('expired', 'banned', 'disabled'):
        reason = {'expired': 'La cuenta ha caducado.', 'banned': 'La cuenta está bloqueada.',
                  'disabled': 'La cuenta está desactivada.'}.get(status.lower(),
                                                                'El usuario o la contraseña no son correctos.')
        raise P.ListError(reason)

    formats = [str(f).lower() for f in user.get('allowed_output_formats') or []]
    fmt = 'm3u8' if 'm3u8' in formats else 'ts'
    cats = _xtream_api(xt, insecure, dp, timeout, action='get_live_categories')
    streams = _xtream_api(xt, insecure, dp, timeout, action='get_live_streams')
    raw = P.xtream_channels(xt['server'], xt['user'], xt['pass'], streams, cats, fmt)
    epg = f"{xt['server']}/xmltv.php?" + urllib.parse.urlencode(
        {'username': xt['user'], 'password': xt['pass']})
    account = {'status': status, 'exp': user.get('exp_date'), 'conns': user.get('max_connections'),
               'fmt': fmt}
    parsed = P.finalize(raw, 'xtream', epg)
    # Las otras secciones del servidor se leen al abrirlas. Si no contestan, se sigue sin ellas.
    parsed['more'] = []
    for kind, action in (('m', 'get_vod_categories'), ('s', 'get_series_categories')):
        try:
            parsed['more'] += P.xtream_categories(_xtream_api(xt, insecure, dp, timeout, action=action), kind)
        except _NoXtreamApi as e:
            _log(f'{action} sin leer: {e}', xbmc.LOGWARNING)
    return parsed, account


def _port(value):
    try:
        port = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return port if 0 < port < 65536 else None


def _engine_server():
    """(host, puerto) del motor del usuario: el que tenga puesto en EKHorus o, sin EKHorus, el
    de este aparato. Sigue las mismas reglas que engine_port() de EKHorus (lib/utils.py): en
    Android, AceServe puede llevar su propio puerto y la app oficial el que EKHorus le encontró."""
    if not xbmc.getCondVisibility(f'System.AddonIsEnabled({_EKHORUS})'):
        return '127.0.0.1', 6878
    try:
        ek = xbmcaddon.Addon(_EKHORUS)
    except RuntimeError:
        return '127.0.0.1', 6878
    host = re.sub(r'^https?://', '', ek.getSetting('ip_addr').strip(), flags=re.I)
    host = host.split('/')[0].split(':')[0].strip().lower() or '127.0.0.1'
    configured = ek.getSetting('ace_port').strip()
    raw = configured
    if xbmc.getCondVisibility('System.Platform.Android'):
        if ek.getSetting('ace_engine') == 'org.free.aceserve':
            raw = ek.getSetting('aceserve_port').strip() or configured
        elif ek.getSetting('ace_port_hallado') and ek.getSetting('ace_port_hallado_base').strip() == configured:
            raw = ek.getSetting('ace_port_hallado')
    return host, _port(raw) or 6878


def _engine_is_local(host):
    return host in _ENGINE_LOCAL or host.startswith('127.') or host == (xbmc.getIPAddress() or '')


def _engine_get(host, port, path, dp=None, limit=_MAX_XTREAM, timeout=(3, 20)):
    return _download(f'http://{host}:{port}/{path}', dp=dp, limit=limit, timeout=timeout)


def _engine_version(host, port):
    """Versión del motor, o '' si no contesta como un motor AceStream."""
    try:
        data = json.loads(P.decode(_engine_get(host, port, 'webui/api/service?method=get_version&format=json',
                                               limit=65536, timeout=(2, 4))))
        version = (data.get('result') or {}).get('version')
    except (P.ListError, _NeedsInsecure, ValueError, AttributeError):
        return ''
    return str(version) if version else ''


def _engine_down(host, port):
    where = f'{host}:{port}'
    if not _engine_is_local(host):
        return (f'No contesta el motor AceStream de {where}.\n\nArráncalo en ese aparato o revisa '
                'su dirección en el Cuadro de mandos de EKHorus.')
    if xbmc.getCondVisibility('System.Platform.Android'):
        return (f'No contesta el motor AceStream de {where}.\n\nAbre la app Ace Stream o AceServe '
                '(EKHorus las descarga si no las tienes) y vuelve a intentarlo.')
    return (f'No contesta el motor AceStream de {where}.\n\nArráncalo y vuelve a intentarlo. '
            'EKHorus lo arranca solo al reproducir cualquier canal AceStream.')


def _engine_failure(host, port):
    """Por qué el motor no ha dado su lista, como lo distingue EKHorus: no hay motor, es
    demasiado antiguo (la lista es de la serie 3.2) o contesta pero no la consigue."""
    version = _engine_version(host, port)
    if not version:
        return _engine_down(host, port)
    parts = [int(p) if p.isdigit() else 0 for p in re.split(r'[._-]', version)[:2]]
    if tuple(parts + [0, 0])[:2] < (3, 2):
        return (f'El motor de {host}:{port} (versión {version}) es demasiado antiguo para dar su '
                'lista de canales. Hace falta uno de la serie 3.2, como el de la app del móvil o '
                'un Docker de AceServe.')
    return ('El motor AceStream contesta, pero no ha conseguido su lista de canales. Vuelve a '
            'intentarlo dentro de un rato.')


def _kodi_lang():
    try:
        return xbmc.getLanguage(xbmc.ISO_639_2).strip().lower()
    except (AttributeError, TypeError, RuntimeError):
        return ''


def _engine_catalog(dp=None, timeout=(3, 20)):
    """Los canales del motor del usuario, con lo mismo que importa Canales de EKHorus: el
    catálogo entero de /search y, si el motor es AceServe, su propia lista (/pl.m3u), con
    algunos canales que el catálogo no trae. parsed['partial'] indica que el motor dejó de
    contestar a mitad."""
    host, port = _engine_server()
    groups, total, complete = [], 0, False
    for page in range(_ENGINE_MAX_PAGES):
        query = urllib.parse.urlencode({'query': '', 'page': page, 'page_size': _ENGINE_PAGE})
        try:
            result = json.loads(P.decode(_engine_get(host, port, f'search?{query}', dp, timeout=timeout))).get('result')
            page_groups = result.get('results') if isinstance(result, dict) else None
            if not isinstance(page_groups, list):
                raise ValueError('respuesta sin results')
        except (P.ListError, _NeedsInsecure, ValueError, AttributeError) as e:
            if not groups:
                raise P.ListError(_engine_failure(host, port)) from e
            _log(f'catálogo del motor: página {page}: {e}', xbmc.LOGWARNING)
            break
        groups.extend(page_groups)
        try:
            total = int(result.get('total') or total)
        except (TypeError, ValueError):
            pass
        if dp is not None and total > 0:
            dp.update(min(100, len(groups) * 100 // total), f'{len(groups)} de {total} canales...')
        if len(page_groups) < _ENGINE_PAGE:
            complete = True
            break
    try:
        # La app oficial no tiene esta lista y responde con un error, que aquí es lo normal.
        playlist = P.engine_playlist(P.decode(_engine_get(host, port, 'pl.m3u', dp, _MAX_DOWNLOAD, (3, 10))))
    except (P.ListError, _NeedsInsecure):
        playlist = []
    parsed = P.finalize(P.engine_merge(P.engine_channels(groups), playlist, P.engine_adult_links(groups)),
                        'engine')
    parsed['channels'] = P.engine_sort(parsed['channels'], _kodi_lang())
    if not complete:
        parsed['partial'] = True
    return parsed


def _engine_content_id(infohash):
    """content_id de un infohash según el motor del usuario, o '' si no contesta. Lo cachea el
    propio motor, así que la primera vez tarda medio segundo y el resto es instantáneo."""
    host, port = _engine_server()
    query = urllib.parse.urlencode({'method': 'get_content_id', 'infohash': infohash})
    try:
        data = json.loads(P.decode(_engine_get(host, port, f'server/api?{query}', limit=65536, timeout=(2, 5))))
        cid = (data.get('result') or {}).get('content_id')
    except (P.ListError, _NeedsInsecure, _Cancelled, ValueError, AttributeError):
        return ''
    return cid.lower() if isinstance(cid, str) and re.fullmatch(r'[0-9a-fA-F]{40}', cid) else ''


def _fetch_source(lst, dp=None, quiet=False):
    """Canales frescos de la fuente de lst (resultado de parse_any)."""
    kind, src = lst['kind'], lst['src']
    insecure = bool(lst.get('insecure'))
    timeout = _TIMEOUT_QUIET if quiet else _TIMEOUT
    if kind == 'text':
        text = STORE.load_text(lst['id'])
        if text is None:
            raise P.ListError('Se ha perdido el contenido de esta lista. Bórrala y vuelve a añadirla.')
        return P.parse_any(text)
    if kind == 'file':
        return _parse_file(src, _sublist_fetcher(insecure, dp, timeout))
    if kind == 'url':
        return P.parse_any(P.decode(_download(src, insecure, dp, timeout=timeout)), base_url=src,
                           fetch=_sublist_fetcher(insecure, dp, timeout))
    if kind == 'web':
        return P.parse_any(P.decode(_download_page(src, insecure, dp, timeout)), base_url=src)
    if kind == 'telegram':
        return P.parse_any(_telegram_html(src, dp, timeout), hint='telegram')
    if kind == 'engine':
        return _engine_catalog(dp, (3, timeout[1]))
    if kind == 'xtream':
        xt = lst.get('xt') or {}
        if not all(xt.get(k) for k in ('server', 'user', 'pass')):
            raise P.ListError('Faltan los datos del servidor Xtream. Borra la lista y vuelve a añadirla.')
        parsed, account = _xtream_fetch(xt, insecure, dp, timeout)
        if account:
            parsed['account'] = account
        return parsed
    raise P.ListError('Tipo de lista desconocido.')


# --- Copias y contenido de cada lista ---

def _parse_cached(text, meta):
    if meta.get('fmt') == 'engine':
        chans = P.engine_load(text)
        if chans is not None:
            return {'channels': chans, 'epg': '', 'fmt': 'engine', 'unsupported': 0}
    parsed = P.parse_any(text)
    more = meta.get('more') if isinstance(meta.get('more'), list) else []
    parsed['more'] = [m for m in more if isinstance(m, dict) and m.get('k') in ('m', 's') and m.get('id')]
    if meta.get('sublists'):
        parsed.update(sublists=meta['sublists'], sublists_failed=meta.get('sublists_failed', 0))
    return parsed


def _cache_meta(parsed, now):
    """Datos de la copia en caché. Una copia a medias nace caducada, para que se complete la
    próxima vez que se abra la lista."""
    meta = {'ts': 0 if parsed.get('partial') else now, 'count': len(parsed['channels']),
            'fmt': parsed.get('fmt', '')}
    if parsed.get('more'):
        meta['more'] = parsed['more']
    if parsed.get('sublists'):
        meta.update(sublists=parsed['sublists'], sublists_failed=parsed.get('sublists_failed', 0),
                    mtime=parsed.get('mtime'))
    return meta


def _is_fresh(lst, cached, meta):
    """Si la copia vale sin volver a la fuente. Un archivo se relee cada vez, salvo si enlaza otras
    listas, que entonces se relee solo cuando cambia su fecha o cuando caduca como una lista de
    internet."""
    if cached is None:
        return False
    age = time.time() - float(meta.get('ts') or 0)
    if lst['kind'] == 'file':
        return (bool(meta.get('sublists')) and age < _TTL['url'] and meta.get('mtime') is not None
                and meta['mtime'] == _file_mtime(lst['src']))
    return age < _TTL.get(lst['kind'], 0)


def _copy_text(parsed):
    """Texto de la copia en caché: M3U, salvo el motor, que guarda en JSON su categoría, país,
    idioma y enlaces de repuesto."""
    if parsed.get('fmt') == 'engine':
        return P.engine_dump(parsed['channels'])
    return P.to_m3u(parsed['channels'], parsed.get('epg', ''))


def _update(lid, **fields):
    """Cambia campos de una lista por su id. Devuelve la lista, o None si ya no existe."""
    def apply(lists):
        for entry in lists:
            if entry['id'] == lid:
                entry.update(fields)
                return dict(entry)
        return None
    return STORE.mutate(apply)


def _save_copy(lst, parsed):
    """Guarda la copia buena y apunta el recuento. Si la lista se borró mientras se descargaba,
    se quita la copia recién escrita."""
    chans = parsed['channels']
    now = int(time.time())
    if lst['kind'] != 'text':
        STORE.save_cache(lst['id'], _copy_text(parsed), _cache_meta(parsed, now))
    fields = {'count': len(chans), 'updated': now, 'epg': parsed.get('epg', '')}
    if parsed.get('account'):
        fields['account'] = parsed['account']
    try:
        if _update(lst['id'], **fields) is None:
            STORE.delete_files(lst['id'])
    except (iptv_store.LockBusy, iptv_store.StoreError) as e:
        _log(f'no se ha podido apuntar el recuento de {lst["id"]}: {e}', xbmc.LOGWARNING)


def channels(lst, network=True, quiet=False, dp=None):
    """Canales de una lista para enseñarlos, de la copia si está al día y de la fuente si no.

    network=False nunca descarga (grupos, búsqueda, TV de Kodi). Si la fuente falla, o
    devuelve de golpe muchos menos canales que antes, se usa la última copia buena y
    parsed['note'] explica por qué."""
    kind = lst['kind']
    if kind == 'text':
        return _fetch_source(lst)
    cached, meta = STORE.load_cache(lst['id'])
    if cached is not None and (not network or _is_fresh(lst, cached, meta)):
        return _parse_cached(cached, meta)
    if not network:
        raise P.ListError('Esta lista aún no se ha descargado. Ábrela una vez.')
    try:
        parsed = _fetch_source(lst, dp, quiet)
    except _Cancelled:
        if cached is None:
            raise
        return dict(_parse_cached(cached, meta), stale=True,
                    note='Has cancelado la actualización. Se muestra la copia anterior.')
    except (P.ListError, _NeedsInsecure) as e:
        if cached is None:
            raise
        _log(f'fuente de {lst["id"]} no disponible, se usa la copia: {e}', xbmc.LOGWARNING)
        return dict(_parse_cached(cached, meta), stale=True,
                    note=f'No se ha podido leer la fuente. Copia del {_fmt_date(meta.get("ts"))}.')
    new, old = len(parsed['channels']), int(meta.get('count') or 0)
    if cached is not None and parsed.get('partial'):
        return dict(_parse_cached(cached, meta), stale=True,
                    note='El motor ha dejado de contestar a mitad de la lista. Se muestra la copia '
                         f'del {_fmt_date(meta.get("ts"))}.')
    if cached is not None and (_empty(parsed) or (old and new < old * _KEEP_BELOW)):
        return dict(_parse_cached(cached, meta), stale=True,
                    note=f'La fuente ha devuelto {new} de {old} canales. Se muestra la copia '
                         'anterior; usa "Actualizar ahora" para aceptar la nueva.')
    if _empty(parsed):
        raise P.ListError(_empty_reason(parsed))
    _save_copy(lst, parsed)
    return parsed


def _empty(parsed):
    return not parsed['channels'] and not parsed.get('more')


def _empty_reason(parsed):
    if (not parsed.get('channels') and parsed.get('sublists')
            and parsed.get('sublists_failed') == parsed['sublists']):
        return 'Esta lista enlaza otras listas y no se ha podido leer ninguna. Prueba más tarde.'
    # En una web o un canal de Telegram casi todos los enlaces son de charla o de navegación,
    # así que contarlos como "no se pueden reproducir" despistaría.
    if parsed.get('fmt') in ('web', 'telegram'):
        return ('No se han encontrado emisiones en directo. Si son de un evento, puede que '
                'aún no se hayan publicado. Prueba más tarde.')
    if parsed.get('unsupported'):
        return f'Los {parsed["unsupported"]} enlaces de esta lista no se pueden reproducir en Kodi.'
    return 'No se han encontrado canales en directo.'


def _missing_sublists(parsed):
    """(cuántas, cuáles) de las listas enlazadas no se han podido leer, como 'su lista enlazada',
    'sus 3 listas enlazadas' o '1 de sus 3 listas enlazadas'. (0, '') si se leyeron todas."""
    failed, total = parsed.get('sublists_failed') or 0, parsed.get('sublists') or 0
    if not failed:
        return 0, ''
    if total == 1:
        return 1, 'su lista enlazada'
    if failed == total:
        return failed, f'sus {total} listas enlazadas'
    return failed, f'{failed} de sus {total} listas enlazadas'


# --- Menú de TV en directo ---

def _list_label(lst):
    count = lst.get('count') or 0
    label = lst['name']
    if count:
        label += f'  [COLOR gray]· {_canales(count)}[/COLOR]'
    if lst.get('pvr'):
        label += '  [COLOR lightskyblue]· TV[/COLOR]'
    return label


def _list_context(lst):
    lid = lst['id']
    cm = []
    if lst['kind'] != 'text':
        cm.append(('Actualizar ahora', f'RunPlugin({_u(action="iptv_refresh", id=lid)})'))
    cm += [
        ('Renombrar', f'RunPlugin({_u(action="iptv_rename", id=lid)})'),
        ('Subir', f'RunPlugin({_u(action="iptv_move", id=lid, dir="up")})'),
        ('Bajar', f'RunPlugin({_u(action="iptv_move", id=lid, dir="down")})'),
        ('Quitar de la TV de Kodi' if lst.get('pvr') else 'Mostrar en la TV de Kodi',
         f'RunPlugin({_u(action="iptv_pvr", id=lid)})'),
        ('Información', f'RunPlugin({_u(action="iptv_info", id=lid)})'),
        ('Eliminar', f'RunPlugin({_u(action="iptv_delete", id=lid)})'),
        ('Guía de las listas de canales', f'RunPlugin({_u(action="iptv_guide")})'),
    ]
    return cm


def _list_plot(lst):
    if lst.get('updated'):
        lines = [f"{_KIND_LABEL.get(lst['kind'], '')} con {_canales(lst.get('count') or 0)} en directo.",
                 f"Última lectura: {_fmt_date(lst.get('updated'))}."]
    else:
        lines = [f"{_KIND_LABEL.get(lst['kind'], '')}. Aún no se ha leído. Ábrela para cargar sus canales."]
    if lst.get('pvr'):
        lines.append('También está en la sección TV de Kodi.')
    return '\n'.join(lines) + '\n\n' + _LIST_CONTEXT_HELP


def add_menu_items():
    """Las listas del usuario y el botón de añadir, al final de TV en directo. Solo lee el
    JSON: nada de red, para que el menú de directos abra siempre al momento."""
    try:
        lists = STORE.lists()
    except Exception as e:
        # Pase lo que pase con las listas, el resto del menú de directos tiene que salir.
        _log(f'no se han podido leer las listas: {e}', xbmc.LOGERROR)
        lists = []
    for lst in lists:
        ui_utils.add_item(action='iptv_open', title=_list_label(lst),
                          thumbnail=_icon(_KIND_ICON.get(lst['kind'], 'url.png')), folder=True,
                          plot=_list_plot(lst), context=_list_context(lst), id=lst['id'])
    if len(lists) >= 2:
        ui_utils.add_item(action='iptv_search', title='Buscar en mis listas', nuevo='iptv_search', id='*',
                          thumbnail=_icon('busqueda.png'), folder=False,
                          plot='Busca un canal por su nombre o su grupo en todas tus listas a la '
                               'vez, sin importar mayúsculas ni tildes.')
    ui_utils.add_item(action='iptv_add',
                      title='Añadir lista de canales [COLOR gray](IPTV, AceStream, Telegram, Xtream...)[/COLOR]',
                      nuevo='iptv_add',
                      thumbnail=_icon('iptv_anadir.png'), folder=False, plot=ADD_PLOT)


# --- Añadir ---

def _clipboard_text():
    try:
        import url_player
        return url_player._get_system_clipboard_text() or ''
    except Exception as e:
        _log(f'portapapeles no disponible: {e}', xbmc.LOGDEBUG)
        return ''


def _option(label, desc, icon):
    li = xbmcgui.ListItem(label=label, label2=desc)
    li.setArt({'icon': icon, 'thumb': icon})
    return li


def add_list():
    # La marca es un archivo de vistos y no un ajuste, porque setSetting reescribe el settings.xml
    # entero desde la copia de cada xbmcaddon.Addon() y puede pisar lo que otra invocación acaba de
    # guardar. Quien ya la vio con el ajuste iptv_guide_seen no la vuelve a ver.
    if ui_utils.visto('iptv_guia_primera') and _ADDON.getSetting(_GUIDE_SEEN) != '1':
        iptv_guide.show()

    clip = _clipboard_text().strip()
    options = [
        ('link', 'Escribir o pegar un enlace',
         'Lista M3U, M3U8 o de Wiseplay (W3U), web, canal de Telegram, AceStream o servidor Xtream.',
         'url_paste.png'),
        ('phone', 'Enviar desde el móvil o el PC',
         'Abre una página en la red de casa para pegar la lista o subir el archivo.', 'url_remote.png'),
        ('file', 'Archivo del dispositivo',
         'Una lista de este aparato (también de Wiseplay), de una memoria USB o de una carpeta de red.',
         'adv_ruta_dl.png'),
    ]
    if clip:
        lines = len([ln for ln in clip.splitlines() if ln.strip()])
        options.append(('clip', f'Pegar del portapapeles ({lines} línea{"s" if lines != 1 else ""})',
                        'Lo que tienes copiado en este equipo, sea una dirección o la lista entera.',
                        'url_clipboard.png'))
    options += [
        ('web', 'Canal de Telegram o web con enlaces',
         'Recoge las emisiones que se publican. Se revisa cada vez que abres la lista.', 'url_scan.png'),
        ('ace', 'Enlaces AceStream',
         'Uno o varios acestream:// o identificadores de 40 caracteres.', 'adv_acestream.png'),
        ('engine', _ENGINE_NAME,
         'Canales de televisión en directo, con buscador y filtros por categoría, país e '
         'idioma.', 'adv_acestream.png'),
        ('xtream', 'Servidor Xtream Codes',
         'Servidor, usuario y contraseña de tu proveedor. Sus canales, por categorías.', 'tv.png'),
        ('catalog', 'Listas públicas',
         'Listas abiertas de canales en directo para añadir con un clic.', 'catalogo.png'),
        ('guide', 'Cómo funciona (guía)',
         'Todo lo que puedes hacer con las listas de canales, paso a paso.', 'info_guia.png'),
    ]
    sel = xbmcgui.Dialog().select('Añadir lista de canales',
                                  [_option(label, desc, _icon(icon)) for _k, label, desc, icon in options],
                                  useDetails=True)
    if sel < 0:
        return
    key = options[sel][0]
    try:
        if key == 'link':
            text = xbmcgui.Dialog().input('Enlace de la lista, web, @canal de Telegram o AceStream',
                                          defaultt=clip if _looks_like_link(clip) else '')
            if text.strip():
                _ingest_link(text)
        elif key == 'phone':
            _src_phone()
        elif key == 'file':
            path = xbmcgui.Dialog().browse(1, 'Elige la lista', 'files', '.m3u|.m3u8|.txt|.json|.w3u')
            if path:
                _ingest_file(path)
        elif key == 'clip':
            _ingest_link(clip) if _looks_like_link(clip) else _ingest_text(clip)
        elif key == 'web':
            text = xbmcgui.Dialog().input('Canal de Telegram (@canal, t.me/canal) o dirección de la web')
            if text.strip():
                _ingest_link(text, prefer_web=True)
        elif key == 'ace':
            text = xbmcgui.Dialog().input('Enlaces AceStream (con su nombre delante, si quieres)')
            if text.strip():
                # El teclado da una sola línea, así que se corta tras cada enlace para que el texto
                # de delante sea el nombre de ese canal y no el de todos.
                _ingest_text(_ACE_TOKEN_RE.sub(r'\1\n', text.strip()))
        elif key == 'engine':
            _ingest_engine()
        elif key == 'xtream':
            _src_xtream(clip)
        elif key == 'catalog':
            _src_catalog()
        elif key == 'guide':
            iptv_guide.show()
    except _Cancelled:
        return


def _looks_like_link(text):
    """Una sola dirección (y no una lista pegada): URL, AceStream, @canal o t.me/canal."""
    text = text.strip()
    return bool(text) and not re.search(r'\s', text) and bool(_LINK_RE.match(text))


def _src_phone():
    import web_input
    got = web_input.receive_list('Pega una dirección o la lista entera, o elige un archivo')
    if got is None:
        show_message('No se ha podido abrir la página. Este aparato no parece '
                                      'estar conectado a una red local, o los puertos 8080 a 8088 '
                                      'están ocupados.\n\nPrueba con otra de las formas de añadir.')
        return
    if not got:
        return
    if 'data' in got:
        try:
            text = P.decode(got['data'])
        except P.ListError as e:
            show_message(str(e))
            return
        _ingest_text(text, fallback=_file_stem(got.get('name') or ''))
    else:
        text = got['text']
        _ingest_link(text) if _looks_like_link(text) else _ingest_text(text)


def _src_xtream(clip=''):
    sel = xbmcgui.Dialog().select('Servidor Xtream Codes', [
        'Pegar la dirección M3U que te dio tu proveedor',
        'Escribir servidor, usuario y contraseña'])
    if sel < 0:
        return
    if sel == 0:
        prefill = clip if P.parse_xtream_url(clip) else ''
        raw = xbmcgui.Dialog().input('Dirección con get.php?username=...&password=...', defaultt=prefill)
        if not raw.strip():
            return
        found = P.parse_xtream_url(raw.strip())
        if not found:
            show_message('Esa dirección no lleva el usuario y la contraseña de '
                                          'un servidor Xtream. Suele tener esta forma:\n\n'
                                          'http://servidor:8080/get.php?username=USUARIO&password=CLAVE')
            return
        server, user, password = found
    else:
        server = xbmcgui.Dialog().input('Servidor (por ejemplo http://servidor:8080)')
        if not server.strip():
            return
        user = xbmcgui.Dialog().input('Usuario')
        if not user.strip():
            return
        password = xbmcgui.Dialog().input('Contraseña', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return
        server = P.normalize_server(server)
    _ingest_xtream(server, user.strip(), password)


def _src_catalog():
    have = {lst['src'] for lst in STORE.lists() if lst['kind'] == 'url'}
    items = []
    for name, url, desc in CATALOG:
        label = f'{name}  [COLOR lime](ya la tienes)[/COLOR]' if url in have else name
        items.append(_option(label, desc, _icon('catalogo.png')))
    sel = xbmcgui.Dialog().select('Listas públicas', items, useDetails=True)
    if sel < 0:
        return
    name, url, _desc = CATALOG[sel]
    what = xbmcgui.Dialog().select(name, ['Ver ahora (sin guardarla)', 'Guardar en mis listas'])
    if what == 0:
        xbmc.executebuiltin(f'Container.Update({_u(action="iptv_preview", url=url, title=name)})')
    elif what == 1:
        _ingest_source({'kind': 'url', 'src': url}, name_hint=name)


def _file_stem(path):
    base = re.split(r'[\\/]', str(path or ''))[-1]
    return base.rsplit('.', 1)[0] if '.' in base else base


def _suggest(entry, hint):
    if hint:
        return hint
    kind, src = entry['kind'], entry['src']
    if kind == 'telegram':
        return f'@{src}'
    if kind == 'file':
        return _file_stem(src) or 'Mi lista'
    if kind in ('url', 'web'):
        try:
            parts = urllib.parse.urlsplit(src)
            host = (parts.hostname or '').replace('www.', '')
            stem = _file_stem(parts.path)
            return f'{host} · {stem}' if stem and stem not in ('index', 'playlist') else host
        except ValueError:
            return 'Mi lista'
    if kind == 'xtream':
        try:
            return urllib.parse.urlsplit(entry['xt']['server']).hostname or 'Xtream'
        except (KeyError, ValueError):
            return 'Xtream'
    return 'Mi lista'


def _ask_name(heading, default):
    kb = xbmc.Keyboard(default, heading)
    kb.doModal()
    if not kb.isConfirmed():
        return None
    return P.clean_name(kb.getText())[:_NAME_MAX] or default


def _same_source(a, b):
    # Del motor solo hay una, porque su dirección sale de EKHorus y puede cambiar.
    return a['kind'] == b['kind'] and (a['kind'] == 'engine' or a['src'] == b['src'])


def _with_insecure_retry(entry, work):
    """Ejecuta work(insecure) y, si el certificado HTTPS no es válido, pregunta y repite."""
    try:
        return work(bool(entry.get('insecure')))
    except _NeedsInsecure:
        if entry.get('insecure') or not xbmcgui.Dialog().yesno(
                _HEADING, 'El certificado HTTPS de ese servidor no es válido, algo habitual en '
                          'servidores IPTV. ¿Sigo igualmente? Solo esta lista se descargará sin '
                          'comprobarlo.',
                nolabel='Cancelar', yeslabel='Seguir'):
            raise _Cancelled()
        entry['insecure'] = True
        return work(True)


def _ingest_link(raw, name_hint='', prefer_web=False):
    raw = raw.strip()
    if telegram_scanner.is_private_invite(raw):
        show_message('Es una invitación a un canal o grupo privado de Telegram. '
                                      'Esos no se pueden leer sin una cuenta; solo los públicos '
                                      '(t.me/nombre).')
        return
    channel = P.telegram_channel(raw) if telegram_scanner.is_telegram(raw) else ''
    if channel:
        _ingest_source({'kind': 'telegram', 'src': channel}, name_hint)
        return
    # Una dirección no lleva espacios, así que con espacios o saltos de línea es una lista pegada.
    if P.classify(raw)[0] in (P.KIND_ACE, P.KIND_TORRENT) or re.search(r'\s', raw):
        _ingest_text(raw, name_hint)
        return
    url = raw if '://' in raw else f'http://{raw}'
    found = P.parse_xtream_url(url)
    if found and xbmcgui.Dialog().yesno(
            _HEADING, 'Es un servidor Xtream. ¿Importo sus canales por categorías? Es lo '
                      'recomendado. Con "Lista M3U" se usa su lista entera.',
            nolabel='Lista M3U', yeslabel='Por categorías'):
        _ingest_xtream(*found)
        return
    _ingest_source({'kind': 'web' if prefer_web else 'url', 'src': P.raw_url(url)}, name_hint)


def _offer_open(dup, text=''):
    if xbmcgui.Dialog().yesno(_HEADING, text or f'Ya tienes esta lista con el nombre "{dup["name"]}".\n\n'
                                                '¿La abro?', nolabel='No', yeslabel='Abrirla'):
        xbmc.executebuiltin(f'Container.Update({_u(action="iptv_open", id=dup["id"])})')


def _ingest_source(entry, name_hint=''):
    if entry['kind'] in ('url', 'web'):
        # Antes de descargar, porque una lista que enlaza otras tarda en leerse entera. Vale igual si
        # se guardó como lista o como web, porque el tipo lo decide el contenido.
        dup = next((lst for lst in STORE.lists()
                    if lst['kind'] in ('url', 'web') and lst['src'] == entry['src']), None)
        if dup:
            _offer_open(dup)
            return

    def work(insecure):
        entry['insecure'] = insecure
        with _progress('Leyendo la lista...') as dp:
            return _fetch_source(entry, dp)
    try:
        parsed = _with_insecure_retry(entry, work)
    except P.ListError as e:
        show_message(f'No se ha podido añadir la lista.\n\n{e}')
        return
    if entry['kind'] in ('url', 'web'):
        # Lo decide lo que ha llegado y no la opción elegida, porque una web se revisa cada 30 min
        # y una lista cada 6 h.
        entry['kind'] = 'web' if parsed['fmt'] == 'web' else 'url'
    _finish_add(entry, parsed, name_hint)


def _ingest_file(path):
    try:
        parsed = _parse_file(path)
        if parsed.get('pending_refs'):
            with _progress('Leyendo las listas enlazadas...') as dp:
                parsed = _parse_file(path, _sublist_fetcher(False, dp, _TIMEOUT))
    except P.ListError as e:
        show_message(f'No se ha podido leer el archivo.\n\n{e}')
        return
    _finish_add({'kind': 'file', 'src': path}, parsed, '')


def _ingest_text(text, name_hint='', fallback=''):
    """Una lista pegada o enviada. Las listas que enlace se leen ahora y se guarda el resultado,
    porque una lista pegada no tiene fuente que volver a leer."""
    parsed = P.parse_any(text)
    snapshot = text
    if parsed.get('pending_refs'):
        with _progress('Leyendo las listas enlazadas...') as dp:
            parsed = P.parse_any(text, fetch=_sublist_fetcher(False, dp, _TIMEOUT))
        snapshot = P.to_m3u(parsed['channels'], parsed.get('epg', ''))
    name = name_hint or parsed.get('title') or fallback
    if not name and parsed['channels'] and all(ch['kind'] == P.KIND_ACE for ch in parsed['channels']):
        name = f'AceStream ({len(parsed["channels"])})'
    _finish_add({'kind': 'text', 'src': P.content_hash(text)}, parsed, name or 'Lista pegada',
                snapshot=snapshot)


def _ingest_engine():
    """Importa los canales del motor del usuario como una lista más."""
    dup = next((lst for lst in STORE.lists() if lst['kind'] == 'engine'), None)
    if dup:
        # Antes de pedir las diez páginas al motor, que tardan unos segundos.
        _offer_open(dup, f'Ya tienes los {_ENGINE_NAME} con el nombre "{dup["name"]}".\n\n¿La abro?')
        return
    try:
        with _progress('Bajando la lista de canales...') as dp:
            parsed = _engine_catalog(dp)
    except P.ListError as e:
        show_message(str(e))
        return
    _finish_add({'kind': 'engine', 'src': 'motor'}, parsed, _ENGINE_NAME)


def _ingest_xtream(server, user, password):
    entry = {'kind': 'xtream', 'src': f'{server}|{user}',
             'xt': {'server': server, 'user': user, 'pass': password}}

    def work(insecure):
        entry['insecure'] = insecure
        with _progress('Comprobando la cuenta y leyendo los canales en directo...') as dp:
            parsed, account = _xtream_fetch(entry['xt'], insecure, dp)
        if account:
            parsed['account'] = account
        return parsed
    try:
        parsed = _with_insecure_retry(entry, work)
    except P.ListError as e:
        show_message(f'No se ha podido añadir el servidor Xtream.\n\n{e}')
        return
    _finish_add(entry, parsed, '')


def _finish_add(entry, parsed, name_hint, snapshot=None):
    chans = parsed['channels']
    if _empty(parsed):
        show_message(_empty_reason(parsed))
        return
    dup = next((lst for lst in STORE.lists() if _same_source(lst, entry)), None)
    if dup:
        _offer_open(dup)
        return
    failed, missing = _missing_sublists(parsed)
    if missing and entry['kind'] == 'text' and not xbmcgui.Dialog().yesno(
            _HEADING, f'No se {"ha" if failed == 1 else "han"} podido leer {missing}, y una lista pegada '
                      'o enviada no se actualiza.\n\n¿La guardo así o prefieres añadirla más tarde?',
            nolabel='Más tarde', yeslabel='Guardar'):
        return
    name = _ask_name(f'Nombre de la lista ({_canales(len(chans))})' if chans else 'Nombre de la lista',
                     _suggest(entry, name_hint or parsed.get('title', '')))
    if name is None:
        return

    lid = iptv_store.new_id()
    now = int(time.time())
    entry.update(id=lid, name=name, count=len(chans), updated=now, epg=parsed.get('epg', ''),
                 pvr=False)
    if parsed.get('account'):
        entry['account'] = parsed['account']
    if not entry.get('insecure'):
        entry.pop('insecure', None)
    # El contenido primero y la entrada después, para que quien vea la entrada encuentre su copia.
    if snapshot is not None:
        saved = STORE.save_text(lid, snapshot)
    else:
        saved = STORE.save_cache(lid, _copy_text(parsed), _cache_meta(parsed, now))
    if not saved:
        show_message('No se ha podido guardar la lista. Mira si queda espacio '
                                      'en el aparato.')
        return

    def add(lists):
        if any(_same_source(lst, entry) for lst in lists):
            return False
        lists.append(entry)
        return True
    try:
        added = STORE.mutate(add)
    except iptv_store.LockBusy:
        STORE.delete_files(lid)
        show_message('Otra operación con tus listas está en curso. Inténtalo de '
                                      'nuevo en unos segundos.')
        return
    except iptv_store.StoreError as e:
        STORE.delete_files(lid)
        show_message(f'No se ha podido guardar la lista.\n\n{e}')
        return
    if not added:
        STORE.delete_files(lid)
        _notify('Esa lista ya estaba añadida')
        return

    if missing and entry['kind'] != 'text':
        # El aviso de Kodi es de una línea y el resto desfila despacio.
        _notify(f'"{name}" añadida · {_canales(len(chans))}, sin {missing}', ms=10000)
    else:
        _notify(f'"{name}" añadida' + (f' · {_canales(len(chans))}' if chans else ''), ms=6000)
    _log(f'lista añadida: {entry["kind"]} {entry["src"]} ({len(chans)} canales)')
    _refresh_container()


# --- Ver una lista ---

def _engine_plot(ch):
    """Líneas de la ficha de un canal del motor: lo mismo que enseña Canales de EKHorus."""
    lines = []
    for field, title in (('cats', 'Categorías'), ('countries', 'País'), ('langs', 'Idioma')):
        values = [P.engine_label(field, v) for v in ch.get(field) or ()]
        if values:
            lines.append(f"{title}: {', '.join(values)}")
    if ch.get('status') != 2:
        lines.append('Enlace dudoso. Puede que no arranque o que se corte.')
    if ch.get('alts'):
        lines.append(f"Tiene {len(ch['alts'])} enlace{'s' if len(ch['alts']) > 1 else ''} de repuesto "
                     '(menú contextual, "Probar otro enlace").')
    return lines


def _sort_channels(h):
    # Sin máscara, Kodi pinta el título de la ficha (%T) en vez de la etiqueta, y se pierden lo que
    # se emite ahora, el grupo y las marcas de _channel_item.
    for method in (xbmcplugin.SORT_METHOD_UNSORTED, xbmcplugin.SORT_METHOD_LABEL):
        xbmcplugin.addSortMethod(h, method, '%L')


def _rec(estado, lid='', epg=''):
    """Lo que necesita _channel_item para ofrecer grabar: el estado de las grabaciones (una vez por
    listado) y lo que se añade a la orden para que encuentre la guía de la lista."""
    if lid:
        return estado, f'&id={urllib.parse.quote_plus(lid)}'
    return estado, f'&epg={urllib.parse.quote_plus(epg)}' if epg else ''


def _channel_item(ch, list_name, show_group, now, rec=None):
    """rec sale de _rec; sin él, el canal no ofrece grabar."""
    name = ch['name']
    params = {'url': ch['url'], 'title': name, 'ua': ch.get('ua'), 'ref': ch.get('ref'),
              'extra': json.dumps(ch['props']) if ch.get('props') else ''}
    play_url = _u(action='iptv_play', **params)
    rec_mark, rec_entry = '', None
    if (rec and ch['kind'] in (P.KIND_HLS, P.KIND_DIRECT) and not P.not_live(ch)
            and grabaciones.admite(ch['url'])):
        estado, sufijo = rec
        tvg = f"&tvg={urllib.parse.quote_plus(ch['tvg_id'])}" if ch.get('tvg_id') else ''
        # Sobre la dirección de reproducción ya codificada, porque _u() en cada canal se nota en las
        # listas de miles.
        orden = play_url.replace('action=iptv_play', 'action=iptv_record', 1) + sufijo + tvg
        rec_mark, rec_entry = grabaciones.entrada(estado, ch['url'], orden)
    label = name
    engine = 'status' in ch
    if ch['kind'] == P.KIND_ACE and not engine:
        label = f'[COLOR orange]ACE[/COLOR] {label}'
    if show_group and ch.get('group'):
        label = f"[COLOR gray][{ch['group']}][/COLOR] {label}"
    label = rec_mark + label
    if engine and ch.get('status') != 2:
        label += '  [COLOR gray]· dudoso[/COLOR]'
    plot = [name]
    if now:
        title, start, stop, desc = now
        label += f'  [COLOR skyblue]Ahora: {title}' + (f' ({start}-{stop})' if start and stop else '') + '[/COLOR]'
        plot.append(f'Ahora: {title}' + (f' ({start}-{stop})' if start and stop else ''))
        if desc:
            plot.append(desc)
    if engine:
        plot += _engine_plot(ch)
    elif ch.get('group'):
        plot.append(f"Grupo: {ch['group']}")
    plot.append(f'Lista: {list_name}')
    if ch['kind'] == P.KIND_ACE and not engine:
        plot.append('Canal AceStream. Se abre con StreamNinja o EKHorus, y necesita el motor '
                    'AceStream en marcha.')

    li = xbmcgui.ListItem(label=label)
    # Sin logo, el icono de directos del addon, como hace EKHorus. El favorito se queda con el
    # del skin, que no depende de dónde esté instalado el addon.
    thumb = ch.get('logo') or _no_logo()
    li.setArt({'icon': thumb, 'thumb': thumb})
    li.setInfo('video', {'title': name, 'plot': '\n'.join(plot)})

    fav_url = _with_headers(ch['url'], ch.get('ua'), ch.get('ref'))
    cm = [('Añadir a Favoritos', 'RunPlugin({0})'.format(_u(
        action='add_fav', title=name, url=fav_url, f_thumb=ch.get('logo') or 'DefaultAddonPVRClient.png',
        extra=params['extra'],
        f_action='iptv_play_fav')))]
    if ch.get('alts'):
        cm.append(('Probar otro enlace', f"RunPlugin({_u(action='iptv_alt', title=name, alts=','.join(ch['alts']))})"))
    if rec_entry:
        cm.append(rec_entry)
    li.addContextMenuItems(cm)
    return play_url, li, False


def _with_headers(url, ua, ref):
    """La URL con sus cabeceras en formato pipe de Kodi, para que un favorito las conserve. Las
    que ya lleva la dirección mandan sobre las de la lista."""
    if P.classify(url)[0] not in (P.KIND_HLS, P.KIND_DASH, P.KIND_DIRECT):
        return url
    base, _, tail = url.partition('|')
    present = {p.split('=', 1)[0].strip().lower() for p in tail.split('&') if p.strip()}
    parts = [tail] if tail.strip() else []
    if ua and 'user-agent' not in present:
        parts.append(f'User-Agent={urllib.parse.quote(ua)}')
    if ref and 'referer' not in present:
        parts.append(f'Referer={urllib.parse.quote(ref)}')
    return f"{base}|{'&'.join(parts)}" if parts else base


def _now_map(chans, guide=''):
    """({posición: programa}, hace falta descargar la guía). La guía solo se consulta si la
    lista trae tvg-id, porque sin ellos casi nunca empareja y no merece la pena. guide es la de la
    propia lista (su url-tvg); sin ella se usa la general, que es de canales españoles."""
    if not any(ch.get('tvg_id') for ch in chans):
        return {}, False
    found = epg_texto.now_playing([(ch.get('tvg_id'), ch['name']) for ch in chans], url=guide)
    return (found or {}), found is None


def _groups(chans):
    order, counts = [], {}
    for ch in chans:
        g = ch.get('group') or ''
        if g not in counts:
            order.append(g)
            counts[g] = 0
        counts[g] += 1
    return order, counts


def _load_for_view(lst, root):
    """Canales para la vista. En la raíz se actualizan si toca; dentro de un grupo o de una
    búsqueda se usa siempre la copia, para que la lista no cambie mientras se navega."""
    def work(insecure):
        lst['insecure'] = insecure
        if not root:
            return channels(lst, network=False)
        cached, meta = STORE.load_cache(lst['id'])
        needs_network = lst['kind'] != 'text' and not _is_fresh(lst, cached, meta)
        if not needs_network:
            return channels(lst)
        with _progress(f'Leyendo "{lst["name"]}"...') as dp:
            return channels(lst, dp=dp)
    had_insecure = bool(lst.get('insecure'))
    parsed = _with_insecure_retry(lst, work)
    if lst.get('insecure') and not had_insecure:
        _set_or_warn(lst['id'], insecure=True)
    return parsed


def open_list(params):
    h = _handle()
    lid, group, query, facet = params.get('id', ''), params.get('g'), params.get('q'), params.get('f')
    if lid == '*':
        _search_all(query or '')
        return
    lst = STORE.get(lid)
    if lst is None:
        _notify('Esa lista ya no existe', xbmcgui.NOTIFICATION_WARNING)
        _end(False)
        return
    root = group is None and query is None and facet is None
    try:
        parsed = _load_for_view(lst, root)
    except _Cancelled:
        _end(False)
        return
    except P.ListError as e:
        show_message(f'No se ha podido abrir "{lst["name"]}".\n\n{e}')
        _end(False)
        return
    if root and parsed.get('note'):
        _notify(parsed['note'], xbmcgui.NOTIFICATION_WARNING, 6000)

    everything = parsed['channels']
    if parsed.get('fmt') == 'engine' and query is None and group != '*':
        _engine_listing(h, lst, everything, facet, group)
        return
    order, counts = _groups(everything)
    grouped = len(order) >= 2
    if query is not None:
        wanted = P.fold(query)
        chans = [ch for ch in everything
                 if wanted in P.fold(ch['name']) or wanted in P.fold(ch.get('group'))]
        if not chans:
            _notify(f'Ningún canal de "{lst["name"]}" coincide con "{query}"')
            _end(False)
            return
    elif group in (None, '*'):
        chans = everything
    else:
        chans = [ch for ch in everything if (ch.get('group') or '') == group]

    xbmcplugin.setPluginCategory(h, lst['name'] if group in (None, '*') else f"{lst['name']} · {group or 'Sin grupo'}")
    more = parsed.get('more') if root else None
    items = []
    if root and (grouped or len(chans) > _SEARCH_ITEM_FROM):
        items.append(_action_item('Buscar en esta lista', _u(action='iptv_search', id=lid),
                                  'busqueda.png', 'Busca un canal por su nombre o su grupo, sin '
                                  'importar mayúsculas ni tildes.'))
    if root and (grouped or more):
        if grouped:
            items.append(_folder_item(f'Todos los canales ({len(chans)})',
                                      _u(action='iptv_open', id=lid, g='*'), 'directo.png'))
        items += [_folder_item(f'{g or "Sin grupo"} ({counts[g]})',
                               _u(action='iptv_open', id=lid, g=g), 'carpeta.png') for g in order]
        items += [_folder_item(m.get('n') or m['id'], _u(action='iptv_more', id=lid, k=m['k'], c=m['id']),
                               'carpeta.png') for m in more or ()]
    else:
        now, needs_epg = _now_map(chans, lst.get('epg') or '')
        if needs_epg:
            items.append(_action_item('Mostrar qué emiten ahora', _u(action='iptv_epg', id=lid),
                                      'cat_epg_texto.png', 'Descarga la guía de programación (unos '
                                      'segundos) y enseña lo que se emite ahora en cada canal.'))
        show_group = grouped and (group == '*' or query is not None)
        rec = _rec(grabaciones.estado(), lid)
        items += [_channel_item(ch, lst['name'], show_group, now.get(i), rec) for i, ch in enumerate(chans)]
        _sort_channels(h)
    xbmcplugin.addDirectoryItems(h, items, len(items))
    _end(True, cache=False)


_MORE_CALLS = {'m': ('get_vod_streams', 'category_id'), 's': ('get_series', 'category_id'),
               'e': ('get_series_info', 'series_id')}


def open_more(params):
    """Las otras secciones de un servidor Xtream, que se leen al abrirlas: k='m' y k='s' son una
    categoría, k='e' una entrada de 's' y t, una de sus partes."""
    h = _handle()
    lid, kind, cid, part = params.get('id', ''), params.get('k'), params.get('c', ''), params.get('t')
    lst = STORE.get(lid)
    xt = (lst or {}).get('xt') or {}
    if kind not in _MORE_CALLS or not all(xt.get(k) for k in ('server', 'user', 'pass')):
        _notify('Esa lista ya no existe', xbmcgui.NOTIFICATION_WARNING)
        _end(False)
        return
    action, key = _MORE_CALLS[kind]
    try:
        data = _xtream_api(xt, bool(lst.get('insecure')), action=action, **{key: cid})
    except P.ListError as e:
        show_message(f'No se ha podido abrir la carpeta.\n\n{e}')
        _end(False)
        return
    except _NeedsInsecure:
        show_message('No se ha podido abrir la carpeta.\n\nEl certificado HTTPS del servidor no es válido.')
        _end(False)
        return
    server, user, password = xt['server'], xt['user'], xt['pass']
    items, raw = [], []
    if kind == 'm':
        raw = P.xtream_channels(server, user, password, data, [], '', 'movie')
    elif kind == 's':
        for s in P.xtream_series(data):
            li = xbmcgui.ListItem(label=s['n'])
            thumb = s['logo'] or _icon('carpeta.png')
            li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
            li.setInfo('video', {'title': s['n'], 'plot': s['plot']})
            items.append((_u(action='iptv_more', id=lid, k='e', c=s['id']), li, True))
    else:
        parts = P.xtream_episodes(server, user, password, data)
        if len(parts) > 1 and part is None:
            items = [_folder_item(f'Temporada {n}', _u(action='iptv_more', id=lid, k='e', c=cid, t=n),
                                  'carpeta.png') for n, _chans in parts]
        elif parts:
            raw = next((chans for n, chans in parts if str(n) == part), parts[0][1])
    items += [_channel_item(ch, lst['name'], False, None) for ch in P.finalize(raw, 'xtream')['channels']]
    if not items:
        _notify('Esta carpeta está vacía')
        _end(False)
        return
    xbmcplugin.addDirectoryItems(h, items, len(items))
    _sort_channels(h)
    _end(True)


def _engine_listing(h, lst, chans, facet, key):
    """Los canales del motor como los enseña Canales de EKHorus: todos por fiabilidad, o por
    categoría, país, idioma y, con AceServe, sus grupos. facet y key vienen de la URL, así que
    una que no exista da la raíz."""
    lid, facets = lst['id'], dict(P.ENGINE_FACETS)
    lang = _kodi_lang()
    items = []
    if facet not in facets:
        xbmcplugin.setPluginCategory(h, lst['name'])
        items.append(_action_item('Buscar en esta lista', _u(action='iptv_search', id=lid),
                                  'busqueda.png', 'Busca un canal por su nombre o su categoría, sin '
                                  'importar mayúsculas ni tildes.'))
        items.append(_folder_item(f'Todos los canales ({len(chans)})', _u(action='iptv_open', id=lid, g='*'),
                                  'directo.png', 'Ordenados por fiabilidad del enlace, con los de tu '
                                  'idioma primero.'))
        for field, title in P.ENGINE_FACETS:
            rows = P.engine_facets(chans, field, P.engine_preferred(field, lang))
            if rows:
                plot = ('Agrupa los canales como vienen agrupados de origen, con algunos que no '
                        'salen en las otras carpetas.' if field == 'pl' else f'Los {len(chans)} canales agrupados así.')
                items.append(_folder_item(f'{title} ({len(rows)})', _u(action='iptv_open', id=lid, f=field),
                                          _ENGINE_FACET_ICON[field], plot))
    elif key is None:
        xbmcplugin.setPluginCategory(h, f"{lst['name']} · {facets[facet]}")
        for value, label, members in P.engine_facets(chans, facet, P.engine_preferred(facet, lang)):
            sample = ', '.join(ch['name'] for ch in members[:5])
            items.append(_folder_item(f'{label} ({len(members)})', _u(action='iptv_open', id=lid, f=facet, g=value),
                                      _facet_icon(facet, value), f'{_canales(len(members))}: {sample}...'))
    else:
        members = next((m for value, _label, m in P.engine_facets(chans, facet) if value == key), [])
        xbmcplugin.setPluginCategory(h, f"{lst['name']} · {P.engine_label(facet, key)}")
        items = [_channel_item(ch, lst['name'], False, None) for ch in members]
        if not items:
            _notify('No queda ningún canal aquí')
            _end(False)
            return
        _sort_channels(h)
    xbmcplugin.addDirectoryItems(h, items, len(items))
    _end(True, cache=False)


def _action_item(label, url, icon, plot):
    li = xbmcgui.ListItem(label=f'[COLOR khaki]{label}[/COLOR]')
    li.setArt({'icon': _icon(icon), 'thumb': _icon(icon)})
    li.setInfo('video', {'title': label, 'plot': plot})
    return url, li, False


def _folder_item(label, url, icon, plot=''):
    li = xbmcgui.ListItem(label=label)
    named = icon.endswith('.png') and not icon.startswith('Default') and not os.path.isabs(icon)
    art = _icon(icon) if named else icon
    li.setArt({'icon': art, 'thumb': art})
    if plot:
        li.setInfo('video', {'title': label, 'plot': plot})
    return url, li, True


def search_prompt(params):
    lid = params.get('id', '')
    text = xbmcgui.Dialog().input('Buscar canal')
    if not text.strip():
        return
    # Container.Update desde un item que no es carpeta, para que al volver atrás no reaparezca el teclado.
    xbmc.executebuiltin(f'Container.Update({_u(action="iptv_open", id=lid, q=text.strip())})')


def _search_all(query):
    h = _handle()
    wanted = P.fold(query)
    items = []
    estado = grabaciones.estado()
    for lst in STORE.lists():
        try:
            parsed = channels(lst, network=False)
        except P.ListError:
            continue
        rec = _rec(estado, lst['id'])
        for ch in parsed['channels']:
            if wanted in P.fold(ch['name']) or wanted in P.fold(ch.get('group')):
                url, li, folder = _channel_item(ch, lst['name'], False, None, rec)
                li.setLabel(f"{li.getLabel()}  [COLOR gray]· {lst['name']}[/COLOR]")
                items.append((url, li, folder))
    if not items:
        _notify(f'Ningún canal de tus listas coincide con "{query}"')
        _end(False)
        return
    xbmcplugin.setPluginCategory(h, f'Buscar: {query}')
    xbmcplugin.addDirectoryItems(h, items, len(items))
    _end(True, cache=False)


def load_epg(lid=''):
    """Descarga la guía de la lista lid si trae una propia, o si no la general. La de un servidor
    Xtream puede pesar decenas de MB, así que se ve lo que va bajando y se puede cancelar."""
    lst = STORE.get(lid) if lid else None
    with _progress('Descargando la guía de programación...') as dp:
        def progreso(read, total):
            mb = f'{read / 1048576:.1f} MB' + (f' de {total / 1048576:.1f} MB' if total else '')
            dp.update(min(99, read * 100 // total) if total else 0,
                      f'Descargando la guía de programación...\n{mb}')
            return not dp.iscanceled()
        try:
            found = epg_texto.now_playing([], download=True, url=(lst or {}).get('epg') or '',
                                          progreso=progreso)
        except epg_texto.DescargaCancelada:
            return
        except epg_texto.GuiaDemasiadoGrande:
            found = False
    if found is False:
        show_message('La guía de esta lista es demasiado grande y no se puede cargar.')
        return
    if found is None:
        _notify('No se ha podido descargar la guía. Prueba más tarde.', xbmcgui.NOTIFICATION_WARNING)
        return
    _refresh_container()


def preview(params):
    """Una lista sin guardarla (Ver ahora del catálogo, o un enlace antiguo que ya no está)."""
    h = _handle()
    url, title = params.get('url', ''), params.get('title', '') or 'Lista'
    entry = {'kind': 'url', 'src': url}
    try:
        def work(insecure):
            entry['insecure'] = insecure
            with _progress(f'Leyendo "{title}"...') as dp:
                return _fetch_source(entry, dp)
        parsed = _with_insecure_retry(entry, work)
    except _Cancelled:
        _end(False)
        return
    except P.ListError as e:
        show_message(f'No se ha podido abrir la lista.\n\n{e}')
        _end(False)
        return
    chans = parsed['channels']
    if not chans:
        show_message(_empty_reason(parsed))
        _end(False)
        return
    xbmcplugin.setPluginCategory(h, title)
    now, _needs = _now_map(chans, parsed.get('epg') or '')
    rec = _rec(grabaciones.estado(), epg=parsed.get('epg') or '')
    items = [_channel_item(ch, title, True, now.get(i), rec) for i, ch in enumerate(chans)]
    xbmcplugin.addDirectoryItems(h, items, len(items))
    _sort_channels(h)
    _end(True, cache=False)


# --- Reproducir ---

def _props(extra):
    try:
        value = json.loads(extra) if extra else []
    except ValueError:
        return []
    return P.safe_props([str(v) for v in value]) if isinstance(value, list) else []


def _has_header(headers, name):
    return any(k.lower() == name for k in headers)


_RADIO_LIST_EXTS = ('.pls', '.m3u')
_PLS_ENTRY_RE = re.compile(r'^file\d+\s*=\s*(\S+)', re.I)


def _unwrap_radio_list(url, depth=2):
    """(url, tipo) de la emisión que hay dentro de una lista .pls o .m3u, que Kodi no abre desde
    un ListItem y se queda sin sonar. Una .m3u que es un HLS sigue siendo la misma dirección, como
    HLS. Si no se puede leer, la dirección tal cual."""
    base, _sep, pipe = url.partition('|')
    try:
        if not urllib.parse.urlsplit(base).path.lower().endswith(_RADIO_LIST_EXTS):
            return url, P.KIND_DIRECT
        # Con el tope, una emisión mal llamada .m3u corta enseguida en vez de bajarse sin fin.
        text = P.decode(_download(base, limit=65536, timeout=(5, 10)))
    except (ValueError, P.ListError, _NeedsInsecure):
        return url, P.KIND_DIRECT
    if '#EXT-X-' in text:
        return url, P.KIND_HLS
    for line in text.splitlines():
        line = line.strip()
        match = _PLS_ENTRY_RE.match(line)
        if match:
            entry = match.group(1)
        elif '://' in line and not line.startswith('#'):
            entry = line
        else:
            continue
        kind, norm = P.classify(entry)
        if kind not in (P.KIND_HLS, P.KIND_DASH, P.KIND_DIRECT):
            continue
        inner = f'{norm}|{pipe}' if pipe and '|' not in norm else norm
        if kind == P.KIND_DIRECT and depth:
            return _unwrap_radio_list(inner, depth - 1)
        return inner, kind
    return url, P.KIND_DIRECT


_DRM_KEY_RE = re.compile(r'#EXT-X-(?:SESSION-)?KEY:[^\n]*(?:METHOD=SAMPLE-AES-CTR|'
                         r'KEYFORMAT="(?:urn:uuid:|com\.apple\.streamingkeydelivery))', re.I)
_DRM_MSG = ('Este canal está protegido con DRM y Kodi no puede abrirlo. Los canales de la TDT '
            'los tienes en TDT Channels España.')


def _drm_blocked(url, props):
    """True si es un canal de un redirector (Samsung TV Plus y otros) cifrado con DRM y sin
    licencia en la lista. Kodi no puede abrirlo y, en Windows, intentarlo con su HLS lo cierra."""
    licensed = any(kp.lower().startswith('inputstream.adaptive.license') for kp in props)
    if licensed or not P.via_redirector(url):
        return False
    try:
        text = P.decode(_download(url.split('|', 1)[0], limit=262144, timeout=(4, 8)))
    except (P.ListError, _NeedsInsecure):
        return False
    return bool(_DRM_KEY_RE.search(text))


def _cabeceras(url, ua, ref):
    """(dirección, cabeceras) de un directo: las que trae tras | y, si no las dice, el User-Agent y
    el Referer de la lista. La grabación las usa también, para pedir lo mismo que el reproductor."""
    import url_player
    base, headers = url_player.parse_url_with_headers(url)
    # Kodi decodifica los valores que van tras | (CURL::Decode, con + como espacio) y aquí se vuelven
    # a codificar.
    headers = {k: urllib.parse.unquote_plus(v) for k, v in headers.items()}
    if ua and not _has_header(headers, 'user-agent'):
        headers['User-Agent'] = ua
    if ref and not _has_header(headers, 'referer'):
        headers['Referer'] = ref
    if not _has_header(headers, 'user-agent') and base.lower().startswith(('http://', 'https://')):
        # Sin User-Agent en la lista, el de un navegador, porque hay servidores que rechazan el de
        # Kodi (el directo de La 1 de RTVE, por ejemplo, da 403 con el de Kodi).
        headers['User-Agent'] = ui_utils.HEADERS['User-Agent']
    return base, headers


def _listitem(url, ua, ref, props, title, kind=None):
    """(ruta, ListItem) de un directo HTTP/RTMP/UDP, o None si falta InputStream Adaptive. kind
    sirve cuando el tipo ya se sabe por el contenido y no se ve en la dirección."""
    base, headers = _cabeceras(url, ua, ref)
    kind = kind or P.classify(base)[0]
    prop_map = dict(kp.split('=', 1) for kp in props)
    wants_isa = any(k.lower() == 'inputstream' and v == 'inputstream.adaptive' for k, v in prop_map.items())
    has_isa = bool(xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'))
    use_isa = kind == P.KIND_DASH or wants_isa or (
        kind == P.KIND_HLS and has_isa and _ADDON.getSetting('use_inputstream') == 'true')
    if use_isa and not has_isa:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            # Instalado pero desactivado. InstallAddon no hace nada con él, así que se ofrece activarlo.
            if not ui_utils.addon_listo('inputstream.adaptive', 'InputStream Adaptive'):
                return None
        else:
            show_message('Este canal necesita InputStream Adaptive, el componente de '
                                          'Kodi para DASH y para los canales con DRM.\n\nKodi te '
                                          'preguntará ahora si quieres instalarlo.')
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
            return None

    # También la /: la base de vídeos de Kodi parte la dirección por la última, que caería dentro del
    # User-Agent, y al volver a abrirla sale con el título "537.36" y sin el punto donde se quedó.
    header_str = '&'.join(f'{k}={urllib.parse.quote(str(v), safe="")}' for k, v in headers.items())
    if use_isa:
        path = base
        li = xbmcgui.ListItem(label=title, path=path)
        li.setProperty('inputstream', 'inputstream.adaptive')
        if _kodi_major() < 21:
            # Desde InputStream Adaptive 21 el tipo se detecta solo y la propiedad está obsoleta.
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd' if kind == P.KIND_DASH else 'hls')
        if header_str:
            li.setProperty('inputstream.adaptive.manifest_headers', header_str)
            li.setProperty('inputstream.adaptive.stream_headers', header_str)
    else:
        # RTMP no admite cabeceras por pipe, porque se las comería como parte de la dirección.
        path = f'{base}|{header_str}' if header_str and not base.lower().startswith('rtmp') else base
        li = xbmcgui.ListItem(label=title, path=path)
    if kind == P.KIND_HLS:
        li.setMimeType('application/x-mpegURL')
    elif kind == P.KIND_DASH:
        li.setMimeType('application/dash+xml')
    li.setContentLookup(False)
    for key, value in prop_map.items():
        li.setProperty(key, value)
    li.setInfo('video', {'title': title})
    return path, li


def _engine_alive(host, port):
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except OSError:
        return False


def play(params, mode='list'):
    """mode: 'list' (un canal de una lista), 'fav' (desde Favoritos, que abre los canales
    como carpeta) o 'pvr' (la sección TV de Kodi, que espera setResolvedUrl)."""
    url = params.get('url') or ''
    ua, ref, title = params.get('ua') or '', params.get('ref') or '', params.get('title') or ''
    props = _props(params.get('extra'))
    # classify conserva las cabeceras "|..." de un directo y normaliza los AceStream.
    kind, norm = P.classify(url)
    try:
        if mode == 'pvr':
            _resolve_for_pvr(kind, norm, ua, ref, props, title)
        elif kind == P.KIND_ACE:
            _play_ace(norm)
        elif kind in (P.KIND_WEB, P.KIND_TORRENT):
            import url_player
            url_player.play_without_history(norm)
        elif kind == P.KIND_PLUGIN:
            if '"' not in norm:
                xbmc.executebuiltin(f'PlayMedia("{norm}")')
        elif kind in (P.KIND_HLS, P.KIND_DASH, P.KIND_DIRECT):
            if kind == P.KIND_DIRECT:
                norm, kind = _unwrap_radio_list(norm)
            elif _drm_blocked(norm, props):
                show_message(_DRM_MSG)
                return
            built = _listitem(norm, ua, ref, props, title, kind)
            if built:
                xbmc.Player().play(built[0], built[1])
        else:
            _notify('Este enlace no se puede reproducir en Kodi', xbmcgui.NOTIFICATION_WARNING)
    finally:
        if mode == 'fav':
            _end(False)


def _play_ace(url):
    """AceStream por la cadena de url_player (StreamNinja, EKHorus/Horus, motor local).
    Un canal del motor viene por infohash, así que se le pide al motor del usuario su content_id,
    que es lo que entienden esos reproductores, y si no lo da se abre directamente en el motor."""
    import url_player
    ref = P.ace_ref(url)
    if not ref or ref[0] == 'id':
        url_player.play_without_history(url)
        return
    cid = _engine_content_id(ref[1])
    if cid:
        url_player.play_without_history(f'acestream://{cid}')
        return
    host, port = _engine_server()
    if _engine_alive(host, port):
        path = f'http://{host}:{port}/ace/getstream?infohash={ref[1]}'
        li = xbmcgui.ListItem(path=path)
        li.setContentLookup(False)
        xbmc.Player().play(path, li)
    else:
        show_message(_engine_down(host, port))


def play_alt(params):
    """Otro de los enlaces de un canal del motor que trae varios, elegido por el usuario."""
    alts = [h for h in (params.get('alts') or '').split(',') if re.fullmatch(r'[0-9a-f]{40}', h)]
    if not alts:
        return
    title = params.get('title') or 'Canal'
    labels = [f'Enlace de repuesto {n}' for n in range(1, len(alts) + 1)]
    sel = 0 if len(alts) == 1 else xbmcgui.Dialog().select(title, labels)
    if sel >= 0:
        _play_ace(P.engine_url(alts[sel]))


def _resolve_for_pvr(kind, url, ua, ref, props, title):
    h = _handle()
    if kind == P.KIND_ACE:
        ace = P.ace_ref(url)
        host, port = _engine_server()
        if not ace or not _engine_alive(host, port):
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            show_message('Para ver este canal AceStream desde la TV de Kodi hace falta EKHorus o '
                         f'el motor AceStream en marcha ({host}:{port}).')
            return
        li = xbmcgui.ListItem(path=f'http://{host}:{port}/ace/getstream?{ace[0]}={ace[1]}')
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
        return
    if kind == P.KIND_PLUGIN:
        xbmcplugin.setResolvedUrl(h, True, xbmcgui.ListItem(path=url))
        return
    if kind == P.KIND_HLS and _drm_blocked(url, props):
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        show_message(_DRM_MSG)
        return
    built = _listitem(url, ua, ref, props, title) if kind in (P.KIND_HLS, P.KIND_DASH, P.KIND_DIRECT) else None
    if built:
        xbmcplugin.setResolvedUrl(h, True, built[1])
    else:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())


# --- Gestionar ---

def _get_or_warn(lid):
    lst = STORE.get(lid)
    if lst is None:
        _notify('Esa lista ya no existe', xbmcgui.NOTIFICATION_WARNING)
    return lst


def _mutate_or_warn(fn):
    """(resultado de fn, guardado). Avisa si no se ha podido guardar."""
    try:
        return STORE.mutate(fn), True
    except iptv_store.LockBusy:
        _notify('Otra operación con tus listas está en curso. Inténtalo de nuevo.', xbmcgui.NOTIFICATION_WARNING)
    except iptv_store.StoreError as e:
        show_message(f'No se han podido guardar los cambios.\n\n{e}')
    return None, False


def _set_or_warn(lid, **fields):
    """Cambia campos de una lista y avisa si no se ha podido. True si se ha guardado."""
    def apply(lists):
        for entry in lists:
            if entry['id'] == lid:
                entry.update(fields)
                return True
        return False
    changed, saved = _mutate_or_warn(apply)
    return bool(saved and changed)


def _sync_tv(interactive, reload_tv):
    import iptv_pvr
    return iptv_pvr.sync(interactive=interactive, reload_tv=reload_tv)


def refresh(lid):
    lst = _get_or_warn(lid)
    if lst is None:
        return
    if lst['kind'] == 'text':
        _notify('Esta lista es texto pegado y no tiene una fuente que actualizar')
        return

    def work(insecure):
        lst['insecure'] = insecure
        with _progress(f'Actualizando "{lst["name"]}"...') as dp:
            return _fetch_source(lst, dp)
    try:
        parsed = _with_insecure_retry(lst, work)
    except _Cancelled:
        return
    except P.ListError as e:
        show_message(f'No se ha podido actualizar "{lst["name"]}".\n\n{e}\n\n'
                                      'Se mantiene la copia anterior.')
        return
    new, old = len(parsed['channels']), int(lst.get('count') or 0)
    if _empty(parsed):
        show_message(f'{_empty_reason(parsed)}\n\nSe mantiene la copia anterior.')
        return
    if parsed.get('partial') and old:
        show_message(f'El motor ha dejado de contestar a mitad de la lista ({new} canales).\n\n'
                     'Se mantiene la copia anterior.')
        return
    if old and new < old * _ASK_BELOW and not xbmcgui.Dialog().yesno(
            _HEADING, f'La lista pasa de {old} a {_canales(new)}. Suele ser una caída de la fuente.\n\n'
                      '¿Aceptas la versión nueva?', nolabel='Mantener la anterior', yeslabel='Aceptar'):
        return
    if lst.get('insecure'):
        _set_or_warn(lid, insecure=True)
    _save_copy(lst, parsed)
    _notify(f'"{lst["name"]}" actualizada: {old} → {_canales(new)}')
    if lst.get('pvr'):
        _sync_tv(interactive=False, reload_tv=False)
    _refresh_container()


def rename(lid):
    lst = _get_or_warn(lid)
    if lst is None:
        return
    name = _ask_name('Nuevo nombre de la lista', lst['name'])
    if not name or name == lst['name']:
        return
    if _set_or_warn(lid, name=name):
        if lst.get('pvr'):
            _sync_tv(interactive=False, reload_tv=False)
        _refresh_container()


def move(lid, direction):
    def apply(lists):
        pos = next((i for i, entry in enumerate(lists) if entry['id'] == lid), None)
        if pos is None:
            return False
        other = pos - 1 if direction == 'up' else pos + 1
        if not 0 <= other < len(lists):
            return False
        lists[pos], lists[other] = lists[other], lists[pos]
        return True
    moved, ok = _mutate_or_warn(apply)
    if ok and moved:
        _refresh_container()


def delete(lid):
    lst = _get_or_warn(lid)
    if lst is None:
        return
    if not xbmcgui.Dialog().yesno(_HEADING, f'¿Eliminar la lista "{lst["name"]}"? Se borra con todo '
                                            'lo guardado de ella y no se puede deshacer.',
                                  nolabel='Cancelar', yeslabel='Eliminar'):
        return
    removed, ok = _mutate_or_warn(lambda lists: _remove_entry(lists, lid))
    if not ok:
        return
    STORE.delete_files(lid)
    if removed and removed.get('pvr'):
        _sync_tv(interactive=True, reload_tv=True)
    _notify('Lista eliminada')
    _refresh_container()


def _remove_entry(lists, lid):
    for i, entry in enumerate(lists):
        if entry['id'] == lid:
            return lists.pop(i)
    return None


def toggle_tv(lid):
    lst = _get_or_warn(lid)
    if lst is None:
        return
    enable = not lst.get('pvr')
    if not _set_or_warn(lid, pvr=enable):
        return
    if not _sync_tv(interactive=True, reload_tv=True) and enable:
        # Sin IPTV Simple, o si no se ha podido escribir, la marca no se queda puesta.
        _set_or_warn(lid, pvr=False)
    _refresh_container()


def _ttl_text(seconds):
    if seconds >= 86400 and seconds % 86400 == 0:
        days = seconds // 86400
        return 'un día' if days == 1 else f'{days} días'
    if seconds >= 3600 and seconds % 3600 == 0:
        hours = seconds // 3600
        return 'una hora' if hours == 1 else f'{hours} horas'
    return f'{seconds // 60} minutos'


def info(lid):
    lst = _get_or_warn(lid)
    if lst is None:
        return
    lines = [f"[B]{lst['name']}[/B]", '', f"Tipo: {_KIND_LABEL.get(lst['kind'], lst['kind'])}"]
    src = lst['src']
    if lst['kind'] == 'text':
        src = 'texto guardado en este aparato'
    elif lst['kind'] == 'telegram':
        src = f'https://t.me/s/{src}'
    elif lst['kind'] == 'xtream':
        xt = lst.get('xt') or {}
        src = f"{xt.get('server', '?')} (usuario {xt.get('user', '?')}, contraseña guardada)"
    if lst['kind'] != 'engine':
        lines.append(f'Fuente: {_mask(src)}')
    try:
        parsed = channels(lst, network=False)
        groups, ace = P.summary(parsed['channels'])
        lines.append(f"Canales en directo: {len(parsed['channels'])}   Grupos: {groups}   AceStream: {ace}")
        if parsed.get('sublists'):
            failed = parsed.get('sublists_failed') or 0
            lines.append(f"Listas enlazadas: {parsed['sublists']}" + (
                f" ({failed} no se {'pudo' if failed == 1 else 'pudieron'} leer la última vez)" if failed else ''))
            if lst['kind'] == 'file':
                lines.append('Las listas enlazadas se vuelven a leer si cambias el archivo o si han '
                             f'pasado {_ttl_text(_TTL["url"])}.')
    except P.ListError:
        lines.append(f"Canales en directo: {lst.get('count') or 0}")
    lines.append(f"Última lectura: {_fmt_date(lst.get('updated'))}")
    if lst['kind'] in _TTL:
        ttl = _ttl_text(_TTL[lst['kind']])
        lines.append(f"Se actualiza sola al abrirla si {'ha' if ttl.startswith('un') else 'han'} pasado {ttl}.")
    if lst.get('epg'):
        lines.append('Trae su propia guía de programación.')
    if lst.get('insecure'):
        lines.append('Se descarga sin comprobar el certificado HTTPS (lo aceptaste al añadirla).')
    account = lst.get('account') or {}
    if account:
        exp = account.get('exp')
        try:
            exp_txt = time.strftime('%d/%m/%Y', time.localtime(int(exp))) if exp else 'sin caducidad'
        except (TypeError, ValueError, OverflowError, OSError):
            exp_txt = str(exp)
        lines += ['', f"Cuenta: {account.get('status') or 'activa'}   Caduca: {exp_txt}   "
                      f"Conexiones: {account.get('conns') or '?'}   Formato: {account.get('fmt') or '?'}"]
    lines += ['', 'En la sección TV de Kodi: ' + ('sí' if lst.get('pvr') else 'no'), '', _LIST_CONTEXT_HELP]
    xbmcgui.Dialog().textviewer(_HEADING, '\n'.join(lines))


# --- Copias de seguridad ---

_SNAPSHOT_RE = re.compile(r'^iptv_lists/([0-9a-f]{12})\.txt$')


def backup_files():
    """[(ruta en disco, nombre en el zip)] de lo que hay que guardar, que es el JSON y lo
    pegado o enviado desde el móvil (no tiene otra copia). Las copias descargadas no, porque se regeneran."""
    out = [(STORE.path, iptv_store.LISTS_FILE)] if os.path.exists(STORE.path) else []
    folder = os.path.join(STORE.profile, iptv_store.TEXT_DIR)
    try:
        names = sorted(os.listdir(folder))
    except OSError:
        names = []
    out += [(os.path.join(folder, n), f'{iptv_store.TEXT_DIR}/{n}') for n in names
            if _SNAPSHOT_RE.match(f'{iptv_store.TEXT_DIR}/{n}')]
    return out


def restore_from_backup(zf):
    """Restaura las listas de una copia (zip ya abierto), sustituyendo las actuales o sumándolas.

    Del zip solo se leen nombres que casan con iptv_lists/<12 hex>.txt, así que una copia
    manipulada no puede escribir fuera de la carpeta del addon. Las listas restauradas llegan
    sin marcar para la TV de Kodi."""
    try:
        with zf.open(iptv_store.LISTS_FILE) as f:
            incoming = iptv_store.normalize_lists(json.loads(f.read().decode('utf-8')))
    except (KeyError, OSError, ValueError) as e:
        _log(f'restaurar: la copia no trae listas válidas: {e}', xbmc.LOGWARNING)
        incoming = []
    snapshots = {m.group(1): name for name in zf.namelist() for m in [_SNAPSHOT_RE.match(name)] if m}
    # Una lista pegada sin su texto en la copia no tiene de dónde leer, así que no se restaura.
    incoming = [dict(e, pvr=False) for e in incoming if e['kind'] != 'text' or e['id'] in snapshots]
    if not incoming:
        _notify('La copia no trae listas de canales que se puedan restaurar', xbmcgui.NOTIFICATION_WARNING)
        return False

    current = STORE.lists()
    replace = True
    if current:
        sel = xbmcgui.Dialog().select('Listas de canales', [
            'Sustituir mis listas por las de la copia', 'Añadir las de la copia a las mías', 'Omitir'])
        if sel in (-1, 2):
            return False
        replace = sel == 0
    had_tv = any(lst.get('pvr') for lst in current)

    def apply(lists):
        keep = [] if replace else lists
        added = []
        for entry in incoming:
            if any(lst['id'] == entry['id'] or _same_source(lst, entry) for lst in keep + added):
                continue
            if entry['kind'] == 'text':
                with zf.open(snapshots[entry['id']]) as f:
                    if not STORE.save_text(entry['id'], P.decode(f.read())):
                        continue
            added.append(entry)
        dropped = [lst['id'] for lst in lists] if replace else []
        lists[:] = keep + added
        return dropped, len(added)
    result, saved = _mutate_or_warn(apply)
    if not saved:
        return False
    dropped, count = result
    kept = {lst['id'] for lst in STORE.lists()}
    for lid in dropped:
        if lid not in kept:
            STORE.delete_files(lid)
    if replace and had_tv:
        _sync_tv(interactive=True, reload_tv=True)
    _notify(f'Listas de canales restauradas: {count}')
    return True


# --- Enlaces antiguos (favoritos y atajos del formato anterior) ---

def _find_by_src(url):
    tg = re.match(r'^https?://t\.me/s/([A-Za-z0-9_]{5,})/?$', url or '', re.I)
    for lst in STORE.lists():
        if lst['src'] == url or (tg and lst['kind'] == 'telegram' and lst['src'] == tg.group(1)):
            return lst
    return None


def open_legacy(url):
    lst = _find_by_src(url)
    if lst:
        open_list({'id': lst['id']})
    else:
        preview({'url': url, 'title': 'Lista'})


def delete_legacy(url):
    lst = _find_by_src(url)
    if lst:
        delete(lst['id'])


# Acciones que son scripts (items que no son carpeta) y acaban en Container.Refresh/Update.
_SCRIPT_ACTIONS = {'iptv_add', 'iptv_search', 'iptv_epg', 'iptv_refresh', 'iptv_rename',
                   'iptv_move', 'iptv_delete', 'iptv_pvr', 'iptv_info', 'iptv_guide', 'iptv_alt',
                   'iptv_record', 'iptv_record_stop'}


def route(action, params):
    """Punto de entrada desde el router de default.py para las acciones iptv_*."""
    if action in _SCRIPT_ACTIONS and _handle() >= 0:
        # Abierta como carpeta (un atajo, un widget, un favorito), se cierra ya. Si no, Kodi
        # espera un listado que no llega, y el Container.Refresh del final volvería a ejecutar
        # esta misma acción en bucle hasta tumbar Kodi.
        _end(False)
    lid = params.get('id', '')
    if action == 'iptv_add':
        ui_utils.visto('iptv_add')
        add_list()
    elif action == 'iptv_open':
        open_list(params)
    elif action == 'iptv_more':
        open_more(params)
    elif action == 'iptv_search':
        ui_utils.visto('iptv_search')
        search_prompt(params)
    elif action == 'iptv_play':
        play(params, 'pvr' if params.get('src') == 'pvr' else 'list')
    elif action == 'iptv_play_fav':
        play(params, 'fav')
    elif action == 'iptv_preview':
        preview(params)
    elif action == 'iptv_epg':
        load_epg(lid)
    elif action == 'iptv_refresh':
        refresh(lid)
    elif action == 'iptv_rename':
        rename(lid)
    elif action == 'iptv_move':
        move(lid, params.get('dir', ''))
    elif action == 'iptv_delete':
        delete(lid)
    elif action == 'iptv_pvr':
        toggle_tv(lid)
    elif action == 'iptv_info':
        info(lid)
    elif action == 'iptv_guide':
        if iptv_guide.show():
            xbmc.executebuiltin('Container.Refresh')
    elif action == 'iptv_alt':
        play_alt(params)
    elif action == 'iptv_record':
        # Solo aquí: el grabador no se compila en cada listado.
        import iptv_grabar
        iptv_grabar.grabar(params)
    elif action == 'iptv_record_stop':
        grabaciones.parar(params)
