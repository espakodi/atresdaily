# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Novedades del addon: el <news> de addon.xml en la ventana de la guía de las listas.

El texto se lee de addon.xml cada vez que se abre, así que sale lo que diga el archivo. Cada
versión ("v5.0.0", "v4.0.1 - lema") es una sección del índice y cada apartado en mayúsculas
(LISTAS DE CANALES, CORRECCIONES...) una entrada. El punto verde del botón depende del propio
texto: se enciende cuando el <news> cambia y se apaga al leerlo.
"""
import os
import re
import zlib

import xbmc
import xbmcgui
import xbmcplugin

import ui_utils
from plugin_utils import _handle

ADDON_XML = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'addon.xml')
_PROPIEDAD = 'atresdaily.novedades'
_VERSION = re.compile(r'^(?:v|versi[oó]n\s+)(\d+(?:\.\d+)+)\b[\s:.–—-]*(.*)$', re.I)
_VINETA = re.compile(r'^[-*•·]\s+')
_FORMATO = re.compile(r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR)\]|\[COLOR [^\]]*\]|\[/COLOR\]', re.I)


def firma():
    """Huella del <news>: cambia en cuanto cambia el texto. Lee el archivo en crudo, sin
    ElementTree, porque se calcula en cada visita al menú principal."""
    try:
        with open(ADDON_XML, 'rb') as f:
            datos = f.read()
    except OSError:
        datos = b''
    inicio = datos.find(b'<news')
    fin = datos.find(b'</news>', inicio) if inicio >= 0 else -1
    return f'{zlib.crc32(datos[inicio:fin] if fin > inicio else b""):08x}'


def claves():
    """Claves del punto verde de EspaKodi e Información y del botón Novedades."""
    huella = firma()
    return f'info_{huella}', f'novedades_{huella}'


def leer():
    # Importar ElementTree cuesta unos 20 ms: solo se paga al abrir las novedades.
    import xml.etree.ElementTree as ET
    nodo = ET.parse(ADDON_XML).getroot().find('.//news')
    return nodo.text if nodo is not None and nodo.text else ''


def _seccion(titulo, lema=''):
    return {'num': '', 'titulo': titulo, 'icono': 'info_version.png',
            'lineas': [f'[B]{lema}[/B]', ''] if lema else [], 'entradas': []}


def _texto(lineas):
    lineas = [_VINETA.sub('·  ', x) for x in lineas]
    return re.sub(r'\n{3,}', '\n\n', '\n'.join(lineas)).strip()


def secciones(news):
    """El <news> con el formato de iptv_guide.GUIA."""
    guia = []
    for linea in news.splitlines():
        linea = linea.strip()
        limpia = _FORMATO.sub('', linea).strip()
        version = _VERSION.match(limpia)
        if version:
            guia.append(_seccion(f'Versión {version.group(1)}', version.group(2).strip()))
            continue
        if not guia:
            if not limpia:
                continue
            # Texto antes de la primera versión, o un <news> sin versiones: una sola sección.
            guia.append(_seccion('Novedades'))
        seccion = guia[-1]
        if limpia.isupper() and not _VINETA.match(limpia):
            seccion['entradas'].append({'titulo': limpia.rstrip(':').strip(), 'lineas': []})
        elif seccion['entradas']:
            seccion['entradas'][-1]['lineas'].append(linea)
        else:
            seccion['lineas'].append(linea)
    for seccion in guia:
        seccion['cuerpo'] = _texto(seccion.pop('lineas'))
        for entrada in seccion['entradas']:
            entrada['cuerpo'] = _texto(entrada.pop('lineas'))
    return guia


def mostrar():
    if _handle() >= 0:
        # Abierta como carpeta (un atajo o un widget): se cierra el listado ya, o Kodi se
        # quedaría esperándolo y el Container.Refresh del final volvería a abrir la ventana.
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
    _, clave = claves()
    era_nuevo = ui_utils.visto(clave)
    try:
        guia = secciones(leer())
    except (OSError, SyntaxError) as e:  # ElementTree.ParseError es un SyntaxError
        xbmc.log(f'[AtresDaily] Novedades: no se puede leer {ADDON_XML}: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Novedades', 'No se han podido leer las novedades del addon.')
    else:
        if guia:
            import iptv_guide  # la ventana y el texto de la guía, solo al abrir las novedades
            iptv_guide.abrir(guia, 'Novedades', _PROPIEDAD, abiertas={0}, entera=True)
        else:
            xbmcgui.Dialog().ok('Novedades', 'Esta versión no trae notas de novedades.')
    if era_nuevo:
        # Para que el botón pierda el punto verde al volver al menú.
        xbmc.executebuiltin('Container.Refresh')
