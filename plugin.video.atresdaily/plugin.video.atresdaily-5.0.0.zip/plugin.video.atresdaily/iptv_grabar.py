# -*- coding: utf-8 -*-
# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Grabar un canal o una emisora de las listas de canales en la carpeta de descargas.

Cada grabación corre dentro de su propia llamada al addon (RunPlugin desde el menú contextual),
apuntada en grabaciones, hasta la hora de fin o hasta que se pide pararla. Del HLS se guardan los
segmentos tal como llegan (TS, fMP4 o audio) y de un directo, los bytes. Lo cifrado y lo que manda
el sonido aparte necesitarían descifrar o mezclar, así que se avisa antes de empezar.
"""
import collections
import errno
import hashlib
import os
import re
import shutil
import sys
import time
import traceback
import urllib.parse
import warnings

import requests
import xbmc
import xbmcgui
import xbmcvfs

import epg_texto
import grabaciones
import iptv_lists as L
import iptv_parse as P
import ui_utils

_LOG = '[AtresDaily/Grabar]'
_MARGEN_FIN = 5 * 60
_DURACIONES = ((30 * 60, '30 minutos'), (3600, '1 hora'), (2 * 3600, '2 horas'), (3 * 3600, '3 horas'))
_SIN_LIMITE = 8 * 3600
# Android avisa de poco espacio a partir de 500 MiB, y Kodi necesita sitio para sus bases de datos.
_LIBRE_MIN = 1024 ** 3
# FAT32, el formato de muchas memorias USB, no admite archivos de 4 GiB.
_TOPE_PARTE = 4 * 1024 ** 3 - 16 * 1024 ** 2
_TOPE_SEGMENTO = 50 * 1024 ** 2
_TOPE_MANIFIESTO = 2 * 1024 ** 2
# Al cerrarse, Kodi deja 5 s a los scripts y luego mete un SystemExit, que no corta una conexión ni
# una lectura que se han quedado esperando; por eso las dos esperas son cortas.
_TIEMPO = (4, 4)
_TIEMPO_PREPARAR = (5, 10)
_TROZO_HLS = 65536
# Hasta llenar un trozo no se mira si hay que parar, y una radio de 32 kbps tarda 16 s en llenar 64 KB.
_TROZO_DIRECTO = 8192
# Como un reproductor que entra en un directo (RFC 8216, 6.3.3).
_EN_DIRECTO = 3
_SIN_DATOS_MAX = 5 * 60
_CIFRADO_MAX = 2 * 60
_CORTES_MAX = 3
_CORTES_VENTANA = 5 * 60
_CADA_ESPACIO = 30
_CADA_BARRA = 2
_AUDIO_TS = {0x03, 0x04, 0x0F, 0x11, 0x81, 0x87}
_VIDEO = ('avc', 'hvc', 'hev', 'dvh', 'dva', 'vp08', 'vp09', 'av01', 'mp4v')
_EXT_TIPO = {'audio/mpeg': '.mp3', 'audio/mp3': '.mp3', 'audio/aac': '.aac', 'audio/aacp': '.aac',
             'audio/x-aac': '.aac', 'audio/ogg': '.ogg', 'application/ogg': '.ogg',
             'audio/opus': '.ogg', 'audio/flac': '.flac', 'video/mp2t': '.ts'}
_ATRIBUTO_RE = re.compile(r'([A-Z0-9-]+)=("[^"]*"|[^",]*)')
_NO_VALE_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')

_CIFRADO = 'Este canal va cifrado y no se puede grabar.'
_SONIDO_APARTE = 'Este canal manda el sonido aparte del vídeo y no se puede grabar.'
_NO_GRABABLE = 'Este canal no se puede grabar.'
_NO_EMITE = 'El canal no está emitiendo ahora mismo. Prueba más tarde.'
_NO_RESPONDE = 'No se ha podido conectar con el canal. Comprueba que se ve y prueba otra vez.'
_ICY = 'Esta emisora usa un formato antiguo (ICY) que no se puede grabar.'
_WEB = 'Esta dirección lleva a una página web y no a una emisión.'
_SIN_DATOS = 'El canal ha dejado de emitir'
_SERVIDOR_CORTA = 'El servidor corta la conexión una y otra vez, y puede que solo deje una'
_PASO_A_CIFRADO = 'El canal ha empezado a ir cifrado'
_OTRO_FORMATO = 'El canal ha cambiado de formato'
_TERMINADA = 'La emisión ha terminado'
_POCO_ESPACIO = 'Queda menos de 1 GB libre en la carpeta de descargas'
_DISCO_LLENO = 'El disco se ha llenado'
_NO_ESCRIBE = 'No se ha podido seguir escribiendo en la carpeta de descargas'
_ERROR = 'Ha fallado algo inesperado'

_Variante = collections.namedtuple('_Variante', 'url sonido video bps')
_Seg = collections.namedtuple('_Seg', 'num ruta url dur cifrado init')
_Media = collections.namedtuple('_Media', 'objetivo segs terminada numerada rangos')


class _NoSePuede(Exception):
    """No se puede grabar el canal; el texto se enseña tal cual."""


class _Fin(Exception):
    """Se acaba la grabación. El texto es el motivo si no ha llegado a su hora ni se ha parado."""


class _Http(Exception):
    """Una respuesta que no es 200."""

    def __init__(self, codigo):
        super().__init__(f'HTTP {codigo}')
        self.codigo = codigo

    @property
    def rechazo(self):
        return self.codigo in (401, 403, 429)


class _Grande(Exception):
    """Un manifiesto o un segmento pasa de su tope."""


def _log(texto, nivel=xbmc.LOGINFO):
    xbmc.log(f'{_LOG} {L._mask(texto)}', nivel)


def _tam(n):
    if n >= 1024 ** 3:
        return f'{n / 1024 ** 3:.1f} GB'
    mb = n / 1024 ** 2
    # Con un decimal al principio, porque una radio tarda un minuto en llegar a 1 MB.
    return f'{mb:.1f} MB' if mb < 10 else f'{mb:.0f} MB'


def _hora(ts):
    return time.strftime('%H:%M', time.localtime(ts))


def _libre(carpeta):
    try:
        return shutil.disk_usage(carpeta).free
    except OSError:
        return None


def _entero(texto):
    try:
        return int(str(texto).strip())
    except ValueError:
        return 0


def _real(texto):
    try:
        return float(str(texto).strip())
    except ValueError:
        return 0.0


# --- Red ---

class _Red:
    """Una sesión con las cabeceras del canal, que guarda sus cookies entre peticiones. Si el
    certificado no vale, sigue sin comprobarlo, como las listas."""

    def __init__(self, cabeceras):
        self.sesion = requests.Session()
        self.sesion.headers.update(cabeceras)
        self.verificar = True

    def get(self, url, tiempo=_TIEMPO):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            try:
                r = self.sesion.get(url, timeout=tiempo, stream=True, verify=self.verificar)
            except requests.exceptions.SSLError:
                if not self.verificar:
                    raise
                self.verificar = False
                r = self.sesion.get(url, timeout=tiempo, stream=True, verify=False)
        if r.status_code != 200:
            r.close()
            raise _Http(r.status_code)
        return r

    def bytes(self, url, tope, tiempo=_TIEMPO, comprobar=None):
        with self.get(url, tiempo) as r:
            return _juntar(r.iter_content(_TROZO_HLS), tope, comprobar)

    def texto(self, url, tiempo=_TIEMPO):
        """(texto, dirección final tras las redirecciones) de un manifiesto."""
        with self.get(url, tiempo) as r:
            return P.decode(_juntar(r.iter_content(_TROZO_HLS), _TOPE_MANIFIESTO)), r.url

    def cerrar(self):
        self.sesion.close()


def _juntar(trozos, tope, comprobar=None, empieza=b''):
    datos = bytearray(empieza)
    for trozo in trozos:
        if comprobar:
            comprobar()
        datos += trozo
        if len(datos) > tope:
            raise _Grande()
    return bytes(datos)


# --- Lo que llega ---

def _atributos(linea):
    return {k: v.strip('"') for k, v in _ATRIBUTO_RE.findall(linea.partition(':')[2])}


def _variantes(texto, base):
    """Las variantes de un maestro, de la que más interesa grabar a la que menos: con vídeo (una
    solo de audio no sirve para un canal de televisión), con el sonido dentro (su grupo de audio
    tiene alguna pista sin URI, o no tiene grupo) y de más calidad."""
    lineas = [linea.strip() for linea in texto.splitlines()]
    grupos = {}
    for linea in lineas:
        if linea.startswith('#EXT-X-MEDIA:'):
            a = _atributos(linea)
            if a.get('TYPE') == 'AUDIO':
                grupos.setdefault(a.get('GROUP-ID'), []).append(bool(a.get('URI')))
    variantes = []
    for i, linea in enumerate(lineas):
        if not linea.startswith('#EXT-X-STREAM-INF:'):
            continue
        uri = next((x for x in lineas[i + 1:] if x and not x.startswith('#')), '')
        if not uri:
            continue
        a = _atributos(linea)
        grupo, codecs = a.get('AUDIO'), a.get('CODECS', '').lower()
        variantes.append(_Variante(
            url=urllib.parse.urljoin(base, uri),
            sonido=not grupo or not all(grupos.get(grupo) or [False]),
            video=bool(a.get('RESOLUTION')) or not codecs or any(c in codecs for c in _VIDEO),
            bps=_entero(a.get('BANDWIDTH'))))
    return sorted(variantes, key=lambda v: (v.video, v.sonido, v.bps), reverse=True)


def _cifrado_de_sesion(texto):
    return any(_atributos(linea).get('METHOD', 'NONE') != 'NONE'
               for linea in texto.splitlines() if linea.startswith('#EXT-X-SESSION-KEY:'))


def _leer_media(texto, base):
    """Un manifiesto de medios. Cada clave vale hasta la siguiente de su mismo KEYFORMAT, y
    METHOD=NONE las quita todas (RFC 8216, 4.3.2.4)."""
    objetivo, num, numerada, rangos, terminada = 6.0, 0, False, False, False
    dur, init, claves, segs = 0.0, '', {}, []
    for linea in texto.splitlines():
        linea = linea.strip()
        if not linea:
            continue
        if not linea.startswith('#'):
            url = urllib.parse.urljoin(base, linea)
            segs.append(_Seg(num + len(segs), urllib.parse.urlsplit(url).path, url, dur, bool(claves), init))
            dur = 0.0
            continue
        etiqueta, _, valor = linea.partition(':')
        if etiqueta == '#EXTINF':
            dur = _real(valor.split(',', 1)[0])
        elif etiqueta == '#EXT-X-TARGETDURATION':
            objetivo = _real(valor) or objetivo
        elif etiqueta == '#EXT-X-MEDIA-SEQUENCE':
            num, numerada = _entero(valor), True
        elif etiqueta == '#EXT-X-KEY':
            a = _atributos(linea)
            if a.get('METHOD', 'NONE') == 'NONE':
                claves.clear()
            else:
                claves[a.get('KEYFORMAT', 'identity')] = a['METHOD']
        elif etiqueta == '#EXT-X-MAP':
            a = _atributos(linea)
            if a.get('URI'):
                init = urllib.parse.urljoin(base, a['URI'])
            rangos = rangos or 'BYTERANGE' in a
        elif etiqueta == '#EXT-X-BYTERANGE':
            rangos = True
        elif etiqueta == '#EXT-X-ENDLIST':
            terminada = True
    return _Media(objetivo, segs, terminada, numerada, rangos)


def _ts_con_audio(datos):
    """Si la PMT de un segmento TS declara alguna pista de audio."""
    pmt = None
    for i in range(0, len(datos) - 187, 188):
        paquete = datos[i:i + 188]
        if paquete[0] != 0x47 or not paquete[1] & 0x40:
            continue
        pid = (paquete[1] & 0x1F) << 8 | paquete[2]
        pos = 4 + (1 + paquete[4] if paquete[3] & 0x20 else 0)
        if pos >= 188:
            continue
        seccion = paquete[pos + 1 + paquete[pos]:]
        if len(seccion) < 12:
            continue
        fin = min(len(seccion), 3 + ((seccion[1] & 0x0F) << 8 | seccion[2]) - 4)
        if pid == 0 and pmt is None:
            for j in range(8, fin - 3, 4):
                # El programa 0 es la NIT.
                if seccion[j] << 8 | seccion[j + 1]:
                    pmt = (seccion[j + 2] & 0x1F) << 8 | seccion[j + 3]
                    break
        elif pid == pmt:
            j = 12 + ((seccion[10] & 0x0F) << 8 | seccion[11])
            while j + 5 <= fin:
                if seccion[j] in _AUDIO_TS:
                    return True
                j += 5 + ((seccion[j + 3] & 0x0F) << 8 | seccion[j + 4])
            return False
    return False


_RELOJ = 1 << 33
# Tolerancia de un salto de reloj entre segmentos: atrás un poco, por los fotogramas B, y adelante
# lo que se pierde si se salta algún segmento.
_ATRAS_MAX = 90000
_ADELANTE_MAX = 30 * 90000
# Lo que se deja entre el último fotograma de un tramo y el primero del siguiente (1/25 s).
_HUECO = 3600


class _Tiempos:
    """Marcas de tiempo (PTS, DTS y PCR) continuas en un TS que junta tramos con relojes distintos:
    los cortes de publicidad de los canales gratuitos (EXT-X-DISCONTINUITY), una sesión nueva o una
    secuencia que vuelve a empezar. Sin esto, Kodi calcula la duración con la primera y la última
    marca, que pueden ser de relojes distintos, y no sabe saltar."""

    def __init__(self):
        self.desfase = 0
        self.maximo = None

    def ajustar(self, datos):
        datos = bytearray(datos)
        primero = self._pts(datos)
        if primero is not None and self.maximo is not None:
            nuevo = (primero + self.desfase) % _RELOJ
            salto = self._diferencia(nuevo, self.maximo)
            if not -_ATRAS_MAX <= salto <= _ADELANTE_MAX:
                self.desfase = (self.desfase + self.maximo + _HUECO - nuevo) % _RELOJ
                _log(f'Reloj nuevo en el TS (salto de {salto / 90000:.1f} s): sigue sin saltos')
        self._reescribir(datos)
        return bytes(datos)

    @staticmethod
    def _diferencia(a, b):
        """a - b en el reloj de 33 bits, con signo y contando la vuelta."""
        return (a - b + _RELOJ // 2) % _RELOJ - _RELOJ // 2

    @staticmethod
    def _pes(datos, i):
        """Dónde empieza la cabecera PES del paquete de la posición i si la trae con PTS, o None."""
        if not datos[i + 1] & 0x40:
            return None
        pos = i + 4 + (1 + datos[i + 4] if datos[i + 3] & 0x20 else 0)
        if pos + 14 > i + 188 or datos[pos:pos + 3] != b'\x00\x00\x01':
            return None
        # Solo las de audio, vídeo y privadas llevan la cabecera opcional con las marcas.
        if not (datos[pos + 3] == 0xBD or 0xC0 <= datos[pos + 3] <= 0xEF) or not datos[pos + 7] & 0x80:
            return None
        return pos

    @staticmethod
    def _leer(datos, i):
        return ((datos[i] >> 1) & 7) << 30 | datos[i + 1] << 22 | (datos[i + 2] >> 1) << 15 | datos[i + 3] << 7 | datos[i + 4] >> 1

    @staticmethod
    def _escribir(datos, i, valor):
        datos[i] = (datos[i] & 0xF1) | ((valor >> 29) & 0x0E)
        datos[i + 1] = (valor >> 22) & 0xFF
        datos[i + 2] = ((valor >> 14) & 0xFE) | 1
        datos[i + 3] = (valor >> 7) & 0xFF
        datos[i + 4] = ((valor << 1) & 0xFE) | 1

    def _pts(self, datos):
        for i in range(0, len(datos) - 187, 188):
            if datos[i] == 0x47:
                pos = self._pes(datos, i)
                if pos is not None:
                    return self._leer(datos, pos + 9)
        return None

    def _reescribir(self, datos):
        for i in range(0, len(datos) - 187, 188):
            if datos[i] != 0x47:
                continue
            if datos[i + 3] & 0x20 and datos[i + 4] and datos[i + 5] & 0x10 and self.desfase:
                # La base del PCR ocupa los 33 primeros bits de sus 6 bytes.
                j = i + 6
                base = datos[j] << 25 | datos[j + 1] << 17 | datos[j + 2] << 9 | datos[j + 3] << 1 | datos[j + 4] >> 7
                base = (base + self.desfase) % _RELOJ
                datos[j:j + 4] = (base >> 1).to_bytes(4, 'big')
                datos[j + 4] = (datos[j + 4] & 0x7F) | ((base & 1) << 7)
            pos = self._pes(datos, i)
            if pos is None:
                continue
            j = pos + 9
            pts = (self._leer(datos, j) + self.desfase) % _RELOJ
            if self.desfase:
                self._escribir(datos, j, pts)
                if datos[pos + 7] & 0x40:
                    self._escribir(datos, j + 5, (self._leer(datos, j + 5) + self.desfase) % _RELOJ)
            if self.maximo is None or self._diferencia(pts, self.maximo) > 0:
                self.maximo = pts


def _extension(datos, tipo=''):
    """La extensión de lo que se graba, por sus primeros bytes o, si no se reconocen, por el tipo
    que dice el servidor."""
    if datos[:3] == b'ID3' and len(datos) >= 10:
        # El audio empaquetado de HLS lleva delante una etiqueta ID3 con la marca de tiempo.
        tam = (datos[6] & 0x7F) << 21 | (datos[7] & 0x7F) << 14 | (datos[8] & 0x7F) << 7 | datos[9] & 0x7F
        datos = datos[10 + tam:]
    if len(datos) > 188 and datos[0] == 0x47 and datos[188] == 0x47:
        return '.ts'
    if datos[:4] == b'OggS':
        return '.ogg'
    if datos[:4] == b'fLaC':
        return '.flac'
    if datos[4:8] in (b'ftyp', b'styp', b'moof'):
        return '.mp4'
    if len(datos) > 1 and datos[0] == 0xFF and datos[1] & 0xE0 == 0xE0:
        # ADTS (AAC) lleva la capa a 0; MPEG audio, a 1, 2 o 3.
        return '.aac' if (datos[1] >> 1) & 3 == 0 else '.mp3'
    tipo = tipo.split(';')[0].strip().lower()
    return _EXT_TIPO.get(tipo, '.mp3' if tipo.startswith('audio/') else '.ts')


def _nombre_archivo(texto):
    """El texto sin lo que Windows no admite en un nombre de archivo, ni punto o espacio en los
    extremos (con un punto delante, en Android sería un archivo oculto)."""
    limpio = ' '.join(_NO_VALE_RE.sub(' ', texto).split())[:120]
    return limpio.strip(' .') or 'Grabación'


# --- Fuentes ---

class _Hls:
    """Un directo HLS: su variante, lo que falta por grabar y cómo seguirle la pista. Los segmentos
    se reconocen por su número (EXT-X-MEDIA-SEQUENCE), porque la dirección puede llevar un token
    que cambia; sin número, por la ruta."""

    def __init__(self, red, canal, variante, media):
        self.red, self.canal, self.variante = red, canal, variante
        self.objetivo, self.terminada, self.numerada = media.objetivo, media.terminada, media.numerada
        self.ultimo = -1
        self._vistos, self._orden = set(), collections.deque()
        self.init, self.init_url, self.init_huella = b'', '', ''
        self.primero, self.ext, self.bps, self.pendientes = b'', '.ts', 0.0, []

    def marcar(self, seg):
        if self.numerada:
            self.ultimo = seg.num
        elif seg.ruta not in self._vistos:
            self._vistos.add(seg.ruta)
            self._orden.append(seg.ruta)
            if len(self._orden) > 2000:
                self._vistos.discard(self._orden.popleft())

    def desde_el_final(self, segs):
        """Los últimos segmentos, como hace un reproductor al entrar; los de antes cuentan como vistos."""
        antes = segs[:-_EN_DIRECTO]
        if self.numerada:
            self.ultimo = segs[-_EN_DIRECTO - 1].num if antes else segs[0].num - 1
        else:
            for seg in antes:
                self.marcar(seg)
        return segs[-_EN_DIRECTO:]

    def seguir(self, media, desde_el_final=False):
        """Los segmentos de media que faltan por grabar."""
        self.objetivo, self.terminada = media.objetivo, media.terminada
        if media.numerada != self.numerada:
            self.numerada, desde_el_final = media.numerada, True
        segs = media.segs
        if not segs:
            return []
        # Un paso atrás pequeño es un servidor del CDN que va retrasado. Si el último cae más de
        # una ventana por debajo de lo grabado, la secuencia ha vuelto a empezar.
        if self.numerada and segs[-1].num + len(segs) < self.ultimo:
            desde_el_final = True
        if desde_el_final:
            return self.desde_el_final(segs)
        if self.numerada:
            return [s for s in segs if s.num > self.ultimo]
        return [s for s in segs if s.ruta not in self._vistos]

    def cambiar_init(self, url):
        """Un EXT-X-MAP nuevo. Si solo ha cambiado su dirección (un token) se sigue; si cambia el
        contenido, otro init a mitad de archivo lo estropearía."""
        if not url or not self.init:
            raise _Fin(_OTRO_FORMATO)
        datos = self.red.bytes(url, _TOPE_SEGMENTO)
        if hashlib.sha1(datos).hexdigest() != self.init_huella:
            raise _Fin(_OTRO_FORMATO)
        self.init_url = url

    def cerrar(self):
        self.red.cerrar()


class _Directo:
    """Una emisión que llega como un chorro de bytes (una radio, un TS por HTTP)."""

    def __init__(self, red, url, respuesta, trozos, primero, ext):
        self.red, self.url, self.respuesta, self.trozos = red, url, respuesta, trozos
        self.primero, self.ext, self.init, self.bps = primero, ext, b'', 0.0

    def cerrar(self):
        self.respuesta.close()
        self.red.cerrar()


def _cancelado(dp):
    if dp is not None and dp.iscanceled():
        raise L._Cancelled()


def _preparar(url, ua, ref, props, dp=None):
    """La fuente lista para grabar, con lo primero ya bajado, o _NoSePuede con el motivo."""
    if any(p.lower().startswith('inputstream.adaptive.license') for p in props):
        raise _NoSePuede(_CIFRADO)
    base, cabeceras = L._cabeceras(url, ua, ref)
    kind = P.classify(base)[0]
    red = _Red(cabeceras)
    try:
        if kind == P.KIND_DIRECT:
            dentro, kind = L._unwrap_radio_list(base)
            base = dentro.split('|', 1)[0]
        if kind == P.KIND_HLS:
            return _preparar_hls(red, base, dp)
        if kind == P.KIND_DIRECT and base.lower().startswith(('http://', 'https://')):
            return _preparar_directo(red, base, dp)
        raise _NoSePuede(_NO_GRABABLE)
    except _Http as e:
        red.cerrar()
        raise _NoSePuede(
            f'El servidor ha rechazado la conexión (error {e.codigo}). Si estás viendo otro canal '
            'suyo, puede que solo deje una a la vez.' if e.rechazo else
            f'El canal no responde (error {e.codigo}). Comprueba que se ve y prueba otra vez.') from e
    except requests.RequestException as e:
        red.cerrar()
        _log(f'No se puede preparar {base}: {e}', xbmc.LOGWARNING)
        # El Python de Kodi no entiende "ICY 200 OK", la respuesta de los servidores SHOUTcast antiguos.
        raise _NoSePuede(_ICY if 'BadStatusLine' in repr(e) else _NO_RESPONDE) from e
    except _Grande as e:
        red.cerrar()
        raise _NoSePuede(_NO_GRABABLE) from e
    except BaseException:
        red.cerrar()
        raise


def _preparar_hls(red, url, dp, texto=None, final=None):
    if texto is None:
        texto, final = red.texto(url, _TIEMPO_PREPARAR)
        _cancelado(dp)
    if '#EXTM3U' not in texto[:1024]:
        raise _NoSePuede(_NO_GRABABLE)
    variante, sonido = url, True
    if '#EXT-X-STREAM-INF' in texto:
        if _cifrado_de_sesion(texto):
            raise _NoSePuede(_CIFRADO)
        variantes = _variantes(texto, final)
        if not variantes:
            raise _NoSePuede(_NO_GRABABLE)
        variante, sonido = variantes[0].url, variantes[0].sonido
        texto, final = red.texto(variante, _TIEMPO_PREPARAR)
        _cancelado(dp)
    media = _leer_media(texto, final)
    if media.rangos:
        raise _NoSePuede(_NO_GRABABLE)
    if not media.segs:
        raise _NoSePuede(_NO_EMITE)
    if any(seg.cifrado for seg in media.segs):
        raise _NoSePuede(_CIFRADO)
    h = _Hls(red, url, variante, media)
    inicio = media.segs if media.terminada else h.desde_el_final(media.segs)
    primero = inicio[0]
    if primero.init:
        h.init = red.bytes(primero.init, _TOPE_SEGMENTO, _TIEMPO_PREPARAR)
        h.init_url, h.init_huella = primero.init, hashlib.sha1(h.init).hexdigest()
        _cancelado(dp)
    h.primero = red.bytes(primero.url, _TOPE_SEGMENTO, _TIEMPO_PREPARAR)
    _cancelado(dp)
    # Un grupo de audio con todas sus pistas aparte no prueba que el vídeo no traiga sonido.
    if not sonido and not (b'soun' in h.init if h.init else _ts_con_audio(h.primero)):
        raise _NoSePuede(_SONIDO_APARTE)
    h.ext = '.mp4' if h.init else _extension(h.primero)
    h.bps = len(h.primero) / primero.dur if primero.dur > 0 else 0.0
    h.marcar(primero)
    h.pendientes = inicio[1:]
    return h


def _abrir_directo(red, url):
    """La respuesta de un directo. Sin User-Agent en la lista, se pide primero como VLC, porque
    los servidores de streamtheworld (LOS40, SER, Dial, RAC1...) cortan a un navegador a los 32 KB;
    como navegador solo si rechazan a VLC."""
    navegador = ui_utils.HEADERS['User-Agent']
    if red.sesion.headers.get('User-Agent') != navegador:
        return red.get(url, _TIEMPO_PREPARAR)
    red.sesion.headers['User-Agent'] = L._UA_VLC
    try:
        return red.get(url, _TIEMPO_PREPARAR)
    except _Http as e:
        if not e.rechazo:
            raise
    red.sesion.headers['User-Agent'] = navegador
    return red.get(url, _TIEMPO_PREPARAR)


def _preparar_directo(red, url, dp, profundidad=1):
    r = _abrir_directo(red, url)
    try:
        tipo = r.headers.get('Content-Type', '').lower()
        trozos = r.iter_content(_TROZO_DIRECTO)
        primero = next(trozos, b'')
        _cancelado(dp)
        if 'mpegurl' in tipo or primero.lstrip()[:7] == b'#EXTM3U':
            # Un HLS o una lista .m3u con la emisión dentro, aunque la dirección no lo diga.
            texto, final = P.decode(_juntar(trozos, _TOPE_MANIFIESTO, empieza=primero)), r.url
            r.close()
            if '#EXT-X-' in texto:
                return _preparar_hls(red, url, dp, texto, final)
            dentro = next((x.strip() for x in texto.splitlines()
                           if '://' in x and not x.strip().startswith('#')), '')
            if dentro and profundidad:
                return _preparar_directo(red, urllib.parse.urljoin(final, dentro), dp, profundidad - 1)
            raise _NoSePuede(_NO_GRABABLE)
        if 'text/html' in tipo or primero.lstrip()[:1] == b'<':
            raise _NoSePuede(_WEB)
        if 'dash+xml' in tipo:
            raise _NoSePuede(_NO_GRABABLE)
        if not primero:
            raise _NoSePuede(_NO_EMITE)
        return _Directo(red, url, r, trozos, primero, _extension(primero, tipo))
    except BaseException:
        r.close()
        raise


# --- El archivo ---

def _apuntar_descarga(titulo, ruta):
    """La grabación en "Mis Descargas", arriba del todo como una descarga recién hecha."""
    dls = ui_utils.load_json('downloads.json')
    if not isinstance(dls, list):
        dls = []
    dls.insert(0, {'title': titulo, 'path': ruta, 'vid': 'Grabación',
                   'date': time.strftime('%Y-%m-%d %H:%M')})
    ui_utils.save_json('downloads.json', dls)


class _Salida:
    """El archivo de la grabación, con su nombre final desde el principio, porque un TS, MP3 o AAC
    a medias se reproduce y así un cierre brusco no deja temporales. Pasa a otra parte antes de
    _TOPE_PARTE, y cada parte se apunta en "Mis Descargas"."""

    def __init__(self, carpeta, titulo, archivo, ext, init=b''):
        self.carpeta, self.titulo, self.archivo, self.ext, self.init = carpeta, titulo, archivo, ext, init
        self.al_cambiar = None
        self.parte, self.total, self.en_parte = 0, 0, 0
        self.f, self.ruta = None, ''
        self._abrir()

    def _abrir(self):
        self.parte += 1
        base = self.archivo if self.parte == 1 else f'{self.archivo} (parte {self.parte})'
        for n in range(1, 100):
            ruta = os.path.join(self.carpeta, base + (f' ({n})' if n > 1 else '') + self.ext)
            try:
                # Sin búfer, para que lo grabado llegue al disco segmento a segmento y un disco
                # lleno se note al escribir y no al cerrar.
                self.f = open(ruta, 'xb', buffering=0)
                break
            except FileExistsError:
                continue
        else:
            raise OSError(errno.EEXIST, 'Hay demasiados archivos con ese nombre')
        self.ruta, self.en_parte = ruta, 0
        if self.init:
            try:
                self._escribir(self.init)
            except _Fin:
                self.descartar()
                raise

    def apuntar(self):
        titulo = self.titulo if self.parte == 1 else f'{self.titulo} (parte {self.parte})'
        _apuntar_descarga(titulo, self.ruta)

    def escribir(self, datos):
        if self.en_parte + len(datos) > _TOPE_PARTE:
            self.f.close()
            try:
                self._abrir()
            except OSError as e:
                self.f = None
                raise _Fin(_NO_ESCRIBE) from e
            self.apuntar()
            if self.al_cambiar:
                self.al_cambiar(self.ruta)
        self._escribir(datos)

    def _escribir(self, datos):
        vista = memoryview(datos)
        try:
            while vista:
                vista = vista[self.f.write(vista):]
        except OSError as e:
            raise _Fin(_DISCO_LLENO if e.errno == errno.ENOSPC else _NO_ESCRIBE) from e
        self.en_parte += len(datos)
        self.total += len(datos)

    def cerrar(self):
        if self.f is not None:
            try:
                self.f.close()
            except OSError as e:
                _log(f'No se pudo cerrar {self.ruta}: {e}', xbmc.LOGWARNING)
            self.f = None

    def descartar(self):
        self.cerrar()
        try:
            os.remove(self.ruta)
        except OSError:
            pass


# --- La grabación ---

class _Grabacion:
    """Lo que dura una grabación: cuándo acaba, si hay que parar y la barra de fondo de Kodi."""

    def __init__(self, token, nombre, inicio, fin, salida, monitor, tiempos=None):
        self.token, self.nombre, self.inicio, self.fin = token, nombre, inicio, fin
        self.salida, self.monitor, self.tiempos = salida, monitor, tiempos
        self.parada = False
        ahora = time.monotonic()
        self.ultimo_dato, self._espacio_t, self._barra_t = ahora, ahora, 0.0
        self.barra = xbmcgui.DialogProgressBG()
        self.barra.create(f'Grabando "{nombre}"', 'Empezando...')

    def comprobar(self, con_fin=True):
        """Lanza _Fin si hay que acabar: Kodi se cierra, se pide parar, llega la hora o queda
        poco espacio. De paso, pinta la barra."""
        if self.monitor.abortRequested():
            raise _Fin('')
        if grabaciones.pide_parar(self.token):
            self.parada = True
            raise _Fin('')
        if con_fin and time.time() >= self.fin:
            raise _Fin('')
        ahora = time.monotonic()
        if ahora - self._espacio_t >= _CADA_ESPACIO:
            self._espacio_t = ahora
            libre = _libre(self.salida.carpeta)
            if libre is not None and libre < _LIBRE_MIN:
                raise _Fin(_POCO_ESPACIO)
        if ahora - self._barra_t >= _CADA_BARRA:
            self._barra_t = ahora
            self._pintar()

    def _pintar(self):
        # "Hasta que la pares" también tiene hora de fin (la de las 8 horas), y así la barra avanza.
        pasados = time.time() - self.inicio
        porcentaje = int(min(100, max(0, pasados * 100 / max(1, self.fin - self.inicio))))
        self.barra.update(porcentaje, f'Grabando "{self.nombre}"',
                          f'{int(pasados // 60)} min · {_tam(self.salida.total)} · hasta las {_hora(self.fin)}')

    def escribir(self, datos):
        self.salida.escribir(self.tiempos.ajustar(datos) if self.tiempos else datos)
        self.ultimo_dato = time.monotonic()

    def sin_datos(self, maximo):
        return time.monotonic() - self.ultimo_dato > maximo

    def esperar(self, segundos):
        limite = time.monotonic() + segundos
        while True:
            self.comprobar()
            queda = limite - time.monotonic()
            if queda <= 0:
                return
            self.monitor.waitForAbort(min(0.5, queda))

    def cerrar(self):
        self.barra.close()


def _contar_corte(cortes):
    """Apunta un corte y lanza _Fin si el servidor corta demasiado. Suele ser uno que solo deja
    una conexión y se pelea con el reproductor."""
    ahora = time.monotonic()
    cortes.append(ahora)
    while ahora - cortes[0] > _CORTES_VENTANA:
        cortes.popleft()
    if len(cortes) > _CORTES_MAX:
        raise _Fin(_SERVIDOR_CORTA)


def _bajar(g, red, url):
    """Los bytes de un segmento, o None si no llega tras dos reintentos y hay que saltarlo. Un
    rechazo del servidor sale como _Http, para volver a resolver el canal."""
    for intento in range(3):
        try:
            return red.bytes(url, _TOPE_SEGMENTO, comprobar=lambda: g.comprobar(con_fin=False))
        except _Http as e:
            if e.rechazo:
                raise
            if e.codigo in (404, 410):
                return None
        except _Grande:
            _log('Segmento demasiado grande; se salta', xbmc.LOGWARNING)
            return None
        except requests.RequestException as e:
            _log(f'Segmento: {e}', xbmc.LOGDEBUG)
        if intento < 2:
            g.esperar(1)
    return None


def _volver_a_resolver(g, h, rechazos, por_rechazo):
    """Pide otra vez el canal desde su dirección, por si ha caducado un token. Si la variante
    sigue siendo la misma, se sigue por número; si no, los números no se pueden comparar
    (RFC 8216, 6.3.1) y se sigue desde el final."""
    if por_rechazo:
        _contar_corte(rechazos)
    try:
        texto, final = h.red.texto(h.canal)
        variante = h.canal
        if '#EXT-X-STREAM-INF' in texto:
            variantes = _variantes(texto, final)
            if not variantes:
                return []
            anterior = urllib.parse.urlsplit(h.variante).path
            variante = next((v.url for v in variantes if urllib.parse.urlsplit(v.url).path == anterior),
                            variantes[0].url)
            texto, final = h.red.texto(variante)
    except (requests.RequestException, _Http, _Grande) as e:
        _log(f'No se puede volver a resolver el canal: {e}', xbmc.LOGWARNING)
        g.esperar(5)
        return []
    misma = urllib.parse.urlsplit(variante).path == urllib.parse.urlsplit(h.variante).path
    h.variante = variante
    return h.seguir(_leer_media(texto, final), desde_el_final=not misma)


def _grabar_segmentos(g, h, pendientes):
    for seg in pendientes:
        g.comprobar()
        if seg.cifrado:
            h.marcar(seg)
            if g.sin_datos(_CIFRADO_MAX):
                raise _Fin(_PASO_A_CIFRADO)
            continue
        if seg.init != h.init_url:
            try:
                h.cambiar_init(seg.init)
            except (requests.RequestException, _Http, _Grande) as e:
                if isinstance(e, _Http) and e.rechazo:
                    raise
                _log(f'No se puede bajar el init nuevo: {e}', xbmc.LOGWARNING)
                continue
        datos = _bajar(g, h.red, seg.url)
        h.marcar(seg)
        if datos:
            g.escribir(datos)


def _bucle_hls(g, h):
    """Graba hasta que comprobar() lanza _Fin. Recarga el manifiesto a la duración objetivo si
    trajo segmentos nuevos y a la mitad si no, contando desde la carga anterior (RFC 8216, 6.3.4)."""
    pendientes, hubo, carga = h.pendientes, True, time.monotonic()
    rechazos, fallos = collections.deque(), 0
    while True:
        try:
            _grabar_segmentos(g, h, pendientes)
        except _Http as e:
            pendientes = _volver_a_resolver(g, h, rechazos, e.rechazo)
            continue
        if h.terminada:
            raise _Fin(_TERMINADA)
        if g.sin_datos(_SIN_DATOS_MAX):
            raise _Fin(_SIN_DATOS)
        g.esperar(carga + (h.objetivo if hubo else h.objetivo / 2) - time.monotonic())
        carga = time.monotonic()
        try:
            texto, final = h.red.texto(h.variante)
            pendientes, fallos = h.seguir(_leer_media(texto, final)), 0
        except (requests.RequestException, _Http, _Grande) as e:
            fallos += 1
            pendientes = []
            rechazo = isinstance(e, _Http) and e.rechazo
            if rechazo or fallos >= 3:
                pendientes, fallos = _volver_a_resolver(g, h, rechazos, rechazo), 0
        hubo = bool(pendientes)


def _bucle_directo(g, d):
    r, trozos, cortes = d.respuesta, d.trozos, collections.deque()
    while True:
        try:
            for trozo in trozos:
                g.comprobar()
                if trozo:
                    g.escribir(trozo)
        except requests.RequestException as e:
            _log(f'Se ha cortado la emisión: {e}', xbmc.LOGINFO)
        finally:
            r.close()
        _contar_corte(cortes)
        while True:
            g.comprobar()
            if g.sin_datos(_SIN_DATOS_MAX):
                raise _Fin(_SIN_DATOS)
            try:
                r = d.respuesta = d.red.get(d.url)
                trozos = r.iter_content(_TROZO_DIRECTO)
                break
            except (requests.RequestException, _Http) as e:
                _log(f'No se puede volver a conectar: {e}', xbmc.LOGDEBUG)
            g.esperar(3)


# --- Lo que ve la usuaria ---

def _carpeta():
    """La carpeta de descargas, en la ruta del aparato, que se pide la primera vez y se guarda
    como la de Configuración. None, tras avisar, si no se puede grabar en ella."""
    cfg = ui_utils.load_json('settings.json')
    if not isinstance(cfg, dict):
        cfg = {}
    ruta = cfg.get('download_path') or ''
    if not ruta:
        ruta = xbmcgui.Dialog().browse(3, 'Carpeta para las descargas y las grabaciones', 'files')
        if not ruta:
            return None
        cfg['download_path'] = ruta
        ui_utils.save_json('settings.json', cfg)
    local = xbmcvfs.translatePath(ruta)
    if '://' in local:
        L.show_message('Para grabar hace falta una carpeta de este aparato, y la de descargas es de '
                       f'red:\n{ruta}\n\nElige otra en Configuración > Ruta de Descargas.')
        return None
    if not os.path.isdir(local):
        L.show_message(f'No se encuentra la carpeta de descargas:\n{ruta}\n\nSi es un disco o una '
                       'memoria USB, conéctalo, o elige otra en Configuración > Ruta de Descargas.')
        return None
    libre = _libre(local)
    if libre is not None and libre < _LIBRE_MIN:
        L.show_message(f'Queda poco espacio en la carpeta de descargas ({_tam(libre)} libres). Para '
                       'grabar tiene que quedar más de 1 GB.')
        return None
    return local


def _aviso_una_conexion(lst):
    """False si, sabiendo que su servidor Xtream solo deja una conexión, no quiere grabar."""
    lst = lst or {}
    if lst.get('kind') != 'xtream' or _entero((lst.get('account') or {}).get('conns')) != 1:
        return True
    return xbmcgui.Dialog().yesno(
        L._HEADING, 'Tu servidor solo deja una conexión a la vez. Mientras grabas no podrás ver otro '
        'canal suyo, y si lo intentas se cortará uno de los dos.\n\n¿Grabar?',
        nolabel='Cancelar', yeslabel='Grabar')


def _elegir_duracion(nombre, programa):
    """(segundos, fin del programa, título del programa) de lo elegido, o None."""
    opciones, valores = [], []
    if programa and programa[1] - time.time() > 60:
        titulo, fin = programa
        que = f'"{titulo}"' if titulo else 'el programa'
        opciones.append(f'Hasta que acabe {que} ({_hora(fin)}, y {_MARGEN_FIN // 60} minutos más)')
        valores.append((0, fin + _MARGEN_FIN, titulo))
    for segundos, texto in _DURACIONES:
        opciones.append(texto)
        valores.append((segundos, 0, ''))
    opciones.append('Hasta que la pares (8 horas como mucho)')
    valores.append((_SIN_LIMITE, 0, ''))
    sel = xbmcgui.Dialog().select(f'Grabar "{nombre}"', opciones)
    return valores[sel] if sel >= 0 else None


def _cabe(carpeta, necesario):
    libre = _libre(carpeta)
    if libre is None or necesario <= libre - _LIBRE_MIN:
        return True
    return xbmcgui.Dialog().yesno(
        L._HEADING, f'Puede que no quepa entera. Harán falta unos {_tam(necesario)} y quedan '
        f'{_tam(libre)} libres, y la grabación se para cuando queda 1 GB.\n\n¿Grabar igualmente?',
        nolabel='Cancelar', yeslabel='Grabar')


def _avisar_fin(nombre, motivo, parada, total):
    grabado = f'Se han grabado {_tam(total)}.'
    if motivo:
        texto, nivel = f'{motivo}. {grabado}', xbmcgui.NOTIFICATION_WARNING
    else:
        texto, nivel = f"{'Parada' if parada else 'Terminada'}. {grabado}", xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(f'Grabación de "{nombre}"', texto, nivel, 8000)


_ES_CONTINUOUS = 0x80000000
_ES_SYSTEM_REQUIRED = 0x00000001


def _despierto(si, ultima=True):
    """Que el aparato no se duerma mientras graba. Lo de Kodi vale para todas las grabaciones, así
    que solo lo quita la última en acabar; lo de Windows es de este hilo."""
    if sys.platform == 'win32':
        # Windows suspende el equipo por inactividad aunque Kodi esté abierto; Kodi solo lo evita
        # mientras reproduce o está minimizado.
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(_ES_CONTINUOUS | (_ES_SYSTEM_REQUIRED if si else 0))
        except (AttributeError, ImportError, OSError) as e:
            _log(f'No se puede pedir a Windows que no suspenda el equipo: {e}', xbmc.LOGWARNING)
    if si or ultima:
        valor = 'true' if si else 'false'
        xbmc.executebuiltin(f'InhibitIdleShutdown({valor})')
        # En Android, Kodi no retiene el aparato y con la pantalla apagada se duerme y deja de
        # grabar. Así la pantalla no se apaga sola, como cuando se ve un vídeo.
        if xbmc.getCondVisibility('System.Platform.Android'):
            xbmc.executebuiltin(f'InhibitScreensaver({valor})')


def grabar(params):
    """Menú contextual "Grabar" de un canal: pregunta cuánto, prepara el canal y graba hasta la
    hora de fin, dentro de esta misma llamada."""
    ui_utils.visto(grabaciones.NUEVO)
    url = params.get('url') or ''
    nombre = (params.get('title') or '').strip() or 'Canal'
    k = grabaciones.clave(url)
    if k in grabaciones.en_marcha():
        if xbmcgui.Dialog().yesno(L._HEADING, f'Ya se está grabando "{nombre}".\n\n¿Quieres pararla?',
                                  nolabel='Seguir grabando', yeslabel='Parar'):
            grabaciones.parar({'k': k, 'refresh': '1'})
        return
    carpeta = _carpeta()
    if not carpeta:
        return
    lst = L.STORE.get(params['id']) if params.get('id') else None
    if not _aviso_una_conexion(lst):
        return
    programa = None
    if params.get('tvg'):
        guia = params.get('epg') or (lst or {}).get('epg') or ''
        programa = epg_texto.programa_ahora(params['tvg'], nombre, guia)
    eleccion = _elegir_duracion(nombre, programa)
    if eleccion is None:
        return
    try:
        with L._progress(f'Preparando la grabación de "{nombre}"...') as dp:
            fuente = _preparar(url, params.get('ua') or '', params.get('ref') or '',
                               L._props(params.get('extra')), dp)
    except L._Cancelled:
        return
    except _NoSePuede as e:
        L.show_message(str(e))
        return
    try:
        _grabar(k, nombre, carpeta, fuente, *eleccion)
    finally:
        fuente.cerrar()


def _grabar(k, nombre, carpeta, fuente, segundos, fin_programa, titulo_programa):
    inicio = time.time()
    fin = fin_programa or inicio + segundos
    sin_limite = segundos == _SIN_LIMITE
    if not sin_limite and fuente.bps and not _cabe(carpeta, fuente.bps * (fin - inicio)):
        return
    visible = f'{titulo_programa} ({nombre})' if titulo_programa else nombre
    archivo = _nombre_archivo(f"{visible} {time.strftime('%Y-%m-%d %H.%M', time.localtime(inicio))}")
    try:
        salida = _Salida(carpeta, visible, archivo, fuente.ext, fuente.init)
    except (OSError, _Fin) as e:
        L.show_message(f'No se puede escribir en la carpeta de descargas:\n{carpeta}\n\n{e}')
        return
    datos = {'nombre': visible, 'ruta': salida.ruta}
    try:
        token = grabaciones.registrar(k, datos)
    except OSError as e:
        salida.descartar()
        L.show_message(f'No se ha podido empezar la grabación:\n{e}')
        return
    if not token:
        salida.descartar()
        L.show_message(f'Ya se está grabando "{nombre}".')
        return
    motivo, g = '', None
    # Kodi solo avisa de que se cierra a los Monitor que ya existen, así que uno para todo.
    monitor = xbmc.Monitor()
    try:
        salida.apuntar()
        salida.al_cambiar = lambda ruta: grabaciones.actualizar(k, dict(datos, ruta=ruta, token=token))
        # Cada segmento TS de un HLS empieza en un paquete entero; un directo TS llega en trozos
        # sueltos y no cambia de reloj.
        tiempos = _Tiempos() if isinstance(fuente, _Hls) and fuente.ext == '.ts' else None
        g = _Grabacion(token, visible, inicio, fin, salida, monitor, tiempos)
        _log(f'Grabando {fuente.variante if isinstance(fuente, _Hls) else fuente.url} en {salida.ruta}')
        _despierto(True)
        g.escribir(fuente.primero)
        if isinstance(fuente, _Hls):
            _bucle_hls(g, fuente)
        else:
            _bucle_directo(g, fuente)
    except _Fin as e:
        motivo = str(e)
    except Exception:
        # Una grabación de horas no puede acabar sin cerrar su registro por un fallo del código.
        _log(traceback.format_exc(), xbmc.LOGERROR)
        motivo = _ERROR
    finally:
        cerrando = monitor.abortRequested()
        salida.cerrar()
        if g is not None:
            g.cerrar()
        _despierto(False, ultima=not grabaciones.terminar(k, token))
    _log(f'Fin de la grabación ({motivo or "a su hora o parada"}): {salida.total} bytes')
    if cerrando:
        return
    parada = g is not None and g.parada
    _avisar_fin(visible, motivo, parada, salida.total)
    if not parada and 'action=view_downloads' in xbmc.getInfoLabel('Container.FolderPath'):
        xbmc.executebuiltin('Container.Refresh')
