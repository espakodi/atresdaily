# -*- coding: utf-8 -*-
# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
import os
import sys
import re
import math
import copy

try:
    import repository
except Exception:
    pass

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import urllib.parse
import zipfile
import requests

# --- CONFIGURACIÓN DEL NÚCLEO ---
ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.jpg')

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    # "Referer": "https://www.atresplayer.com/" # Referer dinámico suele ser mejor
    "Origin": "https://www.atresplayer.com"
}

def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p

def add_item(action, title, url="", thumbnail="", extra="", folder=True, isPlayable=False, plot="", fanart="", context=None, **kwargs):
    li = xbmcgui.ListItem(title)
    
    # Configurar Arte (Icono, Thumbnail y Fanart)
    art = {}
    if thumbnail: 
        art['icon'] = thumbnail
        art['thumb'] = thumbnail
        
    # Solo poner fanart si se pide explícitamente
    if fanart:
        art['fanart'] = fanart
        
    li.setArt(art)
    
    # Información básica
    info = {"title": title}
    if plot: info["plot"] = plot
    li.setInfo("video", info)
    
    if isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False
        
    # Inyectar "Abrir en navegador" para elementos de Dailymotion
    if action == "play_dm" and url:
        _browser_item = ("[COLOR lime]Abrir en navegador[/COLOR]",
                         f"RunPlugin({sys.argv[0]}?action=dm_open_browser&url={urllib.parse.quote(url)})")
        if context:
            context = [_browser_item] + list(context)
        else:
            context = [_browser_item]

    if context:
        li.addContextMenuItems(context)
        
    u = f"{sys.argv[0]}?action={action}&title={urllib.parse.quote(title)}&url={urllib.parse.quote(url)}&extra={urllib.parse.quote(extra)}"
    for key, value in kwargs.items():
        u += f"&{key}={urllib.parse.quote(str(value))}"
        
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)

def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)

# --- AYUDANTES ---
def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, filename)

def load_json(name, default=None):
    """Carga un archivo JSON. Si default es None, devuelve [] para listas o {} para settings."""
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f: return json.load(f)
    except Exception:
        if default is not None: return default
        # Auto-detección: los archivos de ajustes deben devolver dict, otros lista
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []

def save_json(name, data):
    try:
        with open(get_path(name), 'w', encoding='utf-8') as f: json.dump(data, f)
    except Exception as e:
        xbmc.log(f"[AtresDaily] Error guardando {name}: {e}", xbmc.LOGERROR)

def fix_img(url):
    if not url: return ICON_MAIN
    if url.startswith("//"): url = "https:" + url
    elif url.startswith("/"): url = "https://www.atresplayer.com" + url
    if url.endswith("/"): url += "1280x720.jpg"
    return url

# Constantes de StreamNinja requeridas para descarga/verificación fallback
_SN_ID   = "plugin.video.streamninja"
_SN_REPO = "repository.streamninja"
_SN_ZIP  = "https://fullstackcurso.github.io/estreamninja/repository.streamninja-1.0.0.zip"

# --- GESTIÓN DE REPOSITORIOS (NÚCLEO) ---

def is_repo_installed(keyword="atresdaily", target_id="repository.atresdaily"):
    """
    Abstracción para la detección de repositorios.
    Delega la lógica pesada al módulo especializado repository.py.
    """
    try:
        return repository.detector.is_installed(keyword, target_id)
    except Exception:
        # Fallback de seguridad en caso de error de importación
        return xbmc.getCondVisibility(f"System.HasAddon({target_id})")

def check_repo_status():
    """Muestra el estado del repositorio oficial y ofrece instalación si falta."""
    installed = is_repo_installed()
    
    if installed:
        if xbmcgui.Dialog().yesno(
            "Estado del Repositorio",
            "[COLOR green][B]● INSTALADO Y ACTIVO[/B][/COLOR]\n\n"
            "El repositorio oficial está configurado correctamente.\n\n"
            "¿Deseas desinstalarlo y eliminarlo atómicamente del sistema?"
        ):
            if repository.detector.uninstall():
                xbmcgui.Dialog().notification("AtresDaily", "Repositorio eliminado con éxito", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("Error", "No se pudo desinstalar el repositorio.")
    else:
        if xbmcgui.Dialog().yesno(
            "Repositorio No Detectado",
            "Para recibir mejoras y actualizaciones automáticas, es necesario\n"
            "instalar el repositorio oficial de AtresDaily.\n\n"
            "¿Deseas instalarlo ahora mismo (autocontenido)?"
        ):
            if repository.detector.install():
                xbmcgui.Dialog().notification("AtresDaily", "Repositorio instalado con éxito", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                # FALLBACK CAPA 2: Descarga remota
                if xbmcgui.Dialog().yesno(
                    "Error de Sistema de Archivos",
                    "La instalación local falló (probablemente por restricciones del dispositivo Android/UWP).\n\n"
                    "¿Deseas intentar descargarlo directamente desde el servidor oficial?"
                ):
                    dp = xbmcgui.DialogProgress()
                    dp.create("AtresDaily", "Preparando descarga...")
                    if _remote_repo_fallback(dp):
                        xbmcgui.Dialog().notification("AtresDaily", "Repositorio descargado", xbmcgui.NOTIFICATION_INFO)
                        xbmc.executebuiltin("Container.Refresh")
                else:
                    # FALLBACK CAPA 3: Instrucción manual
                    xbmcgui.Dialog().ok(
                        "Instalación Manual", 
                        "Para instalar el repositorio manualmente añade esta fuente al gestor de archivos de Kodi:\n\n"
                        "[B][COLOR yellow]https://fullstackcurso.github.io/atresdaily/[/COLOR][/B]"
                    )


def _remote_repo_fallback(dp):
    """Fallback: Descarga e instala el repositorio oficial desde GitHub."""
    url = "https://fullstackcurso.github.io/atresdaily/repository.atresdaily-1.0.1.zip"
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "atresdaily_repo_fallback.zip")
    try:
        r = requests.get(url, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError("Servidor no disponible (Error HTTP).")

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        with open(zip_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=65536):
                if dp.iscanceled():
                    raise InterruptedError("Cancelado por el usuario.")
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        dp.update(int((downloaded * 90) / total_size), "Descargando desde GitHub...")

        dp.update(95, "Instalando en Kodi (VFS)...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                
                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                    
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                success = v_file.write(content)
                v_file.close()
                
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {vfs_dest}")
            
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1000)
        xbmc.executebuiltin("InstallAddon(repository.atresdaily)")
        if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
            sys.modules['repository'].detector._enable_addon("repository.atresdaily")
        else:
            rpc_payload = json.dumps({"jsonrpc": "2.0", "method": "Addons.SetAddonEnabled", "params": {"addonid": "repository.atresdaily", "enabled": True}, "id": 1})
            xbmc.executeJSONRPC(rpc_payload)
        dp.close()
        return True
    except Exception as e:
        dp.close()
        xbmc.log(f"[AtresDaily] Fallback remoto falló: {e}", xbmc.LOGERROR)
        
        # Rollback: Limpiar posible instalación corrupta
        try:
            dest_vfs = "special://home/addons/repository.atresdaily"
            if xbmcvfs.exists(dest_vfs):
                if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
                    sys.modules['repository'].detector._vfs_rmtree(dest_vfs)
        except:
            pass
            
        xbmcgui.Dialog().ok(
            "Error Crítico", 
            f"La descarga de rescate también falló:\n{e}\n\n"
            "Solución:\n1. Ve al Gestor de Archivos de Kodi.\n"
            "2. Añade: https://fullstackcurso.github.io/atresdaily/\n"
            "3. Instala desde el archivo ZIP."
        )
        return False
    finally:
        if os.path.exists(zip_path):
            try: os.remove(zip_path)
            except: pass


def _sn_download_and_install_repo(dp):
    """Descarga el repositorio de StreamNinja, lo extrae e inicia la instalación del addon.

    Recibe un DialogProgress ya creado. Retorna True si la secuencia de instalación
    se inició con éxito, False en caso contrario.
    """
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"), "sn_repo.zip")
    try:
        r = requests.get(_SN_ZIP, stream=True, timeout=30)
        if r.status_code != 200:
            raise IOError(f"Error HTTP {r.status_code} al descargar el repositorio.")

        total_size = int(r.headers.get("content-length", 0))
        downloaded = 0
        content = bytearray()

        for chunk in r.iter_content(chunk_size=65536):
            if dp.iscanceled():
                raise InterruptedError("Cancelado por el usuario.")
            if chunk:
                content.extend(chunk)
                downloaded += len(chunk)
                if total_size > 0:
                    dp.update(
                        10 + int((downloaded * 80) / total_size),
                        "Descargando repositorio...",
                    )

        raw_b = bytes(content)
        if not raw_b.startswith(b"PK\x03\x04"):
            raise ValueError("El archivo descargado no es un ZIP válido.")

        dp.update(90, "Extrayendo...")
        with open(zip_path, "wb") as f:
            f.write(raw_b)

        dp.update(92, "Instalando en Kodi (VFS)...")
        with zipfile.ZipFile(zip_path, "r") as zf:
            for member in zf.infolist():
                if member.is_dir():
                    continue
                vfs_dest = f"special://home/addons/{member.filename}"
                parent_dir = "special://home/addons/" + "/".join(member.filename.split("/")[:-1])
                if not xbmcvfs.exists(parent_dir):
                    xbmcvfs.mkdirs(parent_dir)
                content = zf.read(member)
                v_file = xbmcvfs.File(vfs_dest, "wb")
                success = v_file.write(content)
                v_file.close()
                
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {vfs_dest}")

        dp.update(95, "Actualizando sistema de addons...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        
        # Monitor para pausas asíncronas sin bloquear el hilo principal (Evita ANR)
        monitor = xbmc.Monitor()
        monitor.waitForAbort(2.0)
        
        dp.update(97, "Habilitando repositorio en Kodi 19+...")
        try:
            if 'repository' in sys.modules and hasattr(sys.modules['repository'], 'detector'):
                sys.modules['repository'].detector._enable_addon(_SN_REPO)
            else:
                # Habilitación directa vía JSON-RPC con reintentos
                # (UpdateLocalAddons es asíncrono; el addon puede no estar indexado aún)
                rpc_payload = json.dumps({
                    "jsonrpc": "2.0",
                    "method": "Addons.SetAddonEnabled",
                    "params": {"addonid": _SN_REPO, "enabled": True},
                    "id": 1
                })
                for _ in range(5):
                    response = xbmc.executeJSONRPC(rpc_payload)
                    if '"error"' not in response:
                        xbmc.log(f"[AtresDaily] Repositorio {_SN_REPO} habilitado vía JSON-RPC.", xbmc.LOGINFO)
                        break
                    monitor.waitForAbort(1.0)
        except Exception as repo_err:
            xbmc.log(f"[AtresDaily] Fallo tolerado en habilitación de {_SN_REPO}: {repo_err}", xbmc.LOGWARNING)
            
        monitor.waitForAbort(1.5)
        
        dp.update(99, "Solicitando instalación del addon...")
        xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
        
        # Bucle de Polling ligero: Da hasta 3 segundos para que Kodi procese el InstallAddon
        installed = False
        for _ in range(6):
            if monitor.waitForAbort(0.5):
                break # Evita colgar si Kodi se está cerrando
            if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
                installed = True
                break
                
        dp.close()
        
        if installed:
            xbmcgui.Dialog().notification("AtresDaily", "Proceso completado con éxito", xbmcgui.NOTIFICATION_INFO, 5000)
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "StreamNinja se ha instalado y activado con éxito.\n\n"
                "Vuelve a pulsar el contenido para reproducirlo."
            )
        else:
            xbmcgui.Dialog().ok(
                "AtresDaily - Instalación Pendiente",
                "El repositorio se ha instalado e indexado correctamente.\n\n"
                "Acepta cualquier ventana emergente de Kodi para finalizar la instalación de StreamNinja.\n\n"
                "Si no aparece nada, puedes instalarlo manualmente en:\n"
                "[B]Addons -> Instalar desde repositorio -> StreamNinja[/B]."
            )
        return True

    except Exception as e:
        dp.close()
        msg = str(e)
        if "Cancelado" in msg:
            xbmcgui.Dialog().notification("AtresDaily", msg, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f"[AtresDaily] Error instalando StreamNinja: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", f"No se pudo instalar StreamNinja:\n{e}")
        return False

    finally:
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass


def streamninja_check_or_install():
    """Comprueba si StreamNinja está instalado e instala si es necesario.

    Uso: connector.py (fallback de reproducción cuando Atresplayer devuelve 403).
    NO abre el addon si ya está instalado — retorna True para que el llamador
    proceda con la reproducción vía RunPlugin.

    Retorna True si StreamNinja está disponible, False en caso contrario.
    """
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        return True

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja Requerido",
            "StreamNinja no está instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a intentarlo.",
            )
        return False

    if not xbmcgui.Dialog().yesno(
        "StreamNinja Requerido",
        "Para reproducir este contenido se necesita el complemento StreamNinja.\n"
        "¿Descargar e instalar automáticamente?",
    ):
        return False

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Preparando instalación de StreamNinja...")
    dp.update(10, "Configurando conexión...")
    _sn_download_and_install_repo(dp)
    return False


def streamninja_open_or_install():
    """Abre StreamNinja si está instalado, o inicia el proceso de instalación.

    Uso: botón del menú Abrir URL en url_player.py.
    Si el addon está instalado lo abre directamente. Si no, ofrece instalarlo.
    """
    if xbmc.getCondVisibility(f"System.HasAddon({_SN_ID})"):
        xbmc.executebuiltin(f"RunAddon({_SN_ID})")
        return

    if is_repo_installed("streamninja", _SN_REPO):
        if xbmcgui.Dialog().yesno(
            "StreamNinja",
            "Addon no instalado pero tienes su repositorio.\n¿Instalarlo ahora?",
        ):
            xbmc.executebuiltin(f"InstallAddon({_SN_ID})")
            xbmcgui.Dialog().ok(
                "AtresDaily",
                "Se ha solicitado la instalación.\n"
                "Acepta las ventanas de Kodi y vuelve a pulsar el botón.",
            )
        return

    if not xbmcgui.Dialog().yesno(
        "Instalar StreamNinja",
        "StreamNinja no está instalado.\n¿Descargar e instalar el repositorio oficial?",
    ):
        return

    dp = xbmcgui.DialogProgress()
    dp.create("AtresDaily", "Descargando StreamNinja...")
    dp.update(5, "Iniciando descarga...")
    _sn_download_and_install_repo(dp)

