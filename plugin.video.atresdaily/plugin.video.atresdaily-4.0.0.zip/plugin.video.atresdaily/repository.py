# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Módulo para detectar e instalar el repositorio oficial de AtresDaily."""
import os
import xml.etree.ElementTree as ET
import xbmc
import xbmcaddon
import xbmcvfs

class RepoDetector:
    """Detector e instalador de repositorios con caché en memoria."""
    
    _instance = None
    _cache = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RepoDetector, cls).__new__(cls)
        return cls._instance

    def is_installed(self, keyword, target_id=None):
        """Devuelve True si el repositorio (o addon coincidente) está instalado o en disco."""
        # 1. Caché de sesión de lectura rápida
        cache_key = f"{keyword}_{target_id}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        # Detección rápida nativa por ID
        if target_id and xbmc.getCondVisibility(f"System.HasAddon({target_id})"):
            self._cache[cache_key] = True
            return True

        # Fallback: escanear archivos addon.xml para detectar carpetas renombradas o desactivadas
        found = self._deep_scan_filesystem_for_addon(keyword.lower(), target_id)
        
        # Habilitar addon si está físicamente pero desactivado en Kodi
        if found and target_id:
            self._enable_addon(target_id)
            
        self._cache[cache_key] = found
        return found

    def _deep_scan_filesystem_for_addon(self, keyword_lower, target_id):
        """Escanea special://home/addons/ parseando los addon.xml para obtener los IDs reales."""
        addons_path = "special://home/addons/"
        
        try:
            if not xbmcvfs.exists(addons_path):
                return False
                
            dirs, _ = xbmcvfs.listdir(addons_path)
            for directory in dirs:
                dir_lower = directory.lower()
                
                # Filtro rápido de carpetas
                if "repository" not in dir_lower and keyword_lower not in dir_lower:
                    continue
                
                # Ruta VFS para evitar traducir special:// a path de sistema
                vfs_xml_path = f"special://home/addons/{directory}/addon.xml"
                
                if xbmcvfs.exists(vfs_xml_path):
                    if self._verify_xml_id(vfs_xml_path, keyword_lower, target_id):
                        # Encontrado físicamente en disco
                        xbmc.log(f"[AtresDaily] Repo localizado vía parseo VFS profundo en: {directory}", xbmc.LOGINFO)
                        return True
                        
        except Exception as e:
            # Capturar I/O Errors en entornos restrictivos (Android, LibreElec)
            xbmc.log(f"[AtresDaily] Error en escaneo profundo de addons: {str(e)}", xbmc.LOGWARNING)
            
        return False

    def _verify_xml_id(self, vfs_xml_path, keyword_lower, target_id):
        """Lee y parsea un addon.xml usando la API VFS de Kodi."""
        try:
            # VFS nativo para evitar fallos de permisos en Android TV / Xbox
            vfs_file = xbmcvfs.File(vfs_xml_path)
            content = vfs_file.read()
            vfs_file.close()

            root = ET.fromstring(content)
            real_id = root.attrib.get('id', '').lower()
            
            # Coincidencia por ID exacto
            if target_id and real_id == target_id.lower():
                return True
                
            # Coincidencia parcial si es un repositorio
            if real_id.startswith('repository.') and keyword_lower in real_id:
                return True
                
        except Exception:
            # XML inválido o error de lectura
            pass
            
        return False


    def install(self):
        """Instala el repositorio oficial bundled en resources usando VFS para saltar Scoped Storage."""
        addon_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
        repo_id = "repository.atresdaily"
        
        # Ruta origen usando OS join (100% fiable para leer dentro del propio addon)
        import os
        src_vfs = os.path.join(addon_path, "resources", repo_id)
        dest_vfs = f"special://home/addons/{repo_id}"
        
        if not os.path.exists(src_vfs):
            xbmc.log(f"[AtresDaily] Error: No se encontró el repo bundled en {src_vfs}", xbmc.LOGERROR)
            return False
            
        try:
            # Limpiar directorio previo
            if xbmcvfs.exists(dest_vfs):
                self._vfs_rmtree(dest_vfs)
                
            # Copiar archivos usando lectura OS y escritura VFS
            self._hybrid_copytree(src_vfs, dest_vfs)
            xbmc.log(f"[AtresDaily] Repositorio copiado híbrido a {dest_vfs}", xbmc.LOGINFO)
            
            # Forzar actualización e instalación en Kodi
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(500)
            xbmc.executebuiltin(f"InstallAddon({repo_id})")
            
            # Habilitar (Kodi 19+ los desactiva al copiarse a mano)
            self._enable_addon(repo_id)
            
            self.reset_cache()
            return True
            
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error crítico VFS instalando repositorio: {str(e)}", xbmc.LOGERROR)
            
            # Rollback: limpiar en caso de error a mitad de copia
            try:
                if xbmcvfs.exists(dest_vfs):
                    self._vfs_rmtree(dest_vfs)
                    xbmc.log(f"[AtresDaily] Rollback ejecutado: Carpeta corrupta eliminada.", xbmc.LOGINFO)
            except Exception as rollback_e:
                xbmc.log(f"[AtresDaily] Fallo durante el rollback: {rollback_e}", xbmc.LOGWARNING)
                
            return False

    def uninstall(self):
        """Desinstala y borra el repositorio."""
        repo_id = "repository.atresdaily"
        dest_vfs = f"special://home/addons/{repo_id}"
        if not dest_vfs.endswith('/'): dest_vfs += '/'
        
        try:
            # Desactivar vía RPC para liberar locks en DB
            self._set_enabled(repo_id, False)
            
            # Borrar archivos
            if xbmcvfs.exists(dest_vfs):
                self._vfs_rmtree(dest_vfs)
                xbmc.log(f"[AtresDaily] Carpeta {repo_id} borrada físicamente.", xbmc.LOGINFO)
                
            xbmc.executebuiltin("UpdateLocalAddons()")
            xbmc.sleep(1000)
            self.reset_cache()
            return True
        except Exception as e:
            xbmc.log(f"[AtresDaily] Error crítico desinstalando repositorio: {str(e)}", xbmc.LOGERROR)
            return False

    def _set_enabled(self, addon_id, enabled):
        """Habilita/deshabilita un addon mediante JSON-RPC."""
        try:
            import json
            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id, "enabled": enabled},
                "id": 1
            }
            xbmc.executeJSONRPC(json.dumps(rpc_cmd))
        except: pass

    def _enable_addon(self, addon_id):
        """Habilita el addon por JSON-RPC con reintentos para dar tiempo a UpdateLocalAddons."""
        try:
            import json
            rpc_cmd = {
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id, "enabled": True},
                "id": 1
            }
            payload = json.dumps(rpc_cmd)
            
            for _ in range(5):
                response = xbmc.executeJSONRPC(payload)
                if '"error"' not in response:
                    xbmc.log(f"[AtresDaily] Repositorio {addon_id} habilitado vía JSON-RPC.", xbmc.LOGINFO)
                    return
                xbmc.sleep(1000)
                
            xbmc.log(f"[AtresDaily] Fallo al habilitar addon tras 5 intentos. Res: {response}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[AtresDaily] Fallo al habilitar addon vía RPC: {e}", xbmc.LOGWARNING)

    def _vfs_rmtree(self, path):
        """Borrado recursivo VFS seguro."""
        if not path.endswith('/'):
            path += '/'
        dirs, files = xbmcvfs.listdir(path)
        for f in files:
            xbmcvfs.delete(f"{path}{f}")
        for d in dirs:
            self._vfs_rmtree(f"{path}{d}")
        xbmcvfs.rmdir(path)

    def _hybrid_copytree(self, src_os, dest_vfs):
        """Copia directorios. Lee con OS y escribe con VFS (inmune a Scoped Storage)."""
        import os
        dest_check = dest_vfs if dest_vfs.endswith('/') else dest_vfs + '/'
        if not xbmcvfs.exists(dest_check):
            xbmcvfs.mkdirs(dest_check)
            
        for item in os.listdir(src_os):
            s = os.path.join(src_os, item)
            d = f"{dest_vfs}/{item}"
            
            if os.path.isdir(s):
                self._hybrid_copytree(s, d)
            else:
                # Leer fichero origen a memoria (vía Python)
                with open(s, 'rb') as f:
                    content = f.read()
                # Escribir con VFS de Kodi
                v_file = xbmcvfs.File(d, 'wb')
                success = v_file.write(content)
                v_file.close()
                
                # Bugfix: Validar escritura correcta de VFS
                if success is False and len(content) > 0:
                    raise IOError(f"VFS devolvió False al escribir {d}")

    def reset_cache(self):
        """Limpia la caché de detección."""
        self._cache = {}

# Instancia singleton para ser importada por el resto del addon
detector = RepoDetector()
