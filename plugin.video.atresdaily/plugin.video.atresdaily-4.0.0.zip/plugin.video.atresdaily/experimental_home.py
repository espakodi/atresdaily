# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
import os
import sys
import time
import hashlib
import threading
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui
import xbmcaddon

import connectorexperimental as ce
import ui_utils

_LOG_TAG = "[AtresDaily/ExpHome]"

# Orden de filas en la home. Fuente única, los rótulos del XML se rellenan desde
# aquí (Window.Property row_label_N), así reordenar esta lista basta.
_ROW_CATS = ["Infantil", "Actualidad", "Programas", "Series", "Cine", "Documentales", "Extra"]

# Categorías candidatas para la cabecera (hero). Solo entran las que tengan un
# episodio libre reproducible directo; el resto se omiten.
_HERO_CATS = ("Series", "Cine", "Programas", "Actualidad", "Infantil")

_ID_HERO = 200
_ID_HOME_ROWS_BASE = 310  # 310..316, uno por categoría
_ID_LOADING = 500
_ID_GRID = 600
_ID_SEASONS = 700
_ID_EPISODES = 710
_ID_SEARCH_BTN = 900
_ID_CLOSE_BTN = 901

_FOCUS_POLL_MS = 250

# Cuántos pósters precargar por fila en la home. Las filas son una vista previa;
# el catálogo completo se ve en la rejilla "Ver todo". Limitar mantiene la home
# ágil (350 imágenes a la vez era el cuello de botella).
_HOME_ROW_LIMIT = 20
# Tamaño de página de la API; si una página devuelve este número, asumimos que
# hay más (la API no expone totalPages).
_PAGE_SIZE = 50

# Cache local de imágenes, persiste 2 días. Mejor que confiar solo en el cache de
# texturas de Kodi (textures.db), que es global y puede expirar por presión de
# espacio o reinstalación.
_IMG_CACHE_DIR_NAME = "imgcache"
_IMG_CACHE_TTL_SECS = 2 * 24 * 3600


def _img_cache_dir():
    p = ui_utils.get_path(_IMG_CACHE_DIR_NAME)
    if not os.path.exists(p):
        try: os.makedirs(p)
        except Exception: pass
    return p


def _url_to_local(url):
    h = hashlib.md5(url.encode('utf-8')).hexdigest()
    return os.path.join(_img_cache_dir(), h + ".jpg")


def _local_if_fresh(url):
    local = _url_to_local(url)
    try:
        if os.path.exists(local):
            age = time.time() - os.path.getmtime(local)
            if age < _IMG_CACHE_TTL_SECS and os.path.getsize(local) > 200:
                return local
    except Exception:
        pass
    return None


def _download_to_local(url):
    local = _url_to_local(url)
    if _local_if_fresh(url):
        return local
    return ce.download_file(url, local)


def _cleanup_old_cache():
    # Elimina imágenes con más de TTL de antigüedad. Se ejecuta en background al
    # abrir la home, no bloquea nada.
    cache_dir = _img_cache_dir()
    if not os.path.exists(cache_dir): return
    now = time.time()
    removed = 0
    try:
        for fname in os.listdir(cache_dir):
            path = os.path.join(cache_dir, fname)
            try:
                if now - os.path.getmtime(path) > _IMG_CACHE_TTL_SECS:
                    os.remove(path)
                    removed += 1
            except Exception:
                pass
    except Exception:
        pass
    if removed:
        xbmc.log(f"{_LOG_TAG} cache cleanup: {removed} imágenes expiradas eliminadas", xbmc.LOGINFO)


_CLOSE_ACTIONS = {xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK}

_PREMIUM_TAGS = ("EXCLUSIVE", "ORIGINAL", "PREVIEW")


def _is_premium_catalog(row):
    return row.get("tagType") in _PREMIUM_TAGS and not row.get("open", False)


def _is_premium_episode(ep):
    return ep.get("tagType") in _PREMIUM_TAGS


def _free_first(rows, premium_fn):
    # Sort estable, los no-premium conservan su orden THE_MOST y van delante.
    return sorted(rows, key=lambda r: 1 if premium_fn(r) else 0)


def _shrink_img(img_url):
    # ui_utils.fix_img pide 1280x720; con 480x270 sobra para fila/rejilla y el JPG
    # pesa ~6x menos. Con 100+ imágenes el ancho de banda total era el cuello.
    if img_url and img_url.endswith("1280x720.jpg"):
        return img_url[:-len("1280x720.jpg")] + "480x270.jpg"
    return img_url


# --- Fetch a la API ---

_fetch_json = ce.fetch_json
_fetch_cat_rows = ce.fetch_cat_rows


def _episodes_from_show_data(data):
    # Un show o una temporada devuelven la misma forma, una fila type=EPISODE que
    # apunta a otro href, o itemRows con los episodios directamente.
    if not isinstance(data, dict):
        return []
    for row in data.get("rows", []):
        if row.get("type") == "EPISODE" and row.get("href"):
            eps = _fetch_json(row["href"])
            return eps.get("itemRows", []) if isinstance(eps, dict) else []
    return data.get("itemRows", []) if "itemRows" in data else []


def _normalize_episode(ep):
    t = ep.get("title", "Episodio")
    n = ep.get("name", "")
    full = f"{n} - {t}" if n else t
    # El id reproducible es contentId; de fallback, lo extraemos del href
    # (.../page/episode/{contentId}).
    vid = ep.get("contentId")
    if not vid:
        href = (ep.get("link") or {}).get("href", "")
        if "/episode/" in href:
            vid = href.split("/episode/")[1].split("/")[0]
    img = _shrink_img(ui_utils.fix_img((ep.get("image") or {}).get("pathHorizontal")
                                       or (ep.get("image") or {}).get("pathVertical")))
    du = ep.get("duration", 0) or 0
    if du > 10000: du = du // 1000  # a veces viene en ms
    return {
        "title": full,
        "vid": vid,
        "premium": _is_premium_episode(ep),
        "img": img,
        "plot": (ep.get("description") or "")[:600],
        "duration": int(du),
    }


def _latest_free_episode(show_href):
    # Episodio libre más reciente de un programa, para que la cabecera reproduzca
    # directamente. La temporada 0 (seasons[0]) es la más reciente; si no hay
    # temporadas, se usan los episodios directos del programa.
    data = _fetch_json(show_href)
    if not isinstance(data, dict):
        return None
    eps = []
    seasons = data.get("seasons", [])
    if seasons:
        sh = (seasons[0].get("link") or {}).get("href")
        if sh:
            sd = _fetch_json(sh)
            if isinstance(sd, dict):
                eps = _episodes_from_show_data(sd)
    if not eps:
        eps = _episodes_from_show_data(data)
    for e in eps:
        if not _is_premium_episode(e):
            n = _normalize_episode(e)
            if n.get("vid"):
                return n
    return None


# --- Constructores de ListItem ---

def _build_show_li(item, cat_name=""):
    title = item.get("title", "Sin título")
    href = item.get("link", {}).get("href", "")
    if not href: return None
    img_url = _shrink_img(ui_utils.fix_img(item.get("image", {}).get("pathHorizontal")))
    img = _local_if_fresh(img_url) or img_url
    plot = (item.get("description") or "")[:600]
    badge = ""
    if _is_premium_catalog(item):
        badge = {"ORIGINAL": "ATP Original", "PREVIEW": "ATP Avance"}.get(item.get("tagType", ""), "ATP+")

    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "show")
    li.setProperty("ad_title", title)
    li.setProperty("ad_plot", plot)
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_href", href)
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_badge", badge)
    return li


def _build_hero_play_li(show_row, ep, cat_name=""):
    # Ítem de cabecera con la carátula del programa pero que reproduce directo su
    # último episodio libre (ad_action=episode + ad_vid). Visualmente idéntico al
    # póster del programa.
    title = show_row.get("title", "Sin título")
    img_url = _shrink_img(ui_utils.fix_img(show_row.get("image", {}).get("pathHorizontal")))
    img = _local_if_fresh(img_url) or img_url
    li = xbmcgui.ListItem(label=title)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", title)
    li.setProperty("ad_plot", ep.get("plot") or (show_row.get("description") or "")[:600])
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_vid", ep.get("vid") or "")
    li.setProperty("ad_is_premium", "0")
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_badge", "")
    return li


def _build_nav_li(action, label, cat_name="", page=""):
    # Centinela de navegación (Ver todo / Siguiente). Reusa el layout de póster.
    img = ui_utils.media_icon("catalogo.png") or "DefaultFolder.png"
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": img, "icon": img, "poster": img, "landscape": img})
    li.setProperty("ad_action", action)
    li.setProperty("ad_title", label)
    li.setProperty("ad_image", img)
    li.setProperty("ad_cat", cat_name)
    li.setProperty("ad_page", str(page))
    li.setProperty("ad_badge", "")
    return li


def _build_episode_li(ep):
    img = _local_if_fresh(ep["img"]) or ep["img"]
    label = ep["title"]
    badge = ""
    if ep["premium"]:
        label = f"[ATP+] {label}"
        badge = "ATP+"
    li = xbmcgui.ListItem(label=label)
    li.setArt({"thumb": img, "icon": img, "poster": img, "fanart": img, "landscape": img})
    li.setProperty("ad_action", "episode")
    li.setProperty("ad_title", ep["title"])
    li.setProperty("ad_plot", ep["plot"])
    li.setProperty("ad_image", img)
    li.setProperty("ad_fanart", img)
    li.setProperty("ad_vid", ep["vid"] or "")
    li.setProperty("ad_is_premium", "1" if ep["premium"] else "0")
    li.setProperty("ad_badge", badge)
    return li


def _build_season_li(title, href):
    li = xbmcgui.ListItem(label=title)
    li.setProperty("ad_action", "season")
    li.setProperty("ad_title", title)
    li.setProperty("ad_href", href)
    return li


class ExperimentalHome(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.selected_action = None
        self.selected_query = ""
        self.selected_vid = ""
        self.selected_title = ""
        self._cat_rows = {}
        self._loaded = False
        self._closing = False
        self._view_stack = ["home"]
        # Estado de la rejilla "Ver todo"
        self._grid_cat = ""
        self._grid_cid = ""
        self._grid_page = 0
        self._grid_rows = []
        self._grid_busy = False

    # --- Ciclo de vida ---

    def onInit(self):
        self.setProperty("view", "home")
        self._set_focus_props(title="Cargando…", plot="", fanart="")
        threading.Thread(target=_cleanup_old_cache, daemon=True).start()
        threading.Thread(target=self._load_all, daemon=True).start()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()

    def _load_all(self):
        try:
            results = {}
            lock = threading.Lock()

            def worker(name):
                cid = self._cid_for(name)
                if not cid: return
                try:
                    rows = _fetch_cat_rows(cid, page=0)
                except Exception as e:
                    xbmc.log(f"{_LOG_TAG} fetch {name} fallo: {e}", xbmc.LOGWARNING)
                    rows = []
                with lock:
                    results[name] = rows or []

            threads = [threading.Thread(target=worker, args=(n,), daemon=True) for n in _ROW_CATS]
            for t in threads: t.start()
            for t in threads: t.join(timeout=20)

            self._cat_rows = results
            if self._closing: return
            self._populate_home()
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} _load_all error: {e}", xbmc.LOGERROR)
            self._set_loading_text("[COLOR red]Error al cargar el catálogo. Pulsa Atrás para cerrar.[/COLOR]")

    def _cid_for(self, name):
        # CATS es lista de (nombre, id).
        return next((c for n, c in ce.CATS if n == name), None)

    # --- Vista HOME ---

    def _populate_home(self):
        # Placeholder inmediato del hero, primer programa libre de cada categoría
        # (abre detalle si se pulsa antes de que _resolve_hero lo haga reproducible).
        hero_items = []
        for name in _HERO_CATS:
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            first_free = next((r for r in rows if not _is_premium_catalog(r)), None)
            if first_free:
                li = _build_show_li(first_free, cat_name=name)
                if li: hero_items.append(li)
        if hero_items:
            try: self.getControl(_ID_HERO).addItems(hero_items)
            except Exception as e: xbmc.log(f"{_LOG_TAG} hero: {e}", xbmc.LOGWARNING)

        any_row = False
        for idx, name in enumerate(_ROW_CATS):
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            items = [li for li in (_build_show_li(r, cat_name=name) for r in rows[:_HOME_ROW_LIMIT]) if li]
            # Rótulo vacío si la fila no tiene contenido, para no dejar un encabezado huérfano.
            self.setProperty(f"row_label_{idx}", name if items else "")
            if not items: continue
            items.append(_build_nav_li("view_all", "Ver todo  »", cat_name=name))
            try:
                self.getControl(_ID_HOME_ROWS_BASE + idx).addItems(items)
                any_row = True
            except Exception as e:
                xbmc.log(f"{_LOG_TAG} fila {name}: {e}", xbmc.LOGWARNING)

        try: self.getControl(_ID_LOADING).setVisible(False)
        except Exception: pass

        if hero_items:
            try: self.setFocusId(_ID_HERO)
            except Exception: pass
        elif any_row:
            try: self.setFocusId(_ID_HOME_ROWS_BASE)
            except Exception: pass
        else:
            self._set_loading_text("[COLOR orange]No hay contenido disponible. Revisa tu conexión.[/COLOR]")

        self._loaded = True
        self._refresh_focus_props()
        if hero_items or any_row:
            threading.Thread(target=self._prefetch_images, daemon=True).start()
        if any(self._cat_rows.get(n) for n in _HERO_CATS):
            threading.Thread(target=self._resolve_hero, daemon=True).start()

    def _resolve_hero(self):
        results = {}
        lock = threading.Lock()

        def work(name):
            rows = _free_first(self._cat_rows.get(name, []), _is_premium_catalog)
            for show in rows[:8]:
                if _is_premium_catalog(show):
                    continue
                href = (show.get("link") or {}).get("href", "")
                ep = _latest_free_episode(href) if href else None
                if ep and ep.get("vid"):
                    li = _build_hero_play_li(show, ep, name)
                    with lock:
                        results[name] = li
                    return

        threads = [threading.Thread(target=work, args=(n,), daemon=True) for n in _HERO_CATS]
        for t in threads: t.start()
        for t in threads: t.join(timeout=18)
        if self._closing: return

        items = [results[n] for n in _HERO_CATS if n in results]
        if not items: return
        try:
            ctrl = self.getControl(_ID_HERO)
            pos = ctrl.getSelectedPosition()
            ctrl.reset()
            ctrl.addItems(items)
            if 0 <= pos < len(items):
                ctrl.selectItem(pos)
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} resolve_hero: {e}", xbmc.LOGWARNING)

    def _prefetch_images(self):
        urls = set()
        for rows in self._cat_rows.values():
            for r in rows[:_HOME_ROW_LIMIT]:
                img = _shrink_img(ui_utils.fix_img(r.get("image", {}).get("pathHorizontal", "")))
                if img and not _local_if_fresh(img):
                    urls.add(img)
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=10) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} prefetch error: {e}", xbmc.LOGWARNING)

    # --- Vista GRID (Ver todo) ---

    def _open_grid(self, cat_name):
        cid = self._cid_for(cat_name)
        if not cid: return
        self._grid_cat = cat_name
        self._grid_cid = cid
        self._grid_page = 0
        self._grid_rows = []
        self.setProperty("grid_title", f"{cat_name}  ·  Cargando…")
        self._navigate_to("grid")
        threading.Thread(target=self._grid_fetch_first, daemon=True).start()

    def _grid_fetch_first(self):
        rows = _fetch_cat_rows(self._grid_cid, page=0)
        self._grid_rows = rows or []
        self.setProperty("grid_title", f"{self._grid_cat}  ·  Todo")
        self._render_grid(last_count=len(rows or []), focus_pos=0)

    def _render_grid(self, last_count, focus_pos=0):
        try:
            ctrl = self.getControl(_ID_GRID)
        except Exception:
            return
        ctrl.reset()
        items = [li for li in (_build_show_li(r, cat_name=self._grid_cat)
                               for r in _free_first(self._grid_rows, _is_premium_catalog)) if li]
        # Si la última página vino llena, probablemente hay más.
        if last_count >= _PAGE_SIZE:
            items.append(_build_nav_li("load_more", "Siguiente  »", cat_name=self._grid_cat,
                                       page=self._grid_page + 1))
        if not items:
            self.setProperty("grid_title", f"{self._grid_cat}  ·  Sin contenido")
            return
        ctrl.addItems(items)
        try:
            ctrl.selectItem(min(focus_pos, len(items) - 1))
            self.setFocusId(_ID_GRID)
        except Exception:
            pass
        # Precargar las imágenes nuevas de la rejilla en background.
        threading.Thread(target=self._prefetch_grid, daemon=True).start()

    def _prefetch_grid(self):
        urls = set()
        for r in self._grid_rows:
            img = _shrink_img(ui_utils.fix_img(r.get("image", {}).get("pathHorizontal", "")))
            if img and not _local_if_fresh(img):
                urls.add(img)
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=10) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception:
            pass

    def _grid_load_more(self):
        if self._grid_busy: return
        self._grid_busy = True

        def work():
            try:
                next_page = self._grid_page + 1
                new_rows = _fetch_cat_rows(self._grid_cid, page=next_page)
                if not new_rows:
                    xbmcgui.Dialog().notification("AtresDaily", "No hay más contenido",
                                                  xbmcgui.NOTIFICATION_INFO, 1500)
                    # Repintar sin centinela (last_count 0) para quitar "Siguiente".
                    self._render_grid(last_count=0, focus_pos=len(self._grid_rows) - 1)
                    return
                focus_at = len(self._grid_rows)  # primer ítem nuevo
                self._grid_rows.extend(new_rows)
                self._grid_page = next_page
                self._render_grid(last_count=len(new_rows), focus_pos=focus_at)
            finally:
                self._grid_busy = False

        threading.Thread(target=work, daemon=True).start()

    # --- Vista DETAIL (temporadas + episodios) ---

    def _open_detail(self, href, title, cat_name=""):
        self.setProperty("detail_title", title)
        self.setProperty("detail_plot", "")
        self.setProperty("seasons_visible", "0")
        self._navigate_to("detail")
        threading.Thread(target=self._load_detail, args=(href, title), daemon=True).start()

    def _load_detail(self, href, title):
        data = _fetch_json(href)
        if not isinstance(data, dict):
            xbmcgui.Dialog().notification("AtresDaily", "No se pudo abrir el programa",
                                          xbmcgui.NOTIFICATION_WARNING, 2000)
            self._go_back()
            return
        self.setProperty("detail_title", data.get("title") or title)

        seasons = data.get("seasons", [])
        # Con varias temporadas mostramos la tira de temporadas (archivo completo);
        # si no, los episodios directos del programa.
        if len(seasons) > 1:
            self._populate_seasons(seasons)
            first_href = (seasons[0].get("link") or {}).get("href", "")
            if first_href:
                self._load_season(first_href)
            return

        self.setProperty("seasons_visible", "0")
        eps = _episodes_from_show_data(data)
        self._populate_episodes(eps)

    def _populate_seasons(self, seasons):
        items = []
        for s in seasons:
            t = s.get("title", "Temporada")
            link = (s.get("link") or {}).get("href", "")
            if link:
                items.append(_build_season_li(t, link))
        try:
            ctrl = self.getControl(_ID_SEASONS)
            ctrl.reset()
            ctrl.addItems(items)
            self.setProperty("seasons_visible", "1")
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} temporadas: {e}", xbmc.LOGWARNING)

    def _load_season(self, href):
        def work():
            data = _fetch_json(href)
            eps = _episodes_from_show_data(data) if isinstance(data, dict) else []
            self._populate_episodes(eps)
        threading.Thread(target=work, daemon=True).start()

    def _populate_episodes(self, raw_eps):
        norm = [n for n in (_normalize_episode(e) for e in raw_eps) if n.get("vid")]
        norm = sorted(norm, key=lambda e: 1 if e["premium"] else 0)  # no-premium primero
        items = [_build_episode_li(e) for e in norm]
        try:
            ctrl = self.getControl(_ID_EPISODES)
            ctrl.reset()
            if items:
                ctrl.addItems(items)
            self.setFocusId(_ID_EPISODES if items else _ID_SEASONS)
        except Exception as e:
            xbmc.log(f"{_LOG_TAG} episodios: {e}", xbmc.LOGWARNING)
        if not items:
            xbmcgui.Dialog().notification("AtresDaily", "Sin episodios disponibles",
                                          xbmcgui.NOTIFICATION_INFO, 2000)
        threading.Thread(target=lambda: self._prefetch_episode_imgs(norm), daemon=True).start()

    def _prefetch_episode_imgs(self, norm):
        urls = {e["img"] for e in norm if e["img"] and not _local_if_fresh(e["img"])}
        if not urls: return
        try:
            with ThreadPoolExecutor(max_workers=8) as ex:
                for _ in ex.map(_download_to_local, urls):
                    if self._closing: return
        except Exception:
            pass

    # --- Reproducción ---

    def _play_episode(self, vid, title):
        # Cerramos la ventana y dejamos que show() delegue en connector.play_media:
        # un diálogo se pinta sobre el vídeo, así que no se puede reproducir con la
        # ventana abierta.
        if not vid: return
        self.selected_action = "play"
        self.selected_vid = vid
        self.selected_title = title
        self._closing = True
        self.close()

    def _do_search(self):
        kb = xbmc.Keyboard('', 'Buscar en Atresplayer')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            return
        self.selected_action = "search"
        self.selected_query = kb.getText().strip()
        self._closing = True
        self.close()

    # --- Navegación entre vistas ---

    def _navigate_to(self, view):
        # No forzamos foco aquí; el contenido se puebla en background y enfocar un
        # control aún vacío genera ruido en el log de Kodi. El método de poblado
        # (_render_grid / _populate_episodes) fija el foco cuando ya hay ítems.
        self._view_stack.append(view)
        self.setProperty("view", view)
        self._refresh_focus_props()

    def _go_back(self):
        if len(self._view_stack) > 1:
            self._view_stack.pop()
            target = self._view_stack[-1]
            self.setProperty("view", target)
            # Al volver, la vista destino ya está poblada; enfocar es seguro.
            fid = {"home": _ID_HERO, "grid": _ID_GRID, "detail": _ID_EPISODES}.get(target, _ID_HERO)
            try: self.setFocusId(fid)
            except Exception: pass
            self._refresh_focus_props()
        else:
            self._closing = True
            self.close()

    # --- Eventos ---

    def onAction(self, action):
        if action.getId() in _CLOSE_ACTIONS:
            self._go_back()

    def onClick(self, controlId):
        if not self._loaded: return
        if controlId == _ID_CLOSE_BTN:
            self._closing = True
            self.close()
            return
        if controlId == _ID_SEARCH_BTN:
            self._do_search()
            return
        try:
            ctrl = self.getControl(controlId)
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
        except Exception:
            return
        action = li.getProperty("ad_action")
        if action == "view_all":
            self._open_grid(li.getProperty("ad_cat"))
        elif action == "load_more":
            self._grid_load_more()
        elif action == "season":
            self._load_season(li.getProperty("ad_href"))
        elif action == "episode":
            # Todos (libres y ATP+) se delegan al connector vía play_media; él
            # decide si hay fuente reproducible. Los premium solo van ordenados al
            # final y con badge.
            self._play_episode(li.getProperty("ad_vid"), li.getProperty("ad_title"))
        else:  # show
            href = li.getProperty("ad_href")
            if href:
                self._open_detail(href, li.getProperty("ad_title"), li.getProperty("ad_cat"))

    # --- Propiedades de foco (título/plot/fanart inferior) ---

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last_key = None
        while not self._closing and not monitor.abortRequested():
            try:
                key = self._current_focus_key()
                if key != last_key:
                    self._refresh_focus_props()
                    last_key = key
            except Exception:
                pass
            if monitor.waitForAbort(_FOCUS_POLL_MS / 1000.0):
                break

    def _current_focus_key(self):
        try:
            ctrl = self.getFocus()
            return (ctrl.getId(), ctrl.getSelectedPosition())
        except Exception:
            return None

    def _refresh_focus_props(self):
        try:
            ctrl = self.getFocus()
            pos = ctrl.getSelectedPosition()
            if pos < 0: return
            li = ctrl.getListItem(pos)
            if li is None: return
            self._set_focus_props(
                title=li.getProperty("ad_title") or li.getLabel() or "",
                plot=li.getProperty("ad_plot") or "",
                fanart=li.getProperty("ad_fanart") or li.getProperty("ad_image") or "",
            )
        except Exception:
            pass

    def _set_focus_props(self, title="", plot="", fanart=""):
        self.setProperty("focused_title", title)
        self.setProperty("focused_plot", plot)
        self.setProperty("focused_fanart", fanart)

    def _set_loading_text(self, msg):
        try:
            ctrl = self.getControl(_ID_LOADING)
            ctrl.setLabel(msg)
            ctrl.setVisible(True)
        except Exception:
            pass


def show():
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    win = ExperimentalHome("experimental_home.xml", addon_path, "Default", "1080i")
    try:
        win.doModal()
        action = win.selected_action
        query = win.selected_query
        vid = win.selected_vid
        title = win.selected_title
    finally:
        del win

    if action == "search" and query:
        qs = {"action": "atresplayer_catalog_search", "q": query}
        next_url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
        xbmc.executebuiltin(f"Container.Update({next_url})")
    elif action == "play" and vid:
        qs = {"action": "play_media", "url": vid, "title": title}
        play_url = sys.argv[0] + "?" + urllib.parse.urlencode(qs)
        xbmc.executebuiltin(f"PlayMedia({play_url})")
