# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""
Resolver Debrid embebido. Convierte enlaces de filehosters y magnets en
streams directos usando la cuenta del usuario, sin depender de ResolveURL.

Proveedores: AllDebrid (apikey), Real-Debrid (OAuth device + refresh),
TorBox (apikey + device) y Premiumize (OAuth device). Cada uno es una clase
independiente que hereda de _DebridBase: un fallo en uno solo afecta a ese
proveedor cuando está seleccionado, nunca al resto del addon.

"""
import base64
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

_VIDEO_EXTS = (
    ".mkv", ".mp4", ".avi", ".ts", ".mov", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg",
)
_HOSTS_TTL = 8 * 3600
_TIMEOUT = 15


class DebridError(Exception):
    pass


class DebridAuthError(DebridError):
    """Token inválido/revocado o cuenta bloqueada: hay que re-vincular."""


class DebridNotSupported(DebridError):
    """El recurso no está soportado: el llamador debe caer al flujo normal."""


class DebridNotPremium(DebridError):
    """La operación requiere cuenta premium activa."""


class DebridNetworkError(DebridError):
    """Fallo de red, timeout o respuesta ilegible: caer al flujo normal."""


def _addon():
    return xbmcaddon.Addon()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[AtresDaily/Debrid] {0}".format(msg), level)


def _http_json(method, url, headers=None, data=None, params=None, json_body=None, timeout=_TIMEOUT):
    """Petición HTTP que devuelve el dict JSON (de éxito o de error de la API).
    Solo lanza DebridNetworkError para fallos de transporte/parseo."""
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)
    h = dict(headers or {})
    body = None
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        h["Content-Type"] = "application/json"
    elif data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            txt = r.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        try:
            txt = e.read().decode("utf-8")
            return json.loads(txt)  # las APIs Debrid devuelven el error en el cuerpo
        except (ValueError, OSError):
            raise DebridNetworkError("HTTP {0}".format(e.code))
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        raise DebridNetworkError(str(e))
    if not txt.strip():
        return {}  # 204 No Content (p.ej. RD selectFiles/delete)
    try:
        return json.loads(txt)
    except ValueError:
        raise DebridNetworkError("respuesta no JSON")


def _flatten_files(files):
    """Aplana la estructura de AllDebrid: 'e' son subcarpetas; los archivos
    tienen 'n' (nombre), 'l' (link interno) y 's' (tamaño)."""
    flat = []
    for f in files or []:
        if "e" in f:
            flat.extend(_flatten_files(f["e"]))
        elif f.get("l"):
            flat.append(f)
    return flat


def _video_files_ad(flat):
    return [f for f in flat if (f.get("n") or "").lower().endswith(_VIDEO_EXTS)]


def _is_video_name(name):
    return bool(name) and name.lower().endswith(_VIDEO_EXTS)


def _fmt_ts(ts):
    try:
        return time.strftime("%d/%m/%Y", time.localtime(int(ts)))
    except (ValueError, OSError, TypeError):
        return ""


def _days_from_ts(ts):
    try:
        return max(0, int((int(ts) - time.time()) / 86400))
    except (TypeError, ValueError):
        return None


def _days_from_iso(iso):
    # Días hasta una fecha ISO 'YYYY-MM-DD...', sin strptime (no fiable en Kodi).
    try:
        import datetime
        y, m, d = iso[:10].split("-")
        return max(0, (datetime.date(int(y), int(m), int(d)) - datetime.date.today()).days)
    except (ValueError, TypeError, AttributeError):
        return None


class _DebridBase:
    name = "base"
    PREFIX = "base"
    TOKEN_KEY = "base_token"
    SUPPORTS_PIN = False  # ¿tiene flujo de vinculación por código en pantalla?

    def __init__(self):
        addon = _addon()
        self.token = addon.getSetting(self.TOKEN_KEY) or ""
        self.cached_only = addon.getSetting("debrid_cached_only") == "true"
        self.auto_cleanup = addon.getSetting("debrid_auto_cleanup") == "true"
        self.auto_quality = addon.getSetting("debrid_auto_quality") == "true"

    # --- estado/credenciales (sin red) ---

    def is_authorized(self):
        return bool(self.token) and _addon().getSetting(self.PREFIX + "_authorized") == "true"

    def stored_user(self):
        return _addon().getSetting(self.PREFIX + "_user") or ""

    def _save_auth(self, token, user):
        addon = _addon()
        addon.setSetting(self.TOKEN_KEY, token)
        addon.setSetting(self.PREFIX + "_authorized", "true")
        addon.setSetting(self.PREFIX + "_user", str(user or ""))
        self.token = token

    def deauthorize(self):
        addon = _addon()
        addon.setSetting(self.TOKEN_KEY, "")
        addon.setSetting(self.PREFIX + "_authorized", "false")
        addon.setSetting(self.PREFIX + "_user", "")
        addon.setSetting("debrid_hosts_cache", "")
        addon.setSetting("debrid_hosts_ts", "")
        self.token = ""

    # --- cache de hosts compartida ({p: provider, items: [...]}) ---

    def _host_cache(self, fetch_fn):
        addon = _addon()
        raw = addon.getSetting("debrid_hosts_cache") or ""
        ts = addon.getSetting("debrid_hosts_ts") or "0"
        try:
            fresh = (int(time.time()) - int(ts)) < _HOSTS_TTL
        except ValueError:
            fresh = False
        if raw and fresh:
            try:
                obj = json.loads(raw)
                if obj.get("p") == self.name:
                    return obj.get("items", [])
            except ValueError:
                pass
        try:
            items = fetch_fn()
        except DebridError:
            return []
        addon.setSetting("debrid_hosts_cache", json.dumps({"p": self.name, "items": items}))
        addon.setSetting("debrid_hosts_ts", str(int(time.time())))
        return items

    def warm_hosts(self):
        """Precalienta la cache de hosts (llamar tras vincular)."""
        try:
            self.is_supported_hoster("https://example.invalid/")
        except DebridError:
            pass

    # --- interfaz (cada proveedor implementa) ---

    def authorize_pin(self):
        raise NotImplementedError

    def authorize_apikey(self, key):
        raise NotImplementedError

    def account_info(self):
        raise NotImplementedError

    def is_supported_hoster(self, url):
        raise NotImplementedError

    def resolve(self, raw_url):
        raise NotImplementedError

    def list_library(self):
        raise NotImplementedError

    def library_files(self, item_id):
        raise NotImplementedError

    def resolve_library_item(self, item_id):
        raise NotImplementedError

    def resolve_library_file(self, item_id, index):
        raise NotImplementedError

    def delete_library_item(self, item_id):
        raise NotImplementedError

    # --- utilidades de UI compartidas ---

    def _pick_video(self, videos):
        """Elige un archivo de vídeo de una lista [{name, size, ...}].
        Automático (mayor) o diálogo según ajustes."""
        if not videos:
            return None
        if self.auto_quality or len(videos) == 1:
            return max(videos, key=lambda f: f.get("size", 0) or 0)
        labels = ["{0} ({1:.2f} GB)".format(f.get("name", "?"), (f.get("size", 0) or 0) / 1e9) for f in videos]
        sel = xbmcgui.Dialog().select("Selecciona archivo", labels)
        return videos[sel] if sel >= 0 else None

    def _resolve_guard(self, fn):
        """Ejecuta una resolución capturando las excepciones de dominio y
        traduciéndolas a None (fallback) + aviso al usuario cuando procede."""
        try:
            return fn()
        except DebridAuthError as e:
            _addon().setSetting(self.PREFIX + "_authorized", "false")
            xbmcgui.Dialog().notification(self.name, "Cuenta no autorizada", xbmcgui.NOTIFICATION_WARNING, 4000)
            _log("auth: {0}".format(e), xbmc.LOGWARNING)
        except DebridNotPremium as e:
            xbmcgui.Dialog().notification(self.name, "Requiere cuenta premium", xbmcgui.NOTIFICATION_WARNING, 4000)
            _log("premium: {0}".format(e), xbmc.LOGWARNING)
        except DebridNotSupported as e:
            _log("no soportado: {0}".format(e))
        except DebridError as e:
            _log("error: {0}".format(e), xbmc.LOGWARNING)
        return None


def _magnet_hash(magnet):
    m = re.search(r"urn:btih:([a-zA-Z0-9]+)", magnet, re.I)
    return m.group(1) if m else None


# ===================== AllDebrid =====================

class AllDebrid(_DebridBase):
    name = "AllDebrid"
    PREFIX = "alldebrid"
    TOKEN_KEY = "alldebrid_token"
    SUPPORTS_PIN = True
    BASE = "https://api.alldebrid.com/v4"
    BASE_1 = "https://api.alldebrid.com/v4.1"
    UA = "AtresDaily"

    def _headers(self):
        h = {"User-Agent": self.UA}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, base, path, data=None, params=None):
        payload = _http_json(method, base + path, self._headers(), data=data, params=params)
        if payload.get("status") == "error":
            err = payload.get("error", {})
            code = err.get("code", "")
            msg = err.get("message", code) or "error"
            if code in ("AUTH_BAD_APIKEY", "AUTH_BLOCKED", "AUTH_USER_BANNED", "AUTH_MISSING_APIKEY"):
                raise DebridAuthError(msg)
            if code in ("MUST_BE_PREMIUM", "MAGNET_MUST_BE_PREMIUM"):
                raise DebridNotPremium(msg)
            if code in ("LINK_HOST_NOT_SUPPORTED", "LINK_DOWN", "LINK_HOST_UNAVAILABLE", "LINK_NOT_SUPPORTED"):
                raise DebridNotSupported(msg)
            raise DebridError("{0} ({1})".format(msg, code))
        return payload.get("data", {})

    def authorize_pin(self):
        self.token = ""
        try:
            data = self._api("GET", self.BASE_1, "/pin/get")
        except DebridError as e:
            xbmcgui.Dialog().ok("AllDebrid", "No se pudo iniciar la vinculación:\n{0}".format(e))
            return False
        pin = data.get("pin", "")
        check = data.get("check", "")
        expires_in = int(data.get("expires_in", 600) or 600)
        base_url = data.get("base_url") or "alldebrid.com/pin/"
        apikey = _pin_poll(
            "Vincular AllDebrid", base_url, pin, expires_in,
            lambda: self._pin_check(pin, check))
        return self._finish_apikey(apikey) if apikey else False

    def _pin_check(self, pin, check):
        try:
            chk = self._api("POST", self.BASE, "/pin/check", data={"pin": pin, "check": check})
        except DebridError:
            return None
        return chk.get("apikey") if chk.get("activated") else None

    def authorize_apikey(self, key):
        return self._finish_apikey((key or "").strip())

    def _finish_apikey(self, apikey):
        if not apikey:
            return False
        self.token = apikey
        try:
            user = self._api("GET", self.BASE, "/user").get("user", {})
        except DebridError as e:
            self.token = ""
            xbmcgui.Dialog().ok("AllDebrid", "La clave no es válida:\n{0}".format(e))
            return False
        self._save_auth(apikey, user.get("username", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        user = self._api("GET", self.BASE, "/user").get("user", {})
        return {
            "username": user.get("username", ""),
            "premium": bool(user.get("isPremium")),
            "expiry_text": _fmt_ts(user.get("premiumUntil")),
            "days": _days_from_ts(user.get("premiumUntil")),
            "extra": "",
        }

    def _fetch_hosts(self):
        data = self._api("GET", self.BASE_1, "/user/hosts")
        hosts = data.get("hosts", {}) or {}
        patterns = []
        for value in hosts.values():
            rx = value.get("regexp")
            if isinstance(rx, list):
                rx = rx[0] if rx else None
            if rx:
                patterns.append(rx)
        return patterns

    def is_supported_hoster(self, url):
        for pat in self._host_cache(self._fetch_hosts):
            try:
                if re.search(pat, url, re.I):
                    return True
            except re.error:
                continue
        return False

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_hoster(raw_url))
        return None

    def _resolve_hoster(self, url):
        data = self._api("POST", self.BASE, "/link/unlock", data={"link": url})
        if data.get("link"):
            return data["link"]
        if data.get("host") == "stream":
            streams = [s for s in data.get("streams", []) if "+" not in str(s.get("id", ""))]
            if not streams:
                return None
            streams.sort(key=lambda s: _safe_int(s.get("quality")), reverse=True)
            if self.auto_quality or len(streams) == 1:
                chosen = streams[0]
            else:
                sel = xbmcgui.Dialog().select("Calidad", ["{0}p".format(s.get("quality")) for s in streams])
                chosen = streams[sel] if sel >= 0 else None
            if not chosen:
                return None
            res = self._api("POST", self.BASE, "/link/streaming",
                            data={"id": data.get("id"), "stream": chosen.get("id")})
            return res.get("link")
        return None

    def _resolve_magnet(self, magnet):
        seed = _magnet_hash(magnet) or magnet
        up = self._api("POST", self.BASE, "/magnet/upload", data={"magnets[]": seed})
        magnets = up.get("magnets") or []
        if isinstance(magnets, dict):  # la API puede devolver objeto en vez de lista
            magnets = [magnets]
        if not magnets:
            return None
        mag = magnets[0]
        mid = mag.get("id")
        if not mag.get("ready"):
            if self.cached_only:
                self._delete(mid)
                return None
            if not self._wait_transfer(mid):
                return None
        link = self._pick_magnet_file(mid)
        if not link:
            return None
        final = self._api("POST", self.BASE, "/link/unlock", data={"link": link}).get("link")
        if self.auto_cleanup:
            self._delete(mid)
        return final

    def _status(self, mid):
        data = self._api("POST", self.BASE_1, "/magnet/status", data={"id": mid})
        magnets = data.get("magnets")
        if isinstance(magnets, list):
            for m in magnets:
                if str(m.get("id")) == str(mid):
                    return m
            return magnets[0] if magnets else {}
        return magnets or {}

    def _wait_transfer(self, mid, interval=5):
        dlg = xbmcgui.DialogProgress()
        dlg.create("AllDebrid", "Preparando el torrent en la nube...")
        try:
            while True:
                info = self._status(mid)
                code = info.get("statusCode", 0)
                if code == 4:
                    xbmc.sleep(2000)  # ResolveURL: dar tiempo a generar los links
                    return True
                if 5 <= code <= 10:
                    self._delete(mid)
                    return False
                size = float(info.get("size") or 0)
                done = float(info.get("downloaded") or 0)
                pct = int(done / size * 100) if size > 0 else 0
                dlg.update(pct, "{0}\n{1}".format(info.get("filename", ""), info.get("status", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("AllDebrid", "¿Mantener la descarga en segundo plano?"):
                        self._delete(mid)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _files(self, mid):
        data = self._api("POST", self.BASE, "/magnet/files", data={"id[]": mid})
        magnets = data.get("magnets") or []
        if isinstance(magnets, dict):
            magnets = [magnets]
        files = magnets[0].get("files", []) if magnets and isinstance(magnets[0], dict) else []
        out = []
        for f in _video_files_ad(_flatten_files(files)):
            out.append({"name": f.get("n", ""), "size": f.get("s", 0), "link": f.get("l")})
        return out

    def _pick_magnet_file(self, mid):
        chosen = self._pick_video(self._files(mid))
        return chosen.get("link") if chosen else None

    def _delete(self, mid):
        if mid is None:
            return
        try:
            self._api("GET", self.BASE, "/magnet/delete", params={"id": mid})
        except DebridError as e:
            _log("delete {0}: {1}".format(mid, e), xbmc.LOGWARNING)

    def unlock(self, link):
        return self._api("POST", self.BASE, "/link/unlock", data={"link": link}).get("link")

    def list_library(self):
        data = self._api("GET", self.BASE_1, "/magnet/status")
        magnets = data.get("magnets", [])
        if not isinstance(magnets, list):
            magnets = [magnets]
        items = []
        for m in magnets:
            items.append({
                "id": m.get("id"),
                "filename": m.get("filename", ""),
                "size": m.get("size", 0),
                "ready": m.get("statusCode") == 4,
                "status": m.get("status", ""),
                "date": m.get("completionDate") or m.get("uploadDate") or 0,
            })
        items.sort(key=lambda x: x.get("date", 0), reverse=True)
        return items

    def library_files(self, item_id):
        return self._files(item_id)

    def resolve_library_item(self, item_id):
        link = self._pick_magnet_file(item_id)
        return self.unlock(link) if link else None

    def resolve_library_file(self, item_id, index):
        files = self._files(item_id)
        if 0 <= index < len(files):
            return self.unlock(files[index].get("link"))
        return None

    def delete_library_item(self, item_id):
        self._delete(item_id)
        return True


# ===================== Real-Debrid =====================

class RealDebrid(_DebridBase):
    name = "Real-Debrid"
    PREFIX = "realdebrid"
    TOKEN_KEY = "realdebrid_token"
    SUPPORTS_PIN = True
    BASE = "https://api.real-debrid.com/rest/1.0"
    OAUTH = "https://api.real-debrid.com/oauth/v2"
    CLIENT_ID = "X245A4XAIBGVM"
    UA = "AtresDaily"

    def __init__(self):
        super().__init__()
        self._access = None

    def _access_token(self):
        """El token guardado es base64('client_id:client_secret:refresh_token')
        (OAuth, se refresca en cada arranque) o un API token plano de la web."""
        if self._access:
            return self._access
        raw = self.token
        parts = []
        try:
            parts = base64.b64decode(raw).decode().split(":")
        except (ValueError, UnicodeDecodeError):  # binascii.Error hereda de ValueError
            parts = []
        if len(parts) == 3 and all(parts):
            cid, csec, refresh = parts
            tok = _http_json("POST", self.OAUTH + "/token", {"User-Agent": self.UA}, data={
                "client_id": cid, "client_secret": csec,
                "code": refresh, "grant_type": "http://oauth.net/grant_type/device/1.0",
            })
            self._access = tok.get("access_token")
            if not self._access:
                raise DebridAuthError("refresh fallido")
        else:
            self._access = raw  # API token directo (real-debrid.com/apitoken)
        return self._access

    def _headers(self, auth=True):
        h = {"User-Agent": self.UA}
        if auth:
            h["Authorization"] = "Bearer {0}".format(self._access_token())
        return h

    def _api(self, method, path, data=None, params=None, auth=True, _retry=True):
        payload = _http_json(method, self.BASE + path, self._headers(auth), data=data, params=params)
        if isinstance(payload, dict) and "error_code" in payload:
            # error_code 8 = token expirado. Si es OAuth, refrescar y reintentar una vez
            # (cubre sesiones largas, p.ej. polling de una descarga > 1h) antes de fallar.
            if payload.get("error_code") == 8 and auth and _retry:
                self._access = None
                return self._api(method, path, data=data, params=params, auth=auth, _retry=False)
            self._raise_rd(payload)
        return payload

    @staticmethod
    def _raise_rd(payload):
        code = payload.get("error_code")
        msg = payload.get("error") or "Real-Debrid error {0}".format(code)
        if code == 8:
            raise DebridAuthError(msg)
        if code in (16, 17, 19, 20):
            raise DebridNotSupported(msg)
        if code in (21, 23, 36):
            raise DebridNotPremium(msg)
        if code == 24:
            raise DebridNotSupported(msg)
        raise DebridError("{0} (code {1})".format(msg, code))

    def authorize_pin(self):
        oauth = _http_json("GET", self.OAUTH + "/device/code", {"User-Agent": self.UA},
                           params={"client_id": self.CLIENT_ID, "new_credentials": "yes"})
        device_code = oauth.get("device_code")
        user_code = oauth.get("user_code", "")
        url = oauth.get("direct_verification_url") or oauth.get("verification_url") or "real-debrid.com/device"
        expires_in = int(oauth.get("expires_in", 1800) or 1800)
        interval = int(oauth.get("interval", 5) or 5)
        if not device_code:
            xbmcgui.Dialog().ok("Real-Debrid", "No se pudo iniciar la vinculación.")
            return False

        creds = {}
        def _check():
            res = _http_json("GET", self.OAUTH + "/device/credentials", {"User-Agent": self.UA},
                             params={"client_id": self.CLIENT_ID, "code": device_code})
            if res.get("client_secret"):
                creds["id"] = res["client_id"]
                creds["secret"] = res["client_secret"]
                return True  # señal de activado
            return None

        got = _pin_poll("Vincular Real-Debrid", url, user_code, expires_in, _check, interval=interval)
        if not got or "secret" not in creds:
            return False
        tok = _http_json("POST", self.OAUTH + "/token", {"User-Agent": self.UA}, data={
            "client_id": creds["id"], "client_secret": creds["secret"],
            "code": device_code, "grant_type": "http://oauth.net/grant_type/device/1.0",
        })
        if not tok.get("refresh_token"):
            xbmcgui.Dialog().ok("Real-Debrid", "No se obtuvo el token.")
            return False
        stored = base64.b64encode(
            "{0}:{1}:{2}".format(creds["id"], creds["secret"], tok["refresh_token"]).encode()).decode()
        return self._finish_token(stored)

    def authorize_apikey(self, key):
        return self._finish_token((key or "").strip())

    def _finish_token(self, token):
        if not token:
            return False
        self.token = token
        self._access = None
        try:
            user = self._api("GET", "/user")
        except DebridError as e:
            self.token = ""
            xbmcgui.Dialog().ok("Real-Debrid", "Token no válido:\n{0}".format(e))
            return False
        self._save_auth(token, user.get("username", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        user = self._api("GET", "/user")
        exp = user.get("expiration", "") or ""
        return {
            "username": user.get("username", ""),
            "premium": user.get("type") == "premium",
            "expiry_text": exp[:10],
            "days": _days_from_iso(exp),
            "extra": "",
        }

    def _fetch_hosts(self):
        domains = _http_json("GET", self.BASE + "/hosts/domains", self._headers())
        return domains if isinstance(domains, list) else []

    def is_supported_hoster(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or "").replace("www.", "")
        except ValueError:
            return False
        if not host:
            return False
        return any(host in d or d in host for d in self._host_cache(self._fetch_hosts))

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_hoster(raw_url))
        return None

    def _resolve_hoster(self, url):
        res = self._api("POST", "/unrestrict/link", data={"link": url})
        return res.get("download")

    def _resolve_magnet(self, magnet):
        # No se usa /torrents/instantAvailability (RD lo dejó inservible en 2024).
        # En su lugar: añadir, seleccionar, y mirar el estado una vez; si ya está
        # "downloaded" estaba cacheado. Con cached_only, si no lo está, se borra.
        added = self._api("POST", "/torrents/addMagnet", data={"magnet": magnet})
        tid = added.get("id")
        if not tid:
            return None
        self._api("POST", "/torrents/selectFiles/{0}".format(tid), data={"files": "all"})
        info = self._api("GET", "/torrents/info/{0}".format(tid))
        if info.get("status") == "downloaded":
            link = self._pick_link(info)
        elif self.cached_only:
            self._delete(tid)
            return None
        else:
            link = self._wait_and_pick(tid)
        if not link:
            self._delete(tid)
            return None
        final = self._api("POST", "/unrestrict/link", data={"link": link}).get("download")
        if self.auto_cleanup:
            self._delete(tid)
        return final

    def _wait_and_pick(self, tid, interval=3):
        dlg = xbmcgui.DialogProgress()
        dlg.create("Real-Debrid", "Preparando el torrent en la nube...")
        try:
            while True:
                info = self._api("GET", "/torrents/info/{0}".format(tid))
                status = info.get("status", "")
                if status == "downloaded":
                    return self._pick_link(info)
                if status in ("error", "magnet_error", "virus", "dead"):
                    return None
                pct = int(info.get("progress", 0) or 0)
                dlg.update(pct, "{0}\n{1}".format(info.get("filename", ""), status))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("Real-Debrid", "¿Mantener la descarga en segundo plano?"):
                        self._delete(tid)
                    return None
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    @staticmethod
    def _pick_link(info):
        """Mapea el mayor archivo de vídeo seleccionado a su link RD."""
        files = info.get("files", [])
        links = info.get("links", [])
        selected = [f for f in files if f.get("selected")]
        # 'links' va en paralelo a los archivos seleccionados, en orden
        best_idx, best_size = -1, -1
        for i, f in enumerate(selected):
            if _is_video_name(f.get("path", "")) and (f.get("bytes", 0) or 0) > best_size:
                best_size = f.get("bytes", 0) or 0
                best_idx = i
        if best_idx < 0:
            best_idx = 0
        if best_idx < len(links):
            return links[best_idx]
        return links[0] if links else None

    def _delete(self, tid):
        if tid is None:
            return
        try:
            self._api("DELETE", "/torrents/delete/{0}".format(tid))
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    def list_library(self):
        downloads = self._api("GET", "/downloads", params={"page": 1, "limit": 100})
        if not isinstance(downloads, list):
            return []
        items = []
        for d in downloads:
            items.append({
                "id": d.get("id"),
                "filename": d.get("filename", ""),
                "size": d.get("filesize", 0),
                "ready": True,
                "status": "",
                "_direct": d.get("download", ""),
            })
        return items

    def library_files(self, item_id):
        for d in self.list_library():
            if str(d.get("id")) == str(item_id):
                return [{"name": d.get("filename", ""), "size": d.get("size", 0), "link": d.get("_direct")}]
        return []

    def resolve_library_item(self, item_id):
        for d in self.list_library():
            if str(d.get("id")) == str(item_id):
                return d.get("_direct") or None
        return None

    def resolve_library_file(self, item_id, index):
        # En RD /downloads cada item es un único archivo ya directo.
        return self.resolve_library_item(item_id)

    def delete_library_item(self, item_id):
        try:
            self._api("DELETE", "/downloads/delete/{0}".format(item_id))
        except DebridError as e:
            _log("delete download {0}: {1}".format(item_id, e), xbmc.LOGWARNING)
        return True


# ===================== TorBox =====================

class TorBox(_DebridBase):
    name = "TorBox"
    PREFIX = "torbox"
    TOKEN_KEY = "torbox_token"
    BASE = "https://api.torbox.app/v1/api"
    UA = "AtresDaily"

    def _headers(self):
        h = {"User-Agent": self.UA, "Accept": "application/json"}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, path, data=None, params=None, json_body=None):
        payload = _http_json(method, self.BASE + path, self._headers(),
                             data=data, params=params, json_body=json_body)
        if isinstance(payload, dict) and payload.get("success") is False:
            err = payload.get("error") or ""
            detail = payload.get("detail", "")
            if err in ("BAD_TOKEN", "AUTH_ERROR", "OAUTH_VERIFICATION_ERROR"):
                raise DebridAuthError(detail or err)
            if err in ("ACTIVE_LIMIT", "MONTHLY_LIMIT", "DOWNLOAD_TOO_LARGE"):
                raise DebridNotPremium(detail or err)
            raise DebridError("{0} {1}".format(err, detail).strip())
        return payload.get("data") if isinstance(payload, dict) else payload

    def authorize_apikey(self, key):
        key = (key or "").strip()
        if not key:
            return False
        self.token = key
        try:
            data = self._api("GET", "/user/me")
        except DebridError as e:
            self.token = ""
            xbmcgui.Dialog().ok("TorBox", "API key no válida:\n{0}".format(e))
            return False
        self._save_auth(key, (data or {}).get("email", ""))
        self.warm_hosts()
        return True

    def authorize_pin(self):
        # TorBox: lo robusto es la API key manual (torbox.app/settings/api).
        xbmcgui.Dialog().ok(
            "TorBox",
            "Copia tu API key desde torbox.app (Settings > API) y usa\n"
            "'Introducir API Key manualmente'.")
        return False

    def account_info(self):
        data = self._api("GET", "/user/me") or {}
        exp = data.get("premium_expires_at", "") or ""
        return {
            "username": data.get("email", ""),
            "premium": bool(data.get("plan")) or bool(exp),
            "expiry_text": exp[:10],
            "days": _days_from_iso(exp),
            "extra": "",
        }

    def _fetch_hosts(self):
        try:
            result = self._api("GET", "/webdl/hosters")
        except DebridError:
            return []
        domains = []
        for h in result or []:
            if h.get("status", False):
                domains.extend(h.get("domains", []) or [])
        return domains

    def is_supported_hoster(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or "").replace("www.", "")
        except ValueError:
            return False
        if not host:
            return False
        return any(host in d or d in host for d in self._host_cache(self._fetch_hosts))

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_webdl(raw_url))
        return None

    def _resolve_magnet(self, magnet):
        _hash = _magnet_hash(magnet)
        if self.cached_only and _hash:
            cached = self._api("GET", "/torrents/checkcached",
                               params={"hash": _hash, "format": "list", "list_files": "false"})
            if not cached:
                return None
        created = self._api("POST", "/torrents/createtorrent",
                            data={"magnet": magnet, "seed": 3, "allow_zip": "false"})
        tid = (created or {}).get("torrent_id")
        if tid is None:
            return None
        if not self._wait_ready(tid, "torrents"):
            return None
        info = self._torrent_info(tid)
        files = [f for f in info.get("files", []) if _is_video_name(f.get("name", ""))]
        chosen = self._pick_video([{"name": f.get("name"), "size": f.get("size"), "id": f.get("id")} for f in files])
        if not chosen:
            return None
        link = self._api("GET", "/torrents/requestdl",
                         params={"token": self.token, "torrent_id": tid, "file_id": chosen.get("id")})
        if self.auto_cleanup:
            self._delete_torrent(tid)
        return link if isinstance(link, str) else None

    def _resolve_webdl(self, url):
        created = self._api("POST", "/webdl/createwebdownload", data={"link": url})
        wid = (created or {}).get("webdownload_id")
        if wid is None:
            return None
        if not self._wait_ready(wid, "webdl"):
            return None
        info = self._api("GET", "/webdl/mylist", params={"id": wid, "bypass_cache": "true"}) or {}
        files = info.get("files", []) if isinstance(info, dict) else []
        file_id = files[0].get("id") if files else 0
        link = self._api("GET", "/webdl/requestdl",
                         params={"token": self.token, "web_id": wid, "file_id": file_id})
        if self.auto_cleanup:
            self._api("POST", "/webdl/controlwebdownload", json_body={"webdl_id": wid, "operation": "delete"})
        return link if isinstance(link, str) else None

    def _torrent_info(self, tid):
        info = self._api("GET", "/torrents/mylist", params={"id": tid, "bypass_cache": "true"})
        if isinstance(info, list):
            return info[0] if info else {}
        return info or {}

    def _wait_ready(self, item_id, kind, interval=2):
        dlg = xbmcgui.DialogProgress()
        dlg.create("TorBox", "Preparando en la nube...")
        path = "/torrents/mylist" if kind == "torrents" else "/webdl/mylist"
        try:
            while True:
                info = self._api("GET", path, params={"id": item_id, "bypass_cache": "true"})
                if isinstance(info, list):
                    info = info[0] if info else {}
                info = info or {}
                if info.get("download_present"):
                    return True
                pct = int((info.get("progress", 0) or 0) * 100)
                dlg.update(pct, "{0}\n{1}".format(info.get("name", ""), info.get("download_state", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("TorBox", "¿Mantener la descarga en segundo plano?"):
                        if kind == "torrents":
                            self._delete_torrent(item_id)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _delete_torrent(self, tid):
        try:
            self._api("POST", "/torrents/controltorrent", json_body={"torrent_id": tid, "operation": "delete"})
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    def list_library(self):
        info = self._api("GET", "/torrents/mylist", params={"bypass_cache": "true"})
        torrents = info if isinstance(info, list) else (info.get("torrents", []) if isinstance(info, dict) else [])
        items = []
        for t in torrents or []:
            items.append({
                "id": t.get("id"),
                "filename": t.get("name", ""),
                "size": t.get("size", 0),
                "ready": bool(t.get("download_present")),
                "status": t.get("download_state", ""),
                "date": t.get("created_at", "") or "",
            })
        return items

    def library_files(self, item_id):
        info = self._torrent_info(item_id)
        out = []
        for f in info.get("files", []):
            if _is_video_name(f.get("name", "")):
                out.append({"name": f.get("name"), "size": f.get("size", 0), "id": f.get("id")})
        return out

    def _requestdl(self, item_id, file_id):
        link = self._api("GET", "/torrents/requestdl",
                         params={"token": self.token, "torrent_id": item_id, "file_id": file_id})
        return link if isinstance(link, str) else None

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        return self._requestdl(item_id, chosen.get("id")) if chosen else None

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        if 0 <= index < len(files):
            return self._requestdl(item_id, files[index].get("id"))
        return None

    def delete_library_item(self, item_id):
        self._delete_torrent(item_id)
        return True


# ===================== Premiumize =====================

class Premiumize(_DebridBase):
    name = "Premiumize"
    PREFIX = "premiumize"
    TOKEN_KEY = "premiumize_token"
    SUPPORTS_PIN = False  # solo API key del usuario (sin client_id de terceros)
    BASE = "https://www.premiumize.me/api"
    UA = "AtresDaily"

    def _headers(self):
        h = {"User-Agent": self.UA, "Accept": "application/json"}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, path, data=None, params=None):
        payload = _http_json(method, self.BASE + path, self._headers(), data=data, params=params)
        if isinstance(payload, dict) and payload.get("status") == "error":
            msg = payload.get("message", "error")
            if "not logged in" in msg.lower() or "token" in msg.lower():
                raise DebridAuthError(msg)
            raise DebridError(msg)
        return payload

    def authorize_pin(self):
        # Premiumize se autentica con la API key del panel del usuario (sin OAuth
        # de terceros). El device flow requeriría un client_id propio registrado.
        xbmcgui.Dialog().ok(
            "Premiumize",
            "Copia tu API key desde premiumize.me/account (Apikey) y usa\n"
            "'Introducir API Key manualmente'.")
        return False

    def authorize_apikey(self, key):
        return self._finish_token((key or "").strip())

    def _finish_token(self, token):
        if not token:
            return False
        self.token = token
        try:
            acc = self._api("GET", "/account/info")
        except DebridError as e:
            self.token = ""
            xbmcgui.Dialog().ok("Premiumize", "Token no válido:\n{0}".format(e))
            return False
        self._save_auth(token, acc.get("customer_id", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        acc = self._api("GET", "/account/info")
        limit = acc.get("limit_used")
        extra = "Uso fair-use: {0:.0f}%".format(float(limit) * 100) if isinstance(limit, (int, float)) else ""
        return {
            "username": str(acc.get("customer_id", "")),
            "premium": bool(acc.get("premium_until")),
            "expiry_text": _fmt_ts(acc.get("premium_until")),
            "days": _days_from_ts(acc.get("premium_until")),
            "extra": extra,
        }

    def _fetch_hosts(self):
        result = self._api("GET", "/services/list")
        patterns = []
        for regexes in (result.get("regexpatterns", {}) or {}).values():
            for rx in regexes:
                patterns.append(rx)
        return patterns

    def is_supported_hoster(self, url):
        if not url.endswith("/"):
            url += "/"
        for pat in self._host_cache(self._fetch_hosts):
            try:
                if re.search(pat, url, re.I):
                    return True
            except re.error:
                continue
        return False

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:") or low.endswith(".torrent"):
            return self._resolve_guard(lambda: self._resolve_src(raw_url, torrent=True))
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_src(raw_url, torrent=False))
        return None

    def _check_cache(self, media_id):
        try:
            res = self._api("GET", "/cache/check", params={"items[]": media_id})
        except DebridError:
            return False
        resp = res.get("response")
        return bool(resp[0]) if isinstance(resp, list) and resp else False

    def _resolve_src(self, media_id, torrent):
        # El cache check solo aplica a torrents; un hoster va directo a directdl.
        if torrent and not self._check_cache(media_id):
            if self.cached_only:
                return None
            if not self._wait_transfer(media_id):
                return None
        res = self._api("POST", "/transfer/directdl", data={"src": media_id})
        if res.get("status") != "success":
            return None
        if not torrent:
            return res.get("location")
        videos = [{"name": (c.get("path") or "").split("/")[-1], "size": _safe_int(c.get("size")), "link": c.get("link")}
                  for c in res.get("content", []) if _is_video_name(c.get("path", ""))]
        chosen = self._pick_video(videos)
        return chosen.get("link") if chosen else None

    def _wait_transfer(self, media_id, interval=5):
        create = self._api("POST", "/transfer/create", data={"src": media_id})
        if create.get("status") != "success":
            return False
        tid = create.get("id")
        dlg = xbmcgui.DialogProgress()
        dlg.create("Premiumize", "Transfiriendo a la nube...")
        try:
            while True:
                info = self._transfer(tid)
                status = info.get("status", "")
                if status == "seeding" or status == "finished":
                    xbmc.sleep(2000)
                    return True
                if status in ("error", "stalled", "deleted", "banned"):
                    self._delete(tid)
                    return False
                pct = int(float(info.get("progress", 0) or 0) * 100)
                dlg.update(pct, "{0}\n{1}".format(info.get("name", ""), info.get("message", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("Premiumize", "¿Mantener la transferencia en segundo plano?"):
                        self._delete(tid)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _transfer(self, tid):
        lst = self._api("GET", "/transfer/list")
        for t in lst.get("transfers", []) or []:
            if t.get("id") == tid:
                return t
        return {}

    def _delete(self, tid):
        if not tid:
            return
        try:
            self._api("POST", "/transfer/delete", data={"id": tid})
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    def list_library(self):
        lst = self._api("GET", "/transfer/list")
        items = []
        for t in lst.get("transfers", []) or []:
            items.append({
                "id": t.get("id"),
                "filename": t.get("name", ""),
                "size": 0,
                "ready": t.get("status") in ("seeding", "finished"),
                "status": t.get("status", ""),
                "_src": t.get("src", ""),
            })
        return items

    def _src_of(self, item_id):
        for t in self.list_library():
            if t.get("id") == item_id:
                return t.get("_src")
        return None

    def library_files(self, item_id):
        src = self._src_of(item_id)
        if not src:
            return []
        res = self._api("POST", "/transfer/directdl", data={"src": src})
        if res.get("status") != "success":
            return []
        out = []
        for c in res.get("content", []):
            if _is_video_name(c.get("path", "")):
                out.append({"name": (c.get("path") or "").split("/")[-1],
                            "size": _safe_int(c.get("size")), "link": c.get("link")})
        return out

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        return chosen.get("link") if chosen else None

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        return files[index].get("link") if 0 <= index < len(files) else None

    def delete_library_item(self, item_id):
        self._delete(item_id)
        return True


# ===================== utilidades comunes =====================

def _safe_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _pin_poll(title, url, code, expires_in, check_fn, interval=5):
    """Diálogo de progreso con cuenta atrás mientras se sondea la activación.
    check_fn() devuelve un valor verdadero (token o True) al activarse, None si no."""
    dlg = xbmcgui.DialogProgress()
    dlg.create(title, "Abre [B]{0}[/B]\ne introduce el código: [B]{1}[/B]".format(url, code))
    start = time.time()
    try:
        while time.time() - start < expires_in:
            if dlg.iscanceled():
                return None
            xbmc.sleep(interval * 1000)
            if dlg.iscanceled():
                return None
            try:
                result = check_fn()
            except DebridError:
                continue
            if result:
                return result
            pct = int((time.time() - start) / expires_in * 100)
            dlg.update(pct, "Esperando activación...\nCódigo: [B]{0}[/B]".format(code))
    finally:
        dlg.close()
    return None


_PROVIDERS = {
    "AllDebrid": AllDebrid,
    "Real-Debrid": RealDebrid,
    "TorBox": TorBox,
    "Premiumize": Premiumize,
}
_instance = None


def get_resolver():
    """Devuelve la instancia del proveedor configurado (cacheada por proceso)."""
    global _instance
    if _instance is None:
        provider = _addon().getSetting("debrid_provider") or "AllDebrid"
        cls = _PROVIDERS.get(provider, AllDebrid)
        _instance = cls()
    return _instance


def reset_resolver():
    """Fuerza recrear la instancia tras cambiar ajustes/credenciales."""
    global _instance
    _instance = None
