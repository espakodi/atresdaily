# AtresDaily, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.
"""Gestor de almacenamiento. Audita y limpia las cachés del addon.

Muestra cuánto ocupa cada caché y permite borrarlas desde un diálogo. Los
datos del usuario (favoritos, historial, ajustes, sesión de Trakt) NUNCA se
tocan. Solo se borra lo que se puede regenerar. Doble seguro, las cachés se
borran por whitelist (_CACHES) y, además, _delete_path se niega a borrar
cualquier archivo de _PROTECTED.
"""
import os
import re
import shutil

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_LOG     = "[AtresDaily-STORAGE]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_META_DB = "atresdaily_metadata.db"

# Registro de cachés borrables.
# Cada entrada: (clave, etiqueta, [archivos], [carpetas], [regex]).
# La metadata (atresdaily_metadata.db) va aparte; regenerarla cuesta cientos de
# llamadas a TMDB, así que tiene su propia opción y no entra en 'Borrar todas'.
_CACHES = [
    ("epg",          "Programación TV (EPG)",                     ["epg_texto_cache.json"], [], []),
    ("cine",         "Metadatos de cine (Cinemeta/FA/SC/TMDb)",
                     ["atresdaily_cinemeta_cache.json", "atresdaily_fa_cache.json",
                      "atresdaily_sc_cache.json", "atresdaily_tmdb_lists_cache.json"], [], []),
    ("trakt_thumbs", "Trakt — miniaturas",                        ["top_movies_thumbs.json"], [],
                     [r"^trakt_thumbs_\d+\.json$"]),
    ("catalogo",     "Catálogo navegable",                        [], [], [r"^cat_cache_.*\.json$"]),
    ("imagenes",     "Imágenes (pósters/fanart)",                 [], ["imgcache"], []),
    ("logos",        "Logos de canales TV",                       [], ["logos"], []),
    ("connector",    "Caché interna del conector",                ["connector_cache.json"], [], []),
]

# Datos del usuario protegidos contra borrado (segundo cerrojo de _delete_path).
_PROTECTED = {
    "favorites.json", "watch_history.json", "downloads_history.json", "history.json",
    "url_history.json", "url_bookmarks.json", "acestream_history.json",
    "exploration_history.json", "search_shortcuts.json", "custom_iptv_lists.json",
    "bt_config.json", "trakt_settings.json",
    "settings.json", "settings.xml",
    "telemetry.json", "stats.json", "egg_count.txt",
    "integration_first_use.json", "messages_state.json", "welcome_state.json",
    "debug_state.json", "frozen_state.json", "recent_state.json",
    "advanced_search_state.json", "priority_state.json", "min_duration.json",
    "snapshot_context.json", "full_context.json",
    _META_DB,
}


def _path(name):
    return os.path.join(_PROFILE, name)


def _list_profile():
    try:
        return os.listdir(_PROFILE)
    except OSError:
        return []


def _size_of(path):
    if not os.path.exists(path):
        return 0
    if os.path.isdir(path):
        total = 0
        for root, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def fmt_size(b):
    if b < 1024:
        return f"{b} B"
    if b < 1024 * 1024:
        return f"{b / 1024:.1f} KB"
    return f"{b / 1024 / 1024:.2f} MB"


def _delete_path(path):
    """Borra un archivo o carpeta. Devuelve los bytes liberados (0 si falló o protegido)."""
    name = os.path.basename(path)
    if name in _PROTECTED:
        xbmc.log(f"{_LOG} BLOQUEADO borrado de archivo protegido: {name}", xbmc.LOGWARNING)
        return 0
    sz = _size_of(path)
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            return sz if not os.path.exists(path) else 0
        if os.path.exists(path):
            os.remove(path)
            return sz
    except OSError as e:
        xbmc.log(f"{_LOG} Error borrando {path}: {e}", xbmc.LOGWARNING)
    return 0


def _resolver_paths(files, dirs, regex_list, profile_entries):
    """Rutas existentes de una entrada de caché (archivos fijos, carpetas y patrones)."""
    rutas = []
    for f in files:
        if os.path.exists(_path(f)):
            rutas.append(_path(f))
    for d in dirs:
        if os.path.exists(_path(d)):
            rutas.append(_path(d))
    if regex_list:
        compiled = [re.compile(rx) for rx in regex_list]
        for entry in profile_entries:
            if any(c.match(entry) for c in compiled):
                rutas.append(_path(entry))
    return rutas


def auditar_cache():
    """[(key, label, bytes, rutas), ...] solo de las cachés con bytes > 0."""
    entries = _list_profile()
    out = []
    for key, label, files, dirs, regex_list in _CACHES:
        rutas = _resolver_paths(files, dirs, regex_list, entries)
        total = sum(_size_of(p) for p in rutas)
        if total > 0:
            out.append((key, label, total, rutas))
    return out


def _borrar_categoria(key):
    """Borra una categoría tras confirmación. Devuelve bytes liberados."""
    entry = next((c for c in _CACHES if c[0] == key), None)
    if entry is None:
        return 0
    _key, label, files, dirs, regex_list = entry
    rutas = _resolver_paths(files, dirs, regex_list, _list_profile())
    total = sum(_size_of(p) for p in rutas)
    if total == 0:
        return 0
    if not xbmcgui.Dialog().yesno(
        "Borrar caché",
        f"{label}\n\nSe liberarán [B]{fmt_size(total)}[/B].\n\n"
        "Se volverá a descargar la próxima vez que abras esa sección.",
    ):
        return 0
    liberado = sum(_delete_path(p) for p in rutas)
    xbmcgui.Dialog().notification("AtresDaily", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    return liberado


def _borrar_todas(total):
    """Borra todas las cachés conocidas (no la metadata) tras confirmación."""
    if total == 0:
        return
    if not xbmcgui.Dialog().yesno(
        "Borrar TODAS las cachés",
        f"Se borrarán todas las cachés del addon ([B]{fmt_size(total)}[/B]).\n\n"
        "[COLOR lightgreen]Tus favoritos, historial, ajustes y sesión de Trakt NO se tocan.[/COLOR]\n\n"
        "¿Continuar?",
    ):
        return
    entries = _list_profile()
    liberado = 0
    for _key, _label, files, dirs, regex_list in _CACHES:
        for p in _resolver_paths(files, dirs, regex_list, entries):
            liberado += _delete_path(p)
    xbmcgui.Dialog().notification("AtresDaily", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3500)


def _vaciar_metadata(antes):
    """Vacía la biblioteca de metadatos (atresdaily_metadata.db) y compacta el archivo."""
    if antes == 0:
        return
    if not xbmcgui.Dialog().yesno(
        "Vaciar biblioteca de metadatos",
        f"Se vaciarán los metadatos de TMDB cacheados ([B]{fmt_size(antes)}[/B]).\n\n"
        "[COLOR orange]Se reconstruyen solos con el uso, pero la primera vez que abras "
        "cada lista irá algo más lento ese rato.[/COLOR]\n\n¿Continuar?",
    ):
        return
    # clear_all() vacía la tabla; prune_and_vacuum() hace el VACUUM que encoge el
    # archivo en disco (segundos en una DB de varios MB); barra de fondo para que
    # no parezca un cuelgue en dispositivos lentos.
    import metadata_enricher
    path = _path(_META_DB)
    prog = xbmcgui.DialogProgressBG()
    prog.create("AtresDaily", "Vaciando biblioteca de metadatos...")
    try:
        metadata_enricher.clear_all()
        metadata_enricher.prune_and_vacuum()
    finally:
        prog.close()
    liberado = max(0, antes - _size_of(path))
    xbmcgui.Dialog().notification("AtresDaily", f"Liberados {fmt_size(liberado)}",
                                  xbmcgui.NOTIFICATION_INFO, 3000)


def _mostrar_info():
    sep = "─" * 40
    texto = "\n".join([
        "GESTIÓN DE CACHÉS DEL ADDON",
        sep,
        "",
        "El addon guarda dos cosas en tu dispositivo:",
        "",
        "  1) CACHÉS: datos descargados de internet que se",
        "     pueden volver a bajar (EPG, imágenes, metadatos",
        "     de cine, miniaturas, logos…).",
        "",
        "  2) DATOS DEL USUARIO: favoritos, historial, ajustes,",
        "     sesión de Trakt. Solo existen aquí.",
        "",
        sep,
        "QUÉ SE BORRA DESDE AQUÍ",
        sep,
        "",
        "Solo las cachés del grupo (1). Al volver a abrir la",
        "sección correspondiente, los datos se descargan otra",
        "vez. No pierdes nada.",
        "",
        sep,
        "QUÉ NO SE TOCA NUNCA",
        sep,
        "",
        "  • Favoritos e historial de reproducción",
        "  • Ajustes del addon",
        "  • Sesión y listas de Trakt",
        "  • Listas IPTV personalizadas",
        "  • Búsquedas y atajos guardados",
        "",
        "La biblioteca de metadatos (TMDB) tiene su propia",
        "opción aparte porque rehidratarla es costoso.",
    ])
    xbmcgui.Dialog().textviewer("Gestión de cachés — ayuda", texto)


def storage_menu():
    """Diálogo en bucle que lista cada caché con su tamaño y permite borrarlas."""
    while True:
        cache = sorted(auditar_cache(), key=lambda x: -x[2])
        meta_size = _size_of(_path(_META_DB))
        total = sum(b for _k, _l, b, _r in cache)

        opciones, acciones = [], []
        if total > 0:
            opciones.append(f"[COLOR red]Borrar TODAS las cachés ({fmt_size(total)})[/COLOR]")
            acciones.append(("all", None))
        for key, label, b, _rutas in cache:
            opciones.append(f"{label}    [COLOR grey]{fmt_size(b)}[/COLOR]")
            acciones.append(("cat", key))
        if meta_size > 0:
            opciones.append(f"[COLOR orange]Vaciar biblioteca de metadatos ({fmt_size(meta_size)})[/COLOR]")
            acciones.append(("meta", None))
        opciones.append("[COLOR grey]¿Qué se borra y qué no?[/COLOR]")
        acciones.append(("info", None))

        if cache or meta_size:
            heading = f"Almacenamiento — {fmt_size(total)} en cachés"
        else:
            heading = "Almacenamiento — nada que borrar"

        idx = xbmcgui.Dialog().select(heading, opciones)
        if idx < 0:
            break
        tipo, key = acciones[idx]
        if tipo == "all":
            _borrar_todas(total)
        elif tipo == "cat":
            _borrar_categoria(key)
        elif tipo == "meta":
            _vaciar_metadata(meta_size)
        elif tipo == "info":
            _mostrar_info()
