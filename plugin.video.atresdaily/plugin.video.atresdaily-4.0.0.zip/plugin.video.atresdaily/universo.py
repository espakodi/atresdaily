# AtresDaily — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/fullstackcurso)
# Licencia: Consulta el archivo LICENSE para mas detalles.

"""
Universo EspaKodi
Ventana informativa con enlaces a los proyectos relacionados,
canales de Telegram y contacto.
"""
import math
import os
import threading
import xbmc
import xbmcgui
import xbmcaddon

_ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
_MEDIA = os.path.join(_ADDON_PATH, "resources", "media")
_TEX = os.path.join(_MEDIA, "white.png")
_TRANSP = os.path.join(_MEDIA, "transparent.png")
_FOCUS = os.path.join(_MEDIA, "focus.png")

W, H = 1280, 720
PW, PH = 600, 520
PX, PY = (W - PW) // 2, (H - PH) // 2

_BREATH_LO = (0x1F, 0x70, 0xE0)
_BREATH_HI = (0xA0, 0xE0, 0xFF)
_BREATH_FRAMES = 40
_BREATH_INTERVAL = 0.1


class UniversoDialog(xbmcgui.WindowDialog):
    """Diálogo con enlaces al ecosistema EspaKodi."""

    def __init__(self):
        super().__init__()
        self.url_map = {}
        self.all_buttons = []
        self.close_btn_id = -1
        self.title_btn_id = -1
        self.signature_requested = False
        self.all_controls = []
        self._breath_stop = threading.Event()
        self._breath_thread = None
        self._breath_colors = self._precompute_breath()
        self._build()

    def _mk_img(self, x, y, w, h, color, img=None):
        c = xbmcgui.ControlImage(x, y, w, h, img or _TEX, colorDiffuse=color)
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _mk_lbl(self, x, y, w, h, text, font="font13", color="FFFFFFFF", align=0):
        c = xbmcgui.ControlLabel(
            x, y, w, h, text, font=font, textColor=color, alignment=align
        )
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _mk_btn(self, x, y, w, h, text, tc="FFFFFFFF", fc="FFFFFFFF", align=0x04):
        c = xbmcgui.ControlButton(
            x, y, w, h, text,
            font="font12", textColor=tc, focusedColor=fc, alignment=align,
            noFocusTexture=_TRANSP, focusTexture=_FOCUS,
        )
        self._pending.append(c)
        self.all_controls.append(c)
        return c

    def _build(self):
        self._pending = []

        # Panel central semi-transparente
        self._mk_img(PX, PY, PW, PH, "D0111922")

        self._mk_img(PX, PY, PW, 3, "FF3090FF")

        y = PY + 17
        title_btn = xbmcgui.ControlButton(
            PX, y, PW, 25,
            '[B]Universo EspaKodi[/B]',
            font='font13', textColor='FF3090FF', focusedColor='FFFFFFFF',
            alignment=0x02 | 0x04,
            noFocusTexture=_TRANSP, focusTexture=_FOCUS,
        )
        self._pending.append(title_btn)
        self.all_controls.append(title_btn)
        self._title_btn = title_btn
        self.all_buttons.append(title_btn)
        y += 39
        self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
        y += 16

        links = [
            ("FFFFD700", "Contacto", "https://t.me/rubensdfa1laberot/?direct"),
            (None, None, None),
            ("FF2AABEE", "Canal de Telegram", "https://t.me/espadaily"),
            ("FF2AABEE", "Chat EspaKodi", "https://t.me/espakodi"),
            (None, None, None),
            ("FFA0522D", "Web", "https://espatv.github.io"),
            ("FF43A047", "Web loioloio", "https://loiolo.io"),
        ]

        self._link_buttons = []
        for color, label, url in links:
            if color is None:
                y += 6
                self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
                y += 10
                continue

            self._mk_lbl(
                PX + 50, y, PW - 100, 24,
                f"[B]{label}[/B]",
                font="font13", color=color, align=0x04
            )
            btn = xbmcgui.ControlButton(
                PX + 35, y, PW - 70, 24,
                "[B]" + (url or "").replace("https://", "") + "[/B]  ",
                font="font13", textColor="FFCCCCCC", focusedColor="FFFFFFFF",
                alignment=0x01 | 0x04,
                noFocusTexture=_TRANSP, focusTexture=_FOCUS,
            )
            self._pending.append(btn)
            self.all_controls.append(btn)
            self._link_buttons.append((btn, url))
            self.all_buttons.append(btn)
            y += 28

        y += 6
        self._mk_img(PX + 35, y, PW - 70, 1, "15FFFFFF")
        y += 15

        close = self._mk_btn(
            PX + (PW - 180) // 2, y, 180, 32,
            "[B]Cerrar[/B]", tc="FF888888", align=0x02 | 0x04,
        )
        self.all_buttons.append(close)

        self.addControls(self._pending)

        self.close_btn_id = close.getId()
        self.title_btn_id = self._title_btn.getId()
        for btn, url in self._link_buttons:
            self.url_map[btn.getId()] = url

        # Navegación circular entre botones
        for i in range(len(self.all_buttons)):
            b = self.all_buttons[i]
            if i > 0:
                b.controlUp(self.all_buttons[i - 1])
            if i < len(self.all_buttons) - 1:
                b.controlDown(self.all_buttons[i + 1])
        self.all_buttons[0].controlUp(self.all_buttons[-1])
        self.all_buttons[-1].controlDown(self.all_buttons[0])
        self.setFocus(self._title_btn)

        self._start_breath()

    def _precompute_breath(self):
        lo, hi = _BREATH_LO, _BREATH_HI
        colors = []
        for i in range(_BREATH_FRAMES):
            t = (math.sin(2 * math.pi * i / _BREATH_FRAMES - math.pi / 2) + 1) / 2
            r = int(lo[0] + (hi[0] - lo[0]) * t)
            g = int(lo[1] + (hi[1] - lo[1]) * t)
            b = int(lo[2] + (hi[2] - lo[2]) * t)
            colors.append(f'[COLOR FF{r:02X}{g:02X}{b:02X}][B]Universo EspaKodi[/B][/COLOR]')
        return colors

    def _breath_loop(self):
        i = 0
        n = len(self._breath_colors)
        while not self._breath_stop.is_set():
            try:
                self._title_btn.setLabel(self._breath_colors[i])
            except RuntimeError as e:
                xbmc.log(f'[atresdaily] universo breath: control invalidado: {e}', xbmc.LOGDEBUG)
                return
            i = (i + 1) % n
            if self._breath_stop.wait(_BREATH_INTERVAL):
                return

    def _start_breath(self):
        self._breath_thread = threading.Thread(target=self._breath_loop, daemon=True)
        self._breath_thread.start()

    def close(self):
        self._breath_stop.set()
        super().close()

    def _handle_click(self, control_id):
        if control_id == self.close_btn_id:
            self.close()
            return
        if control_id == self.title_btn_id:
            self.signature_requested = True
            self.close()
            return
        url = self.url_map.get(control_id)
        if url:
            try:
                if xbmc.getCondVisibility("System.Platform.Android"):
                    xbmc.executebuiltin(
                        f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")'
                    )
                else:
                    import webbrowser
                    webbrowser.open(url)
                xbmcgui.Dialog().notification(
                    "AtresDaily", "Abriendo enlace...",
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
            except Exception:
                xbmcgui.Dialog().ok(
                    "Enlace AtresDaily",
                    "No se pudo abrir automáticamente. Abre esta URL:\n\n" + url,
                )

    def onAction(self, action):
        aid = action.getId()
        if aid in (10, 92, 110):
            self.close()
        elif aid in (7, 100, 101):
            self._handle_click(self.getFocusId())

    def onClick(self, controlId):
        self._handle_click(controlId)


def show():
    """Muestra el diálogo Universo EspaKodi."""
    bg = None
    try:
        import ascii_matrix
        bg = ascii_matrix.get_bg_dialog()
        if bg:
            bg.show()
    except Exception as e:
        xbmc.log(f'[atresdaily] universo: ascii_matrix no disponible: {e}', xbmc.LOGDEBUG)

    dlg = UniversoDialog()
    dlg.doModal()
    signature_requested = getattr(dlg, 'signature_requested', False)
    del dlg

    if bg:
        try:
            bg.close()
        except Exception as e:
            xbmc.log(f'[atresdaily] universo: bg.close falló: {e}', xbmc.LOGDEBUG)

    if signature_requested:
        try:
            import ascii_signature
            ascii_signature.show_signature()
        except Exception as e:
            xbmc.log(f'[atresdaily] universo: ascii_signature error: {e}', xbmc.LOGERROR)
