import { API } from '../api.js';
import { Icons } from '../icons.js';
import { makeRow } from './row.js';
import { makeSkeleton } from './grid.js';
import { toast } from './toast.js';

let _heroItems = [];
let _heroIdx = 0;
let _heroTimer = null;

export async function renderHome(container, { onPlay, onNavigate, favSet }) {
  // Limpiar timer del hero anterior si lo hay
  if (_heroTimer) { clearInterval(_heroTimer); _heroTimer = null; }

  container.innerHTML = '';

  // Hero skeleton
  const heroEl = document.createElement('section');
  heroEl.className = 'hero';
  heroEl.innerHTML = `<div class="hero-bg skeleton-box" style="position:absolute;inset:0"></div>`;
  container.appendChild(heroEl);

  // Filas skeleton
  const rowsEl = document.createElement('section');
  rowsEl.className = 'rows-container';
  for (let i = 0; i < 3; i++) {
    const sec = document.createElement('div');
    sec.className = 'row-section';
    sec.innerHTML = `
      <div class="row-header">
        <span class="skeleton-box" style="height:16px;width:180px;border-radius:4px;display:inline-block"></span>
      </div>
      <div class="row-scroll" style="overflow:hidden"></div>
    `;
    const scroll = sec.querySelector('.row-scroll');
    makeSkeleton(6).forEach(c => scroll.appendChild(c));
    rowsEl.appendChild(sec);
  }
  container.appendChild(rowsEl);

  let data;
  try {
    data = await API.home();
  } catch (e) {
    // 'Failed to fetch' = el servidor de la webapp en Kodi no está corriendo.
    // El SW puede haber servido el shell desde caché aunque el backend esté caído.
    const isNetworkErr = /failed to fetch|networkerror|load failed/i.test(e.message || '');
    if (isNetworkErr) {
      heroEl.remove();
      rowsEl.innerHTML = `
        <div class="empty-state" style="padding:80px 20px;line-height:1.7">
          <div style="font-size:1.3rem;color:var(--text);margin-bottom:12px;font-weight:600">
            El servidor de AtresDaily no está disponible
          </div>
          <div>Vuelve a Kodi y pulsa <b>AtresDaily WebApp</b> en el menú principal para iniciarlo.<br>
          Después recarga esta página (Ctrl+R).</div>
          <button class="btn btn-primary" style="margin-top:24px" onclick="location.reload()">
            Reintentar
          </button>
        </div>`;
    } else {
      toast(`Error cargando inicio: ${e.message}`, 'error');
      rowsEl.innerHTML = `<div class="empty-state">No se pudo cargar el contenido.</div>`;
    }
    return;
  }

  // Construir el hero
  const heroPool = [];
  if (data.hero) heroPool.push(data.hero);
  for (const row of (data.rows || [])) {
    for (const it of (row.items || [])) {
      if (it.thumb && it.type === 'video' && !heroPool.some(h => h.id === it.id)) {
        heroPool.push(it);
        if (heroPool.length >= 6) break;
      }
    }
    if (heroPool.length >= 6) break;
  }
  _heroItems = heroPool.slice(0, 5);

  if (_heroItems.length) {
    buildHero(heroEl, onPlay, favSet);
  } else {
    heroEl.remove();
  }

  // Construir las filas
  rowsEl.innerHTML = '';
  if (!data.rows?.length) {
    rowsEl.innerHTML = `<div class="empty-state">No hay contenido para mostrar todavía.</div>`;
    return;
  }
  for (const row of data.rows) {
    if (!row.items?.length) continue;
    rowsEl.appendChild(makeRow(row, onPlay, onNavigate, favSet));
  }
}

function buildHero(heroEl, onPlay, favSet) {
  heroEl.innerHTML = `
    <div class="hero-bg" id="hero-bg"></div>
    <div class="hero-gradient"></div>
    <div class="hero-content" id="hero-content"></div>
    <div class="hero-dots" id="hero-dots"></div>
  `;

  const bg = heroEl.querySelector('#hero-bg');
  const content = heroEl.querySelector('#hero-content');
  const dotsEl = heroEl.querySelector('#hero-dots');

  const dots = _heroItems.map((_, i) => {
    const d = document.createElement('button');
    d.className = `hero-dot${i === 0 ? ' active' : ''}`;
    d.setAttribute('aria-label', `Slide ${i + 1}`);
    d.addEventListener('click', () => { showHero(i); resetTimer(); });
    dotsEl.appendChild(d);
    return d;
  });

  function showHero(idx) {
    _heroIdx = idx;
    dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    const item = _heroItems[idx];

    // Fade transition con background
    bg.style.opacity = '0';
    setTimeout(() => {
      bg.style.backgroundImage = `url('${item.thumb}')`;
      bg.style.opacity = '1';
    }, 200);

    const label = item.is_live ? 'EN DIRECTO' : (item.play?.kind === 'episode' ? 'ATRESPLAYER' : 'DESTACADO');

    content.innerHTML = `
      <div class="hero-label">${label}</div>
      <h2 class="hero-title">${escHtml(item.title)}</h2>
      ${item.plot ? `<p class="hero-plot">${escHtml(item.plot)}</p>` : ''}
      <div class="hero-actions">
        <button class="btn btn-primary hero-play">${Icons.play} Reproducir</button>
      </div>
    `;
    content.querySelector('.hero-play').addEventListener('click', () => onPlay(item));
  }

  showHero(0);

  function resetTimer() {
    if (_heroTimer) clearInterval(_heroTimer);
    if (_heroItems.length > 1) {
      _heroTimer = setInterval(() => showHero((_heroIdx + 1) % _heroItems.length), 9000);
    }
  }
  resetTimer();
}

function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
